/*
 * \brief  Contacts session interface
 * \author Ivan Loskutov
 * \date   2026-10-01
 *
 * Request interface of the contacts service. What a client may do is
 * decided by the policy the service's config holds for the client's
 * label: every client with a policy may look up the name that belongs
 * to a number it already has, a client with 'read: yes' may list the
 * contacts (a contact picker), a client with 'manage: yes' may list and
 * change them. Without a policy there is no session.
 */

/*
 * SPDX-License-Identifier: MIT
 */

#ifndef _INCLUDE__CONTACTS_SESSION__CONTACTS_SESSION_H_
#define _INCLUDE__CONTACTS_SESSION__CONTACTS_SESSION_H_

#include <session/session.h>
#include <base/rpc.h>
#include <base/signal.h>
#include <contacts_session/types.h>

namespace Contacts { struct Session; }


struct Contacts::Session : Genode::Session
{
	/**
	 * \noapi
	 */
	static const char *service_name() { return "Contacts"; }

	/*
	 * A contacts session consumes a dataspace capability for the server's
	 * session-object allocation and the session capability.
	 */
	static constexpr unsigned CAP_QUOTA = 2;

	static constexpr Genode::size_t RAM_QUOTA = 8*1024;

	/*
	 * 'Label' alone would be 'Genode::Session::Label' in here
	 */
	using Number_label = Contacts::Label;


	/******************
	 ** Lookup right **
	 ******************/

	/**
	 * Find the contact a number belongs to
	 *
	 * The number may have any form (international, with '00', national,
	 * with spaces). Of several matching contacts the first in name
	 * order is returned.
	 */
	virtual Lookup lookup(Number const &) = 0;

	/**
	 * Install handler of the signal sent when the contacts changed
	 */
	virtual void sigh(Genode::Signal_context_capability) = 0;

	/**
	 * Number that increases with every change of the contacts
	 */
	virtual unsigned generation() = 0;


	/******************
	 ** Manage right **
	 ******************/

	/*
	 * Without the manage right, the following calls return 'DENIED',
	 * a count of 0 or an invalid result, and change nothing. 'count',
	 * 'contact', and 'number' need the read right only.
	 */

	virtual unsigned count() = 0;

	/**
	 * Contact at 'index' of the list sorted by name
	 */
	virtual Contact contact(unsigned index) = 0;

	/**
	 * Number at 'index' of a contact
	 */
	virtual Phone number(Id, unsigned index) = 0;

	virtual Added  add(Name const &) = 0;
	virtual Result rename(Id, Name const &) = 0;
	virtual Result remove(Id) = 0;
	virtual Result add_number(Id, Number_label const &, Number const &) = 0;
	virtual Result remove_number(Id, unsigned index) = 0;


	/*******************
	 ** RPC interface **
	 *******************/

	GENODE_RPC(Rpc_lookup,        Lookup,   lookup, Number const &);
	GENODE_RPC(Rpc_sigh,          void,     sigh, Genode::Signal_context_capability);
	GENODE_RPC(Rpc_generation,    unsigned, generation);
	GENODE_RPC(Rpc_count,         unsigned, count);
	GENODE_RPC(Rpc_contact,       Contact,  contact, unsigned);
	GENODE_RPC(Rpc_number,        Phone,    number, Id, unsigned);
	GENODE_RPC(Rpc_add,           Added,    add, Name const &);
	GENODE_RPC(Rpc_rename,        Result,   rename, Id, Name const &);
	GENODE_RPC(Rpc_remove,        Result,   remove, Id);
	GENODE_RPC(Rpc_add_number,    Result,   add_number, Id, Number_label const &,
	                                        Number const &);
	GENODE_RPC(Rpc_remove_number, Result,   remove_number, Id, unsigned);

	GENODE_RPC_INTERFACE(Rpc_lookup, Rpc_sigh, Rpc_generation, Rpc_count,
	                     Rpc_contact, Rpc_number, Rpc_add, Rpc_rename,
	                     Rpc_remove, Rpc_add_number, Rpc_remove_number);
};

#endif /* _INCLUDE__CONTACTS_SESSION__CONTACTS_SESSION_H_ */
