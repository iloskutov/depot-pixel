/*
 * \brief  Client-side contacts session interface
 * \author Ivan Loskutov
 * \date   2026-10-01
 */

/*
 * SPDX-License-Identifier: MIT
 */

#ifndef _INCLUDE__CONTACTS_SESSION__CLIENT_H_
#define _INCLUDE__CONTACTS_SESSION__CLIENT_H_

#include <contacts_session/contacts_session.h>
#include <base/rpc_client.h>

namespace Contacts { struct Session_client; }


struct Contacts::Session_client : Genode::Rpc_client<Session>
{
	explicit Session_client(Genode::Capability<Session> cap)
	: Genode::Rpc_client<Session>(cap) { }

	Lookup lookup(Number const &number) override {
		return call<Rpc_lookup>(number); }

	void sigh(Genode::Signal_context_capability sigh) override {
		call<Rpc_sigh>(sigh); }

	unsigned generation() override { return call<Rpc_generation>(); }

	unsigned count() override { return call<Rpc_count>(); }

	Contact contact(unsigned index) override {
		return call<Rpc_contact>(index); }

	Phone number(Id id, unsigned index) override {
		return call<Rpc_number>(id, index); }

	Added add(Name const &name) override { return call<Rpc_add>(name); }

	Result rename(Id id, Name const &name) override {
		return call<Rpc_rename>(id, name); }

	Result remove(Id id) override { return call<Rpc_remove>(id); }

	Result add_number(Id id, Number_label const &label,
	                  Number const &number) override {
		return call<Rpc_add_number>(id, label, number); }

	Result remove_number(Id id, unsigned index) override {
		return call<Rpc_remove_number>(id, index); }
};

#endif /* _INCLUDE__CONTACTS_SESSION__CLIENT_H_ */
