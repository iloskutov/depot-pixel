/*
 * \brief  Data types of the contacts session
 * \author Ivan Loskutov
 * \date   2026-10-01
 *
 * Plain data, shared by the session interface and the contacts store.
 */

/*
 * SPDX-License-Identifier: MIT
 */

#ifndef _INCLUDE__CONTACTS_SESSION__TYPES_H_
#define _INCLUDE__CONTACTS_SESSION__TYPES_H_

#include <util/string.h>

namespace Contacts {

	using Name   = Genode::String<161>;  /* at most 40 characters (UTF-8) */
	using Number = Genode::String<33>;   /* as Call_tracker::Number */
	using Label  = Genode::String<16>;

	struct Id { unsigned value; };       /* 0 = invalid */

	enum class Result { OK, DENIED, INVALID, FULL, UNKNOWN };

	struct Lookup  { bool found; Id id; Name name; };
	struct Contact { bool valid; Id id; Name name; unsigned numbers; };
	struct Phone   { bool valid; Label label; Number number; };
	struct Added   { Result result; Id id; };
}

#endif /* _INCLUDE__CONTACTS_SESSION__TYPES_H_ */
