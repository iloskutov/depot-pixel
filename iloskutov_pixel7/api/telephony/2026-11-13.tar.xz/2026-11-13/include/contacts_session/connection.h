/*
 * \brief  Connection to the contacts service
 * \author Ivan Loskutov
 * \date   2026-10-01
 */

/*
 * SPDX-License-Identifier: MIT
 */

#ifndef _INCLUDE__CONTACTS_SESSION__CONNECTION_H_
#define _INCLUDE__CONTACTS_SESSION__CONNECTION_H_

#include <contacts_session/client.h>
#include <base/connection.h>

namespace Contacts { struct Connection; }


struct Contacts::Connection : Genode::Connection<Session>, Session_client
{
	/**
	 * Constructor
	 *
	 * Blocks for good if the service has no policy for the client (as
	 * every denied session request does).
	 */
	Connection(Genode::Env &env,
	           Genode::Session_label const &label = Genode::Session_label())
	:
		Genode::Connection<Session>(env, label,
		                            Ram_quota { Session::RAM_QUOTA }, Args()),
		Session_client(cap())
	{ }
};

#endif /* _INCLUDE__CONTACTS_SESSION__CONNECTION_H_ */
