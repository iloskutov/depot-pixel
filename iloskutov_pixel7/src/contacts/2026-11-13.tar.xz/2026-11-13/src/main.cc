/*
 * \brief  Contacts app: the contacts of 'contacts_service'
 * \author Ivan Loskutov
 * \date   2026-11-13
 *
 * A list of the contacts, a tap shows one with its numbers and a button
 * to remove it; the plus button adds a contact with a name and a number
 * typed in. The contacts are those of a 'Contacts' session that may manage
 * them; 'phone_service' looks the names up for the Phone and Messages
 * apps. A change by anyone is shown at once (the session's signal). What
 * the user does is logged:
 *
 *   contacts: add Anna +41790000000
 *   contacts: remove Anna
 */

/*
 * SPDX-License-Identifier: MIT
 */

#include <base/attached_rom_dataspace.h>
#include <base/log.h>
#include <libc/component.h>
#include <contacts_session/connection.h>

#include <lvgl_genode.h>

namespace Contacts_app { struct Main; }


struct Contacts_app::Main : Lvgl_genode::Window::Ui
{
	Genode::Env &_env;

	Genode::Attached_rom_dataspace _ttf;

	Contacts::Connection _contacts { _env };

	lv_font_t *_font(int32_t px)
	{
		lv_font_t *font = lv_tiny_ttf_create_data(_ttf.local_addr<void>(), _ttf.size(), px);
		font->fallback = &lv_font_montserrat_48;
		return font;
	}

	lv_obj_t *_list_page = nullptr, *_list    = nullptr;
	lv_obj_t *_show_page = nullptr, *_name    = nullptr, *_numbers = nullptr;
	lv_obj_t *_add_page  = nullptr, *_new_name = nullptr, *_new_number = nullptr;

	unsigned _shown = 0;   /* id of the shown contact, 0: none */

	static Main &_main(lv_event_t *e) { return *(Main *)lv_event_get_user_data(e); }

	static lv_obj_t *_plain(lv_obj_t *parent)
	{
		lv_obj_t *obj = lv_obj_create(parent);
		lv_obj_set_style_bg_opa(obj, LV_OPA_TRANSP, 0);
		lv_obj_set_style_border_width(obj, 0, 0);
		lv_obj_set_style_radius(obj, 0, 0);
		lv_obj_set_style_pad_all(obj, 0, 0);
		return obj;
	}

	static lv_obj_t *_page(lv_obj_t *screen)
	{
		lv_obj_t *page = _plain(screen);
		lv_obj_set_size(page, lv_pct(100), lv_pct(100));
		lv_obj_set_style_pad_all(page, 24, 0);
		lv_obj_set_style_pad_row(page, 24, 0);
		lv_obj_set_flex_flow(page, LV_FLEX_FLOW_COLUMN);
		return page;
	}

	static lv_obj_t *_row(lv_obj_t *parent)
	{
		lv_obj_t *row = _plain(parent);
		lv_obj_set_size(row, lv_pct(100), LV_SIZE_CONTENT);
		lv_obj_set_flex_flow(row, LV_FLEX_FLOW_ROW);
		lv_obj_set_flex_align(row, LV_FLEX_ALIGN_START, LV_FLEX_ALIGN_CENTER,
		                      LV_FLEX_ALIGN_CENTER);
		lv_obj_set_style_pad_column(row, 24, 0);
		lv_obj_set_scrollable(row, false);
		return row;
	}

	lv_obj_t *_button(lv_obj_t *parent, char const *text, lv_event_cb_t cb)
	{
		lv_obj_t *button = lv_button_create(parent);
		lv_label_set_text(lv_label_create(button), text);
		lv_obj_add_event_cb(button, cb, LV_EVENT_CLICKED, this);
		lv_group_remove_obj(button);
		return button;
	}

	void _show(lv_obj_t *page)
	{
		lv_obj_set_hidden(_list_page, page != _list_page);
		lv_obj_set_hidden(_show_page, page != _show_page);
		lv_obj_set_hidden(_add_page,  page != _add_page);
	}

	void _update_list()
	{
		lv_obj_clean(_list);

		unsigned const count = _contacts.count();
		for (unsigned i = 0; i < count; i++) {
			Contacts::Contact const c = _contacts.contact(i);
			if (!c.valid)
				continue;

			lv_obj_t *entry = lv_button_create(_list);
			lv_obj_set_width(entry, lv_pct(100));
			lv_label_set_text_fmt(lv_label_create(entry), LV_SYMBOL_HOME "  %s",
			                      c.name.string());
			lv_obj_set_user_data(entry, (void *)uintptr_t(c.id.value));
			lv_obj_add_event_cb(entry, _entry_tapped, LV_EVENT_CLICKED, this);
			lv_group_remove_obj(entry);
		}
	}

	/* the shown contact, gone back to the list if it was removed */
	void _update_shown()
	{
		if (!_shown)
			return;

		lv_obj_clean(_numbers);

		bool found = false;
		unsigned const count = _contacts.count();
		for (unsigned i = 0; i < count; i++) {
			Contacts::Contact const c = _contacts.contact(i);
			if (!c.valid || c.id.value != _shown)
				continue;

			found = true;
			lv_label_set_text(_name, c.name.string());
			for (unsigned j = 0; j < c.numbers; j++) {
				Contacts::Phone const p = _contacts.number(c.id, j);
				if (p.valid)
					lv_label_set_text_fmt(lv_label_create(_numbers), LV_SYMBOL_CALL "  %s  (%s)",
					                      p.number.string(), p.label.string());
			}
		}
		if (!found) {
			_shown = 0;
			_show(_list_page);
		}
	}

	static void _entry_tapped(lv_event_t *e)
	{
		Main &main = _main(e);
		main._shown = unsigned(uintptr_t(lv_obj_get_user_data(lv_event_get_current_target_obj(e))));
		main._update_shown();
		main._show(main._show_page);
	}

	static void _back(lv_event_t *e)
	{
		Main &main = _main(e);
		main._shown = 0;
		main._show(main._list_page);
	}

	static void _remove(lv_event_t *e)
	{
		Main &main = _main(e);
		if (!main._shown)
			return;

		Genode::log("contacts: remove ", Genode::Cstring(lv_label_get_text(main._name)));
		main._contacts.remove(Contacts::Id { main._shown });
		main._shown = 0;
		main._show(main._list_page);
		main._update_list();
	}

	static void _add(lv_event_t *e)
	{
		Main &main = _main(e);
		lv_textarea_set_text(main._new_name,   "");
		lv_textarea_set_text(main._new_number, "");
		main._show(main._add_page);
		lv_group_focus_obj(main._new_name);
	}

	static void _save(lv_event_t *e)
	{
		Main &main = _main(e);

		/* the fields keep the key focus while their page is hidden */
		if (lv_obj_is_hidden(main._add_page))
			return;

		Contacts::Name   const name  (lv_textarea_get_text(main._new_name));
		Contacts::Number const number(lv_textarea_get_text(main._new_number));
		if (name.length() <= 1)
			return;

		Genode::log("contacts: add ", name, " ", number);
		Contacts::Added const added = main._contacts.add(name);
		if (added.result != Contacts::Result::OK) {
			Genode::warning("contacts: '", name, "' not added");
			return;
		}
		if (number.length() > 1
		 && main._contacts.add_number(added.id, "mobile", number) != Contacts::Result::OK)
			Genode::warning("contacts: number '", number, "' not added");

		lv_textarea_set_text(main._new_name,   "");
		lv_textarea_set_text(main._new_number, "");
		main._show(main._list_page);
		main._update_list();
	}

	/* the name field's Enter moves on to the number */
	static void _name_ready(lv_event_t *e) {
		lv_group_focus_obj(_main(e)._new_number); }

	void _handle_contacts()
	{
		if (_runtime.in_lvgl()) {
			Genode::Signal_transmitter(_contacts_handler).submit();
			return;
		}

		/* without a window there is nothing to update yet */
		if (!_list_page)
			return;

		_update_list();
		_update_shown();
		_runtime.run();
	}

	Genode::Signal_handler<Main> _contacts_handler {
		_env.ep(), *this, &Main::_handle_contacts };

	void create(lv_display_t &display) override
	{
		lv_font_t *text_font  = _font(64);
		lv_font_t *title_font = _font(96);

		lv_theme_t *theme = lv_theme_default_init(&display,
			lv_palette_main(LV_PALETTE_ORANGE), lv_palette_main(LV_PALETTE_TEAL),
			true, text_font);
		lv_display_set_theme(&display, theme);

		lv_obj_t *screen = lv_display_get_screen_active(&display);
		lv_obj_set_scrollable(screen, false);

		/* the list */
		_list_page = _page(screen);
		lv_obj_t *header = _row(_list_page);
		lv_obj_set_flex_align(header, LV_FLEX_ALIGN_SPACE_BETWEEN, LV_FLEX_ALIGN_CENTER,
		                      LV_FLEX_ALIGN_CENTER);
		lv_obj_t *title = lv_label_create(header);
		lv_obj_set_style_text_font(title, title_font, 0);
		lv_label_set_text(title, "Contacts");
		_button(header, LV_SYMBOL_PLUS, _add);

		_list = _plain(_list_page);
		lv_obj_set_width(_list, lv_pct(100));
		lv_obj_set_flex_grow(_list, 1);
		lv_obj_set_flex_flow(_list, LV_FLEX_FLOW_COLUMN);
		lv_obj_set_style_pad_row(_list, 16, 0);

		/* a contact */
		_show_page = _page(screen);
		lv_obj_t *show_header = _row(_show_page);
		_button(show_header, LV_SYMBOL_LEFT, _back);
		_name = lv_label_create(show_header);
		lv_obj_set_style_text_font(_name, title_font, 0);

		_numbers = _plain(_show_page);
		lv_obj_set_width(_numbers, lv_pct(100));
		lv_obj_set_flex_grow(_numbers, 1);
		lv_obj_set_flex_flow(_numbers, LV_FLEX_FLOW_COLUMN);
		lv_obj_set_style_pad_row(_numbers, 16, 0);

		lv_obj_t *remove = _button(_show_page, LV_SYMBOL_TRASH "  Remove", _remove);
		lv_obj_set_style_bg_color(remove, lv_palette_main(LV_PALETTE_RED), 0);

		/* a new contact */
		_add_page = _page(screen);
		lv_obj_t *add_header = _row(_add_page);
		_button(add_header, LV_SYMBOL_LEFT, _back);
		lv_obj_t *add_title = lv_label_create(add_header);
		lv_obj_set_style_text_font(add_title, title_font, 0);
		lv_label_set_text(add_title, "New contact");

		_new_name = lv_textarea_create(_add_page);
		lv_obj_set_width(_new_name, lv_pct(100));
		lv_textarea_set_one_line(_new_name, true);
		lv_textarea_set_placeholder_text(_new_name, "Name");
		lv_obj_add_event_cb(_new_name, _name_ready, LV_EVENT_READY, this);

		_new_number = lv_textarea_create(_add_page);
		lv_obj_set_width(_new_number, lv_pct(100));
		lv_textarea_set_one_line(_new_number, true);
		lv_textarea_set_accepted_chars(_new_number, "0123456789+");
		lv_textarea_set_placeholder_text(_new_number, "Number");
		lv_obj_add_event_cb(_new_number, _save, LV_EVENT_READY, this);

		_button(_add_page, LV_SYMBOL_OK "  Save", _save);

		_show(_list_page);
		_update_list();
	}

	Lvgl_genode::Runtime _runtime;
	Lvgl_genode::Window  _window;

	Main(Genode::Env &env)
	:
		_env(env), _ttf(env, "LiberationSans-Regular.ttf"),
		_runtime(env), _window(env, _runtime, *this, "")
	{
		_contacts.sigh(_contacts_handler);

		/* a change before the signal handler was installed */
		_handle_contacts();
	}

	Main(Main const &) = delete;
	Main &operator = (Main const &) = delete;
};


void Libc::Component::construct(Libc::Env &env)
{
	static Contacts_app::Main main(env);
}
