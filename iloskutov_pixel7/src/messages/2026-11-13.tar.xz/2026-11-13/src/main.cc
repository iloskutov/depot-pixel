/*
 * \brief  Messages app: SMS through 'sms_store'
 * \author Ivan Loskutov
 * \date   2026-11-12
 *
 * The chats come from the ROM "messages" of 'sms_store' (a chat per
 * number, with its messages), the names from a 'Contacts' session that may
 * list the contacts ('read: yes'); a tap opens one, with a text field that
 * takes the keyboard's input. Send (or Enter) reports an "sms_request"; the
 * message appears once 'sms_store' lists it, and its state follows the
 * modem. The plus button starts a chat with a number typed in or picked
 * from the contacts. The open chat is reported as "messages_view", so
 * 'sms_store' marks it read.
 *
 * The text is drawn in Liberation Sans from the ROM
 * "LiberationSans-Regular.ttf", twice the size of LVGL's default font.
 * What the user does is logged:
 *
 *   messages: open +41790000000
 *   messages: send to +41790000000: hello
 */

/*
 * SPDX-License-Identifier: MIT
 */

#include <base/attached_rom_dataspace.h>
#include <base/log.h>
#include <libc/component.h>
#include <os/reporter.h>
#include <contacts_session/connection.h>

#include <lvgl_genode.h>

namespace Messages_app { struct Main; }


struct Messages_app::Main : Lvgl_genode::Window::Ui
{
	using Number = Genode::String<33>;
	using Name   = Contacts::Name;      /* a contact's name, or a number */
	using Text   = Genode::String<512>;

	Genode::Env &_env;

	Genode::Attached_rom_dataspace _ttf;
	Genode::Attached_rom_dataspace _messages { _env, "messages" };

	Genode::Expanding_reporter _sms_request   { _env, "sms_request",   "sms_request" };
	Genode::Expanding_reporter _messages_view { _env, "messages_view", "messages_view" };

	unsigned _seq = 0;   /* of the last sms_request */

	/* the names of the numbers, and the list of the contact picker */
	Contacts::Connection _contacts { _env };

	Name _name(Number const &number)
	{
		Contacts::Lookup const l = _contacts.lookup(number);
		return l.found ? Name(l.name) : Name(number);
	}

	/* a font of the given size, LVGL's symbols from Montserrat */
	lv_font_t *_font(int32_t px)
	{
		lv_font_t *font = lv_tiny_ttf_create_data(_ttf.local_addr<void>(), _ttf.size(), px);
		font->fallback = &lv_font_montserrat_48;
		return font;
	}

	lv_obj_t *_list_page = nullptr, *_list      = nullptr;
	lv_obj_t *_chat_page = nullptr, *_chat_name = nullptr, *_to = nullptr;
	lv_obj_t *_bubbles   = nullptr, *_input     = nullptr;

	bool   _chat_open = false;
	unsigned _sent_seq = 0;   /* of the SMS sent from the open chat */
	Number _open { };      /* the number of the open chat, empty: a new one */

	static Main &_main(lv_event_t *e) { return *(Main *)lv_event_get_user_data(e); }

	static lv_obj_t *_plain(lv_obj_t *parent)
	{
		lv_obj_t *obj = lv_obj_create(parent);
		lv_obj_set_style_bg_opa(obj, LV_OPA_TRANSP, 0);
		lv_obj_set_style_border_width(obj, 0, 0);
		lv_obj_set_style_radius(obj, 0, 0);
		lv_obj_set_style_pad_all(obj, 0, 0);
		return obj;
	}

	/* a message, at the right if it is the user's own */
	static void _bubble(lv_obj_t *messages, char const *text, bool own, bool failed)
	{
		lv_obj_t *row = _plain(messages);
		lv_obj_set_size(row, lv_pct(100), LV_SIZE_CONTENT);
		lv_obj_set_flex_flow(row, LV_FLEX_FLOW_ROW);
		lv_obj_set_flex_align(row, own ? LV_FLEX_ALIGN_END : LV_FLEX_ALIGN_START,
		                      LV_FLEX_ALIGN_START, LV_FLEX_ALIGN_START);
		lv_obj_set_scrollable(row, false);

		/* the label is the bubble: its width relative to the full-width row */
		lv_obj_t *bubble = lv_label_create(row);
		lv_obj_set_width(bubble, LV_SIZE_CONTENT);
		lv_obj_set_style_max_width(bubble, lv_pct(80), 0);
		lv_label_set_long_mode(bubble, LV_LABEL_LONG_MODE_WRAP);
		lv_obj_set_style_pad_all(bubble, 16, 0);
		lv_obj_set_style_radius(bubble, 16, 0);
		lv_obj_set_style_bg_opa(bubble, LV_OPA_COVER, 0);
		lv_obj_set_style_bg_color(bubble,
			failed ? lv_palette_main(LV_PALETTE_RED)
			       : own ? lv_palette_main(LV_PALETTE_BLUE)
			             : lv_palette_darken(LV_PALETTE_GREY, 3), 0);
		lv_label_set_text(bubble, text);

		/* a text wider than the limit wraps only in a label of fixed width */
		lv_obj_update_layout(row);
		if (lv_obj_get_width(bubble) >= lv_obj_get_width(row)*8/10)
			lv_obj_set_width(bubble, lv_pct(80));
	}

	void _report_view()
	{
		_messages_view.generate([&] (Genode::Generator &g) {
			if (_chat_open && _open.length() > 1)
				g.attribute("chat", _open); });
	}

	/* the chat of a number in the ROM */
	void _with_chat(Number const &number, auto const &fn) const
	{
		_messages.node().for_each_sub_node("chat", [&] (Genode::Node const &chat) {
			if (chat.attribute_value("number", Number()) == number)
				fn(chat); });
	}

	void _update_chat()
	{
		if (!_chat_open)
			return;

		lv_obj_clean(_bubbles);
		lv_label_set_text(_chat_name, _name(_open).string());
		lv_obj_set_hidden(_chat_name, _open.length() <= 1);
		lv_obj_set_hidden(_to,        _open.length() >  1);
		lv_obj_set_hidden(_pick_button, _open.length() > 1);

		lv_obj_t *last = nullptr;
		_with_chat(_open, [&] (Genode::Node const &chat) {
			chat.for_each_sub_node("msg", [&] (Genode::Node const &msg) {
				bool const own    = msg.attribute_value("dir", Genode::String<4>()) == "out";
				bool const failed = msg.attribute_value("state", Genode::String<16>()) == "failed";
				_bubble(_bubbles, msg.attribute_value("text", Text()).string(), own, failed);
				last = lv_obj_get_child(_bubbles, -1);
			});
		});
		if (last)
			lv_obj_scroll_to_view(last, LV_ANIM_OFF);
	}

	static void _opened(lv_event_t *e)
	{
		Main &main = _main(e);
		lv_obj_t *entry = lv_event_get_current_target_obj(e);
		main._open_chat(Number((char const *)lv_obj_get_user_data(entry)));
	}

	void _open_chat(Number const &number)
	{
		Genode::log("messages: open ", number);
		_open      = number;
		_chat_open = true;
		lv_textarea_set_text(_to, "");
		_update_chat();

		lv_obj_set_hidden(_list_page, true);
		lv_obj_set_hidden(_chat_page, false);
		lv_group_focus_obj(_open.length() > 1 ? _input : _to);
		_report_view();
	}

	static void _new_chat(lv_event_t *e) { _main(e)._open_chat(Number()); }

	static void _back(lv_event_t *e)
	{
		Main &main = _main(e);
		main._chat_open = false;

		/* nothing typed from now on belongs to the chat that was left */
		lv_textarea_set_text(main._input, "");
		lv_textarea_set_text(main._to,    "");
		main._open = Number();

		lv_obj_set_hidden(main._chat_page, true);
		lv_obj_set_hidden(main._list_page, false);
		main._report_view();
	}

	static void _send(lv_event_t *e)
	{
		Main &main = _main(e);

		/* the fields keep the key focus while their page is hidden */
		if (!main._chat_open)
			return;

		char const *text = lv_textarea_get_text(main._input);

		/* a new chat: the number typed in */
		if (main._open.length() <= 1)
			main._open = Number(lv_textarea_get_text(main._to));

		if (main._open.length() <= 1 || !text[0])
			return;

		Genode::log("messages: send to ", main._open, ": ", text);
		main._sms_request.generate([&] (Genode::Generator &g) {
			g.attribute("seq",  ++main._seq);
			g.attribute("to",   main._open);
			main._sent_seq = main._seq;
			g.attribute("text", text); });

		lv_textarea_set_text(main._input, "");
		main._update_chat();
		main._report_view();
	}

	/* the list of chats, as 'sms_store' lists them */
	void _update_list()
	{
		lv_obj_clean(_list);

		_messages.node().for_each_sub_node("chat", [&] (Genode::Node const &chat) {
			Number   const number = chat.attribute_value("number", Number());
			unsigned const unread = chat.attribute_value("unread", 0u);

			lv_obj_t *entry = lv_button_create(_list);
			lv_obj_set_width(entry, lv_pct(100));
			lv_obj_t *label = lv_label_create(entry);
			Name const title = _name(number);
			if (unread)
				lv_label_set_text_fmt(label, LV_SYMBOL_ENVELOPE "  %s (%u)", title.string(), unread);
			else
				lv_label_set_text_fmt(label, LV_SYMBOL_ENVELOPE "  %s", title.string());

			/* the number, kept with the entry until the list is rebuilt */
			char *copy = (char *)lv_malloc(number.length());
			Genode::copy_cstring(copy, number.string(), number.length());
			lv_obj_set_user_data(entry, copy);
			lv_obj_add_event_cb(entry, [] (lv_event_t *e) {
				lv_free(lv_obj_get_user_data(lv_event_get_current_target_obj(e))); },
				LV_EVENT_DELETE, nullptr);

			lv_obj_add_event_cb(entry, _opened, LV_EVENT_CLICKED, this);
			lv_group_remove_obj(entry);
		});
	}

	/*
	 * The contact picker of a new chat: a number of each contact, a tap
	 * opens the chat with it
	 */
	lv_obj_t *_picker = nullptr, *_picker_list = nullptr, *_pick_button = nullptr;

	static void _picked(lv_event_t *e)
	{
		Main &main = _main(e);
		lv_obj_t *entry = lv_event_get_current_target_obj(e);
		lv_obj_set_hidden(main._picker, true);
		main._open_chat(Number((char const *)lv_obj_get_user_data(entry)));
	}

	static void _pick(lv_event_t *e)
	{
		Main &main = _main(e);
		main._update_picker();
		lv_obj_set_hidden(main._picker, false);
	}

	static void _pick_cancel(lv_event_t *e) {
		lv_obj_set_hidden(_main(e)._picker, true); }

	void _update_picker()
	{
		lv_obj_clean(_picker_list);

		unsigned const count = _contacts.count();
		for (unsigned i = 0; i < count; i++) {
			Contacts::Contact const c = _contacts.contact(i);
			if (!c.valid)
				continue;
			for (unsigned j = 0; j < c.numbers; j++) {
				Contacts::Phone const p = _contacts.number(c.id, j);
				if (!p.valid)
					continue;

				lv_obj_t *entry = lv_button_create(_picker_list);
				lv_obj_set_width(entry, lv_pct(100));
				lv_label_set_text_fmt(lv_label_create(entry), "%s\n%s",
				                      c.name.string(), p.number.string());

				char *copy = (char *)lv_malloc(p.number.length());
				Genode::copy_cstring(copy, p.number.string(), p.number.length());
				lv_obj_set_user_data(entry, copy);
				lv_obj_add_event_cb(entry, [] (lv_event_t *e) {
					lv_free(lv_obj_get_user_data(lv_event_get_current_target_obj(e))); },
					LV_EVENT_DELETE, nullptr);
				lv_obj_add_event_cb(entry, _picked, LV_EVENT_CLICKED, this);
				lv_group_remove_obj(entry);
			}
		}
		if (!count)
			lv_label_set_text(lv_label_create(_picker_list), "No contacts");
	}

	void _handle_messages()
	{
		if (_runtime.in_lvgl()) {
			Genode::Signal_transmitter(_messages_handler).submit();
			return;
		}
		_messages.update();

		/* without a window there is nothing to update yet */
		if (!_list_page)
			return;

		/* a relaunched app continues after the last request */
		unsigned const request_seq = _messages.node().attribute_value("request_seq", 0u);
		_seq = Genode::max(_seq, request_seq);

		/* the SMS just sent went to a chat known by another form of the number */
		Number const chat = _messages.node().attribute_value("request_chat", Number());
		if (_chat_open && _sent_seq && _sent_seq == request_seq && chat.length() > 1
		 && chat != _open) {
			_open = chat;
			_report_view();
		}

		_update_list();
		_update_chat();
		_runtime.run();
	}

	Genode::Signal_handler<Main> _messages_handler {
		_env.ep(), *this, &Main::_handle_messages };

	void create(lv_display_t &display) override
	{
		lv_font_t *text_font  = _font(64);
		lv_font_t *title_font = _font(96);

		lv_theme_t *theme = lv_theme_default_init(&display,
			lv_palette_main(LV_PALETTE_BLUE), lv_palette_main(LV_PALETTE_TEAL),
			true, text_font);
		lv_display_set_theme(&display, theme);

		lv_obj_t *screen = lv_display_get_screen_active(&display);
		lv_obj_set_scrollable(screen, false);

		/* the list of chats */
		_list_page = _plain(screen);
		lv_obj_set_size(_list_page, lv_pct(100), lv_pct(100));
		lv_obj_set_style_pad_all(_list_page, 24, 0);
		lv_obj_set_style_pad_row(_list_page, 24, 0);
		lv_obj_set_flex_flow(_list_page, LV_FLEX_FLOW_COLUMN);

		lv_obj_t *list_header = _plain(_list_page);
		lv_obj_set_size(list_header, lv_pct(100), LV_SIZE_CONTENT);
		lv_obj_set_flex_flow(list_header, LV_FLEX_FLOW_ROW);
		lv_obj_set_flex_align(list_header, LV_FLEX_ALIGN_SPACE_BETWEEN,
		                      LV_FLEX_ALIGN_CENTER, LV_FLEX_ALIGN_CENTER);

		lv_obj_t *title = lv_label_create(list_header);
		lv_obj_set_style_text_font(title, title_font, 0);
		lv_label_set_text(title, "Messages");

		lv_obj_t *add = lv_button_create(list_header);
		lv_label_set_text(lv_label_create(add), LV_SYMBOL_PLUS);
		lv_obj_add_event_cb(add, _new_chat, LV_EVENT_CLICKED, this);
		lv_group_remove_obj(add);

		_list = _plain(_list_page);
		lv_obj_set_width(_list, lv_pct(100));
		lv_obj_set_flex_grow(_list, 1);
		lv_obj_set_flex_flow(_list, LV_FLEX_FLOW_COLUMN);
		lv_obj_set_style_pad_row(_list, 16, 0);

		/* a chat */
		_chat_page = _plain(screen);
		lv_obj_set_size(_chat_page, lv_pct(100), lv_pct(100));
		lv_obj_set_style_pad_all(_chat_page, 16, 0);
		lv_obj_set_style_pad_row(_chat_page, 16, 0);
		lv_obj_set_flex_flow(_chat_page, LV_FLEX_FLOW_COLUMN);
		lv_obj_set_hidden(_chat_page, true);

		lv_obj_t *header = _plain(_chat_page);
		lv_obj_set_size(header, lv_pct(100), LV_SIZE_CONTENT);
		lv_obj_set_flex_flow(header, LV_FLEX_FLOW_ROW);
		lv_obj_set_flex_align(header, LV_FLEX_ALIGN_START, LV_FLEX_ALIGN_CENTER,
		                      LV_FLEX_ALIGN_CENTER);
		lv_obj_set_style_pad_column(header, 24, 0);

		lv_obj_t *back = lv_button_create(header);
		lv_label_set_text(lv_label_create(back), LV_SYMBOL_LEFT);
		lv_obj_add_event_cb(back, _back, LV_EVENT_CLICKED, this);

		_chat_name = lv_label_create(header);
		lv_obj_set_style_text_font(_chat_name, title_font, 0);

		/* the number of a new chat */
		_to = lv_textarea_create(header);
		lv_textarea_set_one_line(_to, true);
		lv_textarea_set_accepted_chars(_to, "0123456789+");
		lv_textarea_set_placeholder_text(_to, "To");
		lv_obj_set_flex_grow(_to, 1);

		_pick_button = lv_button_create(header);
		lv_label_set_text(lv_label_create(_pick_button), LV_SYMBOL_DIRECTORY);
		lv_obj_add_event_cb(_pick_button, _pick, LV_EVENT_CLICKED, this);
		lv_group_remove_obj(_pick_button);

		_bubbles = _plain(_chat_page);
		lv_obj_set_width(_bubbles, lv_pct(100));
		lv_obj_set_flex_grow(_bubbles, 1);
		lv_obj_set_flex_flow(_bubbles, LV_FLEX_FLOW_COLUMN);
		lv_obj_set_style_pad_row(_bubbles, 12, 0);

		lv_obj_t *input_row = _plain(_chat_page);
		lv_obj_set_size(input_row, lv_pct(100), LV_SIZE_CONTENT);
		lv_obj_set_flex_flow(input_row, LV_FLEX_FLOW_ROW);
		lv_obj_set_flex_align(input_row, LV_FLEX_ALIGN_START, LV_FLEX_ALIGN_CENTER,
		                      LV_FLEX_ALIGN_CENTER);
		lv_obj_set_style_pad_column(input_row, 16, 0);

		_input = lv_textarea_create(input_row);
		lv_textarea_set_one_line(_input, true);
		lv_textarea_set_placeholder_text(_input, "Message");

		/* one SMS; 'sms_store' takes 160 characters of whatever alphabet */
		lv_textarea_set_max_length(_input, 160);
		lv_obj_set_flex_grow(_input, 1);
		lv_obj_add_event_cb(_input, _send, LV_EVENT_READY, this);

		lv_obj_t *send = lv_button_create(input_row);
		lv_label_set_text(lv_label_create(send), LV_SYMBOL_RIGHT);
		lv_obj_add_event_cb(send, _send, LV_EVENT_CLICKED, this);

		/* a tap on a button leaves the keys with the text fields */
		lv_group_remove_obj(back);
		lv_group_remove_obj(send);

		/* the contact picker, above the chat */
		_picker = _plain(screen);
		lv_obj_set_size(_picker, lv_pct(100), lv_pct(100));
		lv_obj_set_style_bg_opa(_picker, LV_OPA_COVER, 0);
		lv_obj_set_style_bg_color(_picker, lv_obj_get_style_bg_color(screen, LV_PART_MAIN), 0);
		lv_obj_set_style_pad_all(_picker, 24, 0);
		lv_obj_set_style_pad_row(_picker, 24, 0);
		lv_obj_set_flex_flow(_picker, LV_FLEX_FLOW_COLUMN);

		lv_obj_t *picker_head = _plain(_picker);
		lv_obj_set_size(picker_head, lv_pct(100), LV_SIZE_CONTENT);
		lv_obj_set_flex_flow(picker_head, LV_FLEX_FLOW_ROW);
		lv_obj_set_flex_align(picker_head, LV_FLEX_ALIGN_START, LV_FLEX_ALIGN_CENTER,
		                      LV_FLEX_ALIGN_CENTER);
		lv_obj_set_style_pad_column(picker_head, 24, 0);
		lv_obj_t *cancel = lv_button_create(picker_head);
		lv_label_set_text(lv_label_create(cancel), LV_SYMBOL_LEFT);
		lv_obj_add_event_cb(cancel, _pick_cancel, LV_EVENT_CLICKED, this);
		lv_group_remove_obj(cancel);
		lv_obj_t *picker_title = lv_label_create(picker_head);
		lv_obj_set_style_text_font(picker_title, title_font, 0);
		lv_label_set_text(picker_title, "Contacts");

		_picker_list = _plain(_picker);
		lv_obj_set_width(_picker_list, lv_pct(100));
		lv_obj_set_flex_grow(_picker_list, 1);
		lv_obj_set_flex_flow(_picker_list, LV_FLEX_FLOW_COLUMN);
		lv_obj_set_style_pad_row(_picker_list, 16, 0);
		lv_obj_set_hidden(_picker, true);

		_update_list();
	}

	Lvgl_genode::Runtime _runtime;
	Lvgl_genode::Window  _window;

	Main(Genode::Env &env)
	:
		_env(env), _ttf(env, "LiberationSans-Regular.ttf"),
		_runtime(env), _window(env, _runtime, *this, "")
	{
		_messages.sigh(_messages_handler);
		_contacts.sigh(_messages_handler);
		_report_view();

		/* a change before the signal handler was installed */
		_handle_messages();
	}

	Main(Main const &) = delete;
	Main &operator = (Main const &) = delete;
};


void Libc::Component::construct(Libc::Env &env)
{
	static Messages_app::Main main(env);
}
