/*
 * \brief  Modem orchestrator: Android-init-like rule engine
 * \author Ivan Loskutov
 * \date   2026-09-26
 *
 * Driven by events (boot, property change, service exit, timer) and acting
 * only through 'Actions'. Boot: init.svc.* = stopped, a warning for every
 * rules event that is not one of the profile's phases (logged once per
 * distinct event -- its actions can never run), phase actions, property
 * triggers against current values, class_start. Commands run from one FIFO
 * queue. Service states stopped/running/restarting, published as
 * init.svc.<name>.
 *
 * The component removes an exited child from its sandbox before it calls
 * 'service_exited'; 'stop' is only called for a running child.
 */

/*
 * SPDX-License-Identifier: MIT
 */

#ifndef _INCLUDE__MODEM_ORCHESTRATOR__ENGINE_H_
#define _INCLUDE__MODEM_ORCHESTRATOR__ENGINE_H_

#include <modem_orchestrator/rules.h>

namespace Modem_orchestrator {
	struct Actions;
	class  Engine;
}


/**
 * An 'Actions' implementation must not call back into the 'Engine'
 * synchronously from within any of these methods (e.g.
 * 'Engine::property_changed'/'service_exited'/'timer_expired'): the engine
 * is not re-entrant. The component therefore calls the engine only from
 * its own signal handlers -- the sandbox's state handler (which the sandbox
 * library invokes from a signal handler of its own, never from within
 * 'apply_config'), 'reap_handler', and the plain 'Genode::Signal_handler'
 * the timeout callback submits to -- and never from within an 'Actions'
 * method.
 */
struct Modem_orchestrator::Actions
{
	virtual ~Actions() { }

	/* argv[0] is the path, argv[1..argc-1] the expanded .rc arguments */
	virtual void start(char const *service, char const * const *argv, unsigned argc) = 0;
	virtual void stop(char const *service) = 0;
	virtual void set_property(char const *name, char const *value) = 0;

	/* false if the property is not set ('buf' is left as it is) */
	virtual bool get_property(char const *name, char *buf, unsigned len) = 0;

	/*
	 * Called at boot before the property triggers are evaluated against
	 * the current values: the changes made up to now must not be reported
	 * by 'Engine::property_changed' afterwards
	 */
	virtual void forget_property_changes() = 0;

	virtual bool mkdir(char const *path, unsigned mode) = 0;
	virtual bool write(char const *path, char const *text) = 0;
	virtual bool rm(char const *path) = 0;

	/* call Engine::timer_expired once, 'ms' from now (replaces a pending one) */
	virtual void timer(unsigned long ms) = 0;
	virtual unsigned long now_ms() = 0;

	virtual void log(char const *line) = 0;
};


class Modem_orchestrator::Engine
{
	public:

		enum class State { STOPPED, RUNNING, RESTARTING };

		enum { RESTART_DELAY_MS = 5000, CRASH_WINDOW_MS = 240000, CRASH_LIMIT = 4,
		       QUEUE_LEN = 1024 };

	private:

		struct Svc
		{
			State         state;
			bool          pending;      /* start requested, gate closed */
			bool          no_template_logged;
			unsigned long started_at;
			unsigned long restart_at;
			unsigned long exits[CRASH_LIMIT];
			unsigned      exit_count;
		};

		Rules   const &_rules;
		Profile const &_profile;
		Actions       &_actions;

		Svc      _svc[MAX_SERVICES] { };
		unsigned _queue[QUEUE_LEN] { };
		unsigned _head = 0, _tail = 0;

		Engine(Engine const &) = delete;
		Engine &operator = (Engine const &) = delete;

		void _log(char const *a, char const *b = "", char const *c = "", char const *d = "");
		void _expand(char const *in, char *out, unsigned len);

		/*
		 * 'changed_name'/'changed_value': the property delivered by the
		 * watcher for this call, if any. A condition on 'changed_name' is
		 * checked against 'changed_value' rather than re-read through
		 * 'Actions::get_property' -- re-reading would collapse two sets of
		 * the same property delivered within one poll (e.g. 0 then 1) onto
		 * the table's final value, and the '=0' trigger would never fire.
		 * Every other condition is still read through 'get_property'.
		 */
		bool _holds(Condition const &, char const *changed_name = nullptr,
		            char const *changed_value = nullptr);
		bool _all_hold(Trigger const &, char const *changed_name = nullptr,
		               char const *changed_value = nullptr);
		void _enqueue(Trigger const &);
		void _run_queue();
		void _execute(Command const &);
		void _publish(unsigned i);
		void _set_state(unsigned i, State);
		bool _has_template(char const *name) const;
		Gate const *_gate(char const *name) const;
		bool _gate_open(unsigned i);
		void _request_start(unsigned i);
		void _start_now(unsigned i);
		void _stop(unsigned i);
		void _check_pending();
		void _arm_timer();
		void _class(char const *cls, bool start);

	public:

		Engine(Rules const &, Profile const &, Actions &);

		void boot();

		/*
		 * A property changed: 'value' is what the watcher delivered for
		 * 'name'. A property-only trigger's condition on 'name' is checked
		 * against 'value'; its other conditions (an '&&' of properties) are
		 * read through 'Actions::get_property' as usual.
		 */
		void property_changed(char const *name, char const *value);

		void service_exited(char const *service, int exit_value);

		void timer_expired();

		State state(char const *service) const;
};

#endif /* _INCLUDE__MODEM_ORCHESTRATOR__ENGINE_H_ */
