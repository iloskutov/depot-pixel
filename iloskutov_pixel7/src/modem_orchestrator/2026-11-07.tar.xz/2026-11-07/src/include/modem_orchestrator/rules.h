/*
 * \brief  Rules (from the .rc files) and device profile of the orchestrator
 * \author Ivan Loskutov
 * \date   2026-09-26
 *
 * Plain fixed-size structures, filled by the component from its ROMs (or by
 * tests through the add_* builders).
 */

/*
 * SPDX-License-Identifier: MIT
 */

#ifndef _INCLUDE__MODEM_ORCHESTRATOR__RULES_H_
#define _INCLUDE__MODEM_ORCHESTRATOR__RULES_H_

#include <stddef.h>

namespace Modem_orchestrator {

	enum { NAME_LEN = 64, PROP_LEN = 128, TEXT_LEN = 160,
	       VALUE_LEN = 1024,   /* longest value of a property, with the NUL */
	       MAX_ARGS = 16, MAX_SERVICES = 16, MAX_TRIGGERS = 64, MAX_CONDS = 4,
	       MAX_COMMANDS = 256, MAX_PHASES = 8, MAX_CLASSES = 4 };

	struct Service_def
	{
		char     name[NAME_LEN];
		char     path[TEXT_LEN];
		char     cls[NAME_LEN];
		bool     disabled;
		bool     oneshot;
		unsigned argc;
		char     args[MAX_ARGS][TEXT_LEN];
	};

	/*
	 * property condition, as in Android's init: an unset property counts
	 * as "", value "*" matches any value but ""
	 */
	struct Condition { char name[PROP_LEN]; char value[TEXT_LEN]; };

	enum class Op { START, STOP, RESTART, SETPROP, MKDIR, WRITE, RM, CLASS_START, CLASS_STOP };

	/*
	 * START/STOP/RESTART: arg = service; SETPROP: arg = name, value;
	 * MKDIR: arg = path, mode (0: none given); WRITE: arg = path, value = text;
	 * RM: arg = path; CLASS_START/CLASS_STOP: arg = class
	 */
	struct Command { Op op; char arg[TEXT_LEN]; char value[TEXT_LEN]; unsigned mode; };

	/* event "" = property-only trigger; commands [first, first + count) */
	struct Trigger
	{
		char      event[NAME_LEN];
		unsigned  cond_count;
		Condition conds[MAX_CONDS];
		unsigned  first, count;
	};

	struct Rules
	{
		Service_def services[MAX_SERVICES];
		unsigned    service_count;
		Trigger     triggers[MAX_TRIGGERS];
		unsigned    trigger_count;
		Command     commands[MAX_COMMANDS];
		unsigned    command_count;
	};

	struct Gate
	{
		char      service[NAME_LEN];
		char      after[NAME_LEN];     /* "": none */
		bool      has_when;
		Condition when;
	};

	struct Profile
	{
		char     phases[MAX_PHASES][NAME_LEN];
		unsigned phase_count;
		char     classes[MAX_CLASSES][NAME_LEN];
		unsigned class_count;
		char     templates[MAX_SERVICES][NAME_LEN];   /* services with a start template */
		unsigned template_count;
		Gate     gates[MAX_SERVICES];
		unsigned gate_count;
	};

	/*
	 * Builders -- return nullptr/false if a limit or a string length is
	 * exceeded (nothing is truncated)
	 */
	Service_def *add_service(Rules &, char const *name, char const *path,
	                         char const *cls, bool disabled, bool oneshot);
	bool         add_arg(Service_def &, char const *arg);

	/* commands added afterwards belong to this trigger */
	Trigger *add_trigger(Rules &, char const *event);
	bool     add_condition(Trigger &, char const *name, char const *value);
	bool     add_command(Rules &, Op, char const *arg, char const *value = "", unsigned mode = 0);

	bool add_phase(Profile &, char const *name);
	bool add_class(Profile &, char const *name);
	bool add_template(Profile &, char const *service);
	bool add_gate(Profile &, char const *service, char const *after,
	              char const *when_name, char const *when_value);

	/* index of the service or -1 */
	int find_service(Rules const &, char const *name);
}

#endif /* _INCLUDE__MODEM_ORCHESTRATOR__RULES_H_ */
