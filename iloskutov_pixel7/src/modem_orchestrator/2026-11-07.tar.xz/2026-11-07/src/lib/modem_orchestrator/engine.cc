/*
 * \brief  Modem orchestrator: Android-init-like rule engine
 * \author Ivan Loskutov
 * \date   2026-09-26
 */

/*
 * SPDX-License-Identifier: MIT
 */

#include <modem_orchestrator/engine.h>
#include <stdio.h>
#include <string.h>

using namespace Modem_orchestrator;

namespace {

	/*
	 * An argument the component can pass on in the config of a child: no
	 * '|', no control character, no blank at either end
	 */
	bool passable(char const *s)
	{
		size_t const len = strlen(s);
		if (len && (s[0] == ' ' || s[len - 1] == ' ')) return false;
		for (size_t i = 0; i < len; i++)
			if ((unsigned char)s[i] < 0x20 || s[i] == '|') return false;
		return true;
	}
}


Engine::Engine(Rules const &rules, Profile const &profile, Actions &actions)
: _rules(rules), _profile(profile), _actions(actions) { }


void Engine::_log(char const *a, char const *b, char const *c, char const *d)
{
	char line[4*TEXT_LEN];
	snprintf(line, sizeof(line), "%s%s%s%s", a, b, c, d);
	_actions.log(line);
}


/* ${name} -> value ("" if unset, logged) */
void Engine::_expand(char const *in, char *out, unsigned len)
{
	unsigned o = 0, i = 0;
	bool truncated = false;
	for (; in[i] && o + 1 < len; ) {
		if (in[i] == '$' && in[i + 1] == '{') {
			char const *end = strchr(in + i + 2, '}');
			if (end) {
				char name[PROP_LEN] { };
				size_t const n = size_t(end - (in + i + 2));
				if (n < sizeof(name)) memcpy(name, in + i + 2, n);

				if (n >= sizeof(name)) {
					_log("over-long property name in '", in, "' expands to \"\"");
				} else if (strstr(name, ":-")) {
					_log("unsupported '${", name, "}' expands to \"\"");
				} else {
					char value[VALUE_LEN] { };
					if (!_actions.get_property(name, value, sizeof(value)))
						_log("unset property '", name, "' expands to \"\"");
					unsigned k = 0;
					for (; value[k] && o + 1 < len; k++) out[o++] = value[k];
					if (value[k]) truncated = true;
				}
				i = unsigned(end - in) + 1;
				continue;
			}
		}
		out[o++] = in[i++];
	}
	out[o] = 0;
	if (in[i] || truncated)   /* a cut argument is a different argument */
		_log("argument truncated: '", in, "' -> '", out);
}


bool Engine::_holds(Condition const &c, char const *changed_name, char const *changed_value)
{
	if (changed_name && !strcmp(c.name, changed_name)) {
		if (!strcmp(c.value, "*")) return true;
		return changed_value && !strcmp(c.value, changed_value);
	}
	char value[VALUE_LEN] { };   /* stays "" if the property is not set */
	_actions.get_property(c.name, value, sizeof(value));
	if (!strcmp(c.value, "*")) return value[0] != 0;
	return !strcmp(c.value, value);
}


bool Engine::_all_hold(Trigger const &t, char const *changed_name, char const *changed_value)
{
	for (unsigned k = 0; k < t.cond_count; k++)
		if (!_holds(t.conds[k], changed_name, changed_value)) return false;
	return true;
}


void Engine::_enqueue(Trigger const &t)
{
	for (unsigned k = 0; k < t.count; k++) {
		if ((_tail + 1) % QUEUE_LEN == _head) { _log("action queue full -- command dropped"); return; }
		_queue[_tail] = t.first + k;
		_tail = (_tail + 1) % QUEUE_LEN;
	}
}


void Engine::_run_queue()
{
	while (_head != _tail) {
		unsigned const c = _queue[_head];
		_head = (_head + 1) % QUEUE_LEN;
		_execute(_rules.commands[c]);
	}
	_check_pending();
}


void Engine::_class(char const *cls, bool start)
{
	for (unsigned i = 0; i < _rules.service_count; i++) {
		Service_def const &s = _rules.services[i];
		if (strcmp(s.cls, cls)) continue;
		if (start && !s.disabled) _request_start(i);
		if (!start)               _stop(i);
	}
}


void Engine::_execute(Command const &c)
{
	char arg[TEXT_LEN], value[TEXT_LEN];
	_expand(c.arg,   arg,   sizeof(arg));
	_expand(c.value, value, sizeof(value));

	int const svc = find_service(_rules, arg);
	auto need_service = [&] (char const *op) {
		if (svc < 0) _log("action: ", op, " ", arg), _log("unknown service '", arg, "'");
		return svc >= 0; };

	switch (c.op) {
	case Op::START:
		if (!need_service("start")) return;
		_log("action: start ", arg);
		_request_start(unsigned(svc));
		return;
	case Op::STOP:
		if (!need_service("stop")) return;
		_log("action: stop ", arg);
		_stop(unsigned(svc));
		return;
	case Op::RESTART:
		if (!need_service("restart")) return;
		_log("action: restart ", arg);
		_stop(unsigned(svc));
		_request_start(unsigned(svc));
		return;
	case Op::SETPROP:
		_log("action: setprop ", arg, " ", value);
		_actions.set_property(arg, value);
		return;
	case Op::MKDIR:
		_log("action: mkdir ", arg);
		if (!_actions.mkdir(arg, c.mode)) _log("mkdir ", arg, " failed");
		return;
	case Op::WRITE:
		_log("action: write ", arg);
		if (!_actions.write(arg, value)) _log("write ", arg, " failed");
		return;
	case Op::RM:
		_log("action: rm ", arg);
		if (!_actions.rm(arg)) _log("rm ", arg, " failed");
		return;
	case Op::CLASS_START:
		_log("action: class_start ", arg);
		_class(arg, true);
		return;
	case Op::CLASS_STOP:
		_log("action: class_stop ", arg);
		_class(arg, false);
		return;
	}
}


void Engine::_publish(unsigned i)
{
	static char const * const names[] = { "stopped", "running", "restarting" };
	char prop[PROP_LEN];
	snprintf(prop, sizeof(prop), "init.svc.%s", _rules.services[i].name);
	char const *v = names[unsigned(_svc[i].state)];
	_log(prop, "=", v);
	_actions.set_property(prop, v);
}


void Engine::_set_state(unsigned i, State s)
{
	if (_svc[i].state == s) return;
	_svc[i].state = s;
	_publish(i);
}


bool Engine::_has_template(char const *name) const
{
	for (unsigned k = 0; k < _profile.template_count; k++)
		if (!strcmp(_profile.templates[k], name)) return true;
	return false;
}


Gate const *Engine::_gate(char const *name) const
{
	for (unsigned k = 0; k < _profile.gate_count; k++)
		if (!strcmp(_profile.gates[k].service, name)) return &_profile.gates[k];
	return nullptr;
}


bool Engine::_gate_open(unsigned i)
{
	Gate const *g = _gate(_rules.services[i].name);
	if (!g) return true;
	if (g->after[0] && state(g->after) != State::RUNNING) return false;
	if (g->has_when && !_holds(g->when)) return false;
	return true;
}


void Engine::_request_start(unsigned i)
{
	Svc &s = _svc[i];
	char const *name = _rules.services[i].name;

	if (!_has_template(name)) {
		if (!s.no_template_logged) _log(name, ": no template -- not started");
		s.no_template_logged = true;
		return;
	}
	if (s.state == State::RUNNING) return;   /* Android: start of a running service */

	/* the crash history stays: Android's init resets nothing on 'start' */
	if (_gate_open(i)) _start_now(i);
	else if (!s.pending) { s.pending = true; _log(name, ": start pending (gate closed)"); }
}


void Engine::_start_now(unsigned i)
{
	Service_def const &d = _rules.services[i];
	char args[MAX_ARGS][TEXT_LEN];
	char const *argv[MAX_ARGS + 1];
	argv[0] = d.path;
	for (unsigned k = 0; k < d.argc; k++) {
		_expand(d.args[k], args[k], sizeof(args[k]));
		argv[k + 1] = args[k];
	}
	_svc[i].pending = false;

	/* a dropped or changed argument is a different command line */
	for (unsigned k = 0; k < d.argc; k++) {
		if (passable(args[k])) continue;
		_log("error: ", d.name, " not started -- its config cannot carry the argument '", args[k]);
		_set_state(i, State::STOPPED);
		return;
	}

	_svc[i].started_at = _actions.now_ms();
	_actions.start(d.name, argv, d.argc + 1);
	_set_state(i, State::RUNNING);
}


void Engine::_stop(unsigned i)
{
	Svc &s = _svc[i];
	s.pending = false;
	if (s.state == State::RUNNING) _actions.stop(_rules.services[i].name);
	_set_state(i, State::STOPPED);
	_arm_timer();
}


void Engine::_check_pending()
{
	for (bool again = true; again; ) {
		again = false;
		for (unsigned i = 0; i < _rules.service_count; i++)
			if (_svc[i].pending && _gate_open(i)) { _start_now(i); again = true; }
	}
}


void Engine::_arm_timer()
{
	unsigned long const now = _actions.now_ms();
	bool any = false;
	unsigned long next = 0;
	for (unsigned i = 0; i < _rules.service_count; i++) {
		if (_svc[i].state != State::RESTARTING) continue;
		if (!any || _svc[i].restart_at < next) next = _svc[i].restart_at;
		any = true;
	}
	if (any) _actions.timer(next > now ? next - now : 0);
}


void Engine::boot()
{
	/* 0: stale init.svc.* of a getprop dump */
	for (unsigned i = 0; i < _rules.service_count; i++) _publish(i);

	/* warn once per distinct rules event that is not one of the profile's phases */
	{
		char const *logged[MAX_TRIGGERS] { };
		unsigned    logged_count = 0;
		for (unsigned t = 0; t < _rules.trigger_count; t++) {
			char const *ev = _rules.triggers[t].event;
			if (!ev[0]) continue;

			bool is_phase = false;
			for (unsigned p = 0; p < _profile.phase_count; p++)
				if (!strcmp(_profile.phases[p], ev)) is_phase = true;
			if (is_phase) continue;

			bool already = false;
			for (unsigned k = 0; k < logged_count; k++)
				if (!strcmp(logged[k], ev)) already = true;
			if (already) continue;

			_log("rules event '", ev, "' is not a profile phase -- its actions never run");
			if (logged_count < MAX_TRIGGERS) logged[logged_count++] = ev;
		}
	}

	/* 1: phase actions */
	for (unsigned p = 0; p < _profile.phase_count; p++) {
		for (unsigned t = 0; t < _rules.trigger_count; t++) {
			Trigger const &tr = _rules.triggers[t];
			if (!strcmp(tr.event, _profile.phases[p]) && _all_hold(tr)) _enqueue(tr);
		}
		_run_queue();
	}

	/* 2: property triggers against the current values */
	_actions.forget_property_changes();
	for (unsigned t = 0; t < _rules.trigger_count; t++) {
		Trigger const &tr = _rules.triggers[t];
		if (!tr.event[0] && tr.cond_count && _all_hold(tr)) _enqueue(tr);
	}
	_run_queue();

	/* 3: class_start */
	for (unsigned c = 0; c < _profile.class_count; c++) _class(_profile.classes[c], true);
	_check_pending();
}


void Engine::property_changed(char const *name, char const *value)
{
	for (unsigned t = 0; t < _rules.trigger_count; t++) {
		Trigger const &tr = _rules.triggers[t];
		if (tr.event[0]) continue;
		bool mentions = false;
		for (unsigned k = 0; k < tr.cond_count; k++)
			if (!strcmp(tr.conds[k].name, name)) mentions = true;
		if (mentions && _all_hold(tr, name, value)) _enqueue(tr);
	}
	_run_queue();
}


void Engine::service_exited(char const *service, int exit_value)
{
	int const idx = find_service(_rules, service);
	if (idx < 0) return;
	unsigned const i = unsigned(idx);
	Svc &s = _svc[i];
	if (s.state != State::RUNNING) return;

	char v[16];
	snprintf(v, sizeof(v), "%d", exit_value);
	_log(service, " exited with ", v);

	if (_rules.services[i].oneshot) { _set_state(i, State::STOPPED); _check_pending(); return; }

	unsigned long const now = _actions.now_ms();

	/* keep only exits inside the window, then add this one */
	unsigned n = 0;
	for (unsigned k = 0; k < s.exit_count; k++)
		if (now - s.exits[k] < CRASH_WINDOW_MS) s.exits[n++] = s.exits[k];
	s.exit_count = n;
	if (s.exit_count == CRASH_LIMIT) {   /* keep the newest CRASH_LIMIT - 1 */
		memmove(s.exits, s.exits + 1, sizeof(s.exits[0]) * (CRASH_LIMIT - 1));
		s.exit_count--;
	}
	s.exits[s.exit_count++] = now;

	if (s.exit_count >= CRASH_LIMIT) {
		_log("service ", service, " crashed 4 times in 4 minutes -- not restarting");
		_set_state(i, State::STOPPED);
		_check_pending();
		return;
	}
	/* as Android's init: the delay counts from the start of the process */
	s.restart_at = s.started_at + RESTART_DELAY_MS;
	if (s.restart_at < now) s.restart_at = now;
	_set_state(i, State::RESTARTING);
	_arm_timer();
	_check_pending();
}


void Engine::timer_expired()
{
	unsigned long const now = _actions.now_ms();
	for (unsigned i = 0; i < _rules.service_count; i++)
		if (_svc[i].state == State::RESTARTING && _svc[i].restart_at <= now)
			_start_now(i);   /* a restart does not wait for gates */
	_arm_timer();
	_check_pending();
}


Engine::State Engine::state(char const *service) const
{
	int const i = find_service(_rules, service);
	return i < 0 ? State::STOPPED : _svc[i].state;
}
