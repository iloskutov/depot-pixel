/*
 * \brief  Builders of the orchestrator's rules and profile
 * \author Ivan Loskutov
 * \date   2026-09-26
 */

/*
 * SPDX-License-Identifier: MIT
 */

#include <modem_orchestrator/rules.h>
#include <string.h>

using namespace Modem_orchestrator;

namespace {

	template <size_t N>
	bool copy(char (&dst)[N], char const *src)
	{
		size_t const len = strlen(src);
		if (len >= N) return false;
		memcpy(dst, src, len + 1);
		return true;
	}
}


Service_def *Modem_orchestrator::add_service(Rules &r, char const *name, char const *path,
                                             char const *cls, bool disabled, bool oneshot)
{
	if (r.service_count == MAX_SERVICES) return nullptr;
	Service_def &s = r.services[r.service_count];
	s = Service_def { };
	if (!copy(s.name, name) || !copy(s.path, path) || !copy(s.cls, cls)) return nullptr;
	s.disabled = disabled;
	s.oneshot  = oneshot;
	r.service_count++;
	return &s;
}


bool Modem_orchestrator::add_arg(Service_def &s, char const *arg)
{
	if (s.argc == MAX_ARGS || !copy(s.args[s.argc], arg)) return false;
	s.argc++;
	return true;
}


Trigger *Modem_orchestrator::add_trigger(Rules &r, char const *event)
{
	if (r.trigger_count == MAX_TRIGGERS) return nullptr;
	Trigger &t = r.triggers[r.trigger_count];
	t = Trigger { };
	if (!copy(t.event, event)) return nullptr;
	t.first = r.command_count;
	r.trigger_count++;
	return &t;
}


bool Modem_orchestrator::add_condition(Trigger &t, char const *name, char const *value)
{
	if (t.cond_count == MAX_CONDS) return false;
	Condition &c = t.conds[t.cond_count];
	if (!copy(c.name, name) || !copy(c.value, value)) return false;
	t.cond_count++;
	return true;
}


bool Modem_orchestrator::add_command(Rules &r, Op op, char const *arg, char const *value, unsigned mode)
{
	if (!r.trigger_count || r.command_count == MAX_COMMANDS) return false;
	Command &c = r.commands[r.command_count];
	c = Command { };
	if (!copy(c.arg, arg) || !copy(c.value, value)) return false;
	c.op   = op;
	c.mode = mode;
	r.command_count++;
	r.triggers[r.trigger_count - 1].count++;
	return true;
}


bool Modem_orchestrator::add_phase(Profile &p, char const *name)
{
	if (p.phase_count == MAX_PHASES || !copy(p.phases[p.phase_count], name)) return false;
	p.phase_count++;
	return true;
}


bool Modem_orchestrator::add_class(Profile &p, char const *name)
{
	if (p.class_count == MAX_CLASSES || !copy(p.classes[p.class_count], name)) return false;
	p.class_count++;
	return true;
}


bool Modem_orchestrator::add_template(Profile &p, char const *service)
{
	if (p.template_count == MAX_SERVICES || !copy(p.templates[p.template_count], service)) return false;
	p.template_count++;
	return true;
}


bool Modem_orchestrator::add_gate(Profile &p, char const *service, char const *after,
                                  char const *when_name, char const *when_value)
{
	if (p.gate_count == MAX_SERVICES) return false;
	Gate &g = p.gates[p.gate_count];
	g = Gate { };
	if (!copy(g.service, service) || !copy(g.after, after)) return false;
	if (when_name && when_name[0]) {
		if (!copy(g.when.name, when_name) || !copy(g.when.value, when_value)) return false;
		g.has_when = true;
	}
	p.gate_count++;
	return true;
}


int Modem_orchestrator::find_service(Rules const &r, char const *name)
{
	for (unsigned i = 0; i < r.service_count; i++)
		if (!strcmp(r.services[i].name, name)) return int(i);
	return -1;
}
