/*
 * \brief  Modem orchestrator: runs the modem daemons like Android init
 * \author Ivan Loskutov
 * \date   2026-09-26
 *
 * ROM "rules" (tool/rc_to_rules of the Genode repository 'pixel') + ROM
 * "config" (device profile). The daemons are children of an embedded
 * Genode::Sandbox; the rule engine (lib modem_orchestrator) decides, this
 * component carries out. Config: README.
 */

/*
 * SPDX-License-Identifier: MIT
 */

#include <base/attached_dataspace.h>
#include <base/attached_rom_dataspace.h>
#include <base/heap.h>
#include <libc/component.h>
#include <sandbox/sandbox.h>
#include <timer_session/connection.h>
#include <util/string.h>

#include <android_prop/watcher.h>
#include <android_property_session/android_property_session.h>
#include <modem_orchestrator/engine.h>
#include <try_connection.h>

#include "config.h"

#include <errno.h>
#include <fcntl.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>

namespace Modem_orchestrator { struct Main; }


struct Modem_orchestrator::Main : Genode::Sandbox::State_handler, Actions, Android_prop::Change_source
{
	using Session    = Android_property_session::Session;
	using Connection = Genode_pixel::Try_connection<Session, Android_property_session::Session_client>;

	Genode::Env &env;
	Genode::Heap heap { env.ram(), env.rm() };

	Genode::Attached_rom_dataspace config    { env, "config" };
	Genode::Attached_rom_dataspace rules_rom { env, "rules" };

	Rules   &rules   = *new (heap) Rules   { };
	Profile &profile = *new (heap) Profile { };

	/* evaluate both, unconditionally, so every ROM's errors are logged */
	bool const rules_ok   = parse_rules(rules_rom.node(), rules);
	bool const profile_ok = parse_profile(config.node(), rules, profile);
	bool const config_ok  = rules_ok && profile_ok;

	Connection prop { env };

	Genode::Constructible<Genode::Attached_dataspace> table_ds    { };
	Genode::Constructible<Genode::Attached_dataspace> transfer_ds { };
	Genode::Constructible<Android_prop::Table>        table       { };
	Genode::Constructible<Android_prop::Watcher>      watcher     { };

	Genode::Signal_handler<Main> prop_handler { env.ep(), *this, &Main::handle_properties };

	/*
	 * A missing child must be reported to the engine only once its current
	 * action has fully returned (see '_reap_missing'): calling
	 * 'engine->service_exited' while still inside the engine's own
	 * 'Actions::start' (itself called from 'Engine::_start_now', before
	 * 'Engine::_set_state' has run) would hit the engine's "only a running
	 * service can exit" guard and be silently dropped. This handler defers
	 * the check to the next dispatch of the entrypoint, by which time the
	 * engine has finished processing the action that changed 'children'.
	 */
	Genode::Signal_handler<Main> reap_handler { env.ep(), *this, &Main::handle_reap };

	Genode::Sandbox sandbox { env, *this };

	Timer::Connection timer_conn { env };
	Timer::One_shot_timeout<Main> restart_timeout { timer_conn, *this, &Main::handle_timeout };

	/*
	 * 'Timer::Connection' dispatches 'Timer::One_shot_timeout' through an
	 * Io_signal_handler, so 'handle_timeout' can run nested inside a
	 * libc-blocked VFS call still on the entrypoint's stack (e.g. a 'write'
	 * done from within 'Engine::_execute', itself called from this timeout
	 * were it to run the engine directly). 'handle_timeout' therefore only
	 * submits this plain 'Genode::Signal_handler' -- like 'reap_handler' --
	 * which the entrypoint dispatches from the top of its loop, after the
	 * blocked call has returned.
	 */
	Genode::Signal_handler<Main> timer_handler { env.ep(), *this, &Main::handle_timer_signal };

	Genode::Constructible<Engine> engine { };

	/* running children: expanded argv and a version to restart a child */
	struct Child
	{
		bool     running;
		unsigned version;
		unsigned argc;
		char     argv[MAX_ARGS + 1][TEXT_LEN];
	};
	Child children[MAX_SERVICES] { };

	/*
	 * Change_source: the transfer dataspace is the watcher's buffer
	 */
	Android_prop::Change_queue::Fetch fetch(Android_prop::Change *, unsigned) override
	{
		Session::Fetch_result const f = prop.client().changes();
		return { f.count, f.overflow != 0 };
	}

	/*
	 * Actions
	 */
	void log(char const *line) override { Genode::log("modem_orchestrator: ", Genode::Cstring(line)); }

	unsigned long now_ms() override { return (unsigned long)timer_conn.elapsed_ms(); }

	void timer(unsigned long ms) override { restart_timeout.schedule(Genode::Microseconds { ms * 1000 }); }

	bool get_property(char const *name, char *buf, unsigned len) override
	{
		Android_prop::Slot const *s = table->find(name);
		if (!s) return false;
		static_assert(unsigned(VALUE_LEN) >= unsigned(Android_prop::LONG_VALUE_MAX));
		char value[Android_prop::LONG_VALUE_MAX];
		table->read_full(*s, value);
		Genode::copy_cstring(buf, value, len);
		return true;
	}

	void forget_property_changes() override { watcher->snapshot(); }

	void set_property(char const *name, char const *value) override
	{
		if (::strlen(value) >= Session::SET_VALUE_MAX - 1) {
			Genode::warning("modem_orchestrator: setprop ", Genode::Cstring(name), ": value too long");
			return;
		}
		Session::Set_result const r = prop.client().set(Session::Name(Genode::Cstring(name)),
		                                                Session::Value(Genode::Cstring(value)));
		/* the rules act on properties: a lost 'init.svc.*' stalls the stack */
		if (r != Session::Set_result::OK)
			Genode::error("modem_orchestrator: setprop ", Genode::Cstring(name), " refused -- "
			              "property triggers on it will not fire");
	}

	/* below /data and without a ".." element that could lead out of it */
	static bool below_data(char const *path)
	{
		if (::strncmp(path, "/data/", 6)) return false;
		for (char const *p = path; (p = ::strstr(p, "/..")); p += 3)
			if (p[3] == '/' || p[3] == 0) return false;
		return true;
	}

	bool mkdir(char const *path, unsigned mode) override
	{
		if (!below_data(path)) { log("skipped (outside /data)"); return true; }
		return ::mkdir(path, mode ? mode : 0755) == 0 || errno == EEXIST;
	}

	bool write(char const *path, char const *text) override
	{
		if (!below_data(path)) { log("skipped (outside /data)"); return true; }
		int const fd = ::open(path, O_WRONLY | O_CREAT | O_TRUNC, 0644);
		if (fd < 0) return false;
		size_t const len = ::strlen(text);
		bool const ok = ::write(fd, text, len) == ssize_t(len);
		return (::close(fd) == 0) && ok;
	}

	bool rm(char const *path) override
	{
		if (!below_data(path)) { log("skipped (outside /data)"); return true; }
		return ::unlink(path) == 0 || errno == ENOENT;
	}

	void start(char const *service, char const * const *argv, unsigned argc) override
	{
		int const i = find_service(rules, service);
		if (i < 0) return;
		Child &c = children[i];
		c.running = true;
		c.version++;
		c.argc = argc;
		for (unsigned k = 0; k < argc && k <= MAX_ARGS; k++)
			Genode::copy_cstring(c.argv[k], argv[k], sizeof(c.argv[k]));
		apply_sandbox_config();
	}

	void stop(char const *service) override
	{
		int const i = find_service(rules, service);
		if (i < 0) return;
		children[i].running = false;
		apply_sandbox_config();
	}

	/*
	 * Sandbox config
	 */
	void with_template(char const *service, auto const &fn)
	{
		config.node().for_each_sub_node("template", [&] (Genode::Node const &t) {
			if (t.attribute_value("service", Text()) == service) fn(t); });
	}

	void generate(Genode::Generator &g)
	{
		using namespace Genode;

		config.node().with_optional_sub_node("parent-provides", [&] (Node const &pp) {
			g.append_node(pp); });

		/*
		 * Services of the daemons offered to our parent (init's service
		 * forwarding, e.g. ril-daemon's Android_binder for rild_modem):
		 * copied as they are. A request for a daemon that is not running
		 * stays pending until the daemon has been started.
		 */
		config.node().for_each_sub_node("service", [&] (Node const &s) {
			g.append_node(s); });

		/* a template's own <route> (if any) overrides this per <start> */
		g.node("default-route", [&] { g.node("any-service", [&] { g.node("parent"); }); });

		g.node("report", [&] { g.attribute("delay_ms", 100); });

		for (unsigned i = 0; i < rules.service_count; i++) {
			Child const &c = children[i];
			if (!c.running) continue;
			char const *name = rules.services[i].name;
			with_template(name, [&] (Node const &t) {
				g.node("start", [&] {
					g.attribute("name",    name);
					g.attribute("caps",    t.attribute_value("caps", 300U));
					g.attribute("ram",     t.attribute_value("ram", String<16>("64M")));
					g.attribute("version", c.version);
					g.node("binary", [&] { g.attribute("name", "android_loader"); });
					t.with_optional_sub_node("provides", [&] (Node const &p) {
						g.append_node(p); });
					g.node("config", [&] {
						t.with_optional_sub_node("loader", [&] (Node const &l) { g.node_attributes(l); });
						g.attribute("program", c.argv[0]);
						for (unsigned k = 0; k < c.argc; k++)
							g.node("arg", [&] { g.attribute("value", c.argv[k]); });
						t.with_optional_sub_node("loader", [&] (Node const &l) {
							g.append_node_content(l); });
					});
					t.with_optional_sub_node("route", [&] (Node const &r) {
						g.append_node(r); });
				});
			});
		}
	}

	/*
	 * Generate and apply the sandbox config only -- no state-report side
	 * effects (used both directly and by '_reap_missing', which must not
	 * recurse into itself through the public 'apply_sandbox_config').
	 */
	void _apply_config()
	{
		Genode::Generated_node(heap, 256*1024, "config", [&] (Genode::Generator &g) {
			generate(g); }
		).node.with_result(
			[&] (Genode::Node const &cfg) { sandbox.apply_config(cfg); },
			[&] (auto) { Genode::error("modem_orchestrator: sandbox config too large"); });
	}

	/*
	 * A child whose creation failed (e.g. insufficient quota, a bad
	 * <start> node) is never added to the sandbox's own state report --
	 * unlike a child that started and then exited, it has no <child>
	 * entry at all. Such a failure may also never raise
	 * 'handle_sandbox_state' on its own, so 'apply_sandbox_config' also
	 * triggers this check (via 'reap_handler', not a direct call -- see
	 * there) after every '_apply_config()', as well as at the end of the
	 * asynchronous state handler. A service still marked 'running' here
	 * but absent from the report (for its current version) is treated
	 * like an exit with value -1. Loops instead of recursing: each round
	 * removes at least one service and 'rules.service_count' is small.
	 *
	 * A real 'Sandbox::Library' creation failure can affect more than the
	 * one failing '<start>' node: 'Config_model::apply_config' (repos/os/
	 * src/lib/sandbox/config_model.cc) wraps its whole
	 * '_model.update_from_node(...)' call -- which walks every child of
	 * the generated '<config>' in order -- in one try/catch for
	 * 'Start_model::Factory::Creation_failed'; the moment one '<start>'
	 * node's construction throws, the walk stops and every later '<start>'
	 * node in that same 'apply_config' is never created either (just
	 * "child creation failed" is logged once). Those later children are
	 * indistinguishable here from ones this component simply never
	 * started -- they get no '<child>' entry at all -- so this same
	 * '_reap_missing' loop is what would notice and count them as exits
	 * (-1) too, on the next dispatch.
	 */
	void _reap_missing()
	{
		for (;;) {
			bool     seen[MAX_SERVICES] { };
			unsigned missing[MAX_SERVICES], n = 0;
			bool     reported = true;

			Genode::Generated_node(heap, 64*1024, "state", [&] (Genode::Generator &g) {
				sandbox.generate_state_report(g); }
			).node.with_result(
				[&] (Genode::Node const &state) {
					state.for_each_sub_node("child", [&] (Genode::Node const &child) {
						Text const name = child.attribute_value("name", Text());
						int const i = find_service(rules, name.string());
						if (i >= 0 && child.attribute_value("version", 0U) == children[i].version)
							seen[i] = true;
					});
				},
				[&] (auto) {
					Genode::error("modem_orchestrator: state report too large");
					reported = false; });

			/* without a report, no child is known to be missing */
			if (!reported) return;

			for (unsigned i = 0; i < rules.service_count; i++)
				if (children[i].running && !seen[i]) missing[n++] = i;

			if (!n) return;

			for (unsigned k = 0; k < n; k++) {
				char const *name = rules.services[missing[k]].name;
				Genode::log("modem_orchestrator: ", Genode::Cstring(name),
				            ": not in the sandbox -- counted as an exit");
				children[missing[k]].running = false;
			}
			_apply_config();
			for (unsigned k = 0; k < n; k++) {
				char const *name = rules.services[missing[k]].name;
				Libc::with_libc([&] { engine->service_exited(name, -1); });
			}
		}
	}

	void apply_sandbox_config()
	{
		_apply_config();
		/* deferred to 'handle_reap' -- see 'reap_handler' */
		Genode::Signal_transmitter(reap_handler).submit();
	}

	void handle_reap() { Libc::with_libc([&] { _reap_missing(); }); }

	/*
	 * Sandbox::State_handler: exits
	 */
	void handle_sandbox_state() override
	{
		Genode::Generated_node(heap, 64*1024, "state", [&] (Genode::Generator &g) {
			sandbox.generate_state_report(g); }
		).node.with_result(
			[&] (Genode::Node const &state) {
				state.for_each_sub_node("child", [&] (Genode::Node const &child) {
					if (!child.has_attribute("exited")) return;
					Text const name = child.attribute_value("name", Text());
					int const i = find_service(rules, name.string());
					if (i < 0 || !children[i].running) return;
					if (child.attribute_value("version", 0U) != children[i].version) return;
					int const value = child.attribute_value("exited", 0);
					children[i].running = false;
					_apply_config();
					Libc::with_libc([&] { engine->service_exited(name.string(), value); });
				});
			},
			[&] (auto) { Genode::error("modem_orchestrator: state report too large"); });

		_reap_missing();
	}

	void handle_timer_signal() { Libc::with_libc([&] { engine->timer_expired(); }); }

	void handle_timeout(Genode::Duration) { Genode::Signal_transmitter(timer_handler).submit(); }

	void handle_properties()
	{
		Libc::with_libc([&] {
			bool const overflowed = watcher->poll([&] (Android_prop::Slot const &s, char const *value) {
				engine->property_changed(s.name, value); });
			if (overflowed)
				Genode::warning("modem_orchestrator: property queue overflow -- intermediate values lost");
		});
	}

	Main(Genode::Env &env) : env(env)
	{
		if (!config_ok) {
			Genode::error("modem_orchestrator: invalid rules or config -- starting nothing");
			return;
		}
		if (prop.open("properties") != Connection::Result::OK) {
			Genode::error("modem_orchestrator: Android_property session refused");
			::exit(1);
		}
		table_ds.construct(env.rm(), prop.client().table());
		transfer_ds.construct(env.rm(), prop.client().transfer());
		table.construct(table_ds->local_addr<void>());
		if (!table->valid()) { Genode::error("modem_orchestrator: bad property table"); ::exit(1); }
		watcher.construct(*table, *this, transfer_ds->local_addr<Android_prop::Change>(),
		                  unsigned(Session::TRANSFER_SIZE / sizeof(Android_prop::Change)));
		watcher->snapshot();
		prop.client().wait_sigh(prop_handler);

		apply_sandbox_config();
		engine.construct(rules, profile, *this);
		engine->boot();
		handle_properties();   /* changes made during boot */
	}
};


void Libc::Component::construct(Libc::Env &env)
{
	Libc::with_libc([&] { static Modem_orchestrator::Main main(env); });
}
