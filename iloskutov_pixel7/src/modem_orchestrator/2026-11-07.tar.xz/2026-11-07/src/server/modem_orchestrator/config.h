/*
 * \brief  Fill the engine's rules and profile from the orchestrator's ROMs
 * \author Ivan Loskutov
 * \date   2026-09-26
 */

/*
 * SPDX-License-Identifier: MIT
 */

#ifndef _MODEM_ORCHESTRATOR__CONFIG_H_
#define _MODEM_ORCHESTRATOR__CONFIG_H_

#include <base/log.h>
#include <base/node.h>
#include <modem_orchestrator/rules.h>
#include <util/string.h>

#include <stdlib.h>
#include <string.h>

namespace Modem_orchestrator {

	using Text = Genode::String<TEXT_LEN + 1>;   /* +1: an over-long value is detected */

	/**
	 * \return false on a malformed rule (logged)
	 */
	inline bool parse_rules(Genode::Node const &node, Rules &r)
	{
		using namespace Genode;
		bool ok = true;
		auto fail = [&] (auto &&... args) { error("modem_orchestrator: rules: ", args...); ok = false; };

		if (!node.has_type("rules")) fail("root node '", node.type(), "' is not <rules> (malformed ROM?)");

		node.for_each_sub_node([&] (Node const &n) {
			if (n.has_type("service")) {
				Service_def *s = add_service(r,
					n.attribute_value("name",  Text()).string(),
					n.attribute_value("path",  Text()).string(),
					n.attribute_value("class", Text("default")).string(),
					n.attribute_value("disabled", false),
					n.attribute_value("oneshot",  false));
				if (!s) { fail("service '", n.attribute_value("name", Text()), "' invalid or too many"); return; }
				n.for_each_sub_node("arg", [&] (Node const &a) {
					if (!add_arg(*s, a.attribute_value("value", Text()).string()))
						fail("service '", Cstring(s->name), "': argument invalid or too many"); });
				return;
			}
			if (n.has_type("on")) {
				Trigger *t = add_trigger(r, n.attribute_value("event", Text()).string());
				if (!t) { fail("too many triggers"); return; }
				n.for_each_sub_node([&] (Node const &c) {
					auto attr = [&] (char const *a) { return c.attribute_value(a, Text()); };
					bool added = true;
					if      (c.has_type("property"))    added = add_condition(*t, attr("name").string(), attr("value").string());
					else if (c.has_type("start"))       added = add_command(r, Op::START,   attr("service").string());
					else if (c.has_type("stop"))        added = add_command(r, Op::STOP,    attr("service").string());
					else if (c.has_type("restart"))     added = add_command(r, Op::RESTART, attr("service").string());
					else if (c.has_type("setprop"))     added = add_command(r, Op::SETPROP, attr("name").string(), attr("value").string());
					else if (c.has_type("mkdir"))       added = add_command(r, Op::MKDIR,   attr("path").string(), "",
					                                                        unsigned(strtoul(attr("mode").string(), nullptr, 8)));
					else if (c.has_type("write"))       added = add_command(r, Op::WRITE,   attr("path").string(), attr("value").string());
					else if (c.has_type("rm"))          added = add_command(r, Op::RM,      attr("path").string());
					else if (c.has_type("class_start")) added = add_command(r, Op::CLASS_START, attr("name").string());
					else if (c.has_type("class_stop"))  added = add_command(r, Op::CLASS_STOP,  attr("name").string());
					else { fail("unknown element '", c.type(), "' in <on>"); return; }
					if (!added) fail("<", c.type(), "> of <on line=\"", n.attribute_value("line", 0U), "\"> invalid or too many");
				});
				return;
			}
			if (n.has_type("unsupported")) {
				log("modem_orchestrator: unsupported ", n.attribute_value("file", Text()), ":",
				    n.attribute_value("line", 0U), ": ", n.attribute_value("command", Text()));
				return;
			}
			fail("unknown top-level element '", n.type(), "'");
		});
		return ok;
	}

	/**
	 * \param r  the rules, already parsed
	 *
	 * \return false on a malformed profile (logged)
	 */
	inline bool parse_profile(Genode::Node const &cfg, Rules const &r, Profile &p)
	{
		using namespace Genode;
		bool ok = true;
		auto fail = [&] (auto &&... args) { error("modem_orchestrator: config: ", args...); ok = false; };

		if (!cfg.has_type("config")) fail("root node '", cfg.type(), "' is not <config> (malformed ROM?)");

		if (cfg.has_sub_node("phases")) {
			cfg.with_optional_sub_node("phases", [&] (Node const &phases) {
				phases.for_each_sub_node("phase", [&] (Node const &ph) {
					if (!add_phase(p, ph.attribute_value("name", Text()).string())) fail("bad <phase>"); }); });
		} else {
			static char const * const default_phases[] {
				"early-init", "init", "fs", "post-fs-data", "boot" };
			for (char const *ph : default_phases) add_phase(p, ph);
		}

		cfg.for_each_sub_node("class_start", [&] (Node const &c) {
			if (!add_class(p, c.attribute_value("name", Text()).string())) fail("bad <class_start>"); });
		if (!p.class_count) add_class(p, "main");

		cfg.for_each_sub_node("template", [&] (Node const &t) {
			Text const service = t.attribute_value("service", Text());

			bool duplicate = false;
			for (unsigned k = 0; k < p.template_count; k++)
				if (!::strcmp(p.templates[k], service.string())) duplicate = true;
			if (duplicate) { fail("duplicate <template service=\"", service, "\">"); return; }

			/*
			 * 'program' and '<arg>' are generated by the orchestrator
			 * itself, from the running service's own path and its (already
			 * expanded) .rc arguments -- see 'Main::generate'. A profile
			 * that sets either would silently override the actual
			 * command line with a stale or wrong one, so it is a config
			 * error instead.
			 */
			bool loader_bad = false;
			t.with_optional_sub_node("loader", [&] (Node const &l) {
				if (l.has_attribute("program")) {
					fail("<template service=\"", service, "\">: <loader> must not set program=");
					loader_bad = true;
				}
				if (l.has_sub_node("arg")) {
					fail("<template service=\"", service, "\">: <loader> must not have <arg>");
					loader_bad = true;
				}
			});
			if (loader_bad) return;

			if (!add_template(p, service.string())) { fail("bad <template service=\"", service, "\">"); return; }
			Text const after = t.attribute_value("after", Text());
			Text const when  = t.attribute_value("when",  Text());
			if (after.length() <= 1 && when.length() <= 1) return;   /* no gate */
			if (after.length() > 1 && find_service(r, after.string()) < 0) {
				fail("<template service=\"", service, "\">: after=\"", after, "\" is no service of the rules");
				return;
			}
			char name[PROP_LEN] { }, value[TEXT_LEN] { };
			if (when.length() > 1) {
				char const *s  = when.string();
				char const *eq = strchr(s, '=');
				if (!eq || eq == s || size_t(eq - s) >= sizeof(name)) { fail("bad when=\"", when, "\""); return; }
				Genode::memcpy(name, s, size_t(eq - s));
				copy_cstring(value, eq + 1, sizeof(value));
			}
			if (!add_gate(p, service.string(), after.string(), name, value))
				fail("bad gate of '", service, "'");
		});
		return ok;
	}
}

#endif /* _MODEM_ORCHESTRATOR__CONFIG_H_ */
