/*
 * \brief  LVGL on Genode GUI sessions
 * \author Ivan Loskutov
 * \date   2026-11-11
 */

/*
 * SPDX-License-Identifier: MIT
 */

#include <base/log.h>
#include <stdlib.h>
#include <string.h>
#include <input/event.h>
#include <libc/component.h>

#include "lvgl_genode.h"

using namespace Genode;


/* LVGL's tick callback carries no context */
static Timer::Connection *_tick_timer;


uint32_t Lvgl_genode::Runtime::_tick()
{
	return uint32_t(_tick_timer->curr_time().trunc_to_plain_ms().value);
}


void Lvgl_genode::Runtime::run()
{
	if (_in_lvgl) {
		_again = true;
		return;
	}

	uint32_t next_ms = 0;
	_in_lvgl = true;
	Libc::with_libc([&] {
		do {
			_again  = false;
			next_ms = lv_timer_handler();
		} while (_again);
	});
	_in_lvgl = false;

	/* LV_NO_TIMER_READY: nothing pending, a signal wakes us up */
	if (next_ms != LV_NO_TIMER_READY)
		_timeout.schedule(Microseconds { 1000*uint64_t(next_ms ? next_ms : 1) });
}


static void _log(lv_log_level_t, char const *msg)
{
	/* LVGL's message ends with a newline */
	size_t len = ::strlen(msg);
	while (len && (msg[len - 1] == '\n' || msg[len - 1] == '\r'))
		len--;
	log("lvgl: ", Cstring(msg, len));
}


Lvgl_genode::Runtime::Runtime(Env &env) : _env(env)
{
	_tick_timer = &_timer;

	Libc::with_libc([&] {
		lv_init();
		lv_log_register_print_cb(_log);
		lv_tick_set_cb(_tick);
	});
}


void Lvgl_genode::Window::_flush(lv_display_t *display, lv_area_t const *area, uint8_t *px)
{
	Lvgl_genode::Window &w = *(Lvgl_genode::Window *)lv_display_get_user_data(display);

	unsigned const width  = unsigned(area->x2 - area->x1 + 1),
	               height = unsigned(area->y2 - area->y1 + 1);

	/* the finished area (packed rows) into the session's buffer */
	size_t const line = width*4, fb_line = w._size.w*4;
	uint8_t * const fb  = w._fb->local_addr<uint8_t>();
	uint8_t       *dst = fb + area->y1*fb_line + area->x1*4;

	/* with alpha, the alpha bytes and the input mask follow the pixels */
	size_t const   pixels = w._size.count();
	uint8_t       *alpha  = fb + pixels*4 + area->y1*w._size.w + area->x1;
	uint8_t       *input  = alpha + pixels;

	for (unsigned y = 0; y < height; y++, dst += fb_line, px += line) {
		::memcpy(dst, px, line);
		if (!w._alpha)
			continue;

		/* ARGB8888: the alpha is the fourth byte of a pixel */
		for (unsigned x = 0; x < width; x++) {
			uint8_t const a = px[x*4 + 3];
			alpha[x] = a;
			input[x] = a ? 1 : 0;
		}
		alpha += w._size.w;
		input += w._size.w;
	}

	w._gui.framebuffer.refresh(Gui::Rect { Gui::Point { area->x1, area->y1 },
	                                       Area { width, height } });
	lv_display_flush_ready(display);
}


void Lvgl_genode::Window::_read_pointer(lv_indev_t *indev, lv_indev_data_t *data)
{
	Lvgl_genode::Window &w = *(Lvgl_genode::Window *)lv_indev_get_user_data(indev);
	Pointer_state &s = w._pointer_state;

	data->point.x = s.x;
	data->point.y = s.y;

	/* a tap shorter than LVGL's read period is still seen as a press */
	bool const pressed = s.pressed || s.unread;
	data->state = pressed ? LV_INDEV_STATE_PRESSED : LV_INDEV_STATE_RELEASED;
	s.unread = false;

	if (w._verbose_input && pressed != s.read_pressed)
		log("lvgl: ", lv_tick_get(), " ms: read ", pressed ? "press" : "release",
		    " at ", s.x, ",", s.y);
	s.read_pressed = pressed;
}


void Lvgl_genode::Window::_read_keypad(lv_indev_t *indev, lv_indev_data_t *data)
{
	Lvgl_genode::Window &w = *(Lvgl_genode::Window *)lv_indev_get_user_data(indev);

	if (w._keys_tail == w._keys_head) {
		data->key   = w._last_key;
		data->state = LV_INDEV_STATE_RELEASED;
		return;
	}

	Key const key = w._keys[w._keys_tail];
	w._keys_tail = (w._keys_tail + 1) % KEYS;

	data->key   = key.key;
	data->state = key.pressed ? LV_INDEV_STATE_PRESSED : LV_INDEV_STATE_RELEASED;
	data->continue_reading = (w._keys_tail != w._keys_head);
}


void Lvgl_genode::Window::_push_key(uint32_t key, bool pressed)
{
	unsigned const next = (_keys_head + 1) % KEYS;
	if (next == _keys_tail)
		return;   /* LVGL is behind, drop the key */

	_keys[_keys_head] = { key, pressed };
	_keys_head = next;
}


/*
 * LVGL's key of an input event: a control key as LVGL's key code, a
 * character as UTF-8 in the bytes of the value (as 'lv_textarea_add_char'
 * takes it), 0 for no key
 */
static uint32_t _lvgl_key(Input::Keycode key, Codepoint c)
{
	switch (key) {
	case Input::KEY_BACKSPACE: return LV_KEY_BACKSPACE;
	case Input::KEY_DELETE:    return LV_KEY_DEL;
	case Input::KEY_ENTER:
	case Input::KEY_KPENTER:   return LV_KEY_ENTER;
	case Input::KEY_ESC:       return LV_KEY_ESC;
	case Input::KEY_HOME:      return LV_KEY_HOME;
	case Input::KEY_END:       return LV_KEY_END;
	case Input::KEY_LEFT:      return LV_KEY_LEFT;
	case Input::KEY_RIGHT:     return LV_KEY_RIGHT;
	case Input::KEY_UP:        return LV_KEY_UP;
	case Input::KEY_DOWN:      return LV_KEY_DOWN;
	default: break;
	}

	if (!c.valid() || c.value < 0x20)
		return 0;

	char utf8[4] { };
	unsigned len = 0;
	uint32_t const v = c.value;
	if (v < 0x80) {
		utf8[len++] = char(v);
	} else if (v < 0x800) {
		utf8[len++] = char(0xc0 | (v >> 6));
		utf8[len++] = char(0x80 | (v & 0x3f));
	} else if (v < 0x10000) {
		utf8[len++] = char(0xe0 | (v >> 12));
		utf8[len++] = char(0x80 | ((v >> 6) & 0x3f));
		utf8[len++] = char(0x80 | (v & 0x3f));
	} else {
		utf8[len++] = char(0xf0 | (v >> 18));
		utf8[len++] = char(0x80 | ((v >> 12) & 0x3f));
		utf8[len++] = char(0x80 | ((v >> 6) & 0x3f));
		utf8[len++] = char(0x80 | (v & 0x3f));
	}
	uint32_t key_value = 0;
	::memcpy(&key_value, utf8, len);
	return key_value;
}


void Lvgl_genode::Window::_apply_size(Area size)
{
	if (size == _size || !size.count())
		return;

	_size = size;

	_gui.buffer({ .area = size, .alpha = _alpha });
	_fb.construct(_env.rm(), _gui.framebuffer.dataspace());
	if (_view.constructed())
		_view->area(size);
	else
		_view.construct(_gui, Gui::Rect { Gui::Point { 0, 0 }, size });

	uint32_t const buf_size = uint32_t(size.count()*4);

	Libc::with_libc([&] {

		uint8_t * const old_buf = _render_buf;
		_render_buf = (uint8_t *)aligned_alloc(64, buf_size);

		if (!_display) {
			_display = lv_display_create(int32_t(size.w), int32_t(size.h));
			lv_display_set_user_data(_display, this);
			lv_display_set_color_format(_display, _alpha ? LV_COLOR_FORMAT_ARGB8888
			                                             : LV_COLOR_FORMAT_XRGB8888);
			lv_display_set_buffers(_display, _render_buf, nullptr, buf_size,
			                       LV_DISPLAY_RENDER_MODE_PARTIAL);
			lv_display_set_flush_cb(_display, _flush);

			_pointer = lv_indev_create();
			lv_indev_set_user_data(_pointer, this);
			lv_indev_set_type(_pointer, LV_INDEV_TYPE_POINTER);
			lv_indev_set_read_cb(_pointer, _read_pointer);
			lv_indev_set_display(_pointer, _display);

			_group  = lv_group_create();
			_keypad = lv_indev_create();
			lv_indev_set_user_data(_keypad, this);
			lv_indev_set_type(_keypad, LV_INDEV_TYPE_KEYPAD);
			lv_indev_set_read_cb(_keypad, _read_keypad);
			lv_indev_set_display(_keypad, _display);
			lv_indev_set_group(_keypad, _group);

			/* objects that take keys, created by 'create', join the group */
			lv_group_set_default(_group);
			_ui.create(*_display);
			lv_group_set_default(nullptr);

			/*
			 * A translucent window shows only what the interface draws, set
			 * after 'create': a theme styles the screen and the layer below
			 */
			if (_alpha) {
				lv_obj_set_style_bg_opa(lv_display_get_screen_active(_display), LV_OPA_TRANSP, 0);
				lv_obj_set_style_bg_opa(lv_display_get_layer_bottom(_display),  LV_OPA_TRANSP, 0);
			}
		} else {
			lv_display_set_resolution(_display, int32_t(size.w), int32_t(size.h));
			lv_display_set_buffers(_display, _render_buf, nullptr, buf_size,
			                       LV_DISPLAY_RENDER_MODE_PARTIAL);
			_ui.resized(*_display);
			lv_obj_invalidate(lv_display_get_screen_active(_display));
		}
		free(old_buf);
	});

	log("lvgl: ", _gui_label, " ", size.w, "x", size.h);
}


void Lvgl_genode::Window::_handle_mode()
{
	/* not in the middle of LVGL's round: retry from the entrypoint */
	if (_runtime.in_lvgl()) {
		Signal_transmitter(_mode_handler).submit();
		return;
	}

	/*
	 * The window the window manager assigns, or the screen; before the
	 * window manager assigned one, the screen as a first size
	 */
	Area size { };
	_gui.window().with_result(
		[&] (Gui::Rect rect) { size = rect.area; },
		[&] (Gui::Undefined) {
			_gui.panorama().with_result(
				[&] (Gui::Rect rect) { if (!_display) size = rect.area; },
				[&] (Gui::Undefined) { }); });

	_apply_size(size);
	_runtime.run();
}


void Lvgl_genode::Window::_handle_input()
{
	Pointer_state &s = _pointer_state;

	_gui.input.for_each_event([&] (Input::Event const &ev) {

		if (_verbose_input)
			log("lvgl: ", lv_tick_get(), " ms: input ", ev);

		/*
		 * Touch: the position of the finger that touched first, followed
		 * until all fingers are lifted (other fingers are ignored); press
		 * and release by BTN_TOUCH, as LVGL's evdev driver on Linux
		 */
		ev.handle_touch([&] (Input::Touch_id id, float x, float y) {
			s.touch = true;
			if (!s.finger_valid) {
				s.finger       = id.value;
				s.finger_valid = true;
			}
			if (id.value == s.finger) {
				s.x = int(x); s.y = int(y); }
		});

		ev.handle_touch_release([&] (Input::Touch_id id) {
			if (s.finger_valid && id.value == s.finger)
				s.pressed = false; });

		/*
		 * A mouse: absolute motion and BTN_LEFT. Not with a touchscreen:
		 * the GUI server then sends its pointer position after a release
		 * (once seen: the middle of the screen), which would move the
		 * release away from the finger.
		 */
		ev.handle_absolute_motion([&] (int x, int y) {
			if (!s.touch) { s.x = x; s.y = y; } });

		if (ev.key_press(Input::BTN_TOUCH) || ev.key_press(Input::BTN_LEFT)) {
			if (!s.pressed) s.unread = true;
			s.pressed = true;
		}

		if (ev.key_release(Input::BTN_TOUCH)) {
			s.pressed      = false;
			s.finger_valid = false;
		}

		if (ev.key_release(Input::BTN_LEFT))
			s.pressed = false;

		/* keys, not the buttons of the pointer */
		ev.handle_press([&] (Input::Keycode key, Codepoint c) {
			if (key == Input::BTN_TOUCH || key == Input::BTN_LEFT)
				return;
			uint32_t const lv_key = _lvgl_key(key, c);
			if (!lv_key)
				return;

			/*
			 * LVGL takes a key at the change from released to pressed:
			 * a key pressed while another one is held (fast typing, key
			 * repeat) needs the release of that one first
			 */
			if (_key_down)
				_push_key(_last_key, false);

			_last_key  = lv_key;
			_last_code = key;
			_key_down  = true;
			_push_key(lv_key, true);
		});

		/* the release of the key LVGL knows as pressed, not of any other */
		ev.handle_release([&] (Input::Keycode key) {
			if (!_key_down || key != _last_code)
				return;
			_key_down = false;
			_push_key(_last_key, false);
		});
	});

	if (_display)
		_runtime.run();
}


Lvgl_genode::Window::Window(Env &env, Lvgl_genode::Runtime &runtime, Ui &ui, char const *label,
               bool verbose_input, Alpha alpha)
:
	_env(env), _runtime(runtime), _ui(ui), _verbose_input(verbose_input),
	_alpha(alpha == TRANSLUCENT),
	_gui_label(label), _gui(env, label)
{
	_gui.input.sigh(_input_handler);
	_gui.info_sigh(_mode_handler);

	_handle_mode();
}
