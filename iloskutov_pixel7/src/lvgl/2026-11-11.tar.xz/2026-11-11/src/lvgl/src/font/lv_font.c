/**
 * @file lv_font.c
 *
 */

/*********************
 *      INCLUDES
 *********************/

#include "lv_font_private.h"
#include "../misc/lv_text_private.h"
#include "../misc/lv_utils.h"

/*********************
 *      DEFINES
 *********************/

/**********************
 *      TYPEDEFS
 **********************/

/**********************
 *  STATIC PROTOTYPES
 **********************/

/**********************
 *  STATIC VARIABLES
 **********************/

/**********************
 *  GLOBAL VARIABLES
 **********************/

/**********************
 * GLOBAL PROTOTYPES
 **********************/

/**********************
 *      MACROS
 **********************/

/**********************
 *   GLOBAL FUNCTIONS
 **********************/

const void * lv_font_get_glyph_bitmap(lv_font_glyph_dsc_t * g_dsc, lv_draw_buf_t * draw_buf)
{
    LV_CHECK_ARG(g_dsc != NULL, return NULL);
    LV_CHECK_ARG(g_dsc->resolved_font != NULL, return NULL);

    return lv_font_get_glyph_bitmap_internal(g_dsc, draw_buf);
}

const void * lv_font_get_glyph_bitmap_internal(lv_font_glyph_dsc_t * g_dsc, lv_draw_buf_t * draw_buf)
{
    LV_ASSERT(g_dsc != NULL);
    LV_ASSERT(g_dsc->resolved_font != NULL);

    const lv_font_t * font_p = g_dsc->resolved_font;

    const uint8_t save_req = g_dsc->req_raw_bitmap;
    g_dsc->req_raw_bitmap = 0;
    const void * bitmap = font_p->get_glyph_bitmap(g_dsc, draw_buf);
    g_dsc->req_raw_bitmap = save_req;

    return bitmap;
}

const void * lv_font_get_glyph_static_bitmap(lv_font_glyph_dsc_t * g_dsc)
{
    LV_CHECK_ARG(g_dsc != NULL, return NULL);
    return lv_font_get_glyph_static_bitmap_internal(g_dsc);

}
const void * lv_font_get_glyph_static_bitmap_internal(lv_font_glyph_dsc_t * g_dsc)
{
    LV_ASSERT(g_dsc != NULL);
    LV_ASSERT(g_dsc->resolved_font != NULL);

    const lv_font_t * font_p = g_dsc->resolved_font;

    if(font_p->static_bitmap == 0) {
        LV_LOG_WARN("Requesting static bitmap of a non-static bitmap of %p font", (void *)font_p);
        return NULL;
    }

    const uint8_t save_req = g_dsc->req_raw_bitmap;
    g_dsc->req_raw_bitmap = 1;
    const void * bitmap = font_p->get_glyph_bitmap(g_dsc, NULL);
    g_dsc->req_raw_bitmap = save_req;

    return bitmap;
}

void lv_font_glyph_release_draw_data(lv_font_glyph_dsc_t * g_dsc)
{
    LV_CHECK_ARG(g_dsc != NULL, return);
    lv_font_glyph_release_draw_data_internal(g_dsc);
}

void lv_font_glyph_release_draw_data_internal(lv_font_glyph_dsc_t * g_dsc)
{
    LV_ASSERT(g_dsc != NULL);
    if(!g_dsc->entry) {
        return;
    }

    const lv_font_t * font = g_dsc->resolved_font;

    if(font != NULL && font->release_glyph) {
        font->release_glyph(font, g_dsc);
    }
}

bool lv_font_get_glyph_dsc(const lv_font_t * font, lv_font_glyph_dsc_t * dsc_out, uint32_t letter,
                           uint32_t letter_next)
{

    LV_CHECK_ARG(dsc_out != NULL, return false);
    LV_CHECK_ARG(font != NULL, return false);
    return lv_font_get_glyph_dsc_internal(font, dsc_out, letter, letter_next);
}

bool lv_font_get_glyph_dsc_internal(const lv_font_t * font, lv_font_glyph_dsc_t * dsc_out, uint32_t letter,
                                    uint32_t letter_next)
{

    LV_ASSERT(dsc_out != NULL);
    LV_ASSERT(font != NULL);

#if LV_USE_FONT_PLACEHOLDER
    const lv_font_t * placeholder_font = NULL;
#endif
    const lv_font_t * f = font;
    const bool has_kerning = f->kerning != LV_FONT_KERNING_NONE;

    lv_memzero(dsc_out, sizeof(lv_font_glyph_dsc_t));

    while(f) {
        bool found = f->get_glyph_dsc(f, dsc_out, letter,
                                      has_kerning ? letter_next : 0);
        if(found) {
            if(!dsc_out->is_placeholder) {
                dsc_out->resolved_font = f;
                return true;
            }
#if LV_USE_FONT_PLACEHOLDER
            else if(placeholder_font == NULL) {
                placeholder_font = f;
            }
#endif
        }
        f = f->fallback;
    }

#if LV_USE_FONT_PLACEHOLDER
    if(placeholder_font != NULL) {
        placeholder_font->get_glyph_dsc(placeholder_font, dsc_out, letter,
                                        has_kerning ? letter_next : 0);
        dsc_out->resolved_font = placeholder_font;
        return true;
    }
#endif

#if LV_USE_FONT_PLACEHOLDER
    dsc_out->box_w = font->line_height / 2;
    dsc_out->adv_w = dsc_out->box_w + 2;
#else
    dsc_out->box_w = 0;
    dsc_out->adv_w = 0;
#endif

    dsc_out->stride = 0;
    dsc_out->resolved_font = NULL;
    dsc_out->box_h = font->line_height;
    dsc_out->ofs_x = 0;
    dsc_out->ofs_y = 0;
    dsc_out->format = LV_FONT_GLYPH_FORMAT_A1;
    dsc_out->is_placeholder = true;

    return false;
}

uint16_t lv_font_get_glyph_width(const lv_font_t * font, uint32_t letter, uint32_t letter_next)
{
    LV_CHECK_ARG(font != NULL, return 0);
    return lv_font_get_glyph_width_internal(font, letter, letter_next);
}

uint16_t lv_font_get_glyph_width_internal(const lv_font_t * font, uint32_t letter, uint32_t letter_next)
{
    LV_ASSERT(font != NULL);
    lv_font_glyph_dsc_t g;

    /*Return zero if letter is marker*/
    if(lv_text_is_marker(letter)) return 0;

    lv_font_get_glyph_dsc_internal(font, &g, letter, letter_next);

    return g.adv_w;
}

void lv_font_set_kerning(lv_font_t * font, lv_font_kerning_t kerning)
{
    LV_CHECK_ARG(font != NULL, return);
    font->kerning = kerning;
}

int32_t lv_font_get_line_height(const lv_font_t * font)
{
    LV_CHECK_ARG(font != NULL, return 0);

    return lv_font_get_line_height_internal(font);
}


const lv_font_t * lv_font_get_default(void)
{
    return LV_FONT_DEFAULT;
}

bool lv_font_info_is_equal(const lv_font_info_t * ft_info_1, const lv_font_info_t * ft_info_2)
{
    LV_CHECK_ARG(ft_info_1 != NULL, return false);
    LV_CHECK_ARG(ft_info_2 != NULL, return false);

    bool is_equal = (ft_info_1->size == ft_info_2->size
                     && ft_info_1->style == ft_info_2->style
                     && ft_info_1->render_mode == ft_info_2->render_mode
                     && ft_info_1->weight == ft_info_2->weight
                     && ft_info_1->kerning == ft_info_2->kerning
                     && lv_strcmp(ft_info_1->name, ft_info_2->name) == 0);

    return is_equal;
}

bool lv_font_has_static_bitmap(const lv_font_t * font)
{
    LV_CHECK_ARG(font != NULL, return false);
    return lv_font_has_static_bitmap_internal(font);
}

int32_t lv_font_glyph_dsc_compare(const lv_font_glyph_dsc_t * lhs, const lv_font_glyph_dsc_t * rhs)
{
    LV_ASSERT(lhs != NULL);
    LV_ASSERT(rhs != NULL);
    if(lhs->resolved_font != rhs->resolved_font) {
        return (lv_uintptr_t)lhs->resolved_font > (lv_uintptr_t)rhs->resolved_font ? 1 : -1;
    }

    int32_t ret = lhs->format - rhs->format;
    if(ret != 0) {
        return ret;
    }

    if(lhs->format == LV_FONT_GLYPH_FORMAT_IMAGE) {
        if(lhs->gid.src == rhs->gid.src) {
            return 0;
        }
        return (lv_uintptr_t)lhs->gid.src > (lv_uintptr_t)rhs->gid.src ? 1 : -1;
    }

    if(lhs->gid.index == rhs->gid.index) {
        return 0;
    }
    return lhs->gid.index > rhs->gid.index ? 1 : -1;
}

/**********************
 *   STATIC FUNCTIONS
 **********************/
