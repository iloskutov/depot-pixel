/**
 * @file lv_svg_render.h
 *
 */

#ifndef LV_SVG_RENDER_H
#define LV_SVG_RENDER_H

/*********************
 *      INCLUDES
 *********************/
#include "../../lvgl_public.h"

#if LV_USE_SVG
#if !LV_USE_VECTOR_GRAPHIC
    #error "LV_USE_SVG requires LV_USE_VECTOR_GRAPHIC = 1"
#endif

#include "../../draw/lv_draw_vector_private.h"
#include "lv_svg_private.h"

/*********************
 *      DEFINES
 *********************/

#define LV_SVG_RENDER_OBJ(n) ((lv_svg_render_obj_t*)(n))

/**********************
 *      TYPEDEFS
 **********************/
struct _lv_svg_render_class;

typedef struct  _lv_svg_render_obj {
    struct _lv_svg_render_obj * next;
    lv_svg_tag_t tag;
    uint32_t flags;
    char * id;
    lv_vector_path_ctx_t dsc;
    lv_matrix_t matrix;

    /* for url(XXX) reference */
    struct _lv_svg_render_obj * head;
    char * fill_ref;
    char * stroke_ref;
    struct _lv_svg_render_class * clz;
} lv_svg_render_obj_t;

typedef struct _lv_svg_render_class {
    void (*set_paint_ref)(lv_svg_render_obj_t * obj, lv_vector_path_ctx_t * dsc,
                          const lv_svg_render_obj_t * target_obj, bool fill);

    void (*init)(lv_svg_render_obj_t * obj, const lv_svg_node_t * node);
    void (*render)(const lv_svg_render_obj_t * obj, lv_draw_vector_dsc_t * dsc, const lv_matrix_t * matrix);
    void (*set_attr)(lv_svg_render_obj_t * obj, lv_vector_path_ctx_t * dsc, const lv_svg_attr_t * attr);
    void (*get_bounds)(const lv_svg_render_obj_t * obj, lv_area_t * area);
    void (*get_size)(const lv_svg_render_obj_t * obj, uint32_t * size);
    void (*destroy)(lv_svg_render_obj_t * obj);
} lv_svg_render_class;


typedef struct {
    void (*load_image)(const char * image_url, lv_draw_image_dsc_t * img_dsc);
    const char * (*get_font_path)(const char * font_family);
} lv_svg_render_hal_t;

/**********************
 * GLOBAL PROTOTYPES
 **********************/

/**
 * @brief Initialize the SVG render
 * @param hal pointer to a structure with rendering functions
 */
void lv_svg_render_init(const lv_svg_render_hal_t * hal);

/**
 * @brief Create a new SVG render from an SVG document
 * @param svg_doc pointer to the SVG document
 * @return pointer to the new SVG render object
 */
lv_svg_render_obj_t * lv_svg_render_create(const lv_svg_node_t * svg_doc);

/**
 * @brief Delete an SVG render object
 * @param render pointer to the SVG render object to delete
 */
void lv_svg_render_delete(lv_svg_render_obj_t * render);

/**
 * @brief Get size of render objects
 * @param render pointer to the SVG render object
 * @return the bytes of SVG render objects
 */
uint32_t lv_svg_render_get_size(const lv_svg_render_obj_t * render);

/**
 * @brief Get viewport's width and height of the render object
 * @param render pointer to the SVG render object
 * @param width pointer to save the width of the viewport of the SVG render object
 * @param height pointer to save the height of the viewport of the SVG render object
 * @return lv_result_t, LV_RESULT_OK if success, LV_RESULT_INVALID if fail
 */
lv_result_t lv_svg_render_get_viewport_size(const lv_svg_render_obj_t * render, float * width, float * height);

/**
 * @brief Render an SVG object to a vector graphics
 * @param dsc pointer to the vector graphics descriptor
 * @param render pointer to the SVG render object to render
 */
void lv_draw_svg_render(lv_draw_vector_dsc_t * dsc, const lv_svg_render_obj_t * render);

/**********************
 *      MACROS
 **********************/

#endif /*LV_USE_SVG*/

#endif /*LV_SVG_RENDER_H*/
