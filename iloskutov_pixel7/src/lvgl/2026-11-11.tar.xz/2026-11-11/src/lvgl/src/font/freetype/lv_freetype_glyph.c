/**
 * @file lv_freetype_glyph.c
 *
 */

/*********************
 *      INCLUDES
 *********************/

#include "lv_freetype_private.h"

#if LV_USE_FREETYPE

#include "../../misc/cache/lv_cache.h"
#include "../../misc/cache/lv_cache_entry.h"

/*********************
 *      DEFINES
 *********************/

#define CACHE_NAME  "FREETYPE_GLYPH"

#if LV_FREETYPE_CACHE_FT_GLYPH_L1

    /** Number of sets - reuse the FreeType glyph count (must be power of 2) */
    #define GLYPH_L1_SETS       ((uint32_t)LV_FREETYPE_CACHE_FT_GLYPH_CNT)

    #if (LV_FREETYPE_CACHE_FT_GLYPH_CNT & (LV_FREETYPE_CACHE_FT_GLYPH_CNT - 1)) != 0
        #error "LV_FREETYPE_CACHE_FT_GLYPH_CNT must be power of 2 for L1 cache"
    #endif

    /** Associativity - fixed at 2-way, do NOT change */
    #define GLYPH_L1_WAYS       2u

    #define GLYPH_L1_SET_MASK   (GLYPH_L1_SETS - 1u)

#endif /* LV_FREETYPE_CACHE_FT_GLYPH_L1 */

/**********************
 *      TYPEDEFS
 **********************/

#if LV_FREETYPE_CACHE_FT_GLYPH_L1

typedef struct {
    uint32_t unicode;
    uint32_t size;
    lv_font_glyph_dsc_t dsc;
} glyph_l1_entry_t;

typedef struct {
    glyph_l1_entry_t ways[GLYPH_L1_WAYS];
    uint8_t lru_bits;
} glyph_l1_set_t;

#endif /* LV_FREETYPE_CACHE_FT_GLYPH_L1 */

typedef struct _lv_freetype_glyph_cache_data_t {
    uint32_t unicode;
    uint32_t size;

    lv_font_glyph_dsc_t glyph_dsc;
} lv_freetype_glyph_cache_data_t;

/**********************
 *  STATIC PROTOTYPES
 **********************/

static bool freetype_get_glyph_dsc_cb(const lv_font_t * font, lv_font_glyph_dsc_t * g_dsc, uint32_t unicode_letter,
                                      uint32_t unicode_letter_next);

static bool freetype_glyph_create_cb(lv_freetype_glyph_cache_data_t * data, void * user_data);
static void freetype_glyph_free_cb(lv_freetype_glyph_cache_data_t * data, void * user_data);
static lv_cache_compare_res_t freetype_glyph_compare_cb(const lv_freetype_glyph_cache_data_t * lhs,
                                                        const lv_freetype_glyph_cache_data_t * rhs);

#if LV_FREETYPE_CACHE_FT_GLYPH_L1
static inline uint32_t glyph_l1_hash(uint32_t unicode, uint32_t size);
static bool glyph_l1_lookup(lv_freetype_cache_node_t * node, uint32_t unicode, uint32_t size,
                            lv_font_glyph_dsc_t * out_dsc);
static void glyph_l1_fill(lv_freetype_cache_node_t * node, uint32_t unicode, uint32_t size,
                          const lv_font_glyph_dsc_t * dsc);
#endif /* LV_FREETYPE_CACHE_FT_GLYPH_L1 */
/**********************
 *  STATIC VARIABLES
 **********************/

/**********************
 *      MACROS
 **********************/

/**********************
 *   GLOBAL FUNCTIONS
 **********************/

lv_cache_t * lv_freetype_create_glyph_cache(uint32_t cache_size)
{
    lv_cache_ops_t ops = {
        .create_cb = (lv_cache_create_cb_t)freetype_glyph_create_cb,
        .free_cb = (lv_cache_free_cb_t)freetype_glyph_free_cb,
        .compare_cb = (lv_cache_compare_cb_t)freetype_glyph_compare_cb,
    };

    lv_cache_t * glyph_cache = lv_cache_create(&lv_cache_class_lru_rb_count, sizeof(lv_freetype_glyph_cache_data_t),
                                               cache_size, ops);
    lv_cache_set_name(glyph_cache, CACHE_NAME);

    return glyph_cache;
}

void lv_freetype_set_cbs_glyph(lv_freetype_font_dsc_t * dsc)
{
    LV_ASSERT_FREETYPE_FONT_DSC(dsc);
    dsc->font.get_glyph_dsc = freetype_get_glyph_dsc_cb;
}

#if LV_FREETYPE_CACHE_FT_GLYPH_L1

void lv_freetype_glyph_l1_init(lv_freetype_cache_node_t * node)
{
    LV_ASSERT(node != NULL);
    size_t sz = sizeof(glyph_l1_set_t) * GLYPH_L1_SETS;
    node->glyph_l1 = lv_malloc_zeroed(sz);
    LV_ASSERT_MALLOC(node->glyph_l1);
    if(node->glyph_l1 == NULL) {
        LV_LOG_WARN("Failed to allocate glyph L1 cache (%u bytes), L1 disabled for this node", (unsigned)sz);
    }
}

void lv_freetype_glyph_l1_deinit(lv_freetype_cache_node_t * node)
{
    LV_ASSERT(node != NULL);
    if(node->glyph_l1) {
        lv_free(node->glyph_l1);
        node->glyph_l1 = NULL;
    }
}

#endif /* LV_FREETYPE_CACHE_FT_GLYPH_L1 */

/**********************
 *   STATIC FUNCTIONS
 **********************/

#if LV_FREETYPE_CACHE_FT_GLYPH_L1

static inline uint32_t glyph_l1_hash(uint32_t unicode, uint32_t size)
{
    uint32_t h = 2166136261u;   /* FNV-1a offset basis */
    h ^= unicode;
    h *= 16777619u;
    h ^= size;
    h *= 16777619u;
    return h;
}

static bool glyph_l1_lookup(lv_freetype_cache_node_t * node,
                            uint32_t unicode, uint32_t size,
                            lv_font_glyph_dsc_t * out_dsc)
{
    glyph_l1_set_t * sets = (glyph_l1_set_t *)node->glyph_l1;
    if(sets == NULL) return false;

    uint32_t idx = glyph_l1_hash(unicode, size) & GLYPH_L1_SET_MASK;
    glyph_l1_set_t * set = &sets[idx];

    for(uint32_t w = 0; w < GLYPH_L1_WAYS; w++) {
        glyph_l1_entry_t * e = &set->ways[w];
        if(e->unicode == unicode && e->size == size) {
            set->lru_bits = (uint8_t)w;
            *out_dsc = e->dsc;
            return true;
        }
    }
    return false;
}

static void glyph_l1_fill(lv_freetype_cache_node_t * node,
                          uint32_t unicode, uint32_t size,
                          const lv_font_glyph_dsc_t * dsc)
{
    glyph_l1_set_t * sets = (glyph_l1_set_t *)node->glyph_l1;
    if(sets == NULL) return;

    uint32_t idx = glyph_l1_hash(unicode, size) & GLYPH_L1_SET_MASK;
    glyph_l1_set_t * set = &sets[idx];

    uint32_t victim = (set->lru_bits == 0) ? 1u : 0u;

    glyph_l1_entry_t * e = &set->ways[victim];
    e->unicode    = unicode;
    e->size       = size;
    e->dsc        = *dsc;
    e->dsc.entry  = NULL;

    set->lru_bits = (uint8_t)victim;
}

#endif /* LV_FREETYPE_CACHE_FT_GLYPH_L1 */

static bool freetype_get_glyph_dsc_cb(const lv_font_t * font, lv_font_glyph_dsc_t * g_dsc, uint32_t unicode_letter,
                                      uint32_t unicode_letter_next)
{
    LV_ASSERT(font != NULL);
    LV_ASSERT(g_dsc != NULL);
    LV_PROFILER_FONT_BEGIN;

    if(unicode_letter < 0x20) {
        g_dsc->adv_w  = 0;
        g_dsc->box_h  = 0;
        g_dsc->box_w  = 0;
        g_dsc->ofs_x  = 0;
        g_dsc->ofs_y  = 0;
        g_dsc->format = LV_FONT_GLYPH_FORMAT_NONE;
        LV_PROFILER_FONT_END;
        return true;
    }

    lv_freetype_font_dsc_t * dsc = (lv_freetype_font_dsc_t *)font->dsc;
    LV_ASSERT_FREETYPE_FONT_DSC(dsc);

    lv_freetype_cache_node_t * cache_node = dsc->cache_node;
    LV_ASSERT(cache_node != NULL);
    LV_LOG_TRACE("Getting glyph for unicode = 0x%" LV_PRIx32 ", size = %" LV_PRIu32, unicode_letter, dsc->size);

#if LV_FREETYPE_CACHE_FT_GLYPH_L1
    /* L1 lookup: per cache_node, 2-way set-associative (single-thread only) */
    if(glyph_l1_lookup(cache_node, unicode_letter, dsc->size, g_dsc)) {
        LV_LOG_TRACE("L1 cache hit");
    }
    else
#endif
    {
        LV_LOG_TRACE("L1 cache miss, looking up L2");
        lv_freetype_glyph_cache_data_t search_key = {
            .unicode = unicode_letter,
            .size = dsc->size,
        };

        lv_cache_t * glyph_cache = cache_node->glyph_cache;

        lv_cache_entry_t * entry = lv_cache_acquire_or_create(glyph_cache, &search_key, dsc);
        if(entry == NULL) {
            LV_LOG_ERROR("glyph lookup failed for unicode = 0x%" LV_PRIx32, unicode_letter);
            LV_PROFILER_FONT_END;
            return false;
        }
        lv_freetype_glyph_cache_data_t * data = lv_cache_entry_get_data(entry);
        *g_dsc = data->glyph_dsc;

#if LV_FREETYPE_CACHE_FT_GLYPH_L1
        /* Populate L1 for future hits */
        glyph_l1_fill(cache_node, unicode_letter, dsc->size, &data->glyph_dsc);
#endif

        lv_cache_release(glyph_cache, entry, NULL);
    }

    if((dsc->style & LV_FREETYPE_FONT_STYLE_ITALIC) && (unicode_letter_next == '\0')) {
        g_dsc->adv_w = g_dsc->box_w + g_dsc->ofs_x;
    }

    if(dsc->kerning == LV_FONT_KERNING_NORMAL && dsc->cache_node->face_has_kerning && unicode_letter_next != '\0') {
        lv_mutex_lock(&dsc->cache_node->face_lock);
        FT_Face face = dsc->cache_node->face;
        if(FT_IS_SCALABLE(face)) {
            FT_Error set_size_error = FT_Set_Pixel_Sizes(face, 0, dsc->size);
            if(set_size_error) {
                FT_ERROR_MSG("FT_Set_Pixel_Sizes", set_size_error);
            }
        }
        FT_UInt glyph_index_next = FT_Get_Char_Index(face, unicode_letter_next);
        FT_Vector kerning;
        FT_Error error = FT_Get_Kerning(face, g_dsc->gid.index, glyph_index_next, FT_KERNING_DEFAULT, &kerning);
        if(!error) {
            g_dsc->adv_w += LV_FREETYPE_F26DOT6_TO_INT(kerning.x);
        }
        else {
            FT_ERROR_MSG("FT_Get_Kerning", error);
        }
        lv_mutex_unlock(&dsc->cache_node->face_lock);
    }

    g_dsc->entry = NULL;

    LV_PROFILER_FONT_END;
    return true;
}

/*-----------------
 * Cache Callbacks
 *----------------*/

static bool freetype_glyph_create_cb(lv_freetype_glyph_cache_data_t * data, void * user_data)
{
    LV_ASSERT(data != NULL);
    LV_ASSERT(user_data != NULL);
    LV_PROFILER_FONT_BEGIN;

    FT_Error error;
    lv_freetype_font_dsc_t * dsc = (lv_freetype_font_dsc_t *)user_data;
    lv_font_glyph_dsc_t * dsc_out = &data->glyph_dsc;

    lv_mutex_lock(&dsc->cache_node->face_lock);
    FT_Face face = dsc->cache_node->face;
    FT_UInt glyph_index = FT_Get_Char_Index(face, data->unicode);

    if(FT_IS_SCALABLE(face)) {
        error = FT_Set_Pixel_Sizes(face, 0, dsc->size);
    }
    else {
        error = FT_Select_Size(face, 0);
    }
    if(error) {
        FT_ERROR_MSG("FT_Set_Pixel_Sizes", error);
        lv_mutex_unlock(&dsc->cache_node->face_lock);
        return false;
    }

    if(dsc->render_mode == LV_FREETYPE_FONT_RENDER_MODE_OUTLINE) {
        error = FT_Load_Glyph(face, glyph_index, FT_LOAD_COMPUTE_METRICS | FT_LOAD_NO_BITMAP | FT_LOAD_NO_AUTOHINT);
    }
    else if(dsc->render_mode == LV_FREETYPE_FONT_RENDER_MODE_BITMAP) {
        error = FT_Load_Glyph(face, glyph_index, FT_LOAD_COMPUTE_METRICS | FT_LOAD_NO_AUTOHINT);
    }
    if(error) {
        FT_ERROR_MSG("FT_Load_Glyph", error);
        lv_mutex_unlock(&dsc->cache_node->face_lock);
        LV_PROFILER_FONT_END;
        return false;
    }

    FT_GlyphSlot glyph = face->glyph;

    if(dsc->render_mode == LV_FREETYPE_FONT_RENDER_MODE_OUTLINE) {

        dsc_out->adv_w = FT_F26DOT6_TO_INT(glyph->metrics.horiAdvance);
        dsc_out->box_h = FT_F26DOT6_TO_INT(glyph->metrics.height);          /*Height of the bitmap in [px]*/
        dsc_out->box_w = FT_F26DOT6_TO_INT(glyph->metrics.width);           /*Width of the bitmap in [px]*/
        dsc_out->ofs_x = FT_F26DOT6_TO_INT(glyph->metrics.horiBearingX);    /*X offset of the bitmap in [pf]*/
        dsc_out->ofs_y = FT_F26DOT6_TO_INT(glyph->metrics.horiBearingY -
                                           glyph->metrics.height);          /*Y offset of the bitmap measured from the as line*/
        dsc_out->format = LV_FONT_GLYPH_FORMAT_VECTOR;

        /*Transform the glyph to italic if required */
        if(dsc->style & LV_FREETYPE_FONT_STYLE_ITALIC) {
            dsc_out->box_w = lv_freetype_italic_transform_on_pos((lv_point_t) {
                dsc_out->box_w, dsc_out->box_h
            });
        }
    }
    else if(dsc->render_mode == LV_FREETYPE_FONT_RENDER_MODE_BITMAP) {
        FT_Bitmap * glyph_bitmap = &face->glyph->bitmap;

        dsc_out->adv_w = FT_F26DOT6_TO_INT(glyph->advance.x);        /*Width of the glyph in [pf]*/
        dsc_out->box_h = glyph_bitmap->rows;                         /*Height of the bitmap in [px]*/
        dsc_out->box_w = glyph_bitmap->width;                        /*Width of the bitmap in [px]*/
        dsc_out->ofs_x = glyph->bitmap_left;                         /*X offset of the bitmap in [pf]*/
        dsc_out->ofs_y = glyph->bitmap_top -
                         dsc_out->box_h;                             /*Y offset of the bitmap measured from the as line*/
        if(glyph->format == FT_GLYPH_FORMAT_BITMAP)
            dsc_out->format = LV_FONT_GLYPH_FORMAT_IMAGE;
        else
            dsc_out->format = LV_FONT_GLYPH_FORMAT_A8;
    }

    dsc_out->is_placeholder = glyph_index == 0;
    dsc_out->gid.index = (uint32_t)glyph_index;

    lv_mutex_unlock(&dsc->cache_node->face_lock);

    LV_PROFILER_FONT_END;
    return true;
}
static void freetype_glyph_free_cb(lv_freetype_glyph_cache_data_t * data, void * user_data)
{
    LV_UNUSED(data);
    LV_UNUSED(user_data);
}
static lv_cache_compare_res_t freetype_glyph_compare_cb(const lv_freetype_glyph_cache_data_t * lhs,
                                                        const lv_freetype_glyph_cache_data_t * rhs)
{
    LV_ASSERT(lhs != NULL);
    LV_ASSERT(rhs != NULL);
    if(lhs->unicode != rhs->unicode) {
        return lhs->unicode > rhs->unicode ? 1 : -1;
    }
    if(lhs->size != rhs->size) {
        return lhs->size > rhs->size ? 1 : -1;
    }
    return 0;
}

#endif /*LV_USE_FREETYPE*/
