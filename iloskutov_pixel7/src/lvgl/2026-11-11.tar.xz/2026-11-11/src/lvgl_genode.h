/*
 * \brief  LVGL on Genode GUI sessions
 * \author Ivan Loskutov
 * \date   2026-11-11
 *
 * 'Runtime' is LVGL of the component: 'lv_init', the tick, and the timers,
 * which run on the entrypoint, driven by a timer session. Each 'Window' is
 * one GUI session with an LVGL display of the session's size (the screen
 * under the GUI server, the window the window manager assigns under 'wm')
 * and one pointer input device. A window follows changes of its size.
 *
 * The pointer takes the session's touch events (the first finger, pressed
 * while BTN_TOUCH is) or a mouse (absolute motion and BTN_LEFT). A
 * touchscreen must reach the GUI server without event_filter's
 * 'touch-click', which hides the start of each touch from the client.
 *
 * Key events go to a keypad input device, which feeds the window's group
 * ('group()'): a character as its codepoint, Backspace, Delete, Enter,
 * Escape, Home, End, and the arrows as LVGL's keys. The objects 'Ui::create'
 * creates join the group if their kind takes keys (text areas, buttons);
 * the one that gets the keys is focused with 'lv_group_focus_obj'.
 *
 * LVGL draws into a buffer of its own; only finished areas are copied into
 * the session's buffer, so the screen never shows a half-drawn frame.
 */

/*
 * SPDX-License-Identifier: MIT
 */

#ifndef _LVGL_GENODE_H_
#define _LVGL_GENODE_H_

#include <base/attached_dataspace.h>
#include <gui_session/connection.h>
#include <timer_session/connection.h>
#include <util/reconstructible.h>

#include <lvgl/lvgl.h>

namespace Lvgl_genode {

	class Runtime;
	class Window;
}


class Lvgl_genode::Runtime : Genode::Noncopyable
{
	private:

		friend class Window;

		Genode::Env &_env;

		Timer::Connection _timer { _env };

		bool _in_lvgl = false;   /* in 'lv_timer_handler' */
		bool _again   = false;   /* a round was asked for meanwhile */

		Timer::One_shot_timeout<Runtime> _timeout {
			_timer, *this, &Runtime::_handle_timeout };

		void _handle_timeout(Genode::Duration) { run(); }

		static uint32_t _tick();

	public:

		Runtime(Genode::Env &);

		/**
		 * Run LVGL's due timers (refresh, input, animations) now
		 *
		 * LVGL waits in the libc for its draw threads, the libc dispatches
		 * further signals meanwhile: a call during LVGL's round does not
		 * enter LVGL again, the round is repeated instead.
		 */
		void run();

		bool in_lvgl() const { return _in_lvgl; }
};


class Lvgl_genode::Window : Genode::Noncopyable
{
	public:

		/*
		 * A translucent window has an alpha channel: what LVGL leaves
		 * transparent shows the windows below and lets their input through
		 */
		enum Alpha { OPAQUE, TRANSLUCENT };

		/*
		 * The user interface of the window
		 */
		struct Ui : Genode::Interface
		{
			/**
			 * Called once the display exists, to build the interface
			 */
			virtual void create(lv_display_t &) = 0;

			/**
			 * Called after the display changed its size
			 */
			virtual void resized(lv_display_t &) { }
		};

	private:

		using Area = Gui::Area;

		Genode::Env &_env;
		Runtime     &_runtime;
		Ui          &_ui;
		bool const   _verbose_input;
		bool const   _alpha;

		Genode::String<64> const _gui_label;

		Gui::Connection _gui;

		Area _size { };

		Genode::Constructible<Genode::Attached_dataspace> _fb   { };
		Genode::Constructible<Gui::Top_level_view>        _view { };

		uint8_t      *_render_buf = nullptr;   /* LVGL's, size of the window */
		lv_display_t *_display    = nullptr;
		lv_indev_t   *_pointer    = nullptr;
		lv_indev_t   *_keypad     = nullptr;
		lv_group_t   *_group      = nullptr;

		/* key events not yet read by LVGL */
		struct Key { uint32_t key; bool pressed; };

		static constexpr unsigned KEYS = 64;
		Key      _keys[KEYS] { };
		unsigned _keys_head = 0, _keys_tail = 0;
		uint32_t       _last_key  = 0;   /* the key LVGL got last */
		Input::Keycode _last_code = Input::KEY_UNKNOWN;
		bool           _key_down  = false;

		void _push_key(uint32_t key, bool pressed);

		struct Pointer_state
		{
			int  x = 0, y = 0;
			bool pressed = false;
			bool unread  = false;   /* a press not yet seen by LVGL */
			bool     touch        = false;   /* touch events seen */
			unsigned finger       = 0;       /* touch id followed */
			bool     finger_valid = false;
			bool     read_pressed = false;   /* state of LVGL's last read */
		} _pointer_state { };

		Genode::Signal_handler<Window> _mode_handler {
			_env.ep(), *this, &Window::_handle_mode };

		Genode::Signal_handler<Window> _input_handler {
			_env.ep(), *this, &Window::_handle_input };

		void _handle_mode();
		void _handle_input();

		void _apply_size(Area);

		static void _flush(lv_display_t *, lv_area_t const *, uint8_t *);
		static void _read_pointer(lv_indev_t *, lv_indev_data_t *);
		static void _read_keypad(lv_indev_t *, lv_indev_data_t *);

	public:

		/**
		 * Constructor
		 *
		 * \param label          label of the GUI session, the window's name
		 * \param verbose_input  log every input event and each press and
		 *                       release LVGL reads
		 * \param alpha          'TRANSLUCENT' for a window with an alpha
		 *                       channel, its screen is transparent then
		 */
		Window(Genode::Env &, Runtime &, Ui &, char const *label,
		       bool verbose_input = false, Alpha alpha = OPAQUE);

		Window(Window const &) = delete;
		Window &operator = (Window const &) = delete;

		lv_display_t *display() { return _display; }

		/**
		 * Group of the objects that take key input
		 */
		lv_group_t *group() { return _group; }
};

#endif /* _LVGL_GENODE_H_ */
