/*
 * \brief  Configuration of LVGL on Genode (the Pixel 7)
 * \author Ivan Loskutov
 * \date   2026-11-11
 *
 * Only the deviations from LVGL's defaults (lv_conf_internal.h). It is part
 * of the library's API: clients compile with the same configuration.
 */

/*
 * SPDX-License-Identifier: MIT
 */

#ifndef LV_CONF_H
#define LV_CONF_H

/* the pixels of a Genode GUI buffer */
#define LV_COLOR_FORMAT_DEFAULT LV_COLOR_FORMAT_XRGB8888

/* malloc, string functions, and printf of the libc */
#define LV_USE_STDLIB_MALLOC  LV_STDLIB_CLIB
#define LV_USE_STDLIB_STRING  LV_STDLIB_CLIB
#define LV_USE_STDLIB_SPRINTF LV_STDLIB_CLIB

/*
 * LVGL's API is called on the entrypoint only; software rendering runs in
 * four draw threads, one per fast core (the component's affinity)
 */
#define LV_USE_OS                 LV_OS_PTHREAD
#define LV_DRAW_SW_DRAW_UNIT_CNT  4
#define LV_DRAW_THREAD_STACK_SIZE (64*1024)

/* NEON blending of arm64 (XRGB8888 is handled by the RGB888 path) */
#define LV_USE_DRAW_SW_ASM LV_DRAW_SW_ASM_NEON

/* the panel: 1080x2400 at about 416 dpi */
#define LV_DPI_DEF         400
#define LV_DEF_REFR_PERIOD 16

/* LVGL's messages go to the Genode log (lv_log_register_print_cb) */
#define LV_USE_LOG    1
#define LV_LOG_LEVEL  LV_LOG_LEVEL_WARN
#define LV_LOG_PRINTF 0

/* frame rate and render time, logged every second */
#define LV_USE_SYSMON                1
#define LV_USE_PERF_MONITOR          1
#define LV_USE_PERF_MONITOR_LOG_MODE 1

/* fonts large enough for the panel */
#define LV_FONT_MONTSERRAT_14 0
#define LV_FONT_MONTSERRAT_32 1
#define LV_FONT_MONTSERRAT_48 1
#define LV_FONT_DEFAULT       LV_FONT_DEFAULT_MONTSERRAT_32

/* TrueType fonts of any size, from a font file in memory (a ROM) */
#define LV_USE_TINY_TTF 1

#endif /* LV_CONF_H */
