/*
 * \brief  Follow property changes: table snapshot + change queue
 * \author Ivan Loskutov
 * \date   2026-09-26
 *
 * A watcher remembers, per slot, the last serial it delivered. 'snapshot'
 * takes the current serials (the caller has read the table); 'poll' drains
 * the change queue and delivers each change whose serial is newer, in queue
 * order (identical repeated sets included). After a queue overflow every
 * slot whose serial is newer than the remembered one is delivered once with
 * its current value -- intermediate values are lost.
 *
 * Platform independent.
 */

/*
 * SPDX-License-Identifier: MIT
 */

#ifndef _INCLUDE__ANDROID_PROP__WATCHER_H_
#define _INCLUDE__ANDROID_PROP__WATCHER_H_

#include <android_prop/queue.h>
#include <android_prop/table.h>

namespace Android_prop {
	struct Change_source;
	class  Watcher;
}


struct Android_prop::Change_source
{
	virtual ~Change_source() { }

	/**
	 * Copy up to 'max' queued changes to 'out'
	 */
	virtual Change_queue::Fetch fetch(Change *out, unsigned max) = 0;
};


class Android_prop::Watcher
{
	private:

		Table const   &_table;
		Change_source &_source;
		Change        *_buffer;
		unsigned const _buffer_len;
		uint32_t       _known[SLOTS] { };
		unsigned long  _overflows = 0;

		Watcher(Watcher const &) = delete;
		Watcher &operator = (Watcher const &) = delete;

		template <typename FN>
		void _deliver_current(unsigned i, FN const &on_change)
		{
			Slot const &s = *_table.slot(i);
			char value[LONG_VALUE_MAX];
			uint32_t serial = 0;
			_table.read_full(s, value, &serial);
			if (!serial_newer(serial, _known[i])) return;
			_known[i] = serial;
			on_change(s, (char const *)value);
		}

	public:

		Watcher(Table const &table, Change_source &source, Change *buffer, unsigned buffer_len)
		:
			_table(table), _source(source), _buffer(buffer), _buffer_len(buffer_len)
		{ }

		/**
		 * Remember the current serial of every slot
		 */
		void snapshot()
		{
			unsigned const n = _table.count();
			for (unsigned i = 0; i < n; i++)
				_known[i] = _table.serial(*_table.slot(i));
		}

		unsigned long overflows() const { return _overflows; }

		/**
		 * Deliver every change not delivered yet
		 *
		 * \return true if the queue had overflowed (resynced from the table)
		 */
		template <typename FN>
		bool poll(FN const &on_change)
		{
			bool overflowed = false;
			for (;;) {
				Change_queue::Fetch const f = _source.fetch(_buffer, _buffer_len);
				if (f.overflow) {
					overflowed = true;
					_overflows++;
					unsigned const n = _table.count();
					for (unsigned i = 0; i < n; i++) _deliver_current(i, on_change);
				}
				if (!f.count) return overflowed;

				for (unsigned k = 0; k < f.count; k++) {
					Change const &c = _buffer[k];
					if (c.slot >= _table.count() || !serial_newer(c.serial, _known[c.slot]))
						continue;
					_known[c.slot] = c.serial;
					Slot const &s = *_table.slot(c.slot);
					if (c.long_value) {
						char full[LONG_VALUE_MAX];
						_table.read_full(s, full);
						on_change(s, (char const *)full);
					} else {
						on_change(s, (char const *)c.value);
					}
				}
			}
		}
};

#endif /* _INCLUDE__ANDROID_PROP__WATCHER_H_ */
