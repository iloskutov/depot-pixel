/*
 * \brief  Android system-property table (shared-memory layout)
 * \author Ivan Loskutov
 * \date   2026-09-26
 *
 * One writer, lock-free readers that may live in other processes: the
 * android_prop server writes, every android_loader maps the table
 * read-only. Properties are never deleted, so slot addresses (the
 * 'prop_info *' bionic code caches) never change. Each slot has a sequence
 * lock: its serial is odd while the value is written.
 *
 * Platform independent.
 */

/*
 * SPDX-License-Identifier: MIT
 */

#ifndef _INCLUDE__ANDROID_PROP__TABLE_H_
#define _INCLUDE__ANDROID_PROP__TABLE_H_

#include <stddef.h>
#include <stdint.h>

namespace Android_prop {

	enum : uint32_t { MAGIC = 0x31505241 /* "ARP1" */, VERSION = 1 };

	enum { NAME_MAX_LEN   = 128,        /* including the terminating NUL */
	       VALUE_MAX      = 92,         /* PROP_VALUE_MAX, including the NUL */
	       SLOTS          = 2048,
	       INDEX_SIZE     = 4096,       /* power of two, twice SLOTS */
	       LONG_AREA      = 64*1024,
	       LONG_VALUE_MAX = 1024 };     /* one long ro.* value, including the NUL */

	struct Header
	{
		uint32_t magic, version, slot_count, used, area_serial, long_used;
		uint32_t reserved[10];
	};

	struct Slot
	{
		char     name[NAME_MAX_LEN];
		uint32_t serial;        /* even; odd while the value is written */
		uint32_t long_offset;   /* into the long-value area, if long_len */
		uint32_t long_len;      /* length of a long ro.* value, 0: none */
		char     value[VALUE_MAX];
	};

	enum class Set_result { OK, INVALID, FULL, READ_ONLY };

	inline bool is_ro(char const *name)
	{
		return name[0] == 'r' && name[1] == 'o' && name[2] == '.';
	}

	/**
	 * Serial 'a' is newer than 'b' (serials wrap around)
	 */
	inline bool serial_newer(uint32_t a, uint32_t b) { return int32_t(a - b) > 0; }

	class Table;
}


class Android_prop::Table
{
	public:

		static constexpr size_t SIZE = sizeof(Header) + SLOTS*sizeof(Slot)
		                             + INDEX_SIZE*sizeof(uint16_t) + LONG_AREA;

	private:

		uint8_t *_mem;

		Header   &_hdr()       const { return *(Header *)_mem; }
		Slot     *_slots()     const { return (Slot *)(_mem + sizeof(Header)); }
		uint16_t *_index()     const { return (uint16_t *)(_mem + sizeof(Header) + SLOTS*sizeof(Slot)); }
		char     *_long_area() const { return (char *)(_index() + INDEX_SIZE); }

		void       _store(Slot &, char const *value, size_t len,
		                  uint32_t long_offset = 0, uint32_t long_len = 0);
		void       _put_long(Slot &, char const *value, size_t len);
		Set_result _set(char const *name, char const *value, bool loading);

	public:

		/**
		 * View of 'SIZE' bytes at 'mem' (read-only memory for pure readers)
		 */
		explicit Table(void *mem) : _mem((uint8_t *)mem) { }

		/**
		 * Writer: initialize an empty table
		 */
		void format();

		/**
		 * Magic number, version and slot count match this code
		 */
		bool valid() const;

		Slot const *find(char const *name) const;

		/**
		 * Writer: set a property (ro.* only if it does not exist yet)
		 */
		Set_result set(char const *name, char const *value) { return _set(name, value, false); }

		/**
		 * Writer, at startup: like 'set', but may overwrite ro.* properties
		 */
		Set_result load(char const *name, char const *value) { return _set(name, value, true); }

		/**
		 * Consistent copy of the value (at most VALUE_MAX-1 characters)
		 *
		 * \param value   buffer of at least VALUE_MAX bytes
		 * \param serial  serial belonging to the copied value
		 * \return        length of the value copied
		 */
		unsigned read(Slot const &, char *value, uint32_t *serial = nullptr) const;

		/**
		 * Full value: a long ro.* value in full, else like 'read'
		 *
		 * \param buf  buffer of at least LONG_VALUE_MAX bytes
		 */
		unsigned read_full(Slot const &, char *buf, uint32_t *serial = nullptr) const;

		/**
		 * Serial of the slot (always even)
		 */
		uint32_t serial(Slot const &) const;

		/**
		 * Incremented after every change of any property
		 */
		uint32_t area_serial() const;

		/**
		 * Slots in use, in the order they were added
		 */
		unsigned    count() const;
		Slot const *slot(unsigned i) const { return &_slots()[i]; }
		unsigned    index(Slot const &s) const { return unsigned(&s - _slots()); }
};

#endif /* _INCLUDE__ANDROID_PROP__TABLE_H_ */
