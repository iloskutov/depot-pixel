/*
 * \brief  Which properties a client may set
 * \author Ivan Loskutov
 * \date   2026-09-26
 *
 * One policy per client (label), filled from '<allow name="..."/>' and
 * '<allow prefix="..."/>' of the server's matching '<policy>'. ro.* is
 * write-once for everyone, also in permissive mode.
 */

/*
 * SPDX-License-Identifier: MIT
 */

#ifndef _INCLUDE__ANDROID_PROP__POLICY_H_
#define _INCLUDE__ANDROID_PROP__POLICY_H_

#include <android_prop/table.h>

namespace Android_prop {

	class Policy;

	enum class Verdict { ALLOW, ALLOW_PERMISSIVE, DENY, DENY_READ_ONLY };

	/**
	 * \param exists      the property is in the table already
	 * \param permissive  log-and-allow instead of deny (not for ro.*)
	 */
	Verdict check(Policy const &, bool exists, char const *name, bool permissive);
}


class Android_prop::Policy
{
	public:

		enum { MAX_RULES = 64 };

	private:

		struct Rule { char text[NAME_MAX_LEN]; bool prefix; };

		Rule     _rules[MAX_RULES] { };
		unsigned _count = 0;
		bool     _watch = false;

	public:

		/**
		 * \return false if the rule is too long or there are too many
		 */
		bool add(char const *text, bool prefix);

		void watch(bool w) { _watch = w; }
		bool watch() const { return _watch; }

		bool allows(char const *name) const;
};

#endif /* _INCLUDE__ANDROID_PROP__POLICY_H_ */
