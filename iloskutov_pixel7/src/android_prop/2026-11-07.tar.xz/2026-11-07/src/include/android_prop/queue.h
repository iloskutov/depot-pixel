/*
 * \brief  Ordered queue of property changes for watchers
 * \author Ivan Loskutov
 * \date   2026-09-26
 *
 * Every successful set appends an entry, also when the value did not
 * change (init runs 'on property:x=*' on every set). Each watcher has its
 * own cursor; one that falls more than CAPACITY entries behind gets the
 * overflow flag and continues at the oldest entry still queued.
 */

/*
 * SPDX-License-Identifier: MIT
 */

#ifndef _INCLUDE__ANDROID_PROP__QUEUE_H_
#define _INCLUDE__ANDROID_PROP__QUEUE_H_

#include <android_prop/table.h>

namespace Android_prop {

	struct Change
	{
		uint64_t seq;          /* position in the queue */
		uint32_t slot;         /* table index of the property */
		uint32_t serial;       /* slot serial right after this set */
		uint32_t long_value;   /* 1: read the (immutable) value from the table */
		char     value[VALUE_MAX];
	};

	class Change_queue;
}


class Android_prop::Change_queue
{
	public:

		enum { CAPACITY = 1024 };

		struct Cursor { uint64_t pos; };
		struct Fetch  { unsigned count; bool overflow; };

	private:

		Change   _ring[CAPACITY] { };
		uint64_t _head = 0;   /* sequence number of the next entry */

	public:

		/**
		 * Cursor of a new watcher: it sees changes from now on
		 */
		Cursor head() const { return { _head }; }

		bool caught_up(Cursor const &c) const { return c.pos == _head; }

		void append(uint32_t slot, uint32_t serial, char const *value, bool long_value);

		/**
		 * Copy up to 'max' entries from the cursor on and advance it
		 */
		Fetch fetch(Cursor &, Change *out, unsigned max) const;
};

#endif /* _INCLUDE__ANDROID_PROP__QUEUE_H_ */
