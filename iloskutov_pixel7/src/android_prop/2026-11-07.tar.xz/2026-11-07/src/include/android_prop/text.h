/*
 * \brief  getprop text ("[name]: [value]" lines) and the persist file
 * \author Ivan Loskutov
 * \date   2026-09-26
 */

/*
 * SPDX-License-Identifier: MIT
 */

#ifndef _INCLUDE__ANDROID_PROP__TEXT_H_
#define _INCLUDE__ANDROID_PROP__TEXT_H_

#include <android_prop/table.h>
#include <string.h>

namespace Android_prop {

	inline bool is_persist(char const *name) { return !strncmp(name, "persist.", 8); }

	/**
	 * Call 'fn(name, value)' for every "[name]: [value]" line
	 *
	 * Other lines are skipped. 'fn' returns true to count the entry.
	 *
	 * \return number of counted entries
	 */
	template <typename FN>
	unsigned parse_getprop(char const *text, size_t len, FN const &fn)
	{
		unsigned n = 0;
		size_t   i = 0;
		while (i < len) {
			size_t e = i;
			while (e < len && text[e] != '\n') e++;

			char line[NAME_MAX_LEN + LONG_VALUE_MAX + 8];
			size_t const l = e - i < sizeof(line) - 1 ? e - i : sizeof(line) - 1;
			memcpy(line, text + i, l);
			line[l] = 0;
			i = e + 1;

			char *name       = strchr(line, '[');
			char *name_end   = name ? strchr(name, ']') : nullptr;
			char *value      = name_end ? strchr(name_end, '[') : nullptr;
			char *value_end  = value ? strrchr(value, ']') : nullptr;
			if (!value_end) continue;
			*name_end = 0;
			*value_end = 0;
			if (fn((char const *)name + 1, (char const *)value + 1)) n++;
		}
		return n;
	}

	/**
	 * Write the persist.* properties of 'table' to 'path'
	 *
	 * Writes '<path>.tmp' and renames it over 'path'.
	 *
	 * \return false on any file error (the previous file stays in place)
	 */
	bool write_persist_file(Table const &, char const *path);
}

#endif /* _INCLUDE__ANDROID_PROP__TEXT_H_ */
