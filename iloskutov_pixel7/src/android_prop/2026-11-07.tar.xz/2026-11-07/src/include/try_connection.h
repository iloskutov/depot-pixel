/*
 * \brief  Session opened on request, reporting a denial instead of blocking
 * \author Ivan Loskutov
 * \date   2026-09-26
 *
 * Genode's Env::session() calls sleep_forever() when the parent denies a
 * session (base/src/lib/base/component.cc). Clients that must survive a
 * denial (a service not exported yet, an unknown device node) use this.
 */

/*
 * SPDX-License-Identifier: MIT
 */

#ifndef _INCLUDE__TRY_CONNECTION_H_
#define _INCLUDE__TRY_CONNECTION_H_

#include <base/env.h>
#include <base/session_label.h>
#include <util/reconstructible.h>

namespace Genode_pixel { template <typename, typename> class Try_connection; }


template <typename SESSION, typename CLIENT>
class Genode_pixel::Try_connection : Genode::Noncopyable
{
	private:

		Genode::Env                                           &_env;
		Genode::Parent::Client                                 _parent_client { };
		Genode::Id_space<Genode::Parent::Client>::Element const _id;
		Genode::Constructible<CLIENT>                          _client { };

	public:

		enum class Result { OK, DENIED, FAILED };

		Try_connection(Genode::Env &env)
		: _env(env), _id(_parent_client, env.id_space()) { }

		~Try_connection() { if (_client.constructed()) _env.close(_id.id()); }

		/**
		 * Request the session once (the caller decides whether to retry)
		 *
		 * \param extra_args  further session arguments, e.g. "flags=2"
		 */
		Result open(char const *label, char const *extra_args = "")
		{
			if (_client.constructed()) return Result::OK;

			Genode::Ram_quota ram  { SESSION::RAM_QUOTA };
			Genode::Cap_quota caps { SESSION::CAP_QUOTA };

			/* grow the donation like Env::session does, stop at a denial */
			for (unsigned attempt = 0; attempt < 16; attempt++) {
				Genode::String<Genode::Parent::Session_args::MAX_SIZE> const args(
					"label=\"", Genode::Session_label(label), "\", "
					"ram_quota=", ram, ", cap_quota=", caps,
					extra_args[0] ? ", " : "", extra_args);

				Result r = Result::FAILED;
				bool retry = false;
				_env.try_session(SESSION::service_name(), _id.id(),
				                 Genode::Parent::Session_args(args.string()),
				                 Genode::Affinity()).with_result(
					[&] (Genode::Session_capability cap) {
						_client.construct(Genode::static_cap_cast<SESSION>(cap));
						r = Result::OK; },
					[&] (Genode::Session_error e) {
						switch (e) {
						case Genode::Session_error::DENIED:            r = Result::DENIED; break;
						case Genode::Session_error::INSUFFICIENT_RAM:  ram  = { ram.value + 4096 }; retry = true; break;
						case Genode::Session_error::INSUFFICIENT_CAPS: caps = { caps.value + 4 };   retry = true; break;
						default: break;
						}
					});
				if (!retry) return r;
			}
			return Result::FAILED;
		}

		/**
		 * Session interface, valid after open() returned OK
		 */
		CLIENT &client() { return *_client; }
};

#endif /* _INCLUDE__TRY_CONNECTION_H_ */
