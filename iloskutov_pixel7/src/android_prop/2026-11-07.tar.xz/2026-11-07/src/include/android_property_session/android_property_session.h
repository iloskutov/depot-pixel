/*
 * \brief  Android_property session: shared Android system properties
 * \author Ivan Loskutov
 * \date   2026-09-26
 *
 * The table (include/android_prop/table.h) is handed out read-only; clients
 * read it without RPCs. 'set' returns once the new value is in the table.
 * A session that called 'arm' gets one signal after the next successful set
 * (the server then disarms it). Watchers (policy watch="yes") fetch the
 * ordered change queue into their transfer buffer; they are signalled when
 * a change arrives while they had fetched everything.
 */

/*
 * SPDX-License-Identifier: MIT
 */

#ifndef _INCLUDE__ANDROID_PROPERTY_SESSION__ANDROID_PROPERTY_SESSION_H_
#define _INCLUDE__ANDROID_PROPERTY_SESSION__ANDROID_PROPERTY_SESSION_H_

#include <android_prop/table.h>
#include <base/connection.h>
#include <base/rpc.h>
#include <base/rpc_client.h>
#include <base/signal.h>
#include <dataspace/capability.h>
#include <session/session.h>

namespace Android_property_session {
	struct Session;
	struct Session_client;
	struct Connection;
}


struct Android_property_session::Session : Genode::Session
{
	static char const *service_name() { return "Android_property"; }

	enum { CAP_QUOTA     = 4,
	       TRANSFER_SIZE = 64*1024,
	       RAM_QUOTA     = TRANSFER_SIZE + 32*1024,

	       /*
	        * 'set's RPC argument, not the full 'LONG_VALUE_MAX': a
	        * 'Genode::String<N>' is marshalled as a fixed-size struct (its
	        * whole 'N'-byte buffer, not just the bytes in use), and this
	        * fork's 'Rpc_entrypoint' has a hard-coded 1024-byte snd/rcv
	        * 'Msgbuf' shared by every session it serves
	        * (repos/base/include/base/rpc_server.h). 'Name' (below) plus a
	        * 1024-byte 'Value' alone exceeds that budget, so every 'set'
	        * call -- even of a one-character value -- would fail with
	        * "IPC marshalling/unmarshalling error" (confirmed on QEMU).
	        * 160 comfortably fits the budget together with 'Name'.
	        *
	        * A 'Genode::String<N>' silently truncates instead of failing,
	        * so a value of 'SET_VALUE_MAX - 1' characters received by the
	        * server cannot be told apart from a longer one that got cut to
	        * fit -- the server refuses both (INVALID). The longest value
	        * this session can ever actually store is therefore
	        * 'SET_VALUE_MAX - 2' = 158 characters, and only for a *new*
	        * ro.* property (an existing property, ro.* or not, stays
	        * limited to 'VALUE_MAX - 1' = 91 characters by the table
	        * itself). A longer ro.* value (up to 'LONG_VALUE_MAX') can
	        * only be loaded in-process at server startup
	        * (defaults/<property>/persist), never set over this session.
	        */
	       SET_VALUE_MAX = 160 };

	/* '+ 1': an over-long name arrives truncated to 'NAME_MAX_LEN'
	 * characters instead of silently becoming a shorter valid name; the
	 * table then refuses it (INVALID) because it is exactly at the limit */
	using Name  = Genode::String<Android_prop::NAME_MAX_LEN + 1>;
	using Value = Genode::String<SET_VALUE_MAX>;

	enum class Set_result : int32_t { OK, DENIED, INVALID, FULL };

	struct Fetch_result { uint32_t count; uint32_t overflow; };

	/**
	 * The property table, read-only for the client
	 */
	virtual Genode::Dataspace_capability table() = 0;

	virtual Set_result set(Name const &, Value const &) = 0;

	/**
	 * Signal for 'arm' and, for watchers, for new changes
	 */
	virtual void wait_sigh(Genode::Signal_context_capability) = 0;

	/**
	 * Ask for one signal after the next successful set by any client
	 */
	virtual void arm() = 0;

	/**
	 * Watchers: buffer that 'changes' fills with 'Android_prop::Change' entries
	 */
	virtual Genode::Dataspace_capability transfer() = 0;

	/**
	 * Watchers: copy queued changes to the transfer buffer
	 */
	virtual Fetch_result changes() = 0;

	GENODE_RPC(Rpc_table, Genode::Dataspace_capability, table);
	GENODE_RPC(Rpc_set, Set_result, set, Name const &, Value const &);
	GENODE_RPC(Rpc_wait_sigh, void, wait_sigh, Genode::Signal_context_capability);
	GENODE_RPC(Rpc_arm, void, arm);
	GENODE_RPC(Rpc_transfer, Genode::Dataspace_capability, transfer);
	GENODE_RPC(Rpc_changes, Fetch_result, changes);

	GENODE_RPC_INTERFACE(Rpc_table, Rpc_set, Rpc_wait_sigh, Rpc_arm, Rpc_transfer,
	                     Rpc_changes);
};


struct Android_property_session::Session_client : Genode::Rpc_client<Session>
{
	explicit Session_client(Genode::Capability<Session> cap)
	: Genode::Rpc_client<Session>(cap) { }

	Genode::Dataspace_capability table() override { return call<Rpc_table>(); }

	Set_result set(Name const &n, Value const &v) override { return call<Rpc_set>(n, v); }

	void wait_sigh(Genode::Signal_context_capability sigh) override { call<Rpc_wait_sigh>(sigh); }

	void arm() override { call<Rpc_arm>(); }

	Genode::Dataspace_capability transfer() override { return call<Rpc_transfer>(); }

	Fetch_result changes() override { return call<Rpc_changes>(); }
};


struct Android_property_session::Connection : Genode::Connection<Session>, Session_client
{
	Connection(Genode::Env &env, Genode::Session_label const &label = "properties")
	:
		Genode::Connection<Session>(env, label, Genode::Ram_quota { Session::RAM_QUOTA }, Args()),
		Session_client(cap())
	{ }
};

#endif /* _INCLUDE__ANDROID_PROPERTY_SESSION__ANDROID_PROPERTY_SESSION_H_ */
