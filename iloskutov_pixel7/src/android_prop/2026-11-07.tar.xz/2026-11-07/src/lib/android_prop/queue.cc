/*
 * \brief  Ordered queue of property changes for watchers
 * \author Ivan Loskutov
 * \date   2026-09-26
 */

/*
 * SPDX-License-Identifier: MIT
 */

#include <android_prop/queue.h>
#include <string.h>

using namespace Android_prop;


void Change_queue::append(uint32_t slot, uint32_t serial, char const *value, bool long_value)
{
	Change &c = _ring[_head % CAPACITY];
	c.seq        = _head;
	c.slot       = slot;
	c.serial     = serial;
	c.long_value = long_value ? 1 : 0;
	strncpy(c.value, long_value ? "" : value, VALUE_MAX - 1);
	c.value[VALUE_MAX - 1] = 0;
	_head++;
}


Change_queue::Fetch Change_queue::fetch(Cursor &cursor, Change *out, unsigned max) const
{
	Fetch f { 0, false };
	if (_head - cursor.pos > CAPACITY) {
		f.overflow = true;
		cursor.pos = _head - CAPACITY;
	}
	while (f.count < max && cursor.pos < _head)
		out[f.count++] = _ring[cursor.pos++ % CAPACITY];
	return f;
}
