/*
 * \brief  Persist file: the persist.* properties in getprop format
 * \author Ivan Loskutov
 * \date   2026-09-26
 */

/*
 * SPDX-License-Identifier: MIT
 */

#include <android_prop/text.h>

#include <fcntl.h>
#include <stdio.h>
#include <unistd.h>

using namespace Android_prop;

namespace {

	bool write_all(int fd, char const *buf, size_t len)
	{
		while (len) {
			ssize_t const n = ::write(fd, buf, len);
			if (n <= 0) return false;
			buf += n;
			len -= size_t(n);
		}
		return true;
	}
}


bool Android_prop::write_persist_file(Table const &table, char const *path)
{
	char tmp[256];
	if (snprintf(tmp, sizeof(tmp), "%s.tmp", path) >= int(sizeof(tmp))) return false;

	int const fd = ::open(tmp, O_WRONLY | O_CREAT | O_TRUNC, 0600);
	if (fd < 0) return false;

	bool ok = true;
	char value[VALUE_MAX];
	char line[NAME_MAX_LEN + VALUE_MAX + 8];
	for (unsigned i = 0; ok && i < table.count(); i++) {
		Slot const &s = *table.slot(i);
		if (!is_persist(s.name)) continue;
		table.read(s, value);   /* persist.* values are never long */
		int const len = snprintf(line, sizeof(line), "[%s]: [%s]\n", s.name, value);
		ok = len > 0 && write_all(fd, line, size_t(len));
	}
	/* a write that never reaches disk must not be renamed over the real file */
	if (ok && ::fsync(fd) != 0) ok = false;
	if (::close(fd) != 0) ok = false;
	if (!ok) { ::unlink(tmp); return false; }
	if (::rename(tmp, path) != 0) { ::unlink(tmp); return false; }
	return true;
}
