/*
 * \brief  Which properties a client may set
 * \author Ivan Loskutov
 * \date   2026-09-26
 */

/*
 * SPDX-License-Identifier: MIT
 */

#include <android_prop/policy.h>
#include <string.h>

using namespace Android_prop;


bool Policy::add(char const *text, bool prefix)
{
	if (_count == MAX_RULES || strlen(text) >= NAME_MAX_LEN) return false;
	strcpy(_rules[_count].text, text);
	_rules[_count].prefix = prefix;
	_count++;
	return true;
}


bool Policy::allows(char const *name) const
{
	for (unsigned i = 0; i < _count; i++) {
		Rule const &r = _rules[i];
		if (r.prefix ? !strncmp(name, r.text, strlen(r.text)) : !strcmp(name, r.text))
			return true;
	}
	return false;
}


Verdict Android_prop::check(Policy const &p, bool exists, char const *name, bool permissive)
{
	if (exists && is_ro(name)) return Verdict::DENY_READ_ONLY;
	if (p.allows(name))        return Verdict::ALLOW;
	return permissive ? Verdict::ALLOW_PERMISSIVE : Verdict::DENY;
}
