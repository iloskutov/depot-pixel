/*
 * \brief  Android system-property table
 * \author Ivan Loskutov
 * \date   2026-09-26
 */

/*
 * SPDX-License-Identifier: MIT
 */

#include <android_prop/table.h>
#include <string.h>
#include <unistd.h>

using namespace Android_prop;

namespace {

	uint32_t fnv1a(char const *s)
	{
		uint32_t h = 2166136261u;
		while (*s) { h ^= uint8_t(*s++); h *= 16777619u; }
		return h;
	}

	/* value truncated to VALUE_MAX-1 characters, rest of the field zeroed */
	void copy_value(char *dst, char const *src, size_t len)
	{
		if (len > VALUE_MAX - 1) len = VALUE_MAX - 1;
		memcpy(dst, src, len);
		memset(dst + len, 0, VALUE_MAX - len);
	}

	/*
	 * Android's IsLegalPropertyName: non-empty, only
	 * '[A-Za-z0-9_.\-@:]', no leading or trailing '.', no "..". Checked on
	 * every set AND load, so a client cannot smuggle "]: [" or a newline
	 * into a name and, via the persist file's "[name]: [value]" lines,
	 * inject a property the policy never allowed.
	 */
	bool legal_name(char const *name, size_t len)
	{
		if (len == 0) return false;
		if (name[0] == '.' || name[len - 1] == '.') return false;
		for (size_t i = 0; i < len; i++) {
			char const c = name[i];
			if (c == '.') { if (name[i - 1] == '.') return false; continue; }
			if (c == '_' || c == '-' || c == '@' || c == ':') continue;
			if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9')) continue;
			return false;
		}
		return true;
	}

	/*
	 * A value must not be able to introduce a line break: the persist file
	 * (and any other getprop-format consumer) is line-oriented, so a
	 * value containing '\n' or '\r' could inject an extra "[name]: [value]"
	 * line the policy never allowed.
	 */
	bool legal_value(char const *value, size_t len)
	{
		for (size_t i = 0; i < len; i++)
			if (value[i] == '\n' || value[i] == '\r') return false;
		return true;
	}

	/*
	 * Called after 'YIELD_AFTER' consecutive retries of a sequence-lock
	 * read, so a reader spinning against a concurrent writer gives up the
	 * CPU instead of busy-looping.
	 *
	 * 'sched_yield()' (the obvious choice) builds and links for the
	 * Genode target -- repos/libports's libc declares it in <sched.h> and
	 * provides a fallback -- but that fallback is a weak DUMMY
	 * (repos/libports/src/lib/libc/dummies.cc) that unconditionally logs
	 * "sched_yield: sched_yield not implemented" and returns -1 without
	 * yielding at all. Confirmed on target: a run/android_prop stress run
	 * hit it 155 times. 'usleep(1)' is used instead: a real (non-dummy)
	 * call on both the host and Genode's libc (the latter rounds up to
	 * "sleep at least 1 ms", repos/libports/src/lib/libc/sleep.cc), so it
	 * actually cedes the CPU to the writer, with no platform '#ifdef'.
	 */
	enum { YIELD_AFTER = 100 };

	inline void maybe_yield(unsigned &retries)
	{
		if (++retries >= YIELD_AFTER) { retries = 0; ::usleep(1); }
	}
}


void Table::format()
{
	memset(_mem, 0, SIZE);
	_hdr().version    = VERSION;
	_hdr().slot_count = SLOTS;
	__atomic_store_n(&_hdr().magic, uint32_t(MAGIC), __ATOMIC_RELEASE);
}


bool Table::valid() const
{
	return __atomic_load_n(&_hdr().magic, __ATOMIC_ACQUIRE) == MAGIC
	    && _hdr().version == VERSION && _hdr().slot_count == SLOTS;
}


Slot const *Table::find(char const *name) const
{
	uint32_t i = fnv1a(name) & (INDEX_SIZE - 1);
	for (unsigned n = 0; n < INDEX_SIZE; n++, i = (i + 1) & (INDEX_SIZE - 1)) {
		uint16_t const e = __atomic_load_n(&_index()[i], __ATOMIC_ACQUIRE);
		if (!e) return nullptr;
		Slot const &s = _slots()[e - 1];
		if (!strcmp(s.name, name)) return &s;
	}
	return nullptr;
}


/*
 * Sequence-lock writer: odd serial, long fields, value, even serial. The release
 * fence orders the odd serial before the value stores; the release store of the
 * even serial orders the value before it. Long-field updates happen inside the
 * critical section to prevent races with concurrent read_full().
 */
void Table::_store(Slot &s, char const *value, size_t len,
                   uint32_t long_offset, uint32_t long_len)
{
	uint32_t const serial = s.serial;
	__atomic_store_n(&s.serial, serial + 1, __ATOMIC_RELAXED);
	__atomic_thread_fence(__ATOMIC_RELEASE);

	/* Update long fields inside critical section */
	if (long_len) {
		s.long_offset = long_offset;
		__atomic_store_n(&s.long_len, long_len, __ATOMIC_RELAXED);
	} else {
		__atomic_store_n(&s.long_len, 0u, __ATOMIC_RELAXED);
	}

	copy_value(s.value, value, len);
	__atomic_store_n(&s.serial, serial + 2, __ATOMIC_RELEASE);
	__atomic_add_fetch(&_hdr().area_serial, 1u, __ATOMIC_RELEASE);
}


void Table::_put_long(Slot &s, char const *value, size_t len)
{
	Header &h = _hdr();
	/* Long-value area is append-only; at load time, overwriting abandons old bytes */
	memcpy(_long_area() + h.long_used, value, len + 1);
	s.long_offset = h.long_used;
	__atomic_store_n(&s.long_len, uint32_t(len), __ATOMIC_RELEASE);
	h.long_used += uint32_t(len + 1);
}


Set_result Table::_set(char const *name, char const *value, bool loading)
{
	size_t const name_len  = strlen(name);
	size_t const value_len = strlen(value);
	bool   const ro        = is_ro(name);

	if (name_len >= NAME_MAX_LEN || !legal_name(name, name_len))
		return Set_result::INVALID;
	if (value_len >= (ro ? LONG_VALUE_MAX : VALUE_MAX) || !legal_value(value, value_len))
		return Set_result::INVALID;

	Header &h = _hdr();
	bool const long_value = value_len >= VALUE_MAX;
	if (long_value && h.long_used + value_len + 1 > LONG_AREA) return Set_result::FULL;

	Slot *s = const_cast<Slot *>(find(name));
	if (s && ro && !loading) return Set_result::READ_ONLY;

	if (s) {
		/* only loading replaces a long value (ro.* is write-once otherwise) */
		uint32_t long_off = 0, long_len_val = 0;
		if (long_value) {
			/* Copy long value to append-only area (abandons old bytes at load time) */
			memcpy(_long_area() + h.long_used, value, value_len + 1);
			long_off = h.long_used;
			long_len_val = uint32_t(value_len);
			h.long_used += uint32_t(value_len + 1);
		}
		_store(*s, value, value_len, long_off, long_len_val);
		return Set_result::OK;
	}

	if (h.used == SLOTS) return Set_result::FULL;

	/* a new slot is complete before the count and the index publish it */
	Slot &n = _slots()[h.used];
	memcpy(n.name, name, name_len + 1);
	n.long_len = 0;
	if (long_value) _put_long(n, value, value_len);
	copy_value(n.value, value, value_len);
	n.serial = 2;  /* even initial serial, not protected by sequence lock yet */

	uint32_t i = fnv1a(name) & (INDEX_SIZE - 1);
	while (_index()[i]) i = (i + 1) & (INDEX_SIZE - 1);   /* never full: 2x SLOTS */

	__atomic_store_n(&h.used, h.used + 1, __ATOMIC_RELEASE);
	__atomic_store_n(&_index()[i], uint16_t(h.used), __ATOMIC_RELEASE);
	__atomic_add_fetch(&h.area_serial, 1u, __ATOMIC_RELEASE);
	return Set_result::OK;
}


unsigned Table::read(Slot const &s, char *value, uint32_t *serial_out) const
{
	char copy[VALUE_MAX];
	unsigned retries = 0;
	for (;;) {
		uint32_t const before = __atomic_load_n(&s.serial, __ATOMIC_ACQUIRE);
		if (before & 1) { maybe_yield(retries); continue; }
		memcpy(copy, s.value, VALUE_MAX);
		__atomic_thread_fence(__ATOMIC_ACQUIRE);
		if (__atomic_load_n(&s.serial, __ATOMIC_RELAXED) != before) { maybe_yield(retries); continue; }

		copy[VALUE_MAX - 1] = 0;
		size_t const len = strlen(copy);
		memcpy(value, copy, len + 1);
		if (serial_out) *serial_out = before;
		return unsigned(len);
	}
}


unsigned Table::read_full(Slot const &s, char *buf, uint32_t *serial_out) const
{
	unsigned retries = 0;
	for (;;) {
		uint32_t const before = __atomic_load_n(&s.serial, __ATOMIC_ACQUIRE);
		if (before & 1) { maybe_yield(retries); continue; }

		uint32_t const len = __atomic_load_n(&s.long_len, __ATOMIC_ACQUIRE);
		if (!len) return read(s, buf, serial_out);

		memcpy(buf, _long_area() + s.long_offset, len + 1);   /* immutable */
		__atomic_thread_fence(__ATOMIC_ACQUIRE);
		if (__atomic_load_n(&s.serial, __ATOMIC_RELAXED) != before) { maybe_yield(retries); continue; }

		if (serial_out) *serial_out = before;
		return len;
	}
}


uint32_t Table::serial(Slot const &s) const
{
	unsigned retries = 0;
	for (;;) {
		uint32_t const v = __atomic_load_n(&s.serial, __ATOMIC_ACQUIRE);
		if (!(v & 1)) return v;
		maybe_yield(retries);
	}
}


uint32_t Table::area_serial() const { return __atomic_load_n(&_hdr().area_serial, __ATOMIC_ACQUIRE); }

unsigned Table::count() const { return __atomic_load_n(&_hdr().used, __ATOMIC_ACQUIRE); }
