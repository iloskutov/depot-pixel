/*
 * \brief  Android property server: one set of system properties for all
 *         android_loader instances
 * \author Ivan Loskutov
 * \date   2026-09-26
 *
 * Config: README.
 *
 * Startup: defaults, then the 'property' nodes, then the persist file. The table is a
 * RAM dataspace attached read-only into a managed region map; clients get
 * that region map's dataspace, so core enforces read-only mappings. On a
 * config error the service is announced but denies every session.
 */

/*
 * SPDX-License-Identifier: MIT
 */

#include <base/attached_ram_dataspace.h>
#include <base/attached_rom_dataspace.h>
#include <base/heap.h>
#include <base/ram_allocator.h>
#include <base/session_object.h>
#include <libc/component.h>
#include <os/session_policy.h>
#include <region_map/client.h>
#include <rm_session/connection.h>
#include <root/component.h>
#include <util/list.h>
#include <util/reconstructible.h>
#include <util/string.h>

#include <android_prop/policy.h>
#include <android_prop/queue.h>
#include <android_prop/table.h>
#include <android_prop/text.h>
#include <android_property_session/android_property_session.h>

#include <errno.h>
#include <fcntl.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>

namespace Android_prop_server {

	using namespace Genode;
	using Session = Android_property_session::Session;

	struct Store;
	class  Session_component;
	class  Root;
	struct Main;

	using Session_list = List<List_element<Session_component>>;
}


/**
 * What sessions need from 'Main'
 */
struct Android_prop_server::Store : Interface
{
	virtual Dataspace_capability              table_ds() = 0;
	virtual Android_prop::Change_queue const &queue() = 0;
	virtual Session::Set_result set(Session_component &, char const *name, char const *value) = 0;

	/**
	 * Counter of the properties created by the clients of 'policy'
	 *
	 * \return nullptr if there are too many policies
	 */
	virtual unsigned *new_slots(Node const &policy) = 0;
};


class Android_prop_server::Session_component : public Session_object<Session>
{
	private:

		Env                                     &_env;
		Store                                   &_store;
		Session_list                            &_sessions;
		List_element<Session_component>          _le { this };
		Android_prop::Policy                     _policy { };

		/* the transfer buffer of a watcher is paid by the session's quota */
		Accounted_ram_allocator                  _ram { _env.ram(), _ram_quota_guard(), _cap_quota_guard() };
		Constructible<Attached_ram_dataspace>    _transfer { };
		Android_prop::Change_queue::Cursor       _cursor;
		Signal_context_capability                _sigh { };

		bool          _armed        = false;
		bool          _watch_signal = false;   /* watcher was caught up before an append */
		bool          _warned       = false;
		unsigned long _redundant_arms = 0;

		/*
		 * Slots are never freed, so one client must not be able to fill the
		 * table for all: the sessions of one policy together may create this
		 * many properties. The counter is kept by 'Main', it outlives the
		 * session.
		 */
		enum { NEW_SLOTS_MAX = 256 };
		unsigned &_new_slots;

	public:

		/**
		 * \param policy     the matching '<policy>' node
		 * \param new_slots  counter of the properties created under 'policy'
		 *
		 * \throw Out_of_ram, Out_of_caps  the quota does not cover the
		 *                                 transfer buffer of a watcher
		 *
		 * The session joins the list last: a constructor that throws leaves
		 * no trace of it.
		 */
		Session_component(Env &env, Resources const &res, Label const &label,
		                  Node const &policy, Store &store, Session_list &sessions,
		                  unsigned &new_slots)
		:
			Session_object(env.ep(), res, label),
			_env(env), _store(store), _sessions(sessions),
			_cursor(store.queue().head()), _new_slots(new_slots)
		{
			policy.for_each_sub_node("allow", [&] (Node const &n) {
				bool const prefix = n.has_attribute("prefix");
				String<Android_prop::NAME_MAX_LEN + 1> const text =
					n.attribute_value(prefix ? "prefix" : "name",
					                  String<Android_prop::NAME_MAX_LEN + 1>());
				if (!_policy.add(text.string(), prefix))
					warning("android_prop: ", label, ": <allow> '", text,
					        "' ignored (too long or too many rules)");
			});
			_policy.watch(policy.attribute_value("watch", false));
			if (_policy.watch())
				_transfer.construct(_ram, _env.rm(), Session::TRANSFER_SIZE);

			_sessions.insert(&_le);
		}

		~Session_component() { _sessions.remove(&_le); }

		Android_prop::Policy const &policy() const { return _policy; }

		/**
		 * \return false if the policy's clients reached their share of the table
		 */
		bool new_slot_available() const { return _new_slots < NEW_SLOTS_MAX; }

		/**
		 * Account a property this session created
		 */
		void charge_new_slot() { _new_slots++; }

		/**
		 * Called before a change is appended
		 */
		void note_queue_state()
		{
			_watch_signal = _policy.watch() && _store.queue().caught_up(_cursor);
		}

		/**
		 * Called after a successful set: wake an armed waiter or a watcher
		 */
		void after_set()
		{
			bool const signal = _armed || _watch_signal;
			_armed = _watch_signal = false;
			if (signal && _sigh.valid()) Signal_transmitter(_sigh).submit();
		}

		Dataspace_capability table() override { return _store.table_ds(); }

		Set_result set(Name const &name, Value const &value) override {
			return _store.set(*this, name.string(), value.string()); }

		void wait_sigh(Signal_context_capability sigh) override { _sigh = sigh; }

		void arm() override
		{
			if (_armed && (++_redundant_arms % 1000) == 0)
				warning("android_prop: ", label(), ": ", _redundant_arms,
				        " redundant arm() calls (a waiter is polling)");
			_armed = true;
		}

		Dataspace_capability transfer() override
		{
			if (!_policy.watch()) {
				if (!_warned) warning("android_prop: ", label(), ": transfer() without watch=\"yes\"");
				_warned = true;
			}
			return _transfer.constructed() ? Dataspace_capability(_transfer->cap())
			                               : Dataspace_capability();
		}

		Fetch_result changes() override
		{
			if (!_policy.watch()) {
				if (!_warned) warning("android_prop: ", label(), ": changes() without watch=\"yes\"");
				_warned = true;
				return { 0, 0 };
			}
			Android_prop::Change_queue::Fetch const f =
				_store.queue().fetch(_cursor, _transfer->local_addr<Android_prop::Change>(),
				                     Session::TRANSFER_SIZE / sizeof(Android_prop::Change));
			return { f.count, f.overflow ? 1u : 0u };
		}
};


class Android_prop_server::Root : public Root_component<Session_component>
{
	private:

		Env                    &_env;
		Store                  &_store;
		Session_list           &_sessions;
		Attached_rom_dataspace &_config;   /* node() returns a copy: keep the ROM */
		bool const              _config_ok;

	protected:

		Create_result _create_session(char const *args) override
		{
			Session_label const label = session_label_from_args(args);

			if (!_config_ok) {
				error("android_prop: config error -- session '", label, "' denied");
				return Session_error::DENIED;
			}

			Session_component *s = nullptr;
			with_matching_policy(label, _config.node(),
				[&] (Node const &policy) {
					unsigned * const new_slots = _store.new_slots(policy);
					if (!new_slots) {
						error("android_prop: too many policies -- session '", label, "' denied");
						return;
					}
					s = new (md_alloc())
						Session_component(_env, session_resources_from_args(args), label,
						                  policy, _store, _sessions, *new_slots);
				},
				[&] { warning("android_prop: no policy for '", label, "' -- session denied"); });

			if (!s) return Session_error::DENIED;
			return *s;
		}

	public:

		Root(Env &env, Allocator &alloc, Store &store, Session_list &sessions,
		     Attached_rom_dataspace &config, bool config_ok)
		:
			Root_component<Session_component>(env.ep(), alloc),
			_env(env), _store(store), _sessions(sessions), _config(config),
			_config_ok(config_ok)
		{ }
};


struct Android_prop_server::Main : Store, Noncopyable
{
	enum { TABLE_DS_SIZE = (Android_prop::Table::SIZE + 4095) & ~size_t(4095) };

	using Path = String<128>;

	Env &env;

	Attached_rom_dataspace config { env, "config" };
	Heap                   heap   { env.ram(), env.rm() };
	Session_list           sessions { };

	Attached_ram_dataspace table_ram { env.ram(), env.rm(), TABLE_DS_SIZE };
	Android_prop::Table    table     { table_ram.local_addr<void>() };

	/* read-only view handed to clients */
	Rm_connection        rm_connection { env };
	Region_map_client    ro_map { rm_connection.create(TABLE_DS_SIZE) };
	Dataspace_capability ro_ds  { };

	Android_prop::Change_queue change_queue { };

	bool permissive       = false;
	bool persist_disabled = false;   /* load_persist hit a real error: sets still succeed, file untouched */
	Path persist_path { };

	/*
	 * Properties created per policy, the policy told by its label
	 * attributes. Not per session or session label: a client chooses the
	 * end of its label and opens as many sessions as it likes.
	 */
	enum { MAX_POLICIES = 32 };

	using Policy_key = String<3*Session_label::capacity() + 8>;

	struct Budget { Policy_key key; unsigned new_slots; };

	Budget   budgets[MAX_POLICIES] { };
	unsigned budget_count = 0;

	Constructible<Root> root { };

	/*
	 * Whole file through libc, handed to 'fn(text, len)'. Fails (and calls
	 * 'fn' not at all) unless every one of 'st_size' bytes was read: a
	 * short read must never hand the caller a truncated file as if it were
	 * complete (a persist-file caller rewriting from that would silently
	 * destroy the properties the partial read missed).
	 *
	 * 'not_found', if given, is set when the failure was 'open()' seeing
	 * ENOENT (the normal "no such file yet" case) and cleared for every
	 * other failure (permission error, I/O error, a short read).
	 */
	static bool with_file(char const *path, auto const &fn, bool *not_found = nullptr)
	{
		if (not_found) *not_found = false;

		int const fd = ::open(path, O_RDONLY);
		if (fd < 0) {
			if (not_found) *not_found = (errno == ENOENT);
			return false;
		}
		struct stat st { };
		if (::fstat(fd, &st) < 0) { ::close(fd); return false; }
		size_t const size = size_t(st.st_size);
		char *buf = (char *)::malloc(size + 1);
		size_t done = 0;
		while (buf && done < size) {
			ssize_t const n = ::read(fd, buf + done, size - done);
			if (n <= 0) break;
			done += size_t(n);
		}
		::close(fd);
		if (!buf || done != size) { ::free(buf); return false; }
		fn((char const *)buf, done);
		::free(buf);
		return true;
	}

	bool load_defaults(Node const &cfg)
	{
		bool ok = true;
		cfg.with_optional_sub_node("defaults", [&] (Node const &n) {
			Path const path = n.attribute_value("file", Path());
			unsigned dropped = 0, loaded = 0;
			bool const found = with_file(path.string(), [&] (char const *text, size_t len) {
				loaded = Android_prop::parse_getprop(text, len, [&] (char const *name, char const *value) {
					if (table.load(name, value) == Android_prop::Set_result::OK) return true;
					dropped++;
					return false; });
			});
			if (!found) {
				error("android_prop: cannot read defaults file '", path, "'");
				ok = false;
				return;
			}
			log("android_prop: ", loaded, " defaults from ", path);
			if (dropped)
				warning("android_prop: ", dropped, " defaults dropped (invalid or table full)");
		});
		return ok;
	}

	bool load_config_properties(Node const &cfg)
	{
		bool ok = true;
		cfg.for_each_sub_node("property", [&] (Node const &n) {
			/* '+ 1': an over-long name or value arrives at (not under) the
			 * table's limit instead of silently becoming a shorter,
			 * different <property> */
			using Name  = String<Android_prop::NAME_MAX_LEN + 1>;
			using Value = String<Android_prop::LONG_VALUE_MAX + 1>;
			Name  const name  = n.attribute_value("name", Name());
			Value const value = n.attribute_value("value", Value());
			switch (table.load(name.string(), value.string())) {
			case Android_prop::Set_result::OK:
				break;
			case Android_prop::Set_result::FULL:
				warning("android_prop: <property name=\"", name, "\"> dropped (table full)");
				break;
			case Android_prop::Set_result::INVALID:
			case Android_prop::Set_result::READ_ONLY:
				error("android_prop: invalid <property name=\"", name, "\">");
				ok = false;
				break;
			}
		});
		return ok;
	}

	void load_persist(Node const &cfg)
	{
		cfg.with_optional_sub_node("persist", [&] (Node const &n) {
			persist_path = n.attribute_value("file", Path()); });
		if (persist_path.length() <= 1) return;

		/* like Android init's /data/property: create the directory if missing */
		char dir[128];
		copy_cstring(dir, persist_path.string(), sizeof(dir));
		if (char *slash = strrchr(dir, '/')) {
			*slash = 0;
			if (dir[0] && ::mkdir(dir, 0700) != 0 && errno != EEXIST)
				warning("android_prop: cannot create '", Cstring(dir), "'");
		}

		unsigned loaded = 0, dropped = 0;
		bool not_found = false;
		bool const found = with_file(persist_path.string(), [&] (char const *text, size_t len) {
			loaded = Android_prop::parse_getprop(text, len, [&] (char const *name, char const *value) {
				if (!Android_prop::is_persist(name)) {
					warning("android_prop: '", Cstring(name), "' in the persist file ignored");
					return false;
				}
				if (table.load(name, value) == Android_prop::Set_result::OK) return true;
				dropped++;
				return false; });
		}, &not_found);

		if (found) {
			log("android_prop: ", loaded, " persistent properties from ", persist_path);
			if (dropped)
				warning("android_prop: ", dropped, " persistent properties dropped (invalid or table full)");
			return;
		}

		if (not_found) {
			log("android_prop: no persist file ", persist_path, " (first boot)");
			return;
		}

		/*
		 * Anything other than ENOENT (permission error, I/O error, or a
		 * short read that 'with_file' now refuses) means the file may
		 * exist but was not read in full: rewriting it from a
		 * partially-loaded table would silently destroy the properties
		 * that were never read. Disable persistence for this run instead
		 * -- sets still succeed, the file on disk is left exactly as is.
		 */
		error("android_prop: cannot read persist file '", persist_path,
		      "' -- persistence disabled for this run");
		persist_disabled = true;
	}

	/*
	 * Store interface
	 */

	Dataspace_capability              table_ds() override { return ro_ds; }
	Android_prop::Change_queue const &queue()    override { return change_queue; }

	unsigned *new_slots(Node const &policy) override
	{
		using Label = String<Session_label::capacity()>;
		auto attr = [&] (char const *a) { return policy.attribute_value(a, Label()); };
		Policy_key const key(attr("label"), " | ", attr("label_prefix"), " | ", attr("label_suffix"));

		for (unsigned i = 0; i < budget_count; i++)
			if (budgets[i].key == key) return &budgets[i].new_slots;

		if (budget_count == MAX_POLICIES) return nullptr;
		budgets[budget_count].key = key;
		return &budgets[budget_count++].new_slots;
	}

	Session::Set_result set(Session_component &who, char const *name, char const *value) override
	{
		using Verdict = Android_prop::Verdict;
		using Result  = Session::Set_result;

		/*
		 * A value of 'SET_VALUE_MAX - 1' characters or more cannot be told
		 * apart from a longer one that the 'Session::Value' wire type
		 * silently truncated to fit; refuse it outright rather than risk
		 * storing a truncated value as if it were the client's real intent
		 * (permanent for a new ro.* property, which is write-once).
		 */
		if (::strlen(value) >= Session::SET_VALUE_MAX - 1) {
			warning("android_prop: invalid: ", who.label(), " ", Cstring(name), " (value too long)");
			return Result::INVALID;
		}

		bool const exists = table.find(name) != nullptr;

		switch (Android_prop::check(who.policy(), exists, name, permissive)) {
		case Verdict::DENY:
			warning("android_prop: denied: ", who.label(), " ", Cstring(name), "=", Cstring(value));
			return Result::DENIED;
		case Verdict::DENY_READ_ONLY:
			warning("android_prop: denied (read-only): ", who.label(), " ", Cstring(name), "=", Cstring(value));
			return Result::DENIED;
		case Verdict::ALLOW_PERMISSIVE:
			log("android_prop: would deny: ", who.label(), " ", Cstring(name), "=", Cstring(value));
			break;
		case Verdict::ALLOW:
			break;
		}

		if (!exists && !who.new_slot_available()) {
			warning("android_prop: ", who.label(), " created its share of the table: ",
			        Cstring(name), " refused");
			return Result::FULL;
		}

		for (List_element<Session_component> *e = sessions.first(); e; e = e->next())
			e->object()->note_queue_state();

		switch (table.set(name, value)) {
		case Android_prop::Set_result::OK:        break;
		case Android_prop::Set_result::INVALID:
			warning("android_prop: invalid: ", who.label(), " ", Cstring(name));
			return Result::INVALID;
		case Android_prop::Set_result::FULL:
			warning("android_prop: table full: ", who.label(), " ", Cstring(name));
			return Result::FULL;
		case Android_prop::Set_result::READ_ONLY: return Result::DENIED;
		}

		if (!exists) who.charge_new_slot();

		Android_prop::Slot const &slot = *table.find(name);
		change_queue.append(table.index(slot), table.serial(slot), value, slot.long_len != 0);

		if (Android_prop::is_persist(name) && persist_path.length() > 1 && !persist_disabled) {
			bool ok = false;
			Libc::with_libc([&] { ok = Android_prop::write_persist_file(table, persist_path.string()); });
			if (!ok) error("android_prop: cannot write persist file '", persist_path, "'");
		}

		for (List_element<Session_component> *e = sessions.first(); e; e = e->next())
			e->object()->after_set();

		return Result::OK;
	}

	Main(Env &env) : env(env)
	{
		table.format();

		ro_map.attach(table_ram.cap(), {
			.size = TABLE_DS_SIZE, .offset = { }, .use_at = { }, .at = { },
			.executable = false, .writeable = false
		}).with_result(
			[&] (Region_map::Range) { ro_ds = ro_map.dataspace(); },
			[&] (Region_map::Attach_error) {
				error("android_prop: cannot attach the table read-only"); });

		Node const &cfg = config.node();
		permissive = cfg.attribute_value("permissive", false);

		bool config_ok = ro_ds.valid();
		config_ok = load_defaults(cfg)          && config_ok;
		config_ok = load_config_properties(cfg) && config_ok;
		load_persist(cfg);

		if (!config_ok)
			error("android_prop: config error -- denying all sessions");
		if (permissive)
			warning("android_prop: permissive mode -- disallowed sets are logged and performed");

		log("android_prop: ", table.count(), " properties");
		root.construct(env, heap, *this, sessions, config, config_ok);
		env.parent().announce(env.ep().manage(*root));
	}
};


void Libc::Component::construct(Libc::Env &env)
{
	Libc::with_libc([&] { static Android_prop_server::Main main(env); });
}
