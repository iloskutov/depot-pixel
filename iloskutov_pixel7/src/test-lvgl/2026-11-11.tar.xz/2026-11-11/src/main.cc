/*
 * \brief  Test of LVGL on Genode: a scrolling list and the on-screen keyboard
 * \author Ivan Loskutov
 * \date   2026-11-11
 *
 * The screen holds a title, a scrolling list of 40 entries, a text area,
 * and LVGL's keyboard. Taps on entries, the text typed, and the keyboard's
 * OK are logged:
 *
 *   test-lvgl: tap: Entry 7
 *   test-lvgl: text: hello
 *   test-lvgl: submitted: hello
 *
 * 'config | verbose_input: yes' also logs the input events and what LVGL
 * reads of them. 'windows: 2' opens a second window of the same content,
 * the GUI sessions are labeled "one" and "two" then.
 */

/*
 * SPDX-License-Identifier: MIT
 */

#include <base/attached_rom_dataspace.h>
#include <base/log.h>
#include <libc/component.h>

#include <lvgl_genode.h>

namespace Test {

	struct Screen;
	struct Main;
}


struct Test::Screen : Lvgl_genode::Window::Ui
{
	static void _entry_clicked(lv_event_t *e)
	{
		lv_obj_t *label = (lv_obj_t *)lv_event_get_user_data(e);
		Genode::log("test-lvgl: tap: ", Genode::Cstring(lv_label_get_text(label)));
	}

	static void _text_changed(lv_event_t *e)
	{
		lv_obj_t *ta = (lv_obj_t *)lv_event_get_target(e);
		Genode::log("test-lvgl: ", lv_tick_get(), " ms: text: ",
		            lv_textarea_get_text(ta));
	}

	static void _submitted(lv_event_t *e)
	{
		lv_obj_t *ta = (lv_obj_t *)lv_event_get_user_data(e);
		Genode::log("test-lvgl: submitted: ", lv_textarea_get_text(ta));
	}

	void create(lv_display_t &display) override
	{
		lv_theme_t *theme = lv_theme_default_init(&display,
			lv_palette_main(LV_PALETTE_BLUE), lv_palette_main(LV_PALETTE_TEAL),
			true, LV_FONT_DEFAULT);
		lv_display_set_theme(&display, theme);

		lv_obj_t *screen = lv_display_get_screen_active(&display);
		lv_obj_set_flex_flow(screen, LV_FLEX_FLOW_COLUMN);
		lv_obj_set_style_pad_all(screen, 24, 0);
		lv_obj_set_style_pad_row(screen, 24, 0);

		lv_obj_t *title = lv_label_create(screen);
		lv_obj_set_style_text_font(title, &lv_font_montserrat_48, 0);
		lv_label_set_text_fmt(title, "LVGL %d.%d.%d on Genode", LVGL_VERSION_MAJOR,
		                      LVGL_VERSION_MINOR, LVGL_VERSION_PATCH);

		/* the list (a scrolling flex column) takes the space left */
		lv_obj_t *list = lv_obj_create(screen);
		lv_obj_set_width(list, lv_pct(100));
		lv_obj_set_flex_grow(list, 1);
		lv_obj_set_flex_flow(list, LV_FLEX_FLOW_COLUMN);
		for (unsigned i = 1; i <= 40; i++) {
			lv_obj_t *button = lv_button_create(list);
			lv_obj_set_width(button, lv_pct(100));
			lv_obj_t *label = lv_label_create(button);
			lv_label_set_text_fmt(label, LV_SYMBOL_FILE "  Entry %u", i);
			lv_obj_add_event_cb(button, _entry_clicked, LV_EVENT_CLICKED, label);
		}

		lv_obj_t *ta = lv_textarea_create(screen);
		lv_obj_set_width(ta, lv_pct(100));
		lv_textarea_set_one_line(ta, true);
		lv_textarea_set_placeholder_text(ta, "Type here");
		lv_obj_add_event_cb(ta, _text_changed, LV_EVENT_VALUE_CHANGED, nullptr);

		lv_obj_t *keyboard = lv_keyboard_create(screen);
		lv_obj_set_size(keyboard, lv_pct(100), lv_pct(35));

		/* the theme's gaps, scaled for 400 dpi, leave the keys too narrow */
		lv_obj_set_style_pad_all(keyboard, 8, 0);
		lv_obj_set_style_pad_row(keyboard, 10, 0);
		lv_obj_set_style_pad_column(keyboard, 10, 0);
		lv_keyboard_set_textarea(keyboard, ta);
		lv_obj_add_event_cb(keyboard, _submitted, LV_EVENT_READY, ta);
	}

	void resized(lv_display_t &display) override
	{
		Genode::log("test-lvgl: resized to ",
		            lv_display_get_horizontal_resolution(&display), "x",
		            lv_display_get_vertical_resolution(&display));
	}
};


struct Test::Main
{
	Genode::Attached_rom_dataspace _config;

	bool const _verbose = _config.node().attribute_value("verbose_input", false);
	bool const _two     = _config.node().attribute_value("windows", 1u) == 2;

	Lvgl_genode::Runtime _runtime;

	Screen _screen_one { }, _screen_two { };

	Lvgl_genode::Window _one;

	Genode::Constructible<Lvgl_genode::Window> _window_two { };

	Main(Genode::Env &env)
	:
		_config(env, "config"),
		_runtime(env),
		_one(env, _runtime, _screen_one, _two ? "one" : "", _verbose)
	{
		if (_two)
			_window_two.construct(env, _runtime, _screen_two, "two", _verbose);
	}
};


void Libc::Component::construct(Libc::Env &env)
{
	static Test::Main main(env);
}
