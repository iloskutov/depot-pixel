/*
 * \brief  Phone app: calls through 'modem_link'
 * \author Ivan Loskutov
 * \date   2026-11-12
 *
 * Two tabs: the keypad, a number field (also typed into from the keyboard)
 * with a dial pad, hidden while the on-screen keyboard leaves too little
 * room, and a button that picks a contact's number; and the recent calls
 * of the ROM "call_log" of 'call_log', a tap puts the number
 * on the keypad (64 px, as the list of Messages). The call button reports a
 * "call_request" to dial.
 *
 * The names come from a 'Contacts' session that may list the contacts
 * ('read: yes'): the recent calls, the call screen, the picker.
 *
 * While a call goes on (ROM "call_state" of 'modem_link'), the call
 * screen covers the tabs: the caller's name or number, the state or the
 * time since the call was answered, and Accept and Reject while it rings,
 * Hang up otherwise. The shown tab is reported as "phone_view", so
 * 'call_log' marks missed calls as seen.
 *
 * The number is drawn large, in Liberation Sans from the ROM
 * "LiberationSans-Regular.ttf". What the user does is logged:
 *
 *   phone: dial 0791234567
 *   phone: accept|reject|hangup
 */

/*
 * SPDX-License-Identifier: MIT
 */

#include <base/attached_rom_dataspace.h>
#include <base/log.h>
#include <libc/component.h>
#include <os/reporter.h>
#include <timer_session/connection.h>
#include <contacts_session/connection.h>

#include <lvgl_genode.h>

namespace Phone_app { struct Main; }


struct Phone_app::Main : Lvgl_genode::Window::Ui
{
	using Number = Genode::String<33>;
	using Name   = Contacts::Name;      /* a contact's name, or a number */
	using State  = Genode::String<16>;

	Genode::Env &_env;

	Genode::Attached_rom_dataspace _ttf;
	Genode::Attached_rom_dataspace _call_state { _env, "call_state" };
	Genode::Attached_rom_dataspace _call_log   { _env, "call_log" };

	/* the names of the numbers, and the list of the contact picker */
	Contacts::Connection _contacts { _env };

	Name _name(Number const &number)
	{
		Contacts::Lookup const l = _contacts.lookup(number);
		return l.found ? Name(l.name) : Name(number);
	}

	Genode::Expanding_reporter _call_request { _env, "call_request", "call_request" };
	Genode::Expanding_reporter _phone_view   { _env, "phone_view",   "phone_view" };

	Timer::Connection _timer { _env };

	unsigned _seq = 0;   /* of the last call_request */

	lv_obj_t *_tabs   = nullptr, *_number = nullptr, *_pad    = nullptr;
	lv_obj_t *_recent = nullptr;
	lv_obj_t *_call   = nullptr, *_call_title = nullptr, *_call_status = nullptr;
	lv_obj_t *_accept = nullptr, *_reject = nullptr, *_hang_up = nullptr;

	lv_font_t *_list_font = nullptr;   /* the recent calls, as Messages' list */

	State    _state { };
	bool     _was_active = false;
	uint64_t _active_since_ms = 0;   /* when the call was answered, by our timer */

	static Main &_main(lv_event_t *e) { return *(Main *)lv_event_get_user_data(e); }

	void _request(char const *action, Number const &number = Number())
	{
		Genode::log("phone: ", action, number.length() > 1 ? " " : "", number);
		_call_request.generate([&] (Genode::Generator &g) {
			g.attribute("seq",    ++_seq);
			g.attribute("action", action);
			if (number.length() > 1)
				g.attribute("number", number); });
	}

	static void _digit(lv_event_t *e)
	{
		lv_obj_t *pad = lv_event_get_target_obj(e);
		char const *text = lv_buttonmatrix_get_button_text(pad,
			lv_buttonmatrix_get_selected_button(pad));
		if (text)
			lv_textarea_add_text(_main(e)._number, text);
	}

	static void _delete(lv_event_t *e) {
		lv_textarea_delete_char(_main(e)._number); }

	static void _dial(lv_event_t *e)
	{
		Main &main = _main(e);

		/* the field keeps the key focus while it is not shown */
		if (lv_tabview_get_tab_active(main._tabs) != 0
		 || !lv_obj_is_hidden(main._picker))
			return;

		char const *number = lv_textarea_get_text(main._number);
		if (!number[0])
			return;

		main._request("dial", Number(number));
		lv_textarea_set_text(main._number, "");
	}

	static void _accept_call (lv_event_t *e) { _main(e)._request("accept"); }
	static void _reject_call (lv_event_t *e) { _main(e)._request("reject"); }
	static void _hang_up_call(lv_event_t *e) { _main(e)._request("hangup"); }

	void _report_view()
	{
		_phone_view.generate([&] (Genode::Generator &g) {
			g.attribute("tab", lv_tabview_get_tab_active(_tabs) == 1 ? "recent" : "keypad"); });
	}

	static void _tab_changed(lv_event_t *e) { _main(e)._report_view(); }

	static void _recent_tapped(lv_event_t *e)
	{
		Main &main = _main(e);
		lv_obj_t *entry = lv_event_get_current_target_obj(e);
		lv_textarea_set_text(main._number, (char const *)lv_obj_get_user_data(entry));
		lv_tabview_set_active(main._tabs, 0, LV_ANIM_OFF);
		main._report_view();
	}

	static lv_obj_t *_plain(lv_obj_t *parent)
	{
		lv_obj_t *obj = lv_obj_create(parent);
		lv_obj_set_style_bg_opa(obj, LV_OPA_TRANSP, 0);
		lv_obj_set_style_border_width(obj, 0, 0);
		lv_obj_set_style_radius(obj, 0, 0);
		lv_obj_set_style_pad_all(obj, 0, 0);
		lv_obj_set_scrollable(obj, false);
		return obj;
	}

	static lv_obj_t *_column(lv_obj_t *parent)
	{
		lv_obj_t *column = _plain(parent);
		lv_obj_set_size(column, lv_pct(100), lv_pct(100));
		lv_obj_set_style_pad_all(column, 24, 0);
		lv_obj_set_style_pad_row(column, 24, 0);
		lv_obj_set_flex_flow(column, LV_FLEX_FLOW_COLUMN);
		lv_obj_set_flex_align(column, LV_FLEX_ALIGN_START, LV_FLEX_ALIGN_CENTER,
		                      LV_FLEX_ALIGN_CENTER);
		return column;
	}

	static lv_obj_t *_round_button(lv_obj_t *parent, char const *symbol,
	                               lv_palette_t color)
	{
		lv_obj_t *button = lv_button_create(parent);
		lv_obj_set_size(button, 128, 128);
		lv_obj_set_style_radius(button, LV_RADIUS_CIRCLE, 0);
		lv_obj_set_style_bg_color(button, lv_palette_main(color), 0);
		lv_obj_t *label = lv_label_create(button);
		lv_label_set_text(label, symbol);
		lv_obj_center(label);
		lv_group_remove_obj(button);
		return button;
	}

	/* the time of an active call, every second */
	bool _clock = false;

	void _handle_clock()
	{
		if (_runtime.in_lvgl()) {
			Genode::Signal_transmitter(_clock_handler).submit();
			return;
		}
		_update_status();
		_runtime.run();
	}

	Genode::Signal_handler<Main> _clock_handler {
		_env.ep(), *this, &Main::_handle_clock };

	void _run_clock(bool run)
	{
		if (run == _clock)
			return;
		_clock = run;
		_timer.trigger_periodic(run ? 1000*1000 : 0);
	}

	void _update_status()
	{
		if (_state == "active") {
			uint64_t const now_ms = _timer.elapsed_ms();
			uint64_t const s      = (now_ms - Genode::min(_active_since_ms, now_ms))/1000;
			lv_label_set_text_fmt(_call_status, "%02u:%02u", unsigned(s/60), unsigned(s%60));
			return;
		}
		lv_label_set_text(_call_status,
			_state == "incoming" ? "Incoming call" :
			_state == "outbound" ? "Calling" :
			_state == "alerting" ? "Ringing" : "");
	}

	void _update_call()
	{
		Genode::Node const &call = _call_state.node();

		_state = call.attribute_value("state", State());

		/*
		 * How long the call has been active, as of the report in which it
		 * became so: a later look at the same report must not start anew
		 */
		bool const active = (_state == "active");
		if (active && !_was_active) {
			uint64_t const active_ms = call.attribute_value("active_s", 0ull)*1000;
			uint64_t const now_ms    = _timer.elapsed_ms();
			_active_since_ms = now_ms - Genode::min(active_ms, now_ms);
		}
		_was_active = active;

		/* a relaunched app continues after the last request */
		_seq = Genode::max(_seq, call.attribute_value("request_seq", 0u));

		bool const in_call = _state == "incoming" || _state == "outbound"
		                  || _state == "alerting" || _state == "active";
		bool const ringing = _state == "incoming";

		Number const number = call.attribute_value("number", Number());
		lv_label_set_text(_call_title, number.length() > 1 ? _name(number).string() : "");

		lv_obj_set_hidden(_call,    !in_call);
		lv_obj_set_hidden(_tabs,     in_call);
		lv_obj_set_hidden(_accept,  !ringing);
		lv_obj_set_hidden(_reject,  !ringing);
		lv_obj_set_hidden(_hang_up,  ringing);

		_update_status();
		_run_clock(_state == "active");
	}

	void _update_recent()
	{
		lv_obj_clean(_recent);

		_call_log.node().for_each_sub_node("call", [&] (Genode::Node const &call) {
			Number const number = call.attribute_value("number", Number());
			State  const dir    = call.attribute_value("direction", State());
			Genode::String<24> const time = call.attribute_value("time", Genode::String<24>());

			lv_obj_t *entry = lv_button_create(_recent);
			lv_obj_set_width(entry, lv_pct(100));
			lv_obj_set_style_bg_color(entry, dir == "missed"
				? lv_palette_main(LV_PALETTE_RED) : lv_palette_darken(LV_PALETTE_GREY, 3), 0);
			lv_obj_t *label = lv_label_create(entry);
			lv_obj_set_style_text_font(label, _list_font, 0);
			lv_label_set_text_fmt(label, "%s  %s\n%s",
				dir == "out" ? LV_SYMBOL_UPLOAD : LV_SYMBOL_DOWNLOAD,
				_name(number).string(), time.string());

			/* the number, kept with the entry until the list is rebuilt */
			char *copy = (char *)lv_malloc(number.length());
			Genode::copy_cstring(copy, number.string(), number.length());
			lv_obj_set_user_data(entry, copy);
			lv_obj_add_event_cb(entry, [] (lv_event_t *e) {
				lv_free(lv_obj_get_user_data(lv_event_get_current_target_obj(e))); },
				LV_EVENT_DELETE, nullptr);

			lv_obj_add_event_cb(entry, _recent_tapped, LV_EVENT_CLICKED, this);
			lv_group_remove_obj(entry);
		});
	}

	/*
	 * The contact picker: a number of each contact, a tap puts it on the
	 * keypad
	 */
	lv_obj_t *_picker = nullptr, *_picker_list = nullptr;

	static void _picked(lv_event_t *e)
	{
		Main &main = _main(e);
		lv_obj_t *entry = lv_event_get_current_target_obj(e);
		lv_textarea_set_text(main._number, (char const *)lv_obj_get_user_data(entry));
		lv_obj_set_hidden(main._picker, true);
		lv_tabview_set_active(main._tabs, 0, LV_ANIM_OFF);
		main._report_view();
	}

	static void _pick(lv_event_t *e)
	{
		Main &main = _main(e);
		main._update_picker();
		lv_obj_set_hidden(main._picker, false);
	}

	static void _pick_cancel(lv_event_t *e) {
		lv_obj_set_hidden(_main(e)._picker, true); }

	void _update_picker()
	{
		lv_obj_clean(_picker_list);

		unsigned const count = _contacts.count();
		for (unsigned i = 0; i < count; i++) {
			Contacts::Contact const c = _contacts.contact(i);
			if (!c.valid)
				continue;
			for (unsigned j = 0; j < c.numbers; j++) {
				Contacts::Phone const p = _contacts.number(c.id, j);
				if (!p.valid)
					continue;

				lv_obj_t *entry = lv_button_create(_picker_list);
				lv_obj_set_width(entry, lv_pct(100));
				lv_obj_t *label = lv_label_create(entry);
				lv_obj_set_style_text_font(label, _list_font, 0);
				lv_label_set_text_fmt(label, "%s\n%s", c.name.string(), p.number.string());

				char *copy = (char *)lv_malloc(p.number.length());
				Genode::copy_cstring(copy, p.number.string(), p.number.length());
				lv_obj_set_user_data(entry, copy);
				lv_obj_add_event_cb(entry, [] (lv_event_t *e) {
					lv_free(lv_obj_get_user_data(lv_event_get_current_target_obj(e))); },
					LV_EVENT_DELETE, nullptr);
				lv_obj_add_event_cb(entry, _picked, LV_EVENT_CLICKED, this);
				lv_group_remove_obj(entry);
			}
		}
		if (!count)
			lv_label_set_text(lv_label_create(_picker_list), "No contacts");
	}

	void _handle_roms()
	{
		if (_runtime.in_lvgl()) {
			Genode::Signal_transmitter(_roms_handler).submit();
			return;
		}
		_call_state.update();
		_call_log.update();

		/* without a window there is nothing to update yet */
		if (!_tabs)
			return;

		_update_call();

		/* the list is built anew: stay where the user scrolled to */
		int32_t const scroll_y = lv_obj_get_scroll_y(_recent);
		_update_recent();
		lv_obj_update_layout(_recent);
		lv_obj_scroll_to_y(_recent, scroll_y, LV_ANIM_OFF);

		_runtime.run();
	}

	Genode::Signal_handler<Main> _roms_handler {
		_env.ep(), *this, &Main::_handle_roms };

	void create(lv_display_t &display) override
	{
		lv_theme_t *theme = lv_theme_default_init(&display,
			lv_palette_main(LV_PALETTE_GREEN), lv_palette_main(LV_PALETTE_TEAL),
			true, LV_FONT_DEFAULT);
		lv_display_set_theme(&display, theme);

		lv_obj_t *screen = lv_display_get_screen_active(&display);
		lv_obj_set_scrollable(screen, false);

		/* the number, 96 px */
		lv_font_t *number_font = lv_tiny_ttf_create_data(_ttf.local_addr<void>(),
		                                                  _ttf.size(), 96);
		number_font->fallback = &lv_font_montserrat_48;

		/* the recent calls in the size of Messages' list */
		_list_font = lv_tiny_ttf_create_data(_ttf.local_addr<void>(), _ttf.size(), 64);
		_list_font->fallback = &lv_font_montserrat_48;

		_tabs = lv_tabview_create(screen);
		lv_tabview_set_tab_bar_position(_tabs, LV_DIR_BOTTOM);
		lv_tabview_set_tab_bar_size(_tabs, 120);
		lv_obj_add_event_cb(_tabs, _tab_changed, LV_EVENT_VALUE_CHANGED, this);
		lv_obj_t *tab_bar = lv_tabview_get_tab_bar(_tabs);
		lv_obj_set_style_text_font(tab_bar, &lv_font_montserrat_48, 0);

		lv_obj_t *keypad = lv_tabview_add_tab(_tabs, LV_SYMBOL_KEYBOARD);
		lv_obj_t *recent = lv_tabview_add_tab(_tabs, LV_SYMBOL_LIST);
		for (unsigned i = 0; i < lv_obj_get_child_count(tab_bar); i++)
			lv_group_remove_obj(lv_obj_get_child(tab_bar, i));

		/* the keypad */
		lv_obj_set_style_pad_all(keypad, 0, 0);
		lv_obj_t *dialer = _column(keypad);

		lv_obj_t *top = _plain(dialer);
		lv_obj_set_width(top, lv_pct(100));
		lv_obj_set_flex_grow(top, 1);
		lv_obj_set_flex_flow(top, LV_FLEX_FLOW_COLUMN);
		lv_obj_set_flex_align(top, LV_FLEX_ALIGN_CENTER, LV_FLEX_ALIGN_CENTER,
		                      LV_FLEX_ALIGN_CENTER);

		_number = lv_textarea_create(top);
		lv_obj_set_width(_number, lv_pct(100));
		lv_textarea_set_one_line(_number, true);
		lv_textarea_set_accepted_chars(_number, "0123456789*#+");
		lv_textarea_set_placeholder_text(_number, "Number");
		lv_obj_set_style_text_font(_number, number_font, 0);
		lv_obj_set_style_text_align(_number, LV_TEXT_ALIGN_CENTER, 0);
		lv_obj_set_style_bg_opa(_number, LV_OPA_TRANSP, 0);
		lv_obj_set_style_border_width(_number, 0, 0);
		lv_obj_add_event_cb(_number, _dial, LV_EVENT_READY, this);
		lv_group_focus_obj(_number);

		static char const *pad_map[] = {
			"1", "2", "3", "\n", "4", "5", "6", "\n",
			"7", "8", "9", "\n", "*", "0", "#", "" };

		_pad = lv_buttonmatrix_create(dialer);
		lv_buttonmatrix_set_map(_pad, pad_map);
		lv_obj_set_size(_pad, lv_pct(100), lv_pct(48));
		lv_obj_set_style_text_font(_pad, &lv_font_montserrat_48, 0);
		lv_obj_add_event_cb(_pad, _digit, LV_EVENT_VALUE_CHANGED, this);
		lv_group_remove_obj(_pad);
		resized(display);

		lv_obj_t *row = _plain(dialer);
		lv_obj_set_size(row, lv_pct(100), LV_SIZE_CONTENT);
		lv_obj_set_flex_flow(row, LV_FLEX_FLOW_ROW);
		lv_obj_set_flex_align(row, LV_FLEX_ALIGN_SPACE_EVENLY,
		                      LV_FLEX_ALIGN_CENTER, LV_FLEX_ALIGN_CENTER);

		lv_obj_add_event_cb(_round_button(row, LV_SYMBOL_CALL, LV_PALETTE_GREEN),
		                    _dial, LV_EVENT_CLICKED, this);
		lv_obj_add_event_cb(_round_button(row, LV_SYMBOL_DIRECTORY, LV_PALETTE_BLUE_GREY),
		                    _pick, LV_EVENT_CLICKED, this);
		lv_obj_add_event_cb(_round_button(row, LV_SYMBOL_BACKSPACE, LV_PALETTE_GREY),
		                    _delete, LV_EVENT_CLICKED, this);

		/* the recent calls */
		lv_obj_set_style_pad_all(recent, 0, 0);
		_recent = _column(recent);
		lv_obj_set_style_pad_row(_recent, 16, 0);
		lv_obj_set_scrollable(_recent, true);
		lv_obj_set_flex_align(_recent, LV_FLEX_ALIGN_START, LV_FLEX_ALIGN_START,
		                      LV_FLEX_ALIGN_START);

		/* the contact picker, above the tabs */
		_picker = _column(screen);
		lv_obj_set_style_bg_opa(_picker, LV_OPA_COVER, 0);
		lv_obj_set_style_bg_color(_picker, lv_obj_get_style_bg_color(screen, LV_PART_MAIN), 0);
		lv_obj_set_flex_align(_picker, LV_FLEX_ALIGN_START, LV_FLEX_ALIGN_START,
		                      LV_FLEX_ALIGN_START);
		lv_obj_t *picker_head = _plain(_picker);
		lv_obj_set_size(picker_head, lv_pct(100), LV_SIZE_CONTENT);
		lv_obj_set_flex_flow(picker_head, LV_FLEX_FLOW_ROW);
		lv_obj_set_flex_align(picker_head, LV_FLEX_ALIGN_START, LV_FLEX_ALIGN_CENTER,
		                      LV_FLEX_ALIGN_CENTER);
		lv_obj_set_style_pad_column(picker_head, 24, 0);
		lv_obj_t *cancel = lv_button_create(picker_head);
		lv_label_set_text(lv_label_create(cancel), LV_SYMBOL_LEFT);
		lv_obj_add_event_cb(cancel, _pick_cancel, LV_EVENT_CLICKED, this);
		lv_group_remove_obj(cancel);
		lv_obj_t *picker_title = lv_label_create(picker_head);
		lv_obj_set_style_text_font(picker_title, _list_font, 0);
		lv_label_set_text(picker_title, "Contacts");
		_picker_list = _plain(_picker);
		lv_obj_set_width(_picker_list, lv_pct(100));
		lv_obj_set_flex_grow(_picker_list, 1);
		lv_obj_set_flex_flow(_picker_list, LV_FLEX_FLOW_COLUMN);
		lv_obj_set_style_pad_row(_picker_list, 16, 0);
		lv_obj_set_scrollable(_picker_list, true);
		lv_obj_set_hidden(_picker, true);

		/* the call */
		_call = _column(screen);
		lv_obj_set_flex_align(_call, LV_FLEX_ALIGN_SPACE_EVENLY,
		                      LV_FLEX_ALIGN_CENTER, LV_FLEX_ALIGN_CENTER);

		_call_title = lv_label_create(_call);
		lv_obj_set_style_text_font(_call_title, number_font, 0);

		_call_status = lv_label_create(_call);
		lv_obj_set_style_text_font(_call_status, &lv_font_montserrat_48, 0);

		lv_obj_t *buttons = _plain(_call);
		lv_obj_set_size(buttons, lv_pct(100), LV_SIZE_CONTENT);
		lv_obj_set_flex_flow(buttons, LV_FLEX_FLOW_ROW);
		lv_obj_set_flex_align(buttons, LV_FLEX_ALIGN_SPACE_EVENLY,
		                      LV_FLEX_ALIGN_CENTER, LV_FLEX_ALIGN_CENTER);

		_accept  = _round_button(buttons, LV_SYMBOL_CALL,  LV_PALETTE_GREEN);
		_reject  = _round_button(buttons, LV_SYMBOL_CLOSE, LV_PALETTE_RED);
		_hang_up = _round_button(buttons, LV_SYMBOL_CALL,  LV_PALETTE_RED);
		lv_obj_add_event_cb(_accept,  _accept_call,  LV_EVENT_CLICKED, this);
		lv_obj_add_event_cb(_reject,  _reject_call,  LV_EVENT_CLICKED, this);
		lv_obj_add_event_cb(_hang_up, _hang_up_call, LV_EVENT_CLICKED, this);

		/* the call and the recent calls follow in the constructor, outside libc */
		lv_obj_set_hidden(_call, true);
		_report_view();
	}

	/* the on-screen keyboard leaves too little room: digits from it */
	void resized(lv_display_t &display) override
	{
		lv_obj_set_hidden(_pad, lv_display_get_vertical_resolution(&display) < 1000);
	}

	Lvgl_genode::Runtime _runtime;
	Lvgl_genode::Window  _window;

	Main(Genode::Env &env)
	:
		_env(env), _ttf(env, "LiberationSans-Regular.ttf"),
		_runtime(env), _window(env, _runtime, *this, "")
	{
		_timer.sigh(_clock_handler);
		_call_state.sigh(_roms_handler);
		_contacts  .sigh(_roms_handler);
		_call_log  .sigh(_roms_handler);

		/* a change before the signal handler was installed */
		_handle_roms();
	}

	Main(Main const &) = delete;
	Main &operator = (Main const &) = delete;
};


void Libc::Component::construct(Libc::Env &env)
{
	static Phone_app::Main main(env);
}
