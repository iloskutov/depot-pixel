/*
 * \brief  GSM 03.40 SMS-SUBMIT PDU encoding, SMS-DELIVER decoding
 * \author Ivan Loskutov
 * \date   2026-09-05
 */

/*
 * SPDX-License-Identifier: MIT
 */

#include <sms_pdu/sms_pdu.h>

namespace {

	/*
	 * GSM 03.38 default alphabet for printable ASCII 0x20..0x7E.
	 * 0xFF marks a character that is not directly representable; the ones with
	 * an extension-table encoding are handled separately in _extension().
	 */
	uint8_t const _basic[0x5F] = {
		/* 0x20 */ 0x20, 0x21, 0x22, 0x23, 0x02, 0x25, 0x26, 0x27,
		/* 0x28 */ 0x28, 0x29, 0x2A, 0x2B, 0x2C, 0x2D, 0x2E, 0x2F,
		/* 0x30 */ 0x30, 0x31, 0x32, 0x33, 0x34, 0x35, 0x36, 0x37,
		/* 0x38 */ 0x38, 0x39, 0x3A, 0x3B, 0x3C, 0x3D, 0x3E, 0x3F,
		/* 0x40 */ 0x00, 0x41, 0x42, 0x43, 0x44, 0x45, 0x46, 0x47,
		/* 0x48 */ 0x48, 0x49, 0x4A, 0x4B, 0x4C, 0x4D, 0x4E, 0x4F,
		/* 0x50 */ 0x50, 0x51, 0x52, 0x53, 0x54, 0x55, 0x56, 0x57,
		/* 0x58 */ 0x58, 0x59, 0x5A, 0xFF, 0xFF, 0xFF, 0xFF, 0x11,
		/* 0x60 */ 0xFF, 0x61, 0x62, 0x63, 0x64, 0x65, 0x66, 0x67,
		/* 0x68 */ 0x68, 0x69, 0x6A, 0x6B, 0x6C, 0x6D, 0x6E, 0x6F,
		/* 0x70 */ 0x70, 0x71, 0x72, 0x73, 0x74, 0x75, 0x76, 0x77,
		/* 0x78 */ 0x78, 0x79, 0x7A, 0xFF, 0xFF, 0xFF, 0xFF,
	};

	/* extension table: returns the second septet, or 0 if not an escape char */
	uint8_t _extension(char c)
	{
		switch (c) {
		case '[':  return 0x3C;
		case '\\': return 0x2F;
		case ']':  return 0x3E;
		case '^':  return 0x14;
		case '{':  return 0x28;
		case '|':  return 0x40;
		case '}':  return 0x29;
		case '~':  return 0x3D;
		default:   return 0;
		}
	}

	/*
	 * Receive direction: the GSM 7-bit default alphabet as Unicode code
	 * points (3GPP TS 23.038 6.2.1). 0x1B is the escape to the extension
	 * table and has no character of its own.
	 */
	uint16_t const _default_alphabet[128] = {
		/* 0x00 */ 0x0040, 0x00A3, 0x0024, 0x00A5, 0x00E8, 0x00E9, 0x00F9, 0x00EC,
		/* 0x08 */ 0x00F2, 0x00C7, 0x000A, 0x00D8, 0x00F8, 0x000D, 0x00C5, 0x00E5,
		/* 0x10 */ 0x0394, 0x005F, 0x03A6, 0x0393, 0x039B, 0x03A9, 0x03A0, 0x03A8,
		/* 0x18 */ 0x03A3, 0x0398, 0x039E, 0x0020, 0x00C6, 0x00E6, 0x00DF, 0x00C9,
		/* 0x20 */ 0x0020, 0x0021, 0x0022, 0x0023, 0x00A4, 0x0025, 0x0026, 0x0027,
		/* 0x28 */ 0x0028, 0x0029, 0x002A, 0x002B, 0x002C, 0x002D, 0x002E, 0x002F,
		/* 0x30 */ 0x0030, 0x0031, 0x0032, 0x0033, 0x0034, 0x0035, 0x0036, 0x0037,
		/* 0x38 */ 0x0038, 0x0039, 0x003A, 0x003B, 0x003C, 0x003D, 0x003E, 0x003F,
		/* 0x40 */ 0x00A1, 0x0041, 0x0042, 0x0043, 0x0044, 0x0045, 0x0046, 0x0047,
		/* 0x48 */ 0x0048, 0x0049, 0x004A, 0x004B, 0x004C, 0x004D, 0x004E, 0x004F,
		/* 0x50 */ 0x0050, 0x0051, 0x0052, 0x0053, 0x0054, 0x0055, 0x0056, 0x0057,
		/* 0x58 */ 0x0058, 0x0059, 0x005A, 0x00C4, 0x00D6, 0x00D1, 0x00DC, 0x00A7,
		/* 0x60 */ 0x00BF, 0x0061, 0x0062, 0x0063, 0x0064, 0x0065, 0x0066, 0x0067,
		/* 0x68 */ 0x0068, 0x0069, 0x006A, 0x006B, 0x006C, 0x006D, 0x006E, 0x006F,
		/* 0x70 */ 0x0070, 0x0071, 0x0072, 0x0073, 0x0074, 0x0075, 0x0076, 0x0077,
		/* 0x78 */ 0x0078, 0x0079, 0x007A, 0x00E4, 0x00F6, 0x00F1, 0x00FC, 0x00E0,
	};

	/*
	 * Extension table (23.038 6.2.1.1): the character of the septet that
	 * follows an escape. A septet without an entry shows its default-
	 * alphabet character; for the escape itself that is the space the
	 * table above holds at 0x1B.
	 */
	uint32_t _extension_char(uint8_t septet)
	{
		switch (septet) {
		case 0x0A: return 0x000C;   /* form feed */
		case 0x14: return '^';
		case 0x28: return '{';
		case 0x29: return '}';
		case 0x2F: return '\\';
		case 0x3C: return '[';
		case 0x3D: return '~';
		case 0x3E: return ']';
		case 0x40: return '|';
		case 0x65: return 0x20AC;   /* euro sign */
		default:   return _default_alphabet[septet & 0x7F];
		}
	}

	enum : uint32_t { REPLACEMENT_CHAR = 0xFFFD };

	/*
	 * Append a code point as UTF-8 if it fits together with the terminating
	 * NUL (which the caller writes). Returns false, writing nothing, if not.
	 */
	bool _put_utf8(uint32_t cp, char *out, unsigned cap, unsigned &k)
	{
		unsigned const n = cp < 0x80 ? 1 : cp < 0x800 ? 2 : cp < 0x10000 ? 3 : 4;
		if (k + n + 1 > cap) return false;

		switch (n) {
		case 1:
			out[k++] = (char)cp;
			break;
		case 2:
			out[k++] = (char)(0xC0 | (cp >> 6));
			out[k++] = (char)(0x80 | (cp & 0x3F));
			break;
		case 3:
			out[k++] = (char)(0xE0 | (cp >> 12));
			out[k++] = (char)(0x80 | ((cp >> 6) & 0x3F));
			out[k++] = (char)(0x80 | (cp & 0x3F));
			break;
		default:
			out[k++] = (char)(0xF0 | (cp >> 18));
			out[k++] = (char)(0x80 | ((cp >> 12) & 0x3F));
			out[k++] = (char)(0x80 | ((cp >> 6) & 0x3F));
			out[k++] = (char)(0x80 | (cp & 0x3F));
			break;
		}
		return true;
	}

	/*
	 * Walk the information elements of a user data header (23.040
	 * 9.2.3.24), 'len' octets after the UDHL, and pick up the concatenation
	 * element. Unknown elements are skipped. Returns false if an element
	 * does not fit the header.
	 */
	bool _parse_udh(uint8_t const *ie, unsigned len, Modem::Sms::Deliver &d)
	{
		bool     have8 = false, have16 = false;
		uint16_t ref8 = 0, ref16 = 0;
		uint8_t  total8 = 0, seq8 = 0, total16 = 0, seq16 = 0;

		for (unsigned p = 0; p < len; ) {

			if (p + 2 > len) return false;          /* identifier without length */
			uint8_t  const iei  = ie[p];
			unsigned const iedl = ie[p + 1];
			p += 2;
			if (p + iedl > len) return false;       /* data beyond the header */

			if (iei == 0x00 && iedl == 3) {
				have8 = true; ref8 = ie[p]; total8 = ie[p + 1]; seq8 = ie[p + 2];
			}
			if (iei == 0x08 && iedl == 4) {
				have16  = true;
				ref16   = (uint16_t)((ie[p] << 8) | ie[p + 1]);
				total16 = ie[p + 2];
				seq16   = ie[p + 3];
			}
			p += iedl;
		}

		/* total 0, sequence 0 or beyond the total: the element is ignored */
		auto usable = [] (uint8_t total, uint8_t seq) {
			return total != 0 && seq != 0 && seq <= total; };

		if (have16 && usable(total16, seq16)) {
			d.concat = true; d.concat_ref16 = true;
			d.concat_ref = ref16; d.concat_total = total16; d.concat_seq = seq16;
		} else if (have8 && usable(total8, seq8)) {
			d.concat = true; d.concat_ref16 = false;
			d.concat_ref = ref8; d.concat_total = total8; d.concat_seq = seq8;
		}
		return true;
	}
}


unsigned Modem::Sms::to_septets(char const *text, uint8_t *out, unsigned cap,
                         bool *truncated)
{
	if (truncated) *truncated = false;
	if (!text || !out) return 0;

	unsigned n = 0;
	for (unsigned i = 0; text[i]; i++) {

		char const c   = text[i];
		uint8_t const e = _extension(c);

		/* an escaped character needs two free septets or it is dropped whole */
		unsigned const need = e ? 2u : 1u;
		if (n + need > cap) { if (truncated) *truncated = true; break; }

		if (e) {
			out[n++] = ESCAPE_SEPTET;
			out[n++] = e;
			continue;
		}

		uint8_t const uc = (uint8_t)c;
		uint8_t septet = 0x3F;   /* '?' for anything unrepresentable */
		if (uc >= 0x20 && uc <= 0x7E) {
			uint8_t const m = _basic[uc - 0x20];
			if (m != 0xFF) septet = m;
		}
		out[n++] = septet;
	}
	return n;
}


unsigned Modem::Sms::pack7(uint8_t const *septets, unsigned n, uint8_t *out)
{
	if (!septets || !out) return 0;

	unsigned bits = 0, octets = 0;
	uint32_t acc = 0;

	for (unsigned i = 0; i < n; i++) {
		acc |= (uint32_t)(septets[i] & 0x7F) << bits;
		bits += 7;
		while (bits >= 8) {
			out[octets++] = (uint8_t)(acc & 0xFF);
			acc >>= 8;
			bits -= 8;
		}
	}
	if (bits) out[octets++] = (uint8_t)(acc & 0xFF);
	return octets;
}


unsigned Modem::Sms::encode_address(char const *number, uint8_t *out, unsigned cap)
{
	if (!number || !out) return 0;

	bool const international = (number[0] == '+');
	char const *p = international ? number + 1 : number;

	/* collect digits */
	uint8_t digits[20];
	unsigned nd = 0;
	for (unsigned i = 0; p[i]; i++) {
		if (p[i] < '0' || p[i] > '9') return 0;      /* reject junk outright */
		if (nd >= sizeof(digits)) return 0;          /* implausibly long */
		digits[nd++] = (uint8_t)(p[i] - '0');
	}
	if (nd == 0) return 0;

	unsigned const bytes = 2 + (nd + 1) / 2;
	if (bytes > cap) return 0;

	out[0] = (uint8_t)nd;                             /* digit count */
	out[1] = international ? 0x91 : 0x81;             /* TON/NPI */

	for (unsigned i = 0; i < nd; i += 2) {
		uint8_t const lo = digits[i];
		uint8_t const hi = (i + 1 < nd) ? digits[i + 1] : 0x0F;
		out[2 + i / 2] = (uint8_t)((hi << 4) | lo);
	}
	return bytes;
}


unsigned Modem::Sms::encode_submit(char const *number, char const *text,
                            uint8_t message_ref, bool status_report,
                            uint8_t *out, unsigned cap, bool *truncated)
{
	if (truncated) *truncated = false;
	if (!number || !text || !out) return 0;

	uint8_t septets[MAX_SEPTETS];
	unsigned const ns = to_septets(text, septets, MAX_SEPTETS, truncated);

	uint8_t ud[140];
	unsigned const nud = pack7(septets, ns, ud);

	/* first octet: MTI = SUBMIT, VPF = relative, optionally SRR */
	uint8_t const first = (uint8_t)(0x11 | (status_report ? 0x20 : 0x00));

	unsigned n = 0;
	if (cap < 2) return 0;
	out[n++] = first;
	out[n++] = message_ref;

	unsigned const na = encode_address(number, out + n, cap - n);
	if (na == 0) return 0;
	n += na;

	if (n + 4 + nud > cap) return 0;
	out[n++] = 0x00;          /* TP-PID  */
	out[n++] = 0x00;          /* TP-DCS: GSM 7-bit default alphabet */
	out[n++] = 0xAA;          /* TP-VP:  relative, 4 days */
	out[n++] = (uint8_t)ns;   /* TP-UDL in septets */

	for (unsigned i = 0; i < nud; i++) out[n++] = ud[i];
	return n;
}


unsigned Modem::Sms::encode_smsc(char const *number, uint8_t *out, unsigned cap)
{
	if (!number || !out || cap < 2) return 0;

	/* reuse the address encoder, then convert its digit count to a byte count */
	uint8_t addr[16];
	unsigned const n = encode_address(number, addr, sizeof(addr));
	if (n < 2) return 0;

	unsigned const bytes = n - 1;          /* drop the digit-count byte */
	if (bytes + 1 > cap) return 0;

	out[0] = (uint8_t)bytes;               /* TON/NPI plus the BCD digits */
	for (unsigned i = 0; i < bytes; i++) out[1 + i] = addr[1 + i];
	return bytes + 1;
}


unsigned Modem::Sms::from_septets(uint8_t const *septets, unsigned n,
                           char *out, unsigned cap)
{
	if (!septets || !out || cap == 0) return 0;

	unsigned k = 0;
	for (unsigned i = 0; i < n; i++) {

		uint8_t const s = septets[i] & 0x7F;
		uint32_t cp = _default_alphabet[s];

		/* the escape prefix and its second septet render as one character */
		if (s == ESCAPE_SEPTET) {
			if (i + 1 >= n) break;
			cp = _extension_char(septets[++i] & 0x7F);
		}

		if (!_put_utf8(cp, out, cap, k)) break;
	}
	out[k] = 0;
	return k;
}


unsigned Modem::Sms::from_ucs2(uint8_t const *in, unsigned octets,
                        char *out, unsigned cap)
{
	if (!out || cap == 0) return 0;

	unsigned k = 0;
	for (unsigned i = 0; in && i + 1 < octets; i += 2) {

		uint32_t cp = (uint32_t)((in[i] << 8) | in[i + 1]);

		if (cp >= 0xD800 && cp <= 0xDBFF) {

			/* high surrogate: only valid with a low one right behind */
			uint32_t const lo = (i + 3 < octets)
			                  ? (uint32_t)((in[i + 2] << 8) | in[i + 3]) : 0;
			if (lo >= 0xDC00 && lo <= 0xDFFF) {
				cp = 0x10000 + ((cp - 0xD800) << 10) + (lo - 0xDC00);
				i += 2;
			} else {
				cp = REPLACEMENT_CHAR;
			}
		} else if ((cp >= 0xDC00 && cp <= 0xDFFF) || cp == 0) {
			cp = REPLACEMENT_CHAR;
		}

		if (!_put_utf8(cp, out, cap, k)) break;
	}
	out[k] = 0;
	return k;
}


unsigned Modem::Sms::unpack7(uint8_t const *packed, unsigned octets, unsigned septets,
                      uint8_t *out, unsigned cap)
{
	if (!packed || !out) return 0;

	unsigned bits = 0, n = 0;
	uint32_t acc = 0;

	for (unsigned i = 0; i < octets && n < septets && n < cap; i++) {
		acc |= (uint32_t)packed[i] << bits;
		bits += 8;
		while (bits >= 7 && n < septets && n < cap) {
			out[n++] = (uint8_t)(acc & 0x7F);
			acc >>= 7;
			bits -= 7;
		}
	}
	return n;
}


unsigned Modem::Sms::decode_address(uint8_t const *in, unsigned len,
                             char *out, unsigned cap)
{
	if (!in || !out || cap == 0 || len < 2) return 0;

	out[0] = 0;

	enum { MAX_SEMI_OCTETS = 20, TON_INTERNATIONAL = 1, TON_ALPHANUMERIC = 5 };

	unsigned const digits = in[0];               /* used semi-octets */
	if (digits == 0 || digits > MAX_SEMI_OCTETS) return 0;

	unsigned const octets = (digits + 1) / 2;
	unsigned const bytes  = 2 + octets;
	if (bytes > len) return 0;

	unsigned const ton = (in[1] >> 4) & 7;

	if (ton == TON_ALPHANUMERIC) {
		uint8_t septets[(MAX_SEMI_OCTETS * 4) / 7];
		unsigned const n = unpack7(in + 2, octets, (digits * 4) / 7,
		                           septets, sizeof(septets));
		from_septets(septets, n, out, cap);
		return bytes;
	}

	unsigned k = 0;
	if (ton == TON_INTERNATIONAL && k + 1 < cap) out[k++] = '+';

	for (unsigned i = 0; i < digits && k + 1 < cap; i++) {
		uint8_t const b = in[2 + i / 2];
		uint8_t const d = (i & 1) ? (uint8_t)(b >> 4) : (uint8_t)(b & 0x0F);
		if (d == 0x0F) break;                    /* fill */

		/* 23.040 9.1.2.3: 0..9, then * # a b c */
		static char const semi_octet[] = "0123456789*#abc";
		out[k++] = semi_octet[d];
	}
	out[k] = 0;
	return bytes;
}


Modem::Sms::Alphabet Modem::Sms::dcs_alphabet(uint8_t dcs)
{
	switch (dcs >> 4) {

	/* general data coding, and the same marked for automatic deletion */
	case 0x0: case 0x1: case 0x2: case 0x3:
	case 0x4: case 0x5: case 0x6: case 0x7:
		if (dcs & 0x20) return Alphabet::COMPRESSED;
		switch ((dcs >> 2) & 3) {
		case 1:  return Alphabet::DATA8;
		case 2:  return Alphabet::UCS2;
		default: return Alphabet::GSM7;          /* 0, and the reserved 3 */
		}

	/* message waiting indication, store message, UCS-2 */
	case 0xE: return Alphabet::UCS2;

	/* data coding / message class */
	case 0xF: return (dcs & 0x04) ? Alphabet::DATA8 : Alphabet::GSM7;

	/*
	 * 0x8..0xB reserved ("shall be assumed to be the GSM 7 bit default
	 * alphabet"), 0xC/0xD message waiting indication with GSM 7-bit text
	 */
	default: return Alphabet::GSM7;
	}
}


Modem::Sms::Deliver Modem::Sms::decode_deliver(uint8_t const *pdu, unsigned len, bool skip_smsc)
{
	Deliver d { };

	if (!pdu || len < 2) return d;

	unsigned p = 0;
	if (skip_smsc) {
		unsigned const smsc_len = pdu[0];
		p = 1 + smsc_len;
		if (p >= len) return d;
	}

	uint8_t const first = pdu[p++];
	if ((first & 0x03) != 0x00) return d;    /* not an SMS-DELIVER */
	bool const udhi = first & 0x40;

	unsigned const used = decode_address(pdu + p, len - p, d.sender, sizeof(d.sender));
	if (!used) return d;
	p += used;

	if (p + 2 > len) return d;
	p++;                                     /* TP-PID */
	Alphabet const alphabet = dcs_alphabet(pdu[p++]);

	if (p + 7 > len) return d;
	for (unsigned i = 0; i < 7; i++) d.scts[i] = pdu[p + i];
	p += 7;

	if (p >= len) return d;
	unsigned const udl = pdu[p++];           /* septets for GSM 7-bit, else octets */

	if (alphabet != Alphabet::GSM7 && alphabet != Alphabet::UCS2) return d;

	unsigned const octets = (alphabet == Alphabet::GSM7) ? (udl * 7 + 7) / 8 : udl;
	if (octets > MAX_UD || octets > len - p) return d;

	uint8_t const *ud = pdu + p;

	/* user data header: its length octet plus that many octets */
	unsigned header = 0;
	if (udhi) {
		if (octets < 1) return d;
		header = 1 + ud[0];
		if (header > octets) return d;
		if (!_parse_udh(ud + 1, ud[0], d)) return d;
	}

	if (alphabet == Alphabet::GSM7) {

		/*
		 * The text starts at the first septet boundary behind the header
		 * (fill bits in between). Septet i occupies the bits 7i..7i+6 of
		 * the user data, so unpacking from the start and dropping the
		 * septets the header covers skips the fill bits as well.
		 */
		unsigned const skip = (header * 8 + 6) / 7;

		uint8_t septets[MAX_SEPTETS];
		unsigned const ns = unpack7(ud, octets, udl, septets, MAX_SEPTETS);
		if (ns < skip) return d;             /* header beyond the TP-UDL */
		from_septets(septets + skip, ns - skip, d.text, sizeof(d.text));

	} else {
		from_ucs2(ud + header, octets - header, d.text, sizeof(d.text));
	}

	d.valid = true;
	return d;
}
