/*
 * \brief  rild_modem: platform-independent backend logic
 * \author Ivan Loskutov
 * \date   2026-09-27
 */

/*
 * SPDX-License-Identifier: MIT
 */

#include <rild_modem/logic.h>
#include <rild_modem/scts.h>
#include <rild_modem/utf8.h>
#include <sms_pdu/sms_pdu.h>
#include <string.h>
#include <stdio.h>

using namespace Rild_modem;


namespace {

	/*
	 * The values below mirror the generated radio_aidl enums
	 * (radio_aidl/{sim,network,radio,voice}.h), copied by hand so
	 * this library needs no radio_aidl / android_binder headers and stays
	 * testable on the host with a plain g++. A future change of the vendored AIDL
	 * that renumbers one of these enums would have to be mirrored here too;
	 * there is no compile-time check tying the two together.
	 */

	/* Radio_aidl::sim::CardStatus::STATE_* */
	enum { CARD_STATE_PRESENT = 1 };

	/* Radio_aidl::sim::PinState */
	enum {
		PIN_ENABLED_NOT_VERIFIED = 1,
		PIN_ENABLED_VERIFIED     = 2,
		PIN_DISABLED             = 3,
		PIN_ENABLED_BLOCKED      = 4,
		PIN_ENABLED_PERM_BLOCKED = 5,
	};

	/* Radio_aidl::network::RegState */
	enum {
		REG_NOT_SEARCHING    = 0,
		REG_HOME             = 1,
		REG_SEARCHING        = 2,
		REG_DENIED           = 3,
		REG_UNKNOWN          = 4,
		REG_ROAMING          = 5,
		REG_NOT_SEARCHING_EM = 10,
		REG_SEARCHING_EM     = 12,
		REG_DENIED_EM        = 13,
		REG_UNKNOWN_EM       = 14,
	};

	/* Radio_aidl::radio::RadioTechnology */
	enum {
		RAT_GPRS = 1, RAT_EDGE = 2, RAT_UMTS = 3, RAT_HSDPA = 9, RAT_HSUPA = 10,
		RAT_HSPA = 11, RAT_LTE = 14, RAT_HSPAP = 15, RAT_GSM = 16,
		RAT_TD_SCDMA = 17, RAT_IWLAN = 18, RAT_LTE_CA = 19, RAT_NR = 20,
	};

	/* Radio_aidl::voice::Call::STATE_* */
	enum {
		CALL_ACTIVE = 0, CALL_HOLDING = 1, CALL_DIALING = 2,
		CALL_ALERTING = 3, CALL_INCOMING = 4, CALL_WAITING = 5,
	};

	/* Radio_aidl::radio::RadioError */
	enum { RADIO_ERROR_NONE = 0, RADIO_ERROR_PASSWORD_INCORRECT = 3 };

	/* Radio_aidl::radio::AccessNetwork */
	enum { AN_GERAN = 1, AN_UTRAN = 2, AN_EUTRAN = 3, AN_NGRAN = 6 };

	enum { ALLOWED_NETWORK_TYPES_BITMAP = 578439 };   /* LineageOS' value */

	void copy(char *dst, char const *src, unsigned cap)
	{
		if (!src) { dst[0] = 0; return; }
		unsigned i = 0;
		for (; i + 1 < cap && src[i]; i++) dst[i] = src[i];
		dst[i] = 0;
	}

	/*
	 * Append 'src' to the text in 'dst' ('len' bytes so far, 'cap' with
	 * the NUL), cut at a UTF-8 character boundary. Returns false if it did
	 * not fit whole.
	 */
	bool append_text(char *dst, unsigned cap, unsigned &len, char const *src)
	{
		unsigned const room = cap - 1 - len;
		unsigned const n    = unsigned(utf8_prefix(src, room));
		::memcpy(dst + len, src, n);
		len += n;
		dst[len] = 0;
		return src[n] == 0;
	}

	/* FNV-1a */
	uint32_t text_hash(char const *text)
	{
		uint32_t h = 2166136261u;
		for (; *text; text++) { h ^= uint8_t(*text); h *= 16777619u; }
		return h;
	}

	void to_hex(uint8_t const *in, unsigned n, char *out, unsigned cap)
	{
		static char const digits[] = "0123456789ABCDEF";
		unsigned o = 0;
		for (unsigned i = 0; i < n && o + 2 < cap; i++) {
			out[o++] = digits[in[i] >> 4];
			out[o++] = digits[in[i] & 0xF];
		}
		out[o] = 0;
	}

	void format_decimal(int v, char *out, unsigned cap)
	{
		::snprintf(out, cap, "%d", v);
	}

	bool ps_only(int rat)
	{
		return rat == RAT_LTE || rat == RAT_LTE_CA || rat == RAT_NR || rat == RAT_IWLAN;
	}

	State::Network::Status map_status(int reg_state)
	{
		using Status = State::Network::Status;
		switch (reg_state) {
		case REG_NOT_SEARCHING: case REG_NOT_SEARCHING_EM: return Status::UNREGISTERED;
		case REG_HOME:                                     return Status::REGISTERED;
		case REG_SEARCHING:     case REG_SEARCHING_EM:     return Status::SEARCHING;
		case REG_DENIED:        case REG_DENIED_EM:        return Status::DENIED;
		case REG_ROAMING:                                  return Status::ROAMING;
		default:                                           return Status::UNKNOWN;
		}
	}

	State::Network::Technology map_technology(int rat)
	{
		using Technology = State::Network::Technology;
		switch (rat) {
		case RAT_GPRS: case RAT_EDGE: case RAT_GSM:                return Technology::GSM;
		case RAT_UMTS: case RAT_HSDPA: case RAT_HSUPA: case RAT_HSPA:
		case RAT_HSPAP: case RAT_TD_SCDMA:                         return Technology::UMTS;
		case RAT_LTE: case RAT_LTE_CA:                             return Technology::LTE;
		case RAT_NR:                                               return Technology::NR;
		default:                                                   return Technology::NONE;
		}
	}

	/* access network of a data-call request on 'rat' (the Android
	 * framework's mapping; unknown: UTRAN, the value LineageOS sent) */
	int access_network(int rat)
	{
		switch (rat) {
		case RAT_GPRS: case RAT_EDGE: case RAT_GSM: return AN_GERAN;
		case RAT_LTE: case RAT_LTE_CA:              return AN_EUTRAN;
		case RAT_NR:                                return AN_NGRAN;
		default:                                    return AN_UTRAN;
		}
	}

	State::Call::State map_call_state(int rat_state)
	{
		using S = State::Call::State;
		switch (rat_state) {
		case CALL_DIALING:                    return S::OUTBOUND;
		case CALL_ALERTING:                   return S::ALERTING;
		case CALL_INCOMING: case CALL_WAITING: return S::INCOMING;
		default:                              return S::ACTIVE;   /* ACTIVE, HOLDING */
		}
	}

	/* "22803" -> mcc "228", mnc "03"; anything else clears both */
	void extract_mcc_mnc(char const *plmn, char *mcc, char *mnc)
	{
		mcc[0] = 0; mnc[0] = 0;
		if (!plmn) return;
		unsigned const len = unsigned(::strlen(plmn));
		if (len != 5 && len != 6) return;
		copy(mcc, plmn, 4);
		char buf[4] { };
		unsigned const mnc_len = len - 3;
		for (unsigned i = 0; i < mnc_len; i++) buf[i] = plmn[3 + i];
		buf[mnc_len] = 0;
		copy(mnc, buf, sizeof(buf));
	}

	/*
	 * True if 'text' contains a character the GSM 03.38 default alphabet
	 * (plus its extension table) cannot represent -- i.e. 'to_septets'
	 * would have replaced it with '?'. Detected by round-tripping through
	 * sms_pdu's own encoder/decoder rather than duplicating its table:
	 * a faithful encode decodes back to the same (possibly truncated)
	 * prefix; a lossy '?' substitution does not. A text that legitimately
	 * contains '?' (septet 0x3F, itself round-trips to '?') is not a false
	 * positive: it decodes back to the same '?', matching the original.
	 */
	bool gsm7_lossy(char const *text)
	{
		uint8_t septets[Modem::Sms::MAX_SEPTETS];
		unsigned const n = Modem::Sms::to_septets(text, septets, sizeof(septets));
		char back[Modem::Sms::MAX_SEPTETS + 1] { };
		Modem::Sms::from_septets(septets, n, back, sizeof(back));
		return ::strncmp(text, back, ::strlen(back)) != 0;
	}

	enum { NUMBER_MATCH_DIGITS = 9 };

	/*
	 * Loose phone-number comparison: digits only (a '+', spaces, dashes
	 * dropped), then the trailing min(len a, len b, NUMBER_MATCH_DIGITS)
	 * digits compared -- "0791234567" (national) matches "+41791234567"
	 * (the modem's international form). Two numbers without any digit
	 * match only if they are equal strings.
	 */
	bool same_number(char const *a, char const *b)
	{
		char da[32] { }, db[32] { };
		auto digits = [] (char const *in, char *out, unsigned cap) {
			unsigned n = 0;
			for (; in && *in && n + 1 < cap; in++)
				if (*in >= '0' && *in <= '9') out[n++] = *in;
			out[n] = 0;
			return n;
		};
		unsigned const la = digits(a, da, sizeof(da));
		unsigned const lb = digits(b, db, sizeof(db));

		if (!la || !lb) return la == lb && ::strcmp(a ? a : "", b ? b : "") == 0;

		unsigned n = la < lb ? la : lb;
		if (n > NUMBER_MATCH_DIGITS) n = NUMBER_MATCH_DIGITS;
		return ::strcmp(da + la - n, db + lb - n) == 0;
	}
}


Logic::Logic(Radio &radio, unsigned long (*now_ms)())
: _radio(radio), _now_ms(now_ms) { }


void Logic::_start(Req kind, unsigned long now)
{
	Pending &p = _pending[unsigned(kind)];
	p.active = true; p.retried = false; p.again = false; p.sent_at = now;
}


void Logic::_clear(Req kind) { _pending[unsigned(kind)].active = false; }


/* the request was answered: ask again if an indication wanted that meanwhile */
void Logic::_answered(Req kind)
{
	Pending &p = _pending[unsigned(kind)];
	bool const again = p.active && p.again;
	p.active = false;
	if (again) {
		_retry(kind);
		_start(kind, _now_ms());
	}
}


void Logic::_retry(Req kind)
{
	switch (kind) {
	case Req::POWER:
		/* power=on -> enableModem(true) + setRadioPower(true);
		 * re-assert both together on a retry too */
		if (_power_target_on) _radio.enable_modem(true);
		_radio.set_radio_power(_power_target_on);
		break;
	case Req::CARD_STATUS:  _radio.get_icc_card_status(); break;
	case Req::REGISTRATION: _radio.query_registration(); break;
	case Req::BASEBAND:     _radio.get_baseband_version(); break;
	case Req::PIN:          break;   /* not idempotent -- never retried */
	case Req::DIAL:         break;   /* not idempotent -- never retried */
	case Req::COUNT:        break;
	}
}


void Logic::_give_up(Req kind)
{
	switch (kind) {
	case Req::POWER:
		_radio.gave_up(_power_target_on ? "power on (enableModem, setRadioPower)"
		                                : "power off (setRadioPower)");
		/* no request outstanding any more -- the display reverts to
		 * whatever is currently reported (see 'Logic' power) */
		_update_power_display();
		_dirty();
		break;
	case Req::CARD_STATUS:
		_radio.gave_up("getIccCardStatus");
		_state.sim = State::Sim::UNKNOWN;
		_dirty();
		break;
	case Req::PIN:
		_radio.gave_up("supplyIccPinForApp");
		/* the SIM may have counted the attempt: never the same pin again */
		copy(_pin_failed, _pin_inflight, sizeof(_pin_failed));
		_pin_no_verdict = true;
		_state.pin = State::Pin::ERROR;
		_dirty();
		break;
	case Req::REGISTRATION:
		_radio.gave_up("registration query");
		_state.network.status = State::Network::Status::UNKNOWN;
		_dirty();
		break;
	case Req::BASEBAND:
		_radio.gave_up("getBasebandVersion");
		_state.info.revision[0] = 0;
		_dirty();
		break;
	case Req::DIAL:
		if (!_dial_pending) break;   /* withdrawn meanwhile: nothing to report */
		_radio.gave_up("dial");
		if (_call_listed()) _dial_dropped();   /* never override a listed call */
		else                _dial_gone();
		break;
	case Req::COUNT:
		break;
	}
}


/*
 * Android's setPowerStateToDesired pattern: issue a request only when the
 * config's desired power actually differs from what is currently reported
 * and nothing is already outstanding. Never called with the intent to
 * retry on its own -- that is tick()'s job for the one request this starts;
 * once given up, only a fresh call (from apply() or on_radio_state()) can
 * trigger another attempt.
 */
void Logic::_reconcile_power()
{
	if (!_connected) return;
	if (_config.power == Config::Power::UNSPECIFIED) return;
	if (_pending[unsigned(Req::POWER)].active) return;

	bool const want_on = _config.power == Config::Power::ON;
	Reported_power const want = want_on ? Reported_power::ON : Reported_power::OFF;
	if (_reported_power == want) return;

	_power_target_on = want_on;

	if (want_on) {
		_state.startup_seconds = 0;
		_radio.enable_modem(true);
		_radio.set_radio_power(true);
	} else {
		_state.shutdown_seconds = 0;
		_radio.set_radio_power(false);
		/* enable_modem(false) follows once on_radio_state(false) confirms it */
	}
	_start(Req::POWER, _now_ms());
}


/* 'starting up'/'shutting down' only while a POWER request is outstanding;
 * otherwise the reported state (assumed 'off' until ever reported). Marks
 * dirty itself on an actual change, so callers need not remember to. */
void Logic::_update_power_display()
{
	State::Power const before = _state.power;

	if (!_connected) {
		_state.power = State::Power::UNAVAILABLE;
	} else if (_pending[unsigned(Req::POWER)].active) {
		_state.power = _power_target_on ? State::Power::STARTING_UP
		                                 : State::Power::SHUTTING_DOWN;
	} else {
		switch (_reported_power) {
		case Reported_power::ON:      _state.power = State::Power::ON;  break;
		case Reported_power::OFF:     _state.power = State::Power::OFF; break;
		case Reported_power::UNKNOWN: _state.power = State::Power::OFF; break;
		}
	}

	if (_state.power != before) _dirty();
}


/*
 * The one-shot modem setup: at connect, and again once a radio that was
 * UNAVAILABLE (rild answers RADIO_NOT_AVAILABLE while the CP boots) is
 * OFF/ON -- the Android framework re-sends it on radio-available too.
 * Without the initial-attach APN the modem does not register.
 */
void Logic::_setup_modem()
{
	_radio.set_preferred_data_modem();
	_radio.enable_modem(true);
	_radio.set_allowed_network_types(ALLOWED_NETWORK_TYPES_BITMAP);
	if (_config.attach_apn[0]) _radio.set_initial_attach_apn(_config.attach_apn);

	_radio.get_icc_card_status();
	_start(Req::CARD_STATUS, _now_ms());

	_radio.get_baseband_version();
	_start(Req::BASEBAND, _now_ms());
}


void Logic::connected()
{
	_connected = true;
	_radio_unavailable = false;
	_reported_power = Reported_power::UNKNOWN;

	_setup_modem();

	_reconcile_power();
	_update_power_display();

	/* replay whatever 'apply()' recorded before this connect (bring-up
	 * config applied early, or left over from before a rild restart) */
	_maybe_supply_pin();
	_apply_call(_config.call);
	_apply_sends(_config);
	_reconcile_data();   /* waits for the data registration */

	_dirty();
}


void Logic::disconnected()
{
	_connected = false;
	_reported_power = Reported_power::UNKNOWN;

	/* the call (if any) went with rild; a new start begins without back-off */
	_data_phase      = Data_phase::IDLE;
	_data_cid        = -1;
	_data_backoff_ms = DATA_BACKOFF_MIN_MS;
	_data_show_idle();

	_state.startup_seconds  = 0;
	_state.shutdown_seconds = 0;

	_state.sim                    = State::Sim::UNKNOWN;
	_state.pin                    = State::Pin::NONE;
	_state.pin_remaining_attempts = -1;

	_state.network = State::Network { };
	_reg_known       = false;
	_oper_name[0]    = 0;
	_oper_numeric[0] = 0;

	_state.call = State::Call { };
	_call_index    = -1;
	_accept_sent   = false;
	_hangup_sent   = false;
	_call_owned    = false;
	_reset_call_retry();
	_dial_confirmed = false;

	if (_dial_pending) {
		/* never confirmed by 'on_calls' -- a reconnect may retry it */
		_dial_pending = false;
		_dial_sent[0] = 0;
	}

	_voice_reg = Reg { };
	_data_reg  = Reg { };

	for (unsigned i = 0; i < unsigned(Req::COUNT); i++) _pending[i].active = false;

	/* every id whose outcome is still PENDING never got a response --
	 * fail it (in the outcome memory, not only in the current report,
	 * since a config change may already have dropped it from the report
	 * while still pending), never resend it */
	for (unsigned i = 0; i < SENT_MEMORY; i++) {
		if (!_sent_memory[i].used || _sent_memory[i].state != State::Sent::State::PENDING) continue;
		_sent_memory[i].state = State::Sent::State::FAILED;
		copy(_sent_memory[i].reason, "rild restarted", sizeof(_sent_memory[i].reason));
	}
	for (unsigned i = 0; i < _state.sent_count; i++) {
		if (_state.sent[i].state != State::Sent::State::PENDING) continue;
		_state.sent[i].state = State::Sent::State::FAILED;
		copy(_state.sent[i].reason, "rild restarted", sizeof(_state.sent[i].reason));
	}
	for (unsigned i = 0; i < MAX_SENT; i++) _send_pending[i].active = false;

	_update_power_display();

	/* kept across a reconnect: _state.received/sent/dropped/undecodable/
	 * duplicates, _sent_memory (dedup + outcome, see the class doc),
	 * _pin_failed, _next_received_id, _state.info, the pending parts of
	 * concatenated SMS (_concat) and both SMS histories */

	_dirty();
}


Logic::Sent_memory *Logic::_sent_find(unsigned id)
{
	for (unsigned i = 0; i < SENT_MEMORY; i++)
		if (_sent_memory[i].used && _sent_memory[i].id == id) return &_sent_memory[i];
	return nullptr;
}


Logic::Sent_memory &Logic::_sent_alloc(unsigned id)
{
	Sent_memory &slot = _sent_memory[_sent_memory_next];
	_sent_memory_next = (_sent_memory_next + 1) % SENT_MEMORY;
	slot = Sent_memory { };
	slot.id   = id;
	slot.used = true;
	return slot;
}


/* false if as many sends as can be tracked are in flight */
bool Logic::_start_send_pending(unsigned id)
{
	for (unsigned i = 0; i < MAX_SENT; i++) {
		if (_send_pending[i].active) continue;
		_send_pending[i].active  = true;
		_send_pending[i].id      = id;
		_send_pending[i].sent_at = _now_ms();
		return true;
	}
	return false;
}


void Logic::_maybe_supply_pin()
{
	if (!_connected) return;
	if (_pending[unsigned(Req::PIN)].active) return;   /* one already in flight */

	/* the config names another pin than the one that ended with an error:
	 * the card tells whether it still asks for one */
	if (_state.pin == State::Pin::ERROR && ::strcmp(_config.pin, _pin_failed)) {
		if (!_pending[unsigned(Req::CARD_STATUS)].active) {
			_radio.get_icc_card_status();
			_start(Req::CARD_STATUS, _now_ms());
		}
		return;
	}

	if (_state.pin != State::Pin::REQUIRED) return;
	if (!_config.pin[0]) return;
	if (_pin_failed[0] && !::strcmp(_config.pin, _pin_failed)) return;   /* failed before */

	copy(_pin_inflight, _config.pin, sizeof(_pin_inflight));
	_radio.supply_pin(_config.pin, "");
	_state.pin = State::Pin::CHECKING;
	_start(Req::PIN, _now_ms());
	_dirty();
}


void Logic::_update_network()
{
	Reg const *primary = (_data_reg.valid && ps_only(_data_reg.rat)) ? &_data_reg
	                    : _voice_reg.valid                           ? &_voice_reg
	                    : _data_reg.valid                            ? &_data_reg
	                    : nullptr;
	if (!primary) return;

	_state.network.status     = map_status(primary->reg_state);
	_state.network.technology = map_technology(primary->rat);

	/* the signal value of the (possibly new) technology applies */
	_update_strength();

	bool const registered = _state.network.status == State::Network::Status::REGISTERED
	                      || _state.network.status == State::Network::Status::ROAMING;

	if (registered) {
		/* an empty/invalid PLMN (rild's first REG_HOME results carry none)
		 * keeps the MCC/MNC already known, e.g. from getOperator */
		char mcc[4], mnc[4];
		extract_mcc_mnc(primary->plmn, mcc, mnc);
		if (mcc[0]) {
			copy(_state.network.mcc, mcc, sizeof(_state.network.mcc));
			copy(_state.network.mnc, mnc, sizeof(_state.network.mnc));
		}

		/* an operator response that arrived before the first registration
		 * result (consumed here) */
		if (!_state.network.oper[0])
			copy(_state.network.oper, _oper_name, sizeof(_state.network.oper));
		if (!_state.network.mcc[0])
			extract_mcc_mnc(_oper_numeric, _state.network.mcc, _state.network.mnc);
		_oper_name[0]    = 0;
		_oper_numeric[0] = 0;
	} else {
		_oper_name[0]    = 0;
		_oper_numeric[0] = 0;
		_state.network.oper[0] = 0;
		_state.network.mcc[0]  = 0;
		_state.network.mnc[0]  = 0;
	}

	if (primary->reg_state == REG_DENIED || primary->reg_state == REG_DENIED_EM)
		format_decimal(primary->reject_cause, _state.network.denial_reason,
		               sizeof(_state.network.denial_reason));
	else
		_state.network.denial_reason[0] = 0;
}


void Logic::_issue_hangup()
{
	_hangup_sent = true;
	if (_state.call.state == State::Call::State::INCOMING) _radio.reject_call();
	else                                                   _radio.hangup(_call_index);
}


/*
 * A dial attempt is over without ever becoming ACTIVE. If we withdrew the
 * call node ourselves (_hangup_sent, set here or by _apply_call even when
 * there was no RIL call yet to cancel), clear silently; otherwise show it
 * 'rejected' (present stays true) until the config withdraws the node or
 * presents a different number (_apply_call).
 */
void Logic::_dial_gone()
{
	/* withdrawn by the config (or hung up by us): nothing to show */
	if (_hangup_sent || !_config.call.present) {
		_state.call = State::Call { };
	} else {
		_state.call.present = true;
		copy(_state.call.number, _dial_sent, sizeof(_state.call.number));
		_state.call.state = State::Call::State::REJECTED;
	}

	_clear(Req::DIAL);
	_call_index     = -1;
	_dial_pending   = false;
	_dial_confirmed = false;
	_accept_sent    = false;
	_hangup_sent    = false;
	_call_owned     = false;
	_reset_call_retry();

	_dirty();
}


/*
 * The pending dial ended (timeout, dialResponse error) while 'on_calls'
 * lists some other call: forget the dial, leave the displayed call alone.
 * '_dial_sent' stays, so an unchanged config does not dial again.
 */
void Logic::_dial_dropped()
{
	_clear(Req::DIAL);
	_dial_pending   = false;
	_dial_confirmed = false;
}


bool Logic::_call_listed() const
{
	return _state.call.present && _call_index >= 0
	    && _state.call.state != State::Call::State::REJECTED;
}


void Logic::_apply_call(Config::Call const &cfg_call)
{
	if (!_connected) return;

	if (!cfg_call.present) {
		if (_state.call.state == State::Call::State::REJECTED) {
			/* config withdrew the node: clear the transient display */
			_state.call = State::Call { };
			_dirty();
		} else if (_state.call.present && _call_owned && !_hangup_sent) {
			/* only a call the config established (our dial, an accepted
			 * call) -- a ringing incoming call is rejected only by
			 * state="rejected" (PinePhone semantics, finding I1) */
			_issue_hangup();
		}
		/* a dial without a RIL call (no index yet) has nothing to cancel;
		 * its eventual "gone" clears silently ('_dial_gone' checks the
		 * config), a call it still produces is hung up as unwanted
		 * ('on_calls') */
		_clear(Req::DIAL);
		_dial_pending   = false;
		_dial_confirmed = false;
		_dial_sent[0]   = 0;   /* a later re-add may dial again */
		return;
	}

	/* a changed number replaces a stale 'rejected' display (probe Q1) */
	if (_state.call.state == State::Call::State::REJECTED
	    && !same_number(cfg_call.number, _state.call.number)) {
		_state.call = State::Call { };
		_dial_sent[0] = 0;
		_dirty();
	}

	/* normalised: the consumer may adopt the modem's form of the number */
	bool const new_number = !_dial_sent[0] || !same_number(cfg_call.number, _dial_sent);

	if (cfg_call.state == Config::Call::State::NONE && cfg_call.number[0]
	    && !_state.call.present && !_dial_pending && new_number) {
		/* like GsmCdmaCallTracker: a call never inherits a mute */
		_radio.set_mute(false);
		_radio.dial(cfg_call.number);
		_dial_pending   = true;
		_dial_confirmed = false;
		copy(_dial_sent, cfg_call.number, sizeof(_dial_sent));
		_start(Req::DIAL, _now_ms());
		return;
	}

	/* 'accepted' and 'rejected' are meant for the call of that number (a
	 * caller without number: both empty), not for one that came after it */
	if (!_state.call.present || !same_number(cfg_call.number, _state.call.number))
		return;

	if (cfg_call.state == Config::Call::State::REJECTED
	    && _state.call.state != State::Call::State::REJECTED
	    && !_hangup_sent) {
		_issue_hangup();
		return;
	}

	if (cfg_call.state == Config::Call::State::ACCEPTED
	    && _state.call.state == State::Call::State::INCOMING
	    && !_accept_sent) {
		_radio.set_mute(false);
		_radio.accept_call();
		_accept_sent = true;
		_call_owned  = true;   /* established by the config from now on */
	}
}


void Logic::_apply_sends(Config const &cfg)
{
	if (!_connected) return;

	/*
	 * Rebuild the report to mirror the config's current send ids, in
	 * config order. Each id's true outcome lives in '_sent_memory', which
	 * outlives an id dropping out of (and later back into) the config's
	 * list, so a re-add shows the real result rather than resetting to
	 * "pending"; an id is issued to 'send_sms' at most once, ever, per
	 * the memory (removing the node later does not cancel a sent message,
	 * re-adding an id later must not resend it either).
	 */
	State::Sent rebuilt[MAX_SENT] { };
	unsigned    rebuilt_count = 0;

	for (unsigned i = 0; i < cfg.send_count && i < MAX_SENDS && rebuilt_count < MAX_SENT; i++) {
		Config::Send const &s = cfg.sends[i];

		Sent_memory *mem = _sent_find(s.id);

		if (!mem) {
			mem = &_sent_alloc(s.id);

			if (s.too_long) {
				/* longer than the config parser keeps (finding M2) */
				mem->state = State::Sent::State::FAILED;
				copy(mem->reason, "too long", sizeof(mem->reason));
			} else if (gsm7_lossy(s.text)) {
				mem->state = State::Sent::State::FAILED;
				copy(mem->reason, "unsupported characters", sizeof(mem->reason));
			} else {
				uint8_t tpdu[Modem::Sms::MAX_TPDU];
				bool truncated = false;
				unsigned const n = Modem::Sms::encode_submit(
					s.to, s.text, uint8_t(s.id & 0xff), false, tpdu, sizeof(tpdu), &truncated);

				if (n == 0) {
					mem->state = State::Sent::State::FAILED;
					copy(mem->reason, "bad number", sizeof(mem->reason));
				} else if (truncated) {
					mem->state = State::Sent::State::FAILED;
					copy(mem->reason, "too long", sizeof(mem->reason));
				} else {
					char pdu_hex[2 * Modem::Sms::MAX_TPDU + 1];
					to_hex(tpdu, n, pdu_hex, sizeof(pdu_hex));

					if (!_start_send_pending(s.id)) {
						mem->state = State::Sent::State::FAILED;
						copy(mem->reason, "busy", sizeof(mem->reason));
					} else {
						/* empty SMSC PDU: use the SIM's default service centre */
						_radio.send_sms("", pdu_hex, s.id);
						mem->state = State::Sent::State::PENDING;
					}
				}
			}
		}

		State::Sent entry { };
		entry.id    = mem->id;
		entry.state = mem->state;
		copy(entry.reason, mem->reason, sizeof(entry.reason));
		rebuilt[rebuilt_count++] = entry;
	}

	bool changed = rebuilt_count != _state.sent_count;
	if (!changed)
		for (unsigned i = 0; i < rebuilt_count; i++)
			if (rebuilt[i].id != _state.sent[i].id
			    || rebuilt[i].state != _state.sent[i].state
			    || ::strcmp(rebuilt[i].reason, _state.sent[i].reason)) { changed = true; break; }

	if (changed) {
		for (unsigned i = 0; i < rebuilt_count; i++) _state.sent[i] = rebuilt[i];
		_state.sent_count = rebuilt_count;
		_dirty();
	}
}


void Logic::_trim_received(unsigned acknowledged)
{
	/* a component restart resets '_next_received_id' to 0; without this,
	 * new messages would get ids <= a consumer's already-acknowledged
	 * high-water mark and be trimmed away immediately. A value at the end
	 * of the range would wrap the ids: not a plausible high-water mark. */
	if (acknowledged >= ~0u - MAX_RECEIVED) return;
	if (acknowledged > _next_received_id) _next_received_id = acknowledged;

	unsigned w = 0;
	bool changed = false;
	for (unsigned i = 0; i < _state.received_count; i++) {
		if (_state.received[i].id <= acknowledged) { changed = true; continue; }
		if (w != i) _state.received[w] = _state.received[i];
		w++;
	}
	if (changed) { _state.received_count = w; _dirty(); }
}


void Logic::epoch(char const *epoch)
{
	::strncpy(_epoch, epoch, sizeof(_epoch) - 1);
	_epoch[sizeof(_epoch) - 1] = 0;
}


unsigned Logic::_acknowledged(Config const &cfg) const
{
	/* a counter of another id space says nothing about the messages here */
	if (cfg.sms_epoch_present && ::strcmp(cfg.sms_epoch, _epoch))
		return 0;

	return cfg.sms_acknowledged;
}


void Logic::apply(Config const &cfg)
{
	Config const prev = _config;
	_config = cfg;

	if (_connected) {
		if (cfg.attach_apn[0] && ::strcmp(cfg.attach_apn, prev.attach_apn)) {
			_radio.set_initial_attach_apn(cfg.attach_apn);
			_dirty();
		}

		_reconcile_power();
		_update_power_display();

		_maybe_supply_pin();
		_apply_call(cfg.call);
		_apply_sends(cfg);
	}

	/* a changed context is a new request: no back-off left from the old one */
	bool const data_changed = cfg.data.present != prev.data.present
	                       || cfg.data.active  != prev.data.active
	                       || cfg.data.roaming != prev.data.roaming
	                       || ::strcmp(cfg.data.apn, prev.data.apn);
	if (data_changed) {
		_data_backoff_ms = DATA_BACKOFF_MIN_MS;
		if (_data_phase == Data_phase::BACKOFF) _data_phase = Data_phase::IDLE;
		if (_data_phase == Data_phase::IDLE) _data_show_idle();
	}
	_reconcile_data();

	_trim_received(_acknowledged(cfg));
}


void Logic::on_radio_unavailable()
{
	_radio_unavailable = true;
	_reported_power    = Reported_power::UNKNOWN;
	_registration_gone();
	_data_radio_gone();
	_update_power_display();
}


void Logic::on_radio_state(bool on)
{
	if (_radio_unavailable) {
		_radio_unavailable = false;
		_setup_modem();
	}

	/* a request in flight ends with the state it asked for, or when the
	 * config no longer wants that state: an indication of the opposite
	 * leaves it and its timeout alone (no new request below) */
	bool const target_wanted = _config.power == (_power_target_on ? Config::Power::ON
	                                                              : Config::Power::OFF);
	if (on == _power_target_on || !target_wanted) _clear(Req::POWER);

	_reported_power = on ? Reported_power::ON : Reported_power::OFF;

	if (on) {
		_state.startup_seconds = 0;
	} else {
		_state.shutdown_seconds = 0;
		_registration_gone();
		_data_radio_gone();
		/* only disable the modem stack when off is actually the config's
		 * desired power -- an unsolicited OFF (e.g. right after
		 * setResponseFunctions, or UNAVAILABLE-then-OFF after a CP crash)
		 * while power=on is wanted must not tear down the modem (probe
		 * P2), and neither must one while power is UNSPECIFIED (probe C
		 * -- '_power_target_on's default value of 'false' would otherwise
		 * accidentally read as "off was requested" even though nothing
		 * was ever actually asked for) */
		if (_config.power == Config::Power::OFF) _radio.enable_modem(false);
	}

	_reconcile_power();
	_update_power_display();
	_dirty();
}


void Logic::on_card_status_error()  { _answered(Req::CARD_STATUS); }
void Logic::on_registration_error() { _answered(Req::REGISTRATION); }


void Logic::on_card_status(int card_state, int pin_state)
{
	_answered(Req::CARD_STATUS);

	_state.sim = (card_state == CARD_STATE_PRESENT) ? State::Sim::PRESENT
	                                                 : State::Sim::ABSENT;

	if (_state.sim != State::Sim::PRESENT) {
		_state.pin = State::Pin::NONE;
		_state.pin_remaining_attempts = -1;
		_dirty();
		return;
	}

	switch (pin_state) {
	case PIN_ENABLED_NOT_VERIFIED:
		/* a supply is already in flight for this exact state -- do not
		 * regress CHECKING back to REQUIRED (which would re-supply the
		 * same pin on every re-query, e.g. after on_network_changed()) */
		if (_state.pin == State::Pin::CHECKING) break;

		/* the config's pin ended with an error or without answer: that
		 * stays the state until the config names another pin */
		_state.pin = (_pin_no_verdict && _pin_failed[0] && !::strcmp(_config.pin, _pin_failed))
		           ? State::Pin::ERROR : State::Pin::REQUIRED;
		break;
	case PIN_ENABLED_VERIFIED:
	case PIN_DISABLED:
		/* also the answer to a supply still in flight */
		_clear(Req::PIN);
		_state.pin = State::Pin::OK;
		_state.pin_remaining_attempts = -1;
		break;
	case PIN_ENABLED_BLOCKED:
	case PIN_ENABLED_PERM_BLOCKED:
		_state.pin = State::Pin::PUK_NEEDED;
		break;
	default:
		_state.pin = State::Pin::UNKNOWN;
		break;
	}

	_dirty();
	_maybe_supply_pin();
}


void Logic::on_pin_result(int radio_error, int remaining)
{
	_clear(Req::PIN);

	if (radio_error == RADIO_ERROR_NONE) {
		_state.pin = State::Pin::OK;
		_state.pin_remaining_attempts = -1;
		_pin_failed[0]  = 0;   /* a later required-again cycle may resupply it */
		_pin_no_verdict = false;
	} else {
		/* whatever the error, the SIM may have counted the attempt: this
		 * pin is never supplied again */
		copy(_pin_failed, _pin_inflight, sizeof(_pin_failed));
		_pin_no_verdict = radio_error != RADIO_ERROR_PASSWORD_INCORRECT;

		if (_pin_no_verdict) {
			/* not a verdict on the pin (SIM busy, internal error, radio
			 * not available, ...) */
			_state.pin = State::Pin::ERROR;
		} else if (remaining == 0) {
			_state.pin = State::Pin::PUK_NEEDED;
			_state.pin_remaining_attempts = -1;
		} else {
			_state.pin = State::Pin::REQUIRED;
			_state.pin_remaining_attempts = remaining < 0 ? -1 : remaining;
		}
	}

	_dirty();

	/* the config's pin may have changed to a new (not failed) value while
	 * the just-resolved one was in flight -- try it right away rather
	 * than waiting for the next card-status re-query */
	_maybe_supply_pin();
}


void Logic::on_registration(Reg_domain domain, int reg_state, int rat,
                             int reject_cause, char const *registered_plmn)
{
	Reg &slot = (domain == Reg_domain::DATA) ? _data_reg : _voice_reg;
	slot.valid        = true;
	slot.reg_state    = reg_state;
	slot.rat          = rat;
	slot.reject_cause = reject_cause;
	copy(slot.plmn, registered_plmn, sizeof(slot.plmn));

	_answered(Req::REGISTRATION);
	_update_network();   /* consumes or drops an early operator */
	_reg_known = true;
	_dirty();

	if (domain == Reg_domain::DATA) {
		/* roaming or not may have changed what an idle context shows */
		if (_data_phase == Data_phase::IDLE) _data_show_idle();
		_reconcile_data();
	}
}


void Logic::on_operator(char const *long_name, char const *numeric)
{
	/* early operator: remembered only while no registration is known */
	if (!_reg_known) {
		copy(_oper_name,    long_name, sizeof(_oper_name));
		copy(_oper_numeric, numeric,   sizeof(_oper_numeric));
	}

	bool const registered = _state.network.status == State::Network::Status::REGISTERED
	                      || _state.network.status == State::Network::Status::ROAMING;
	if (registered) {
		copy(_state.network.oper, long_name, sizeof(_state.network.oper));

		/* the operator's numeric PLMN is as current as the registration's */
		char mcc[4], mnc[4];
		extract_mcc_mnc(numeric, mcc, mnc);
		if (mcc[0]) {
			copy(_state.network.mcc, mcc, sizeof(_state.network.mcc));
			copy(_state.network.mnc, mnc, sizeof(_state.network.mnc));
		}
	}
	_dirty();
}


void Logic::_update_strength()
{
	using Tech = State::Network::Technology;

	/* dBm of the current technology, or no value */
	bool valid = false;
	int  dbm   = 0;

	switch (_state.network.technology) {
	case Tech::UMTS:
		if (_signal.wcdma_rscp >= 0 && _signal.wcdma_rscp <= 96) {
			valid = true; dbm = _signal.wcdma_rscp - 120; }
		break;
	case Tech::GSM:
		if (_signal.gsm_asu >= 0 && _signal.gsm_asu <= 31) {
			valid = true; dbm = 2*_signal.gsm_asu - 113; }
		break;
	case Tech::LTE:
	case Tech::NR:
	case Tech::NONE:
		if (_signal.lte_rsrp >= 44 && _signal.lte_rsrp <= 140) {
			valid = true; dbm = -_signal.lte_rsrp; }
		break;
	}

	int strength = -1;
	if (valid) {
		strength = ((dbm + 140) * 100) / 96;
		if (strength < 0)   strength = 0;
		if (strength > 100) strength = 100;
	}

	if (strength != _state.network.strength) {
		_state.network.strength = strength;
		_dirty();
	}
}


void Logic::on_signal(Signal const &signal)
{
	_signal = signal;
	_update_strength();
	_dirty();
}


void Logic::on_baseband(char const *version)
{
	_clear(Req::BASEBAND);
	copy(_state.info.revision, version, sizeof(_state.info.revision));
	_dirty();
}


void Logic::on_sms_sent(unsigned id, bool ok, int error)
{
	for (unsigned i = 0; i < MAX_SENT; i++)
		if (_send_pending[i].active && _send_pending[i].id == id) _send_pending[i].active = false;

	State::Sent::State const new_state = ok ? State::Sent::State::SENT : State::Sent::State::FAILED;
	char reason[32] { };
	if (!ok) format_decimal(error, reason, sizeof(reason));

	if (Sent_memory *mem = _sent_find(id)) {
		mem->state = new_state;
		copy(mem->reason, reason, sizeof(mem->reason));
	}

	for (unsigned i = 0; i < _state.sent_count; i++) {
		if (_state.sent[i].id != id) continue;
		_state.sent[i].state = new_state;
		copy(_state.sent[i].reason, reason, sizeof(_state.sent[i].reason));
		_dirty();
		return;
	}
}


void Logic::on_new_sms(uint8_t const *pdu, unsigned len)
{
	static_assert(unsigned(CONCAT_PART_TEXT) == unsigned(Modem::Sms::MAX_PART_TEXT),
	              "a set stores its parts as sms_pdu decodes them");

	Modem::Sms::Deliver const d = Modem::Sms::decode_deliver(pdu, len, true);

	/* acknowledged at once, valid or not, like Android */
	_radio.ack_sms(true);

	if (!d.valid) {
		_state.undecodable++;   /* 8-bit data, compressed or malformed */
		_dirty();
		return;
	}

	/* the service-centre time stamp for the report, "" if it does not decode */
	char time[Scts::ISO8601_LEN] { };
	if (!Scts::to_iso8601(d.scts, time, sizeof(time))) time[0] = 0;

	/* a set that is overdue is shown before, not completed by, this one */
	expire_sms();

	if (d.concat && d.concat_total > 1)
		_sms_part(d.sender, time, d.scts, d.text,
		          d.concat_ref, d.concat_ref16, d.concat_total, d.concat_seq);
	else
		_sms_accept(d.sender, time, d.scts, d.text);
}


namespace {

	template <typename SEEN>
	bool same_sms(SEEN const &a, SEEN const &b)
	{
		return a.text_hash == b.text_hash && a.text_length == b.text_length
		    && a.ref == b.ref && a.ref16 == b.ref16
		    && a.total == b.total && a.seq == b.seq
		    && !::memcmp(a.scts, b.scts, sizeof(a.scts))
		    && !::strcmp(a.sender, b.sender);
	}

	template <typename SEEN, unsigned N>
	bool known_sms(SEEN const (&ring)[N], SEEN const &key)
	{
		for (SEEN const &seen : ring)
			if (seen.used && same_sms(seen, key)) return true;
		return false;
	}

	template <typename SEEN, unsigned N>
	void remember_sms(SEEN (&ring)[N], unsigned &next, SEEN const &key)
	{
		ring[next] = key;
		ring[next].used = true;
		next = (next + 1) % N;
	}

	template <typename SEEN>
	void identify_sms(SEEN &key, char const *sender, uint8_t const *scts, char const *text)
	{
		copy(key.sender, sender, sizeof(key.sender));
		::memcpy(key.scts, scts, sizeof(key.scts));
		key.text_hash   = text_hash(text);
		key.text_length = uint16_t(::strlen(text));
	}
}


/*
 * A whole message -- a plain one, or a concatenated one after joining --
 * becomes a <received> entry unless it is a redelivery
 */
void Logic::_sms_accept(char const *sender, char const *time,
                        uint8_t const *scts, char const *text)
{
	Sms_seen key { };
	identify_sms(key, sender, scts, text);

	if (known_sms(_sms_history, key)) {
		_state.duplicates++;
		_dirty();
		return;
	}
	remember_sms(_sms_history, _sms_history_next, key);

	if (_state.received_count == MAX_RECEIVED) {
		for (unsigned i = 1; i < MAX_RECEIVED; i++) _state.received[i - 1] = _state.received[i];
		_state.received_count--;
		_state.dropped++;
	}

	State::Received &r = _state.received[_state.received_count++];
	r.id = ++_next_received_id;
	copy(r.from, sender, sizeof(r.from));
	copy(r.time, time,   sizeof(r.time));

	unsigned length = 0;
	r.text[0] = 0;
	append_text(r.text, sizeof(r.text), length, text);

	_dirty();
}


Logic::Concat_set *Logic::_concat_oldest()
{
	Concat_set *oldest = nullptr;
	for (Concat_set &set : _concat)
		if (set.used && (!oldest || set.first_at < oldest->first_at)) oldest = &set;
	return oldest;
}


/*
 * One part of a concatenated message ('seq' is 1..total, total >= 2)
 */
void Logic::_sms_part(char const *sender, char const *time, uint8_t const *scts,
                      char const *text, uint16_t ref, bool ref16,
                      uint8_t total, uint8_t seq)
{
	/* beyond what a set holds: acknowledged, not kept */
	if (seq > CONCAT_PARTS) return;

	Sms_seen key { };
	identify_sms(key, sender, scts, text);
	key.ref = ref; key.ref16 = ref16; key.total = total; key.seq = seq;

	if (known_sms(_sms_part_history, key)) {
		_state.duplicates++;
		_dirty();
		return;
	}

	Concat_set *set = nullptr;
	for (Concat_set &s : _concat)
		if (s.used && s.ref == ref && s.ref16 == ref16 && s.total == total
		 && !::strcmp(s.sender, sender)) { set = &s; break; }

	if (set && set->present[seq - 1]) {

		/* the same part once more (it left the part history meanwhile) */
		if (!::strcmp(set->text[seq - 1], text)) {
			_state.duplicates++;
			_dirty();
			return;
		}

		/* another message under the same reference: the old one ends here */
		_sms_flush(*set);
		set = nullptr;
	}

	if (!set) {
		for (Concat_set &s : _concat)
			if (!s.used) { set = &s; break; }

		if (!set) {
			set = _concat_oldest();
			_sms_flush(*set);
		}

		set->used     = true;
		set->ref      = ref;
		set->ref16    = ref16;
		set->total    = total;
		set->first_at = _now_ms();
		set->time_seq = 0;
		copy(set->sender, sender, sizeof(set->sender));
		for (bool &present : set->present) present = false;
	}

	set->present[seq - 1] = true;
	copy(set->text[seq - 1], text, sizeof(set->text[seq - 1]));
	remember_sms(_sms_part_history, _sms_part_history_next, key);

	if (!set->time_seq || seq < set->time_seq) {
		set->time_seq = seq;
		copy(set->time, time, sizeof(set->time));
		::memcpy(set->scts, scts, sizeof(set->scts));
	}

	unsigned const parts = total < CONCAT_PARTS ? total : unsigned(CONCAT_PARTS);
	for (unsigned i = 0; i < parts; i++)
		if (!set->present[i]) return;

	_sms_flush(*set);
}


/*
 * Join what a set holds into one message and release the set: the parts in
 * sequence order, "[...]" for each run of missing ones
 */
void Logic::_sms_flush(Concat_set &set)
{
	static char const * const missing = "[...]";

	char     text[MAX_SMS_TEXT + 1];
	unsigned length = 0;
	text[0] = 0;

	unsigned const parts = set.total < CONCAT_PARTS ? set.total : unsigned(CONCAT_PARTS);

	bool gap = false, room = true;
	for (unsigned i = 0; i < parts && room; i++) {
		if (set.present[i]) {
			room = append_text(text, sizeof(text), length, set.text[i]);
			gap  = false;
		} else if (!gap) {
			/* the marker goes in whole or not at all */
			if (length + ::strlen(missing) <= MAX_SMS_TEXT)
				append_text(text, sizeof(text), length, missing);
			else
				room = false;
			gap = true;
		}
	}

	/* parts beyond CONCAT_PARTS were not kept */
	if (room && !gap && set.total > parts && length + ::strlen(missing) <= MAX_SMS_TEXT)
		append_text(text, sizeof(text), length, missing);

	set.used = false;
	_sms_accept(set.sender, set.time, set.scts, text);
}


void Logic::expire_sms()
{
	unsigned long const now = _now_ms();

	/* oldest first, so that the ids follow the order of arrival */
	for (;;) {
		Concat_set * const set = _concat_oldest();
		if (!set || now - set->first_at < CONCAT_TIMEOUT_MS) return;
		_sms_flush(*set);
	}
}


/*
 * The call this driver tracks (one call): while a dial is
 * pending, the outgoing call that confirms it (isMT == false in DIALING/
 * ALERTING/ACTIVE; several such calls are told apart by the normalised
 * number); otherwise the call tracked so far (same index), else the first
 */
Logic::Call_info const *Logic::_select_call(Call_info const *calls, unsigned count,
                                            bool &ours) const
{
	ours = false;

	if (_dial_pending) {
		Call_info const *candidate = nullptr;
		for (unsigned i = 0; i < count; i++) {
			Call_info const &c = calls[i];
			bool const outgoing = !c.is_mt && (c.state == CALL_DIALING
			                                || c.state == CALL_ALERTING
			                                || c.state == CALL_ACTIVE);
			if (!outgoing) continue;
			if (!candidate) candidate = &c;
			if (same_number(c.number, _dial_sent)) { candidate = &c; break; }
		}
		if (candidate) { ours = true; return candidate; }
	}

	if (_call_index >= 0)
		for (unsigned i = 0; i < count; i++)
			if (calls[i].index == _call_index) return &calls[i];

	return &calls[0];
}


void Logic::on_calls(Call_info const *calls, unsigned count)
{
	if (count == 0) {
		/*
		 * A poll that raced ahead of a not-yet-answered dialResponse says
		 * nothing about the dial: it stays pending (its own timeout, Req::DIAL,
		 * covers a call that never shows up), so the call that appears later
		 * is still recognised as ours and a redial is not blocked.
		 */
		bool const dial_unconfirmed = _dial_pending && !_dial_confirmed;
		if (!dial_unconfirmed) _clear(Req::DIAL);

		/* a genuine dial failure: either it was accepted by RIL and then
		 * simply never showed up (only meaningful once on_dial_result(true)
		 * confirmed it), or a call that did appear (OUTBOUND/ALERTING) has
		 * now vanished */
		bool const dial_failed = (_dial_pending && _dial_confirmed)
		                       || (_state.call.present
		                           && (_state.call.state == State::Call::State::OUTBOUND
		                               || _state.call.state == State::Call::State::ALERTING));
		/* a call (or dial) vanished: ask for the modem's release cause */
		bool const rejected_shown = _state.call.present
		                         && _state.call.state == State::Call::State::REJECTED;
		if (dial_failed || (_state.call.present && !rejected_shown))
			_radio.get_last_call_fail_cause();

		if (dial_failed) { _dial_gone(); return; }

		/* shown until the config withdraws the call node */
		if (rejected_shown) return;

		bool const had = _state.call.present;
		_state.call = State::Call { };
		_call_index     = -1;
		if (!dial_unconfirmed) { _dial_pending = false; _dial_confirmed = false; }
		_accept_sent    = false;
		_hangup_sent    = false;
		_call_owned     = false;
		_reset_call_retry();   /* nothing left to retry on */
		if (had) _dirty();
		return;
	}

	/* an unrelated call (e.g. an incoming ring) while our own dial is
	 * still outstanding does not confirm it, nor clear its timer
	 * (finding N-B4) */
	bool ours = false;
	Call_info const &c = *_select_call(calls, count, ours);

	if (ours) {
		_clear(Req::DIAL);
		_dial_pending   = false;
		_dial_confirmed = false;
	}

	bool const was_present  = _state.call.present;
	bool const was_rejected = _state.call.state == State::Call::State::REJECTED;
	bool const is_new       = !was_present || was_rejected || c.index != _call_index;

	State::Call::State const mapped = map_call_state(c.state);

	/* the config no longer wants a call (we withdrew, possibly before RIL
	 * ever confirmed it) but the RIL now shows an outgoing one anyway: hang
	 * it up by its (now known) index instead of losing track of it or later
	 * flashing 'rejected' for it (finding N3 remainder / probes A, A2) */
	bool const unwanted = is_new && !_config.call.present && !c.is_mt
	                    && (mapped == State::Call::State::OUTBOUND
	                        || mapped == State::Call::State::ALERTING
	                        || mapped == State::Call::State::ACTIVE);

	_state.call.present = true;
	copy(_state.call.number, c.number, sizeof(_state.call.number));
	_state.call.state = mapped;
	_call_index = c.index;

	if (is_new) {
		_accept_sent = false; _hangup_sent = false; _call_owned = false;
		_reset_call_retry();
	}
	if (ours) _call_owned = true;

	if (unwanted && !_hangup_sent) _issue_hangup();

	/* the one retry of a failed hangup/accept (see 'on_hangup_result') */
	if (_call_retry) {
		_call_retry = false;
		_apply_call(_config.call);
	}

	_dirty();
}


void Logic::on_dial_result(bool ok)
{
	if (!_dial_pending) return;   /* stray/late answer for a dial we no longer track */
	if (ok) { _dial_confirmed = true; return; }

	/* never override a call 'on_calls' lists (finding I2) */
	if (_call_listed()) _dial_dropped();
	else                _dial_gone();
}


void Logic::_call_failed_request()
{
	if (_call_retry_used) return;
	_call_retry_used = true;
	_call_retry      = true;
}


void Logic::on_accept_result(bool ok)
{
	if (ok) return;
	_accept_sent = false;
	_call_failed_request();
}


void Logic::on_hangup_result(bool ok)
{
	if (ok) return;
	_hangup_sent = false;
	_call_failed_request();
}


/*
 * Mobile data (rule: see the class doc in logic.h)
 */

bool Logic::_data_wanted() const
{
	return _config.data.present && _config.data.active && _config.data.apn[0];
}


/* the data domain is registered roaming and the context does not allow that */
bool Logic::_data_roaming_denied() const
{
	return _data_reg.valid && _data_reg.reg_state == REG_ROAMING
	    && !_config.data.roaming;
}


bool Logic::_data_registered() const
{
	if (!_data_reg.valid) return false;
	return _data_reg.reg_state == REG_HOME
	    || (_data_reg.reg_state == REG_ROAMING && _config.data.roaming);
}


/* no call: 'inactive' while a context is configured (with the cause
 * "roaming" if that is what keeps it down), else no <data> node */
void Logic::_data_show_idle()
{
	_state.data = State::Data { };
	if (_config.data.present) {
		_state.data.state = State::Data::State::INACTIVE;
		copy(_state.data.apn, _config.data.apn, sizeof(_state.data.apn));
		if (_data_wanted() && _data_roaming_denied())
			copy(_state.data.cause, "roaming", sizeof(_state.data.cause));
	}
	_dirty();
}


/* radio off or unavailable: not registered until the next result says so */
void Logic::_registration_gone()
{
	_voice_reg = Reg { };
	_data_reg  = Reg { };
	_reg_known       = false;
	_oper_name[0]    = 0;
	_oper_numeric[0] = 0;
	_state.network = State::Network { };
	_clear(Req::REGISTRATION);
	_dirty();
}


void Logic::_data_show_call(Data_call_info const &call)
{
	State::Data &d = _state.data;
	d = State::Data { };
	d.state = State::Data::State::ACTIVE;
	d.cid   = call.cid;
	d.mtu   = call.mtu;
	copy(d.apn,     _data_apn,    sizeof(d.apn));
	copy(d.ifname,  call.ifname,  sizeof(d.ifname));
	copy(d.type,    call.type,    sizeof(d.type));
	copy(d.address, call.address, sizeof(d.address));
	copy(d.dns,     call.dns,     sizeof(d.dns));
	copy(d.gateway, call.gateway, sizeof(d.gateway));
	_dirty();
}


void Logic::_data_setup()
{
	copy(_data_apn, _config.data.apn, sizeof(_data_apn));
	_radio.setup_data_call(_data_apn, access_network(_data_reg.rat), _config.data.roaming);

	_data_phase   = Data_phase::SETUP_SENT;
	_data_sent_at = _now_ms();

	_state.data = State::Data { };
	_state.data.state = State::Data::State::CONNECTING;
	copy(_state.data.apn, _data_apn, sizeof(_state.data.apn));
	_dirty();
}


void Logic::_data_deactivate()
{
	_radio.deactivate_data_call(_data_cid);
	_data_phase         = Data_phase::DEACT_SENT;
	_data_sent_at       = _now_ms();
	_data_deact_retried = false;
}


/*
 * No call any more and none before the back-off ends: a failed setup
 * ('failed', shown 'failed') or a call the modem dropped (shown 'inactive')
 */
void Logic::_data_backoff(char const *cause, long long suggested_ms, bool failed)
{
	enum : long long { NEVER = 0x7fffffffffffffffLL };

	_data_phase     = Data_phase::BACKOFF;
	_data_cid       = -1;
	_data_failed_at = _now_ms();
	_data_no_retry  = suggested_ms == NEVER;
	_data_delay_ms  = _data_backoff_ms;

	if (!_data_no_retry && suggested_ms > (long long)_data_delay_ms)
		_data_delay_ms = suggested_ms > DATA_SUGGESTED_MAX_MS
		               ? (unsigned long)DATA_SUGGESTED_MAX_MS : (unsigned long)suggested_ms;

	_data_backoff_ms *= 2;
	if (_data_backoff_ms > DATA_BACKOFF_MAX_MS) _data_backoff_ms = DATA_BACKOFF_MAX_MS;

	_state.data = State::Data { };
	_state.data.state = failed ? State::Data::State::FAILED : State::Data::State::INACTIVE;
	copy(_state.data.apn,   _data_apn, sizeof(_state.data.apn));
	copy(_state.data.cause, cause,     sizeof(_state.data.cause));
	_dirty();
}


/* radio off or unavailable: the modem has no call any more, nothing to send */
void Logic::_data_radio_gone()
{
	if (_data_phase == Data_phase::IDLE || _data_phase == Data_phase::BACKOFF) return;

	_data_phase = Data_phase::IDLE;
	_data_cid   = -1;
	_data_show_idle();
}


void Logic::_reconcile_data()
{
	if (!_connected) return;

	switch (_data_phase) {

	case Data_phase::IDLE:
		if (_data_wanted() && _data_registered()) _data_setup();
		break;

	case Data_phase::BACKOFF:
		if (!_data_wanted()) {
			_data_phase = Data_phase::IDLE;
			_data_show_idle();
			break;
		}
		if (_data_no_retry || !_data_registered()) break;
		if (_now_ms() - _data_failed_at >= _data_delay_ms) _data_setup();
		break;

	case Data_phase::ACTIVE:
		if (!_data_wanted() || ::strcmp(_config.data.apn, _data_apn)
		 || _data_roaming_denied()) _data_deactivate();
		break;

	case Data_phase::SETUP_SENT:   /* decided when the answer is there */
	case Data_phase::DEACT_SENT:
		break;
	}
}


void Logic::on_data_call_setup(bool radio_ok, Data_call_info const &call)
{
	bool const up = radio_ok && call.cause_none && call.active && call.cid >= 0;

	if (_data_phase != Data_phase::SETUP_SENT) {
		/* an answer after the time-out: a call that exists must be tracked
		 * (and is deactivated below if nobody wants it) */
		bool const adopt = up && (_data_phase == Data_phase::IDLE
		                       || _data_phase == Data_phase::BACKOFF);
		if (!adopt) return;
	}

	if (!up) {
		char const *cause = call.cause[0] ? call.cause
		                  : (radio_ok && call.cause_none) ? "not active" : "error";
		_data_backoff(cause, radio_ok ? call.retry_ms : -1, true);
		return;
	}

	_data_phase        = Data_phase::ACTIVE;
	_data_cid          = call.cid;
	_data_active_since = _now_ms();
	_data_show_call(call);

	_reconcile_data();   /* withdrawn meanwhile: deactivate */
}


void Logic::on_data_call_deactivated(bool ok)
{
	if (_data_phase != Data_phase::DEACT_SENT) return;

	if (!ok) {
		/* still there? decided by the list, else by the time-out in 'tick' */
		_radio.get_data_call_list();
		return;
	}

	_data_phase = Data_phase::IDLE;
	_data_cid   = -1;
	_data_show_idle();
	_reconcile_data();   /* e.g. the context's new APN */
}


void Logic::on_data_call_list(Data_call_info const *calls, unsigned count,
                              bool complete)
{
	if (_data_phase != Data_phase::ACTIVE && _data_phase != Data_phase::DEACT_SENT)
		return;   /* calls of others (IMS), or ours not known yet */

	Data_call_info const *ours = nullptr;
	for (unsigned i = 0; i < count; i++)
		if (calls[i].cid == _data_cid) { ours = &calls[i]; break; }

	/* ours may be among the calls the list does not show */
	if (!ours && !complete) return;

	bool const up = ours && ours->active;

	if (_data_phase == Data_phase::DEACT_SENT) {
		if (up) return;
		_data_phase = Data_phase::IDLE;
		_data_cid   = -1;
		_data_show_idle();
		_reconcile_data();
		return;
	}

	if (up) {
		_data_show_call(*ours);   /* address, DNS or MTU may have changed */
		return;
	}

	/* dropped by the modem or the network */
	if (_now_ms() - _data_active_since >= DATA_STABLE_MS)
		_data_backoff_ms = DATA_BACKOFF_MIN_MS;

	char const *cause = (ours && !ours->cause_none && ours->cause[0]) ? ours->cause : "lost";
	_data_backoff(cause, ours ? ours->retry_ms : -1, false);
}


/*
 * A query already in flight is not sent again, which would re-arm its
 * timeout (and, under a stream of indications, keep it from ever
 * expiring): it is repeated once when its answer is there ('_answered')
 */
void Logic::on_network_changed()
{
	if (!_connected) return;

	Pending &card = _pending[unsigned(Req::CARD_STATUS)];
	if (card.active) {
		card.again = true;
	} else {
		_radio.get_icc_card_status();
		_start(Req::CARD_STATUS, _now_ms());
	}

	Pending &reg = _pending[unsigned(Req::REGISTRATION)];
	if (reg.active) {
		reg.again = true;
	} else {
		_radio.query_registration();
		_start(Req::REGISTRATION, _now_ms());
	}
}


void Logic::tick()
{
	unsigned long const now = _now_ms();

	if (_state.power == State::Power::STARTING_UP)  { _state.startup_seconds++;  _dirty(); }
	if (_state.power == State::Power::SHUTTING_DOWN) { _state.shutdown_seconds++; _dirty(); }

	for (unsigned i = 0; i < unsigned(Req::COUNT); i++) {
		Pending &p = _pending[i];
		if (!p.active) continue;
		if (now - p.sent_at < REQUEST_TIMEOUT_MS) continue;

		Req const kind = Req(i);
		bool const retryable = kind != Req::PIN && kind != Req::DIAL;

		if (retryable && !p.retried) {
			p.retried = true;
			p.sent_at = now;
			_retry(kind);
		} else {
			p.active = false;
			_give_up(kind);
		}
	}

	expire_sms();

	if (_data_phase == Data_phase::SETUP_SENT
	 && now - _data_sent_at >= DATA_SETUP_TIMEOUT_MS) {
		_radio.gave_up("setupDataCall");
		_data_backoff("timeout", -1, true);
	}
	if (_data_phase == Data_phase::DEACT_SENT
	 && now - _data_sent_at >= REQUEST_TIMEOUT_MS) {
		if (!_data_deact_retried) {
			_data_deact_retried = true;
			_data_sent_at       = now;
			_radio.deactivate_data_call(_data_cid);
		} else {
			_radio.gave_up("deactivateDataCall");
			_data_phase = Data_phase::IDLE;
			_data_cid   = -1;
			_data_show_idle();
		}
	}
	_reconcile_data();   /* a back-off may have ended */

	for (unsigned i = 0; i < MAX_SENT; i++) {
		Send_pending &sp = _send_pending[i];
		if (!sp.active) continue;
		if (now - sp.sent_at < REQUEST_TIMEOUT_MS) continue;

		sp.active = false;
		_radio.gave_up("sendSms");

		if (Sent_memory *mem = _sent_find(sp.id)) {
			mem->state = State::Sent::State::FAILED;
			copy(mem->reason, "timeout", sizeof(mem->reason));
		}
		for (unsigned k = 0; k < _state.sent_count; k++) {
			if (_state.sent[k].id != sp.id) continue;
			_state.sent[k].state = State::Sent::State::FAILED;
			copy(_state.sent[k].reason, "timeout", sizeof(_state.sent[k].reason));
			_dirty();
			break;
		}
	}
}


bool Logic::state_changed()
{
	bool const d = _dirty_flag;
	_dirty_flag = false;
	return d;
}
