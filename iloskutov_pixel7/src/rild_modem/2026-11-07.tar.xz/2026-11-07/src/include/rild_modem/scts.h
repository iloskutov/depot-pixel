/*
 * \brief  rild_modem: SMS-DELIVER service-centre time stamp as ISO 8601
 * \author Ivan Loskutov
 * \date   2026-09-27
 *
 * sms_pdu's 'Deliver' carries the TP-SCTS as its seven raw octets (GSM
 * 03.40 9.2.3.11): semi-octet pairs YY MM DD hh mm ss TZ, TZ in quarter
 * hours with the sign in bit 3 of the (swapped) tens digit. The local time
 * is converted to UTC and written as "YYYY-MM-DDThh:mm:ssZ" (years 00..99
 * are 2000..2099) with the libc's calendar functions.
 */

/*
 * SPDX-License-Identifier: MIT
 */

#ifndef _INCLUDE__RILD_MODEM__SCTS_H_
#define _INCLUDE__RILD_MODEM__SCTS_H_

#include <stdint.h>
#include <time.h>

namespace Rild_modem { namespace Scts {

	enum { ISO8601_LEN = 21 };   /* "YYYY-MM-DDThh:mm:ssZ" and the NUL */

	/* semi-octet pair: low nibble = tens, high nibble = units */
	inline bool bcd(uint8_t b, int &v)
	{
		int const tens = b & 0xf, units = b >> 4;
		if (tens > 9 || units > 9) return false;
		v = tens*10 + units;
		return true;
	}

	inline bool leap(int y) { return (y % 4 == 0 && y % 100 != 0) || y % 400 == 0; }

	inline int days_in_month(int y, int m)
	{
		static int const days[12] = { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
		return (m == 2 && leap(y)) ? 29 : days[m - 1];
	}

	/**
	 * Format the 7 TP-SCTS octets as UTC
	 *
	 * \param out  at least ISO8601_LEN bytes
	 * \return     false on a non-BCD digit or an out-of-range field
	 */
	inline bool to_iso8601(uint8_t const scts[7], char *out, unsigned cap)
	{
		if (cap < ISO8601_LEN) return false;

		int yy, mo, dd, hh, mi, ss;
		if (!bcd(scts[0], yy) || !bcd(scts[1], mo) || !bcd(scts[2], dd)
		 || !bcd(scts[3], hh) || !bcd(scts[4], mi) || !bcd(scts[5], ss))
			return false;

		uint8_t const tz = scts[6];
		int const tz_tens = tz & 0x7, tz_units = tz >> 4;
		if (tz_units > 9) return false;
		int const quarters = tz_tens*10 + tz_units;
		int const offset_min = ((tz & 0x8) ? -quarters : quarters) * 15;

		int const year = 2000 + yy;
		if (mo < 1 || mo > 12 || dd < 1 || dd > days_in_month(year, mo)
		 || hh > 23 || mi > 59 || ss > 59 || quarters > 4*18)
			return false;

		/* local time -> UTC */
		struct tm local { };
		local.tm_year = year - 1900; local.tm_mon = mo - 1; local.tm_mday = dd;
		local.tm_hour = hh;          local.tm_min = mi;     local.tm_sec  = ss;

		time_t const utc = ::timegm(&local) - offset_min*60;

		struct tm tm { };
		if (!::gmtime_r(&utc, &tm)) return false;

		return ::strftime(out, cap, "%Y-%m-%dT%H:%M:%SZ", &tm) == ISO8601_LEN - 1;
	}
} }

#endif /* _INCLUDE__RILD_MODEM__SCTS_H_ */
