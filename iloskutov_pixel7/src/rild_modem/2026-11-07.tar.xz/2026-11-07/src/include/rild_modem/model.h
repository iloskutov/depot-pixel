/*
 * \brief  rild_modem: config/state data model
 * \author Ivan Loskutov
 * \date   2026-09-27
 *
 * Plain, fixed-size structures shared between the platform-independent
 * logic (logic.h) and the component (src/app/rild_modem): 'Config' is
 * the desired state parsed from the config ROM, 'State' is what the
 * component assembles into the modem/state report (README), backward
 * compatible with the report of the PinePhone driver consumed unchanged by
 * phone_manager of Genode's 'gems' repository.
 */

/*
 * SPDX-License-Identifier: MIT
 */

#ifndef _INCLUDE__RILD_MODEM__MODEL_H_
#define _INCLUDE__RILD_MODEM__MODEL_H_

namespace Rild_modem {

	enum { MAX_RECEIVED = 32, MAX_SENT = 8, MAX_SENDS = 8 };

	/* UTF-8 bytes of a received message's text; a longer (concatenated)
	 * message is cut at a character boundary */
	enum { MAX_SMS_TEXT = 1000 };

	/**
	 * Desired state, parsed from the config ROM by the component
	 */
	struct Config
	{
		enum class Power { UNSPECIFIED, ON, OFF };

		Power power = Power::UNSPECIFIED;
		char  pin[16]       { };   /* "" = none */
		char  attach_apn[64] { };

		struct Call
		{
			enum class State { NONE, ACCEPTED, REJECTED };

			bool  present = false;
			char  number[32] { };
			State state = State::NONE;
		} call { };

		unsigned sms_acknowledged = 0;

		/*
		 * The id space 'sms_acknowledged' counts in: the epoch of the
		 * state report the consumer took the ids from (rild_modem/epoch.h).
		 * Not present: a consumer that knows no epoch.
		 */
		bool sms_epoch_present = false;
		char sms_epoch[32]     { };

		struct Send
		{
			unsigned id = 0;
			char     to[32]   { };
			char     text[161] { };
			bool     too_long = false;   /* text did not fit, reported "too long" */
		};

		Send     sends[MAX_SENDS] { };
		unsigned send_count = 0;

		/*
		 * Mobile data: the one data context (<data> <context apn="…"
		 * active="yes" roaming="no"/> </data>, the first <context> node).
		 * 'roaming' allows the data call while registered roaming.
		 */
		struct Data
		{
			bool present = false;   /* a <context> with an apn is configured */
			bool active  = false;
			bool roaming = false;
			char apn[64] { };
		} data { };
	};


	/**
	 * The reported state (README)
	 */
	struct State
	{
		enum class Power { UNAVAILABLE, OFF, STARTING_UP, ON, SHUTTING_DOWN };
		enum class Sim   { UNKNOWN, ABSENT, PRESENT };

		/* UNKNOWN: the pin attribute is omitted (a pin state of the card
		 * this component does not know); ERROR: the supply of the config's
		 * pin ended with an error other than a refusal, or without answer.
		 * The vocabulary of the actually written attribute is
		 * required|checking|ok|puk needed|error */
		enum class Pin { NONE, REQUIRED, CHECKING, OK, PUK_NEEDED, UNKNOWN, ERROR };

		Power    power = Power::UNAVAILABLE;
		unsigned startup_seconds  = 0;
		unsigned shutdown_seconds = 0;

		Sim      sim = Sim::UNKNOWN;
		Pin      pin = Pin::NONE;
		int      pin_remaining_attempts = -1;   /* -1: attribute absent */

		/* IRadio V1 gives no source for manufacturer/model, only the
		 * baseband version (getBasebandVersion) */
		struct Info
		{
			char revision[64] { };   /* baseband version */
		} info { };

		struct Network
		{
			enum class Status
			{
				UNAVAILABLE, UNREGISTERED, REGISTERED, SEARCHING,
				DENIED, ROAMING, UNKNOWN
			};

			enum class Technology { NONE, GSM, UMTS, LTE, NR };

			Status     status     = Status::UNAVAILABLE;
			Technology technology = Technology::NONE;
			char       oper[32]   { };   /* 'operator' is a C++ keyword */
			char       mcc[4]     { };
			char       mnc[4]     { };
			int        strength   = -1;  /* -1: attribute absent, else 0..100 */
			char       denial_reason[16] { };
		} network { };

		struct Call
		{
			/* REJECTED: a transient terminal display -- an outbound call
			 * that ended (remote reject / failed dial) without ever
			 * becoming ACTIVE; stays 'present' until the config withdraws
			 * the call node (backward compatible: an old consumer that
			 * does not know "rejected" falls back to its NONE default) */
			enum class State { NONE, INCOMING, ACTIVE, OUTBOUND, ALERTING, REJECTED };

			bool  present = false;
			char  number[32] { };
			State state = State::NONE;
		} call { };

		struct Received
		{
			unsigned id = 0;
			char     from[32]  { };                 /* number, or the name of an alphanumeric sender (UTF-8) */
			char     time[32]  { };
			char     text[MAX_SMS_TEXT + 1] { };    /* UTF-8, may hold LF/CR */
		};

		struct Sent
		{
			enum class State { PENDING, SENT, FAILED };

			unsigned id    = 0;
			State    state = State::PENDING;
			char     reason[32] { };   /* fits "unsupported characters" */
		};

		Received received[MAX_RECEIVED] { };
		unsigned received_count = 0;

		Sent     sent[MAX_SENT] { };
		unsigned sent_count = 0;

		/*
		 * The data context of the config. NONE: no <data> node in the
		 * report (no context configured). The details (cid .. mtu) are
		 * those of the last SetupDataCallResult and are present only while
		 * ACTIVE; 'cause' explains FAILED (the modem's DataCallFailCause
		 * or radio error by name, "timeout"), the last loss of the call
		 * ("lost", with INACTIVE), or "roaming" (INACTIVE because the data
		 * domain is roaming and the context does not allow that).
		 */
		struct Data
		{
			enum class State { NONE, INACTIVE, CONNECTING, ACTIVE, FAILED };

			State state = State::NONE;
			char  apn[64]      { };
			int   cid          = -1;
			char  ifname[16]   { };
			char  type[16]     { };   /* IP, IPV6, IPV4V6 */
			char  address[128] { };   /* comma-separated, as the modem gives them */
			char  dns[128]     { };
			char  gateway[128] { };
			int   mtu          = 0;
			char  cause[48]    { };
		} data { };

		unsigned dropped     = 0;   /* received messages evicted above MAX_RECEIVED */
		unsigned undecodable = 0;   /* received PDUs without decodable text (8-bit data, compressed, malformed) */
		unsigned duplicates  = 0;   /* redelivered PDUs of an already accepted message, not shown again */
	};
}

#endif /* _INCLUDE__RILD_MODEM__MODEL_H_ */
