/*
 * \brief  rild_modem: cut UTF-8 text without splitting a character
 * \author Ivan Loskutov
 * \date   2026-10-01
 *
 * Received SMS text is UTF-8 (sms_pdu decodes the GSM 7-bit alphabet
 * and UCS-2 to it) and passes through fixed-size buffers on its way into
 * the report. Wherever it may not fit, it is cut with 'utf8_prefix' so
 * that no half character reaches the consumer. Freestanding.
 */

/*
 * SPDX-License-Identifier: MIT
 */

#ifndef _INCLUDE__RILD_MODEM__UTF8_H_
#define _INCLUDE__RILD_MODEM__UTF8_H_

namespace Rild_modem {

	/**
	 * Length of the longest prefix of 's' that has at most 'max' bytes and
	 * does not end inside a multi-byte sequence
	 */
	inline unsigned long utf8_prefix(char const *s, unsigned long max)
	{
		if (!s) return 0;

		unsigned long n = 0;
		while (n < max && s[n]) n++;

		/* cut within a sequence: back to its lead byte, which goes too */
		if (s[n])
			while (n > 0 && ((unsigned char)s[n] & 0xc0) == 0x80) n--;

		return n;
	}
}

#endif /* _INCLUDE__RILD_MODEM__UTF8_H_ */
