/*
 * \brief  rild_modem: make a remote-controlled string safe for the report
 * \author Ivan Loskutov
 * \date   2026-09-27
 *
 * Genode's generators do not escape attribute values: in HID mode a value
 * with a control character or '|' is dropped entirely (with a once-only
 * warning), in XML mode a '"', '<', '>' or '&' is copied verbatim and can
 * close the node or inject new ones. Every string the network or the
 * modem controls (received SMS 'from'/'text', 'operator', ...) therefore
 * passes through 'sanitize' before it becomes an attribute: control
 * characters (0x00-0x1f, 0x7f), '|', '"', '<', '>' and '&' each become
 * '?'. Everything else -- including UTF-8 multi-byte sequences -- is kept;
 * a string that does not fit is cut at a UTF-8 character boundary.
 */

/*
 * SPDX-License-Identifier: MIT
 */

#ifndef _INCLUDE__RILD_MODEM__SANITIZE_H_
#define _INCLUDE__RILD_MODEM__SANITIZE_H_

#include <rild_modem/utf8.h>

namespace Rild_modem {

	/**
	 * True if 'c' is replaced by 'sanitize'
	 */
	inline bool unsafe_report_char(char c)
	{
		unsigned char const u = (unsigned char)c;
		return u < 0x20 || u == 0x7f
		    || c == '|' || c == '"' || c == '<' || c == '>' || c == '&';
	}

	/**
	 * Copy 'in' to 'out' ('cap' bytes including the NUL, truncating at a
	 * UTF-8 character boundary), replacing every unsafe character by '?'
	 */
	inline void sanitize(char const *in, char *out, unsigned long cap)
	{
		if (!cap) return;
		unsigned long const n = utf8_prefix(in, cap - 1);
		for (unsigned long i = 0; i < n; i++)
			out[i] = unsafe_report_char(in[i]) ? '?' : in[i];
		out[n] = 0;
	}

	/**
	 * Sanitised copy of a string, for use as a generator argument
	 */
	template <unsigned long N>
	struct Sanitized
	{
		char string[N];

		Sanitized(char const *in) { sanitize(in, string, N); }
	};
}

#endif /* _INCLUDE__RILD_MODEM__SANITIZE_H_ */
