/*
 * \brief  rild_modem: platform-independent backend logic
 * \author Ivan Loskutov
 * \date   2026-09-27
 *
 * Requests out (through 'Radio', implemented over the generated IRadio
 * encoders in the component), callbacks in (from the generated response /
 * indication dispatchers), state out ('State', README). Free of the
 * generated radio_aidl types so it stays testable on the host with a plain
 * g++; logic.cc uses the generated enum values by hand for the mapping, as
 * documented there.
 *
 * Power (Android's setPowerStateToDesired pattern): 'desired' is the
 * config's 'power' (UNSPECIFIED/ON/OFF); 'reported' is the last 'on_radio_state()' value,
 * reset to unknown by 'connected()'/'disconnected()' and by
 * 'on_radio_unavailable()'. A reconciliation
 * runs on every config change and every 'on_radio_state()': if desired is
 * specified, differs from reported, and no POWER request is already
 * outstanding, it issues one (ON: enableModem(true) + setRadioPower(true);
 * OFF: setRadioPower(false), then enableModem(false) once OFF is actually
 * reported -- never pre-emptively). The displayed power is 'starting up'/
 * 'shutting down' only while a POWER request is outstanding; otherwise it
 * is the reported state (defaulting to 'off' if never reported yet). This
 * means: a config matching what is already reported issues nothing and
 * shows the reported state right away (no stuck 'starting up'); an
 * unspecified config issues nothing at all; an OFF indication while ON is
 * desired (libril's very first indication, or after a CP crash) is treated
 * as a fresh mismatch and re-asserts ON, going through the same one-retry-
 * then-give-up timeout as any other request -- once given up, the display
 * simply reverts to the (still OFF) reported state until the next
 * reconciliation trigger; nothing retries on its own afterwards. An
 * indication that contradicts a POWER request in flight (OFF while the
 * still desired ON is awaited) neither ends that request nor starts a new
 * one: its timeout keeps running.
 *
 * A radio that is OFF or UNAVAILABLE has no registration: both domains
 * and the reported network are reset until the next registration result.
 *
 * Non-idempotent, one-shot requests are NOT retried on their 10 s timeout,
 * only given up on: 'supplyIccPin' (a second blind attempt could burn a
 * retry attempt on the SIM), 'dial' and 'send_sms' (each would place/send
 * a second time). A 'send_sms' timeout marks that id's 'sent' entry
 * 'failed' with reason "timeout".
 *
 * PIN. The config's pin is supplied when the card asks for it. A supply
 * that did not succeed -- refused by the SIM, answered with any other
 * error, or not answered in time -- makes that pin string the failed one:
 * it is never supplied again, whatever asks for a pin later (a card-status
 * cycle, a radio or rild restart, another card), until the config names a
 * different pin. A refusal shows 'required' (or 'puk needed') with the
 * remaining attempts, the other two outcomes show 'error' for as long as
 * the config still names the failed pin. A successful supply forgets the
 * failed pin.
 *
 * Calls follow the PinePhone driver's config semantics (repos/allwinner/
 * src/driver/modem/at_protocol/control.h, '_apply_hang_up'): a missing
 * <call> node hangs up only a call the config itself established -- our
 * own dial, or an incoming call accepted via state="accepted". A ringing
 * (not accepted) incoming call is left alone by a missing node
 * (phone_manager never writes one for it, and an unrelated config change
 * -- an SMS acknowledgement, a <send>, the pin, the attach APN -- must not
 * reject it); it is rejected only by state="rejected".
 *
 * A pending dial is confirmed by the IRadio call's direction and state
 * (isMT == false and DIALING/ALERTING/ACTIVE), not by its number: the
 * modem commonly reports the dialled number normalised (national ->
 * international, a '+' added). The number is compared (after
 * normalisation: digits only, trailing significant digits) only to choose
 * between several such calls. The dial timeout (and a dialResponse error)
 * never overrides a call that 'on_calls' currently lists -- the dial is
 * then dropped silently.
 *
 * A dialled call that never reaches ACTIVE is reported 'rejected'
 * (`State::Call::State::REJECTED`, present stays true with the dialled
 * number) on any of: 'on_dial_result(false)' while that dial is still
 * pending/unconfirmed (a stray or late dialResponse error for a dial we
 * no longer track, e.g. after 'on_calls' already confirmed it, is
 * ignored), the dial timing out, or 'on_calls' reporting no call where
 * one was expected -- the last one only once 'on_dial_result(true)' was
 * actually seen for that dial, so a getCurrentCalls poll that merely
 * raced ahead of a not-yet-answered dialResponse cannot flash 'rejected'.
 * All of this is suppressed (clears silently instead) when we ourselves
 * withdrew the config's call node first, even before the RIL ever
 * confirmed a call existed (no index to cancel yet, but the pending
 * dial's eventual "gone" is still marked to clear quietly). Conversely, if
 * a call belonging to such an already-withdrawn (or never wanted) dial
 * shows up anyway once the config has no <call> node, it is hung up
 * immediately by index rather than left untracked or later shown
 * 'rejected'. The 'rejected' display sticks until the config withdraws
 * the call node (matching the ordinary hangup path) or presents a
 * different number, which replaces it and dials afresh.
 *
 * 'disconnected()' resets everything except the SMS history (a config
 * <send> id, once ever issued to 'send_sms', is remembered together with
 * its outcome -- sent/failed + reason, or still pending -- in a
 * 64-entry ring that outlives a reconnect, so re-adding an evicted-from-
 * the-report-but-still-remembered id neither resends it nor shows a fake
 * "pending"; only a genuine process restart (a fresh 'Logic') or falling
 * out of that 64-entry ring forgets an id -- in either case a still-
 * config-listed id would be sent again, so the consumer is expected to
 * remove an id from its config once it has seen the matching <sent>) and
 * a *failed* pin (kept so a rild restart does not blindly resupply it);
 * an *accepted* pin is not remembered -- if the SIM later asks for it
 * again (e.g. after a restart) it is supplied again.
 * Every PENDING entry in that outcome memory -- not only the ones still
 * listed in the current config's report -- is marked 'failed' ("rild
 * restarted") on disconnect, since none of them will ever get a real
 * response from the dead session.
 *
 * The component is expected to log whenever 'state().undecodable' rises
 * (an incoming SMS PDU without decodable text: 8-bit data, compressed or
 * malformed) -- 'Logic' itself has no logging hook, only the counter.
 *
 * Received SMS ('on_new_sms'). Every SMS-DELIVER is acknowledged to the
 * network at once, whatever becomes of it. sms_pdu decodes it to UTF-8
 * (GSM 7-bit alphabet, UCS-2, alphanumeric senders); the text of a
 * <received> entry holds up to MAX_SMS_TEXT bytes and is cut at a
 * character boundary beyond that.
 *
 * The parts of a concatenated message are collected per (sender,
 * reference, total) and become one entry, joined in sequence order, when
 * the last one arrives; the entry gets its id then and carries the time
 * stamp of part 1. At most CONCAT_SETS messages are pending at a time,
 * each with at most CONCAT_PARTS parts (of a longer message the first
 * CONCAT_PARTS are joined, the others are acknowledged and dropped). A set
 * still incomplete CONCAT_TIMEOUT_MS after its first part, the oldest set
 * when one more than CONCAT_SETS is started, and a set that receives a
 * different part for a sequence number it already has (the sender reused
 * the reference) is shown as far as it got: the parts in order, "[...]"
 * for each run of missing ones, the time stamp of the lowest part there
 * is. The time-out is checked by 'tick', 'expire_sms' and on every
 * received message; pending sets survive a reconnect.
 *
 * Redeliveries (the network repeats a DELIVER whose acknowledgement was
 * late) are not shown again and are counted in 'state().duplicates': a
 * message equal in sender, TP-SCTS and text to one of the last
 * SMS_HISTORY accepted messages, and a part equal in sender, reference,
 * total, sequence number, TP-SCTS and text to one of the last
 * SMS_PART_HISTORY accepted parts. Both histories are independent of the
 * received list (which is trimmed by the consumer's 'acknowledged') and
 * survive a reconnect, but not a restart of the component.
 *
 * The ids of the received list start at 1 with every start of the
 * component; 'epoch' names this id space (rild_modem/epoch.h). The
 * config's 'sms_acknowledged' is applied -- entries up to it are trimmed,
 * the next id lies above it -- only if the config names no epoch (a
 * consumer that knows none) or this one. A counter that belongs to another
 * epoch, kept by the consumer across a restart of this component, says
 * nothing about the messages here and counts as 0: nothing is trimmed and
 * the ids are not raised, so a message that arrived before the consumer
 * caught up is still delivered.
 *
 * Mobile data (one context, 'Config::Data'). The data call is set up when
 * the config has an active context with an APN and the data domain is
 * registered (REG_HOME, or REG_ROAMING if the context says roaming="yes");
 * the access network of the request follows the data registration's RAT.
 * It is deactivated when the context is removed, gets active="no" or
 * another APN (the new APN is set up once the deactivation is answered),
 * and when the data domain is registered roaming while the context does
 * not say roaming="yes" (the registration changed, or the config did): the
 * context is then shown inactive with the cause "roaming" until one of
 * the two changes. Losing the registration does not deactivate: the modem
 * reports the fate of the call itself ('on_data_call_list').
 *
 * Retry rule. A setup that fails (radio error, a DataCallFailCause, a
 * result that is not active, no answer within DATA_SETUP_TIMEOUT_MS) and a
 * call that the modem drops are retried after a back-off: 5 s, doubled
 * with every further failure up to 5 min. A longer retry time suggested by
 * the network is used instead (at most 1 h); a shorter one, also "retry
 * now", never shortens the back-off; "never retry" (the maximum value) is
 * honoured. The back-off starts over when the config's context changes,
 * when rild reconnects, and when a call was lost after it had been up for
 * DATA_STABLE_MS. Nothing else resets it -- in particular not a
 * registration change or a radio off/on --, so no sequence of modem events
 * can make the requests follow each other faster than the back-off.
 *
 * A deactivation without answer is repeated once after 10 s and then given
 * up (the context is shown inactive). An answer with an error asks for the
 * list of data calls: if the call is not listed it counts as deactivated.
 * A setup result that arrives when none is awaited (after the time-out) is
 * adopted if it is an active call, and deactivated at once if the config
 * does not want it. Data calls that exist in rild when this component
 * connects are not adopted.
 */

/*
 * SPDX-License-Identifier: MIT
 */

#ifndef _INCLUDE__RILD_MODEM__LOGIC_H_
#define _INCLUDE__RILD_MODEM__LOGIC_H_

#include <stdint.h>
#include <util/interface.h>
#include <rild_modem/model.h>

namespace Rild_modem {

	/**
	 * Requests issued by the 'Logic', implemented by the component over the
	 * generated IRadio request encoders (radio_aidl headers)
	 */
	struct Radio : Genode::Interface
	{
		virtual void enable_modem(bool) = 0;
		virtual void set_radio_power(bool) = 0;
		virtual void get_icc_card_status() = 0;
		virtual void supply_pin(char const *pin, char const *aid) = 0;
		virtual void set_preferred_data_modem() = 0;
		virtual void set_allowed_network_types(int32_t bitmap) = 0;
		virtual void set_initial_attach_apn(char const *apn) = 0;
		virtual void query_registration() = 0;       /* voice + data reg state + operator + signal */
		virtual void get_baseband_version() = 0;
		virtual void send_sms(char const *smsc_pdu_hex, char const *pdu_hex, unsigned id) = 0;
		virtual void ack_sms(bool ok) = 0;
		virtual void dial(char const *number) = 0;
		virtual void get_current_calls() = 0;
		virtual void accept_call() = 0;
		virtual void hangup(int32_t index) = 0;
		virtual void reject_call() = 0;
		/* after a call vanished: the modem's release cause, logged by the
		 * component (the Android framework asks the same after each call) */
		virtual void get_last_call_fail_cause() = 0;
		/* microphone mute of the call (IRadioVoice.setMute) */
		virtual void set_mute(bool on) = 0;

		/* data call for 'apn'; 'access_network' is the
		 * Radio_aidl::radio::AccessNetwork value */
		virtual void setup_data_call(char const *apn, int access_network,
		                             bool roaming_allowed) = 0;
		virtual void deactivate_data_call(int32_t cid) = 0;
		virtual void get_data_call_list() = 0;

		/**
		 * Not a request: 'Logic' gave up waiting for the response to
		 * 'request' (its timeout expired after the one retry, or without
		 * one for the non-idempotent requests). Called once per give-up,
		 * for the component to log.
		 */
		virtual void gave_up(char const *request) = 0;
	};

	class Logic;
}


class Rild_modem::Logic
{
	public:

		/* which registration domain an 'on_registration' call reports
		 * (Radio_aidl::network::RegStateResult from IRadioNetwork's
		 * getVoiceRegistrationState / getDataRegistrationState) */
		enum class Reg_domain { VOICE, DATA };

		/* one entry of a getCurrentCalls response (Radio_aidl::voice::Call,
		 * reduced to the fields the mapping needs); 'state' is the RIL
		 * Call::STATE_* value */
		struct Call_info
		{
			int32_t index;
			int     state;
			bool    is_mt;        /* Call.isMT: mobile terminated (incoming) */
			char    number[32];
		};

		/* a SetupDataCallResult, reduced (Radio_aidl::data::
		 * SetupDataCallResult); the lists are comma-separated */
		struct Data_call_info
		{
			int32_t   cid          = -1;
			bool      active       = false;   /* 'active' != INACTIVE */
			bool      cause_none   = true;    /* cause == DataCallFailCause::NONE */
			char      cause[48]    { };       /* name of the cause if not NONE */
			long long retry_ms     = -1;      /* suggestedRetryTime */
			char      type[16]     { };
			char      ifname[16]   { };
			char      address[128] { };
			char      dns[128]     { };
			char      gateway[128] { };
			int       mtu          = 0;
		};

		enum {
			DATA_SETUP_TIMEOUT_MS = 60*1000,     /* the modem answered after 2-3 s */
			DATA_BACKOFF_MIN_MS   = 5*1000,
			DATA_BACKOFF_MAX_MS   = 5*60*1000,
			DATA_SUGGESTED_MAX_MS = 60*60*1000,  /* cap of a network-suggested time */
			DATA_STABLE_MS        = 60*1000,     /* a call up that long ends the back-off */
		};

	private:

		enum { REQUEST_TIMEOUT_MS = 10000 };

		/* DIAL: tracked like the other requests only for its timeout (give
		 * up waiting for getCurrentCalls to confirm it; never retried) */
		enum class Req { POWER, CARD_STATUS, PIN, REGISTRATION, BASEBAND, DIAL, COUNT };

		struct Pending
		{
			bool          active  = false;
			bool          retried = false;
			bool          again   = false;   /* asked for once more while in flight */
			unsigned long sent_at = 0;
		};

		/* last 'on_radio_state()' value; UNKNOWN right after connect (or
		 * before the first ever indication) */
		enum class Reported_power { UNKNOWN, ON, OFF };

		/* one registration domain's last reported fields (RegStateResult) */
		struct Reg
		{
			bool valid        = false;
			int  reg_state    = 0;
			int  rat          = 0;
			int  reject_cause = 0;
			char plmn[8]      { };
		};

		/* one in-flight sendSms, tracked only for its own timeout */
		struct Send_pending
		{
			unsigned      id      = 0;
			unsigned long sent_at = 0;
			bool          active  = false;
		};

		/* dedup + outcome memory: every id ever handed to 'send_sms',
		 * with its result, kept well beyond the 8-slot report so a config
		 * replay/restart never resends one and re-showing an id that
		 * dropped out of the report (and back in) shows its real outcome
		 * instead of a fake "pending" (a ring: the oldest of more than
		 * SENT_MEMORY distinct lifetime ids could in principle be
		 * forgotten, deemed acceptable -- real configs keep at most
		 * MAX_SENDS ids live at a time) */
		struct Sent_memory
		{
			unsigned           id    = 0;
			State::Sent::State state = State::Sent::State::PENDING;
			char               reason[32] { };
			bool               used  = false;
		};

		enum { SENT_MEMORY = 64 };

		enum {
			CONCAT_SETS       = 8,             /* concatenated messages pending at a time */
			CONCAT_PARTS      = 16,            /* parts kept per message */
			CONCAT_PART_TEXT  = 320,           /* Modem::Sms::MAX_PART_TEXT */
			CONCAT_TIMEOUT_MS = 5*60*1000,     /* from the first part */
			SMS_HISTORY       = 32,            /* accepted messages remembered */
			SMS_PART_HISTORY  = 64,            /* accepted parts remembered */
		};

		/* identity of an accepted message, or of one part (total != 0) */
		struct Sms_seen
		{
			bool     used        = false;
			char     sender[32]  { };
			uint8_t  scts[7]     { };
			uint32_t text_hash   = 0;
			uint16_t text_length = 0;
			uint16_t ref         = 0;
			bool     ref16       = false;
			uint8_t  total       = 0;
			uint8_t  seq         = 0;
		};

		/* a concatenated message with parts still missing */
		struct Concat_set
		{
			bool          used       = false;
			char          sender[32] { };
			uint16_t      ref        = 0;
			bool          ref16      = false;
			uint8_t       total      = 0;
			unsigned long first_at   = 0;     /* arrival of the first part */

			/* time stamp of the lowest part received so far */
			uint8_t       time_seq   = 0;
			char          time[32]   { };
			uint8_t       scts[7]    { };

			bool          present[CONCAT_PARTS] { };
			char          text[CONCAT_PARTS][CONCAT_PART_TEXT + 1] { };
		};

		Radio         &_radio;
		unsigned long (*_now_ms)();

		State  _state  { };
		Config _config { };

		bool _connected = false;

		/* rild reported UNAVAILABLE (CP booting or crashed): the one-shot
		 * modem setup is re-sent once the radio is OFF/ON again */
		bool _radio_unavailable = false;
		bool _dirty_flag = true;   /* state() differs from what the caller last saw */

		Pending _pending[unsigned(Req::COUNT)] { };
		bool           _power_target_on = false;
		Reported_power _reported_power  = Reported_power::UNKNOWN;

		Reg _voice_reg { };
		Reg _data_reg  { };

		/* a getOperator result that arrived before any registration result
		 * since 'connected()' (it may overtake the registration responses
		 * of the same query): applied by the first registered result,
		 * dropped by the first not-registered one; never kept once a
		 * registration is known, so a stale response cannot resurface */
		bool _reg_known       = false;
		char _oper_name[32]   { };
		char _oper_numeric[8] { };

		char _pin_inflight[16] { };   /* pin string awaiting a supplyIccPinForApp result */
		char _pin_failed[16]   { };   /* pin string whose supply failed, not supplied again; "" = none */
		bool _pin_no_verdict = false; /* '_pin_failed' was not refused: an error or no answer */

		char    _dial_sent[32]     { };   /* number a dial()/hangup outcome is remembered for */
		bool    _dial_pending      = false;
		bool    _dial_confirmed    = false;   /* on_dial_result(true) seen for this dial */
		bool    _accept_sent       = false;
		bool    _hangup_sent       = false;
		bool    _call_owned        = false;   /* established by the config (dial/accept) */
		bool    _call_retry        = false;   /* re-apply the call config at the next on_calls */
		bool    _call_retry_used   = false;   /* the one automatic retry of this call is spent */
		int32_t _call_index        = -1;

		unsigned _next_received_id = 0;

		Concat_set _concat[CONCAT_SETS] { };

		Sms_seen _sms_history[SMS_HISTORY] { };
		unsigned _sms_history_next = 0;        /* ring write cursors */
		Sms_seen _sms_part_history[SMS_PART_HISTORY] { };
		unsigned _sms_part_history_next = 0;

		Sent_memory  _sent_memory[SENT_MEMORY] { };
		unsigned     _sent_memory_next = 0;   /* ring write cursor for a new id */
		Send_pending _send_pending[MAX_SENT] { };

		/*
		 * Data context: IDLE (no call, none requested), SETUP_SENT,
		 * ACTIVE, DEACT_SENT, BACKOFF (waiting to retry after a failure
		 * or a loss), see the class doc
		 */
		enum class Data_phase { IDLE, SETUP_SENT, ACTIVE, DEACT_SENT, BACKOFF };

		Data_phase    _data_phase         = Data_phase::IDLE;
		int32_t       _data_cid           = -1;
		char          _data_apn[64]       { };     /* APN of the call (being) set up */
		unsigned long _data_sent_at       = 0;     /* SETUP_SENT, DEACT_SENT */
		bool          _data_deact_retried = false;
		unsigned long _data_active_since  = 0;     /* ACTIVE */
		unsigned long _data_failed_at     = 0;     /* BACKOFF */
		unsigned long _data_delay_ms      = 0;     /* BACKOFF: wait from '_data_failed_at' */
		bool          _data_no_retry      = false; /* BACKOFF: the network forbids a retry */
		unsigned long _data_backoff_ms    = DATA_BACKOFF_MIN_MS;   /* next failure's delay */

		bool _data_wanted() const;
		bool _data_registered() const;
		bool _data_roaming_denied() const;
		void _data_setup();
		void _data_deactivate();
		void _data_show_idle();
		void _data_show_call(Data_call_info const &);
		void _data_backoff(char const *cause, long long suggested_ms, bool failed);
		void _data_radio_gone();
		void _registration_gone();
		void _reconcile_data();

		Logic(Logic const &) = delete;
		Logic &operator = (Logic const &) = delete;

		void _dirty() { _dirty_flag = true; }

		void _start(Req, unsigned long now);
		void _clear(Req);
		void _answered(Req);
		void _retry(Req);
		void _give_up(Req);

		void _reconcile_power();
		void _setup_modem();
		void _update_power_display();

		void _maybe_supply_pin();
		void _update_network();
		void _apply_call(Config::Call const &);
		void _issue_hangup();
		void _dial_gone();
		void _dial_dropped();
		bool _call_listed() const;
		void _call_failed_request();
		void _reset_call_retry() { _call_retry = false; _call_retry_used = false; }
		Call_info const *_select_call(Call_info const *, unsigned, bool &ours) const;
		void _apply_sends(Config const &);
		void _trim_received(unsigned acknowledged);
		unsigned _acknowledged(Config const &) const;

		char _epoch[32] { };   /* this id space, "" until 'epoch' is called */

		void _sms_accept(char const *sender, char const *time,
		                 uint8_t const *scts, char const *text);
		void _sms_part(char const *sender, char const *time, uint8_t const *scts,
		               char const *text, uint16_t ref, bool ref16,
		               uint8_t total, uint8_t seq);
		void _sms_flush(Concat_set &);
		Concat_set *_concat_oldest();

		Sent_memory *_sent_find(unsigned id);
		Sent_memory &_sent_alloc(unsigned id);
		bool _start_send_pending(unsigned id);

	public:

		Logic(Radio &radio, unsigned long (*now_ms)());

		/* all IRadio* sessions open and setResponseFunctions done: bring-up,
		 * then replays whatever 'apply()' already recorded (a config seen
		 * before this connect, or left over from before a rild restart) */
		void connected();

		/* rild gone: reset to unavailable; in-flight PENDING sends become
		 * 'failed' (reason "rild restarted", never re-sent); a dial that
		 * was never confirmed by 'on_calls' is dropped (a reconnect may
		 * retry it); SMS history and a failed pin are kept */
		void disconnected();

		/* config ROM changed; while not connected, only local bookkeeping
		 * runs (no Radio call is issued) -- 'connected()' replays it */
		void apply(Config const &);

		/* name of this start's id space of received SMS, set once before
		 * the first 'apply' (longer names are cut, which only matters to
		 * a config that repeats the long name: it is then taken as stale) */
		void epoch(char const *);

		/*
		 * Callbacks, called by the component from the generated response /
		 * indication dispatchers
		 */
		void on_radio_state(bool on);
		void on_radio_unavailable();
		void on_card_status(int card_state, int pin_state);

		/* getIccCardStatus / get{Voice,Data}RegistrationState answered with
		 * an error: the request is no longer in flight, the state stays */
		void on_card_status_error();
		void on_registration_error();

		/* supplyIccPinForApp result: 'radio_error' is the raw
		 * RadioResponseInfo.error (Radio_aidl::radio::RadioError, 0 =
		 * NONE). PASSWORD_INCORRECT is a refusal (remaining 0: PUK
		 * needed), any other error shows the pin state 'error'. Either
		 * way the pin is not supplied again (see the class doc) */
		void on_pin_result(int radio_error, int remaining);
		void on_pin_result(bool, int) = delete;   /* catch pre-M1 callers */
		void on_registration(Reg_domain domain, int reg_state, int rat,
		                      int reject_cause, char const *registered_plmn);
		void on_operator(char const *long_name, char const *numeric);

		/*
		 * Raw IRadio 'SignalStrength' fields of all technologies; the
		 * technology of the current registration decides which one gives
		 * 'strength' (LTE/NR/none: LTE). Encoding for all of them:
		 * strength = (dBm + 140) * 100 / 96, clamped to 0..100.
		 *
		 * lte_rsrp:   'LteSignalStrength.rsrp', magnitude, dBm = -rsrp,
		 *             valid 44..140
		 * wcdma_rscp: 'WcdmaSignalStrength.rscp', dBm = rscp - 120,
		 *             valid 0..96 (255: unknown)
		 * gsm_asu:    'GsmSignalStrength.signalStrength', dBm = 2*asu - 113,
		 *             valid 0..31 (99: unknown)
		 *
		 * Anything else (incl. the INT_MAX "not reported" sentinel) is
		 * invalid -> strength absent.
		 */
		struct Signal { int lte_rsrp; int wcdma_rscp; int gsm_asu; };

		void on_signal(Signal const &signal);

		/* LTE only (other technologies not reported) */
		void on_signal(int lte_rsrp) { on_signal(Signal { lte_rsrp, -1, -1 }); }

	private:

		Signal _signal { -1, -1, -1 };   /* last raw values */

		void _update_strength();

	public:

		void on_baseband(char const *version);
		void on_sms_sent(unsigned id, bool ok, int error);

		/* 'pdu' is the raw newSms byte[] (SMSC-prefixed). See the class doc
		 * for concatenated messages and redeliveries. */
		void on_new_sms(uint8_t const *pdu, unsigned len);

		void on_calls(Call_info const *calls, unsigned count);

		/* IRadioVoiceResponse.dialResponse: 'ok' iff its RadioResponseInfo
		 * carried no error. 'true' just remembers that this dial was
		 * accepted (so a later empty getCurrentCalls means it genuinely
		 * failed, see the class doc); 'false' marks it 'rejected' -- but
		 * only while a dial is actually still pending/unconfirmed, so a
		 * stray or late error for a dial 'on_calls' already resolved (in
		 * either direction) does not clobber the current call display, and
		 * one while 'on_calls' lists another call only drops the dial */
		void on_dial_result(bool ok);

		/* acceptCall / hangupConnection or rejectCall responses: 'ok' iff
		 * no error. An error clears the "already sent" guard and, once per
		 * call, arms a retry that runs from the next 'on_calls' -- the call
		 * re-poll the component issues after every such response -- while
		 * the call is still listed (a consumer like phone_manager rewrites
		 * an identical config, which is no config change). A second error
		 * for the same call is not retried automatically; a changed config
		 * still can. */
		void on_accept_result(bool ok);
		void on_hangup_result(bool ok);

		/* setupDataCallResponse: 'radio_ok' iff RadioResponseInfo.error is
		 * NONE; otherwise 'call.cause' names the radio error */
		void on_data_call_setup(bool radio_ok, Data_call_info const &call);

		/* deactivateDataCallResponse */
		void on_data_call_deactivated(bool ok);

		/* dataCallListChanged or a getDataCallListResponse without error;
		 * 'complete' is false if the list has more calls than 'calls'
		 * holds: a call missing from it is then not taken as gone */
		void on_data_call_list(Data_call_info const *calls, unsigned count,
		                       bool complete);

		/* an indication arrived that makes the sim/network state stale
		 * (simStatusChanged, networkStateChanged): re-query both, a query
		 * in flight is repeated once it is answered */
		void on_network_changed();

		/* called once a second: timeouts, seconds counters */
		void tick();

		/* show concatenated messages whose parts did not all arrive in
		 * time; part of 'tick', to be called instead of it while not
		 * connected (the component does not tick then) */
		void expire_sms();

		State const &state() const { return _state; }

		/* true if 'state()' differs from what the caller observed at the
		 * last call to 'state_changed()' */
		bool state_changed();
};

#endif /* _INCLUDE__RILD_MODEM__LOGIC_H_ */
