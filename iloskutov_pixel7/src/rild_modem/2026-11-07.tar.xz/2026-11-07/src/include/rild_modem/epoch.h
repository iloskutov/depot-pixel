/*
 * \brief  rild_modem: epoch of the received-SMS id space
 * \author Ivan Loskutov
 * \date   2026-10-01
 *
 * The ids of received SMS start at 1 after every start of the component.
 * A consumer that keeps its acknowledge counter across restarts (a
 * persistent store) needs to know when the id space started over: the
 * state report carries an 'epoch' string that differs after every start
 * and stays the same while the component runs. The string is opaque,
 * consumers compare it for equality only.
 *
 * With a plausible real-time clock value the epoch is the start time
 * followed by a few bits that tell two starts within one second apart
 * ("20261001T093000-5f1c2a90"). Without one (no Rtc session, or a clock
 * that was never set) it is derived from two free-running counters, the
 * time since boot in microseconds and the CPU's cycle counter
 * ("t-3b9f2c5d7e1a0486"): no two starts read the same pair in practice,
 * but nothing guarantees it.
 *
 * Freestanding.
 */

/*
 * SPDX-License-Identifier: MIT
 */

#ifndef _INCLUDE__RILD_MODEM__EPOCH_H_
#define _INCLUDE__RILD_MODEM__EPOCH_H_

#include <stdint.h>

namespace Rild_modem { namespace Epoch {

	/* longest result with its terminating zero ("YYYYMMDDThhmmss-xxxxxxxx") */
	enum { MAX_LEN = 25 };

	struct Rtc_time
	{
		unsigned year, month, day, hour, minute, second;
	};

	/*
	 * A clock that lost its time restarts at its reset value (1970, 2000,
	 * the year of manufacture): every start would then read nearly the
	 * same time. Accepted is a valid date from 2024 on.
	 */
	inline bool plausible(Rtc_time const &t)
	{
		return t.year >= 2024 && t.year <= 2099
		    && t.month >= 1 && t.month <= 12
		    && t.day   >= 1 && t.day   <= 31
		    && t.hour <= 23 && t.minute <= 59 && t.second <= 59;
	}

	/* bijective 64-bit mixer (splitmix64 finaliser) */
	inline uint64_t mix(uint64_t x)
	{
		x ^= x >> 30; x *= 0xbf58476d1ce4e5b9ull;
		x ^= x >> 27; x *= 0x94d049bb133111ebull;
		x ^= x >> 31;
		return x;
	}

	inline void put_hex(char *&out, uint64_t v, unsigned digits)
	{
		for (unsigned i = digits; i-- > 0; )
			*out++ = "0123456789abcdef"[(v >> (4*i)) & 0xf];
	}

	inline void put_dec(char *&out, unsigned v, unsigned digits)
	{
		unsigned div = 1;
		for (unsigned i = 1; i < digits; i++) div *= 10;
		for (; div; div /= 10) *out++ = char('0' + (v / div) % 10);
	}

	/**
	 * Format the epoch of this start
	 *
	 * \param out       at least MAX_LEN bytes
	 * \param rtc       real-time clock value at start, nullptr if there is
	 *                  none
	 * \param timer_us  time since boot in microseconds
	 * \param cycles    CPU cycle counter (0 if the CPU has none)
	 * \return          false if 'cap' is too small ('out' is then empty)
	 */
	inline bool format(char *out, unsigned cap, Rtc_time const *rtc,
	                   uint64_t timer_us, uint64_t cycles)
	{
		if (cap) out[0] = 0;
		if (cap < MAX_LEN) return false;

		/* the two counters into one value, either one changing changes it */
		uint64_t const counters = mix(mix(timer_us) ^ (cycles + 0x9e3779b97f4a7c15ull));

		char *p = out;
		if (rtc && plausible(*rtc)) {
			put_dec(p, rtc->year,  4); put_dec(p, rtc->month,  2); put_dec(p, rtc->day,    2);
			*p++ = 'T';
			put_dec(p, rtc->hour,  2); put_dec(p, rtc->minute, 2); put_dec(p, rtc->second, 2);
			*p++ = '-';
			put_hex(p, counters, 8);
		} else {
			*p++ = 't';
			*p++ = '-';
			put_hex(p, counters, 16);
		}
		*p = 0;
		return true;
	}
} }

#endif /* _INCLUDE__RILD_MODEM__EPOCH_H_ */
