/*
 * \brief  GSM 03.40 SMS-SUBMIT PDU encoding, SMS-DELIVER decoding
 * \author Ivan Loskutov
 * \date   2026-09-05
 *
 * Freestanding (no Genode dependencies).
 *
 * Send side: encodes a single-part SMS-SUBMIT TPDU with the GSM 03.38
 * default alphabet, 7-bit packed, from ASCII text. Long messages are
 * truncated to one part (160 septets).
 *
 * Receive side (3GPP TS 23.040 / 23.038): decodes one SMS-DELIVER TPDU to
 * UTF-8 -- the GSM 7-bit default alphabet with its extension table, UCS-2
 * (UTF-16BE), the TP-DCS coding groups, the user data header (skipped; the
 * concatenation elements are returned) and numeric as well as alphanumeric
 * originating addresses. Joining the parts of a concatenated message is
 * the caller's job. Not handled: compressed text and 8-bit data (both
 * yield valid=false), national language shift tables (IEI 0x24/0x25; such
 * text is decoded with the default tables).
 */

/*
 * SPDX-License-Identifier: MIT
 */

#ifndef _INCLUDE__SMS_PDU__SMS_PDU_H_
#define _INCLUDE__SMS_PDU__SMS_PDU_H_

#include <stdint.h>
#include <stddef.h>

namespace Modem { namespace Sms {

	enum : unsigned {
		MAX_SEPTETS   = 160,   /* single-part GSM7 message */
		MAX_TPDU      = 176,   /* header + 140 octets of user data */
		ESCAPE_SEPTET = 0x1B,
		MAX_UD        = 140,   /* octets of TP-UD */

		/* UTF-8 bytes one TPDU can decode to: 160 septets of two bytes
		 * each (the Greek capitals); 70 UCS-2 characters need at most 210 */
		MAX_PART_TEXT = 320,
	};

	/*
	 * Map ASCII text to GSM 03.38 default-alphabet septets.
	 *
	 * Characters outside the alphabet become '?'. The extension table is used
	 * for [ \ ] ^ { | } ~ , each of which costs TWO septets. Returns the
	 * number of septets written, capped at cap; sets truncated when the input
	 * did not fit.
	 */
	unsigned to_septets(char const *text, uint8_t *out, unsigned cap,
	                    bool *truncated = nullptr);

	/*
	 * Pack n septets into 7-bit octets. Returns the number of octets, which is
	 * (n * 7 + 7) / 8. out must hold at least that many bytes.
	 */
	unsigned pack7(uint8_t const *septets, unsigned n, uint8_t *out);

	/*
	 * Encode a phone number as a TP-DA / TP-OA address field:
	 * [digit count][TON/NPI][swapped BCD digits, high nibble 0xF padded].
	 * A leading '+' selects international (0x91), otherwise unknown (0x81).
	 * Returns bytes written, or 0 on a malformed or oversized number.
	 */
	unsigned encode_address(char const *number, uint8_t *out, unsigned cap);

	/*
	 * Build a complete SMS-SUBMIT TPDU.
	 *
	 * flags: TP-MTI=01 plus relative validity period, so the first octet is
	 * 0x11 and a TP-VP octet (0xAA, 4 days) is emitted. Set status_report to
	 * also request a delivery report (TP-SRR).
	 *
	 * Returns the TPDU length, or 0 if the number is invalid or cap is too
	 * small. Sets truncated when the text did not fit in one part.
	 */
	unsigned encode_submit(char const *number, char const *text,
	                       uint8_t message_ref, bool status_report,
	                       uint8_t *out, unsigned cap,
	                       bool *truncated = nullptr);

	/*
	 * Encode a service-centre number in the form SEND_SMS expects:
	 * [length of what follows][TON/NPI][semi-octet BCD digits], e.g.
	 * +41791234567 becomes 07 91 14 97 21 43 65 F7. Note the leading byte
	 * counts BYTES, unlike a TP-DA which counts digits.
	 *
	 * Returns bytes written, or 0 if the number is malformed.
	 */
	unsigned encode_smsc(char const *number, uint8_t *out, unsigned cap);

	/*
	 * GSM 03.38 septets to UTF-8: the default alphabet and, after the escape
	 * septet 0x1B, its extension table (form feed ^ { } \ [ ~ ] | and the
	 * euro sign). An escaped septet without an extension-table entry shows
	 * the default-alphabet character, escape-escape a space (23.038 6.2.1.1);
	 * a trailing escape shows nothing. LF, CR and form feed are returned as
	 * the control characters they are. The output is cut at a character
	 * boundary if it does not fit and is always NUL-terminated. Returns the
	 * length in bytes.
	 *
	 * For text produced by to_septets (ASCII) the result is that text again.
	 */
	unsigned from_septets(uint8_t const *septets, unsigned n,
	                      char *out, unsigned cap);

	/*
	 * UCS-2 as SMS carries it (in practice UTF-16BE, surrogate pairs
	 * included) to UTF-8. An unpaired surrogate and U+0000 become U+FFFD, a
	 * trailing odd octet is ignored. Cut at a character boundary, always
	 * NUL-terminated. Returns the length in bytes.
	 */
	unsigned from_ucs2(uint8_t const *in, unsigned octets,
	                   char *out, unsigned cap);

	/* Reverse of pack7. Returns the number of septets produced (capped). */
	unsigned unpack7(uint8_t const *packed, unsigned octets, unsigned septets,
	                 uint8_t *out, unsigned cap);

	/*
	 * Decode a TP-DA / TP-OA address (23.040 9.1.2.5). Returns the number of
	 * bytes consumed, or 0 if malformed (no digits, more than 20 semi-octets,
	 * or longer than len).
	 *
	 * Numbers become "+<digits>" (international) or "<digits>"; the
	 * semi-octets 0xA..0xE are * # a b c, 0xF is the fill and ends the
	 * number. An alphanumeric address (type-of-number 5, e.g. 0xD0; the
	 * length counts the used semi-octets of the 7-bit packed name) becomes
	 * its text in UTF-8, e.g. "Swisscom".
	 */
	unsigned decode_address(uint8_t const *in, unsigned len,
	                        char *out, unsigned cap);

	/* how the user data of a TP-DCS value is coded (23.038 section 4) */
	enum class Alphabet { GSM7, DATA8, UCS2, COMPRESSED };

	/*
	 * 00xx/01xx general data coding: bit 5 compressed, bits 3..2 the
	 * alphabet (the reserved value 3 counts as GSM 7-bit); 1100/1101
	 * message waiting: GSM 7-bit; 1110 message waiting: UCS-2; 1111 data
	 * coding / message class: bit 2 selects 8-bit data; the reserved groups
	 * 1000..1011 are taken as GSM 7-bit, as 23.038 demands.
	 */
	Alphabet dcs_alphabet(uint8_t dcs);

	struct Deliver
	{
		char sender[32];
		char text[MAX_PART_TEXT + 1];   /* UTF-8 */
		bool valid;

		uint8_t scts[7];                /* the raw TP-SCTS */

		/*
		 * Concatenation element of the user data header (IEI 0x00 with an
		 * 8-bit reference, IEI 0x08 with a 16-bit one, which wins if both
		 * are present). concat is false for a message without one or with
		 * an unusable one (total 0, sequence 0 or above total), which
		 * 23.040 9.2.3.24.1 tells the receiver to ignore.
		 */
		bool     concat;
		bool     concat_ref16;          /* reference came from IEI 0x08 */
		uint16_t concat_ref;
		uint8_t  concat_total;
		uint8_t  concat_seq;            /* 1..concat_total */
	};

	/*
	 * Decode an SMS-DELIVER TPDU (what the network sends us).
	 *
	 * valid=false for anything that is no well-formed SMS-DELIVER with text:
	 * a truncated PDU, a TP-UDL beyond 140 octets or beyond the PDU, a user
	 * data header that does not fit the user data (TP-UDHI set), 8-bit data
	 * or compressed text. Fields are only meaningful if valid.
	 *
	 * skip_smsc tolerates a leading SMSC field, as PDU-mode strings carry.
	 */
	Deliver decode_deliver(uint8_t const *pdu, unsigned len, bool skip_smsc);
} }

#endif /* _INCLUDE__SMS_PDU__SMS_PDU_H_ */
