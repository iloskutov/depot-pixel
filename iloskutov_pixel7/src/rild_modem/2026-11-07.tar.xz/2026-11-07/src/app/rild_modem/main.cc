/*
 * \brief  rild_modem: Genode's modem interface served by the vendor rild
 * \author Ivan Loskutov
 * \date   2026-09-27
 *
 * Reads the 'config' ROM, reports 'modem'/'state' (the PinePhone driver's
 * interface, extended as the README describes) and talks IRadio (AIDL
 * V1) to the unmodified vendor rild over one 'Android_binder' session per
 * instance. The decisions live in lib/rild_modem ('Logic'); this component
 * carries them out: the 'Radio' requests over the generated encoders
 * (include/radio_aidl), the responses/indications from the generated
 * dispatchers back into 'Logic', the config ROM into 'Config', 'State'
 * into the report. Config, settings, and state: README.
 */

/*
 * SPDX-License-Identifier: MIT
 */

#include <base/attached_dataspace.h>
#include <base/attached_rom_dataspace.h>
#include <libc/component.h>
#include <os/reporter.h>
#include <rom_session/client.h>
#include <rtc_session/client.h>
#include <timer_session/connection.h>
#include <trace/timestamp.h>
#include <util/reconstructible.h>
#include <util/string.h>

#include <android_binder/client.h>
#include <android_prop/watcher.h>
#include <android_property_session/android_property_session.h>
#include <radio_aidl/config.h>
#include <radio_aidl/data.h>
#include <radio_aidl/messaging.h>
#include <radio_aidl/modem.h>
#include <radio_aidl/network.h>
#include <radio_aidl/sim.h>
#include <radio_aidl/voice.h>
#include <rild_modem/epoch.h>
#include <rild_modem/logic.h>
#include <rild_modem/sanitize.h>
#include <rild_modem/scts.h>
#include <try_connection.h>

#include <string.h>

namespace Rild_modem {

	using namespace Genode;

	using Conn = Android_binder::Client_conn;

	enum { AIDL_VERSION = 1 };   /* vendored android.hardware.radio.* V1 */

	struct Dispatch_cb;
	struct Instance;
	struct Main;

	/**
	 * \return false if the config cannot be applied as a whole: an over-long
	 *         call number would otherwise read as "no call", hanging up
	 */
	bool parse_config(Node const &, Config &);
	void generate_state(Generator &, State const &, char const *epoch);

	static inline char const *data_state_name(State::Data::State state)
	{
		using S = State::Data::State;
		switch (state) {
		case S::NONE:       break;
		case S::INACTIVE:   return "inactive";
		case S::CONNECTING: return "connecting";
		case S::ACTIVE:     return "active";
		case S::FAILED:     return "failed";
		}
		return "none";
	}
}


namespace {

	Timer::Connection *timer_ptr = nullptr;

	unsigned long now_ms() { return (unsigned long)timer_ptr->elapsed_ms(); }

	/*
	 * The first IPv4 item of a comma-separated list of the modem ("" if
	 * none): digits around three dots, optionally followed by '/' and a
	 * prefix length of one or two digits. With 'with_prefix' the item is
	 * returned with its prefix, '/32' if the modem gave none, otherwise
	 * without one.
	 */
	Genode::String<24> first_ipv4(char const *list, bool with_prefix)
	{
		for (char const *s = list; *s; ) {
			char const *end = s;
			while (*end && *end != ',') end++;
			Genode::size_t const n = size_t(end - s);

			bool     v4 = n > 0 && n < 19;
			unsigned dots = 0;
			Genode::size_t address_len = n;   /* without the prefix */
			for (char const *c = s; c < end && v4; c++) {
				bool const in_address = address_len == n;
				if      (*c >= '0' && *c <= '9') continue;
				else if (*c == '.' && in_address) dots++;
				else if (*c == '/' && in_address) address_len = size_t(c - s);
				else v4 = false;
			}
			Genode::size_t const prefix_len = n - address_len;   /* with the '/' */
			if (v4 && dots == 3 && address_len >= 7 && prefix_len != 1 && prefix_len <= 3) {
				Genode::String<24> const address { Genode::Cstring(s, address_len) };
				if (!with_prefix) return address;
				if (prefix_len)   return Genode::String<24>(Genode::Cstring(s, n));
				return Genode::String<24>(address, "/32");
			}
			s = *end ? end + 1 : end;
		}
		return { };
	}
}


/**
 * Callback object whose incoming transactions go to a generated dispatcher
 */
struct Rild_modem::Dispatch_cb : Android_binder::Callback
{
	using Fn = bool (*)(Main &, uint32_t, AParcel const &);

	Main       &main;
	Fn   const  fn;
	char const *iface;

	Dispatch_cb(Dispatch_cb const &) = delete;
	Dispatch_cb &operator = (Dispatch_cb const &) = delete;

	Dispatch_cb(Main &main, Fn fn, char const *iface)
	: main(main), fn(fn), iface(iface) { }

	void on_transact(uint32_t code, AParcel const &in) override
	{
		if (!fn(main, code, in))
			warning("rild_modem: ", iface, ": unknown transaction ", code);
	}
};


/**
 * One IRadio instance: session plus its response and indication objects
 */
struct Rild_modem::Instance
{
	using Set_response = bool (*)(Conn &, Android_binder::Callback &,
	                              Android_binder::Callback &);

	char const * const name;
	Set_response const set_response;

	Constructible<Conn> conn { };

	Dispatch_cb response, indication;

	bool denied_logged = false;

	Instance(Instance const &) = delete;
	Instance &operator = (Instance const &) = delete;

	Instance(char const *name, Set_response set_response, Main &main,
	         Dispatch_cb::Fn response_fn, char const *response_iface,
	         Dispatch_cb::Fn indication_fn, char const *indication_iface)
	:
		name(name), set_response(set_response),
		response(main, response_fn, response_iface),
		indication(main, indication_fn, indication_iface)
	{ }

	bool open() const { return conn.constructed() && conn->connected(); }
};


/*
 * Config ROM -> Config (malformed values are logged and ignored)
 */

namespace Rild_modem {

	using Attr = String<512>;

	/* number of characters of a Genode::String (length() counts the NUL) */
	template <size_t N>
	size_t chars(String<N> const &s) { return s.length() ? s.length() - 1 : 0; }

	/* copy an attribute, false (and 'dst' left untouched) if too long */
	bool read_text(Node const &node, char const *attr, char *dst, size_t cap,
	               char const *where)
	{
		Attr const v = node.attribute_value(attr, Attr());
		if (chars(v) >= cap) {
			warning("rild_modem: config: ", where, " ", attr, " too long (max ",
			        cap - 1, " characters), ignored");
			return false;
		}
		copy_cstring(dst, v.string(), cap);
		return true;
	}

	bool parse_unsigned(char const *s, unsigned &out)
	{
		if (!s[0]) return false;
		unsigned long v = 0;
		for (; *s; s++) {
			if (*s < '0' || *s > '9') return false;
			v = v*10 + unsigned(*s - '0');
			if (v > 0xffffffffUL) return false;
		}
		out = unsigned(v);
		return true;
	}

	bool read_unsigned(Node const &node, char const *attr, unsigned &out,
	                   char const *where)
	{
		Attr const v = node.attribute_value(attr, Attr());
		if (parse_unsigned(v.string(), out)) return true;
		warning("rild_modem: config: ", where, " ", attr, "=\"", v, "\" is no number, ignored");
		return false;
	}
}


bool Rild_modem::parse_config(Node const &node, Config &cfg)
{
	bool ok = true;

	String<16> const power = node.attribute_value("power", String<16>());
	if (power == "on" || power == "yes" || power == "true")
		cfg.power = Config::Power::ON;
	else if (power == "off" || power == "no" || power == "false")
		cfg.power = Config::Power::OFF;
	else if (node.has_attribute("power"))
		warning("rild_modem: config: power=\"", power, "\" unknown, ignored");

	if (node.has_attribute("pin"))
		read_text(node, "pin", cfg.pin, sizeof(cfg.pin), "<config>");

	node.with_optional_sub_node("network", [&] (Node const &net) {
		read_text(net, "attach_apn", cfg.attach_apn, sizeof(cfg.attach_apn), "<network>"); });

	node.with_optional_sub_node("call", [&] (Node const &call) {
		if (!read_text(call, "number", cfg.call.number, sizeof(cfg.call.number), "<call>")) {
			ok = false;   /* not "no call": that would hang up a call in progress */
			return;
		}
		String<16> const state = call.attribute_value("state", String<16>());
		if      (state == "accepted") cfg.call.state = Config::Call::State::ACCEPTED;
		else if (state == "rejected") cfg.call.state = Config::Call::State::REJECTED;
		else if (call.has_attribute("state"))
			warning("rild_modem: config: <call state=\"", state, "\"> unknown, ignored");

		/* a caller without number is accepted or rejected by a node
		 * without number; there is no dial without one, and "no call"
		 * would hang up a call in progress */
		if (!cfg.call.number[0] && cfg.call.state == Config::Call::State::NONE) {
			warning("rild_modem: config: <call> to dial without number");
			ok = false;
			return;
		}
		cfg.call.present = true;
	});

	node.with_optional_sub_node("data", [&] (Node const &data) {
		data.with_optional_sub_node("context", [&] (Node const &context) {
			if (!read_text(context, "apn", cfg.data.apn, sizeof(cfg.data.apn), "<context>"))
				return;
			if (!cfg.data.apn[0]) {
				warning("rild_modem: config: <context> without apn, ignored");
				return;
			}
			cfg.data.present = true;
			cfg.data.active  = context.attribute_value("active",  false);
			cfg.data.roaming = context.attribute_value("roaming", false);
		});
	});

	node.with_optional_sub_node("sms", [&] (Node const &sms) {
		if (sms.has_attribute("acknowledged"))
			read_unsigned(sms, "acknowledged", cfg.sms_acknowledged, "<sms>");

		/* an epoch too long to be ours stays "": taken as another one */
		if (sms.has_attribute("epoch")) {
			cfg.sms_epoch_present = true;
			read_text(sms, "epoch", cfg.sms_epoch, sizeof(cfg.sms_epoch), "<sms>");
		}

		sms.for_each_sub_node("send", [&] (Node const &send) {
			Config::Send s;
			::memset((void *)&s, 0, sizeof(s));
			if (!read_unsigned(send, "id", s.id, "<send>")) return;
			if (!read_text(send, "to", s.to, sizeof(s.to), "<send>")) return;

			/* an over-long text is a request with an outcome, not a
			 * malformed value: reported <sent state="failed" reason=
			 * "too long"/> by the Logic */
			Attr const text = send.attribute_value("text", Attr());
			if (chars(text) >= sizeof(s.text)) {
				warning("rild_modem: config: <send id=\"", s.id, "\"> text too long (max ",
				        sizeof(s.text) - 1, " characters), reported as failed");
				s.too_long = true;
			} else {
				copy_cstring(s.text, text.string(), sizeof(s.text));
			}
			if (!s.to[0]) {
				warning("rild_modem: config: <send id=\"", s.id, "\"> without 'to', ignored");
				return;
			}
			if (cfg.send_count == MAX_SENDS) {
				warning("rild_modem: config: more than ", unsigned(MAX_SENDS),
				        " <send> nodes, id ", s.id, " ignored");
				return;
			}
			/* bytewise, keeping the zeroed padding (see '_handle_config') */
			::memcpy((void *)&cfg.sends[cfg.send_count++], (void const *)&s, sizeof(s));
		});
	});
	return ok;
}


/*
 * State -> report (README). Every string the network or the modem
 * controls goes through 'Sanitized' (rild_modem/sanitize.h): the
 * generators do not escape.
 */

void Rild_modem::generate_state(Generator &g, State const &s, char const *epoch)
{
	using Safe = Sanitized<256>;

	/* a received text passes whole */
	using Safe_text = Sanitized<sizeof(State::Received::text)>;

	switch (s.power) {
	case State::Power::UNAVAILABLE:   break;   /* attribute omitted */
	case State::Power::OFF:           g.attribute("power", "off");           break;
	case State::Power::STARTING_UP:   g.attribute("power", "starting up");   break;
	case State::Power::ON:            g.attribute("power", "on");            break;
	case State::Power::SHUTTING_DOWN: g.attribute("power", "shutting down"); break;
	}

	/* counters only in the transient states */
	if (s.power == State::Power::STARTING_UP)   g.attribute("startup_seconds",  s.startup_seconds);
	if (s.power == State::Power::SHUTTING_DOWN) g.attribute("shutdown_seconds", s.shutdown_seconds);

	switch (s.sim) {
	case State::Sim::UNKNOWN: break;
	case State::Sim::ABSENT:  g.attribute("sim", "no");  break;
	case State::Sim::PRESENT: g.attribute("sim", "yes"); break;
	}

	switch (s.pin) {
	case State::Pin::NONE:       break;
	case State::Pin::UNKNOWN:    break;
	case State::Pin::REQUIRED:   g.attribute("pin", "required");   break;
	case State::Pin::CHECKING:   g.attribute("pin", "checking");   break;
	case State::Pin::OK:         g.attribute("pin", "ok");         break;
	case State::Pin::PUK_NEEDED: g.attribute("pin", "puk needed"); break;
	case State::Pin::ERROR:      g.attribute("pin", "error");      break;
	}

	if (s.pin_remaining_attempts >= 0)
		g.attribute("pin_remaining_attempts", s.pin_remaining_attempts);

	if (s.info.revision[0])
		g.node("info", [&] { g.attribute("revision", Safe(s.info.revision).string); });

	using Status = State::Network::Status;
	using Tech   = State::Network::Technology;

	if (s.network.status != Status::UNAVAILABLE) {
		g.node("network", [&] {
			auto status = [] (Status st) {
				switch (st) {
				case Status::UNREGISTERED: return "unregistered";
				case Status::REGISTERED:   return "registered";
				case Status::SEARCHING:    return "searching";
				case Status::DENIED:       return "denied";
				case Status::ROAMING:      return "roaming";
				case Status::UNKNOWN:      break;
				case Status::UNAVAILABLE:  break;
				}
				return "unknown";
			};
			g.attribute("status", status(s.network.status));

			switch (s.network.technology) {
			case Tech::NONE: break;
			case Tech::GSM:  g.attribute("technology", "gsm");  break;
			case Tech::UMTS: g.attribute("technology", "umts"); break;
			case Tech::LTE:  g.attribute("technology", "lte");  break;
			case Tech::NR:   g.attribute("technology", "nr");   break;
			}
			if (s.network.oper[0]) g.attribute("operator", Safe(s.network.oper).string);
			if (s.network.mcc[0])  g.attribute("mcc", Safe(s.network.mcc).string);
			if (s.network.mnc[0])  g.attribute("mnc", Safe(s.network.mnc).string);
			if (s.network.strength >= 0) g.attribute("strength", s.network.strength);
			if (s.network.denial_reason[0])
				g.attribute("denial_reason", s.network.denial_reason);
		});
	}

	if (s.call.present) {
		g.node("call", [&] {
			g.attribute("number", Safe(s.call.number).string);
			using C = State::Call::State;
			switch (s.call.state) {
			case C::NONE:     break;
			case C::INCOMING: g.attribute("state", "incoming"); break;
			case C::ACTIVE:   g.attribute("state", "active");   break;
			case C::OUTBOUND: g.attribute("state", "outbound"); break;
			case C::ALERTING: g.attribute("state", "alerting"); break;
			case C::REJECTED: g.attribute("state", "rejected"); break;
			}
		});
	}

	if (s.data.state != State::Data::State::NONE) {
		g.node("data", [&] {
			g.node("context", [&] {
				State::Data const &d = s.data;
				g.attribute("apn", Safe(d.apn).string);
				g.attribute("state", data_state_name(d.state));
				if (d.cause[0]) g.attribute("cause", Safe(d.cause).string);
				if (d.state != State::Data::State::ACTIVE) return;

				/* the modem's strings */
				g.attribute("cid", d.cid);
				if (d.ifname[0])  g.attribute("ifname",  Safe(d.ifname).string);
				if (d.type[0])    g.attribute("type",    Safe(d.type).string);
				if (d.address[0]) g.attribute("address", Safe(d.address).string);
				if (d.dns[0])     g.attribute("dns",     Safe(d.dns).string);
				if (d.gateway[0]) g.attribute("gateway", Safe(d.gateway).string);
				if (d.mtu > 0)    g.attribute("mtu", d.mtu);

				/* the IPv4 part on its own, for a consumer that takes one address */
				String<24> const address = first_ipv4(d.address, true);
				String<24> const dns     = first_ipv4(d.dns, false);
				if (address.length() > 1)
					g.node("ipv4", [&] {
						g.attribute("address", address);
						if (dns.length() > 1) g.attribute("dns", dns); });
			});
		});
	}

	/* always present: the consumer learns the epoch before the first SMS */
	{
		g.node("sms", [&] {
			if (epoch[0])      g.attribute("epoch", epoch);
			if (s.dropped)     g.attribute("dropped", s.dropped);
			if (s.undecodable) g.attribute("undecodable", s.undecodable);
			if (s.duplicates)  g.attribute("duplicates", s.duplicates);

			for (unsigned i = 0; i < s.received_count; i++) {
				State::Received const &r = s.received[i];
				g.node("received", [&] {
					g.attribute("id",   r.id);
					g.attribute("from", Safe(r.from).string);
					if (r.time[0]) g.attribute("time", r.time);
					g.attribute("text", Safe_text(r.text).string);
				});
			}
			for (unsigned i = 0; i < s.sent_count; i++) {
				State::Sent const &t = s.sent[i];
				g.node("sent", [&] {
					g.attribute("id", t.id);
					using S = State::Sent::State;
					switch (t.state) {
					case S::PENDING: g.attribute("state", "pending"); break;
					case S::SENT:    g.attribute("state", "sent");    break;
					case S::FAILED:  g.attribute("state", "failed");  break;
					}
					if (t.reason[0]) g.attribute("reason", t.reason);
				});
			}
		});
	}
}


namespace Rild_modem {

	namespace ra = ::Radio_aidl;

	using ra::radio::RadioResponseInfo;
	using ra::radio::RadioIndicationType;
	using ra::radio::RadioError;
}


struct Rild_modem::Main : Radio, Android_prop::Change_source,
                          ra::modem::IRadioModemResponse_handler,
                          ra::modem::IRadioModemIndication_handler,
                          ra::sim::IRadioSimResponse_handler,
                          ra::sim::IRadioSimIndication_handler,
                          ra::network::IRadioNetworkResponse_handler,
                          ra::network::IRadioNetworkIndication_handler,
                          ra::messaging::IRadioMessagingResponse_handler,
                          ra::messaging::IRadioMessagingIndication_handler,
                          ra::voice::IRadioVoiceResponse_handler,
                          ra::voice::IRadioVoiceIndication_handler,
                          ra::data::IRadioDataResponse_handler,
                          ra::data::IRadioDataIndication_handler,
                          ra::config::IRadioConfigResponse_handler,
                          ra::config::IRadioConfigIndication_handler
{
	using Prop_session = Android_property_session::Session;
	using Prop_conn    = Genode_pixel::Try_connection<Prop_session,
	                                                  Android_property_session::Session_client>;
	using Rom_conn     = Genode_pixel::Try_connection<Rom_session, Rom_session_client>;

	/* Rtc::Session with the donation Rtc::Connection makes */
	struct Rtc_session : Rtc::Session { static constexpr size_t RAM_QUOTA = 8*1024; };
	using Rtc_conn     = Genode_pixel::Try_connection<Rtc_session, Rtc::Session_client>;

	Main(Main const &) = delete;
	Main &operator = (Main const &) = delete;

	Env &_env;

	Timer::Connection _timer { _env };

	Attached_rom_dataspace _config_rom { _env, "config" };

	/* optional static settings (a denied session is no error) */
	Rom_conn                          _settings_rom  { _env };
	bool                              _settings_open = false;
	Constructible<Attached_dataspace> _settings_ds   { };

	Expanding_reporter _reporter { _env, "modem", "state" };

	Logic _logic { *this, now_ms };

	Config _config { };
	bool   _config_seen = false;

	/*
	 * IRadio instances (rild exports them one by one; a session is denied
	 * until its instance is exported)
	 */

	using Cb = Android_binder::Callback;

	Instance _modem {
		"android.hardware.radio.modem.IRadioModem/slot1",
		[] (Conn &c, Cb &r, Cb &i) { return ra::modem::setResponseFunctions(c, r, i); }, *this,
		[] (Main &m, uint32_t code, AParcel const &in) {
			return ra::modem::dispatch_RadioModemResponse(code, in, m); }, "IRadioModemResponse",
		[] (Main &m, uint32_t code, AParcel const &in) {
			return ra::modem::dispatch_RadioModemIndication(code, in, m); }, "IRadioModemIndication" };

	Instance _sim {
		"android.hardware.radio.sim.IRadioSim/slot1",
		[] (Conn &c, Cb &r, Cb &i) { return ra::sim::setResponseFunctions(c, r, i); }, *this,
		[] (Main &m, uint32_t code, AParcel const &in) {
			return ra::sim::dispatch_RadioSimResponse(code, in, m); }, "IRadioSimResponse",
		[] (Main &m, uint32_t code, AParcel const &in) {
			return ra::sim::dispatch_RadioSimIndication(code, in, m); }, "IRadioSimIndication" };

	Instance _network {
		"android.hardware.radio.network.IRadioNetwork/slot1",
		[] (Conn &c, Cb &r, Cb &i) { return ra::network::setResponseFunctions(c, r, i); }, *this,
		[] (Main &m, uint32_t code, AParcel const &in) {
			return ra::network::dispatch_RadioNetworkResponse(code, in, m); }, "IRadioNetworkResponse",
		[] (Main &m, uint32_t code, AParcel const &in) {
			return ra::network::dispatch_RadioNetworkIndication(code, in, m); }, "IRadioNetworkIndication" };

	Instance _messaging {
		"android.hardware.radio.messaging.IRadioMessaging/slot1",
		[] (Conn &c, Cb &r, Cb &i) { return ra::messaging::setResponseFunctions(c, r, i); }, *this,
		[] (Main &m, uint32_t code, AParcel const &in) {
			return ra::messaging::dispatch_RadioMessagingResponse(code, in, m); }, "IRadioMessagingResponse",
		[] (Main &m, uint32_t code, AParcel const &in) {
			return ra::messaging::dispatch_RadioMessagingIndication(code, in, m); }, "IRadioMessagingIndication" };

	Instance _voice {
		"android.hardware.radio.voice.IRadioVoice/slot1",
		[] (Conn &c, Cb &r, Cb &i) { return ra::voice::setResponseFunctions(c, r, i); }, *this,
		[] (Main &m, uint32_t code, AParcel const &in) {
			return ra::voice::dispatch_RadioVoiceResponse(code, in, m); }, "IRadioVoiceResponse",
		[] (Main &m, uint32_t code, AParcel const &in) {
			return ra::voice::dispatch_RadioVoiceIndication(code, in, m); }, "IRadioVoiceIndication" };

	Instance _data {
		"android.hardware.radio.data.IRadioData/slot1",
		[] (Conn &c, Cb &r, Cb &i) { return ra::data::setResponseFunctions(c, r, i); }, *this,
		[] (Main &m, uint32_t code, AParcel const &in) {
			return ra::data::dispatch_RadioDataResponse(code, in, m); }, "IRadioDataResponse",
		[] (Main &m, uint32_t code, AParcel const &in) {
			return ra::data::dispatch_RadioDataIndication(code, in, m); }, "IRadioDataIndication" };

	Instance _cfg {
		"android.hardware.radio.config.IRadioConfig/default",
		[] (Conn &c, Cb &r, Cb &i) { return ra::config::setResponseFunctions(c, r, i); }, *this,
		[] (Main &m, uint32_t code, AParcel const &in) {
			return ra::config::dispatch_RadioConfigResponse(code, in, m); }, "IRadioConfigResponse",
		[] (Main &m, uint32_t code, AParcel const &in) {
			return ra::config::dispatch_RadioConfigIndication(code, in, m); }, "IRadioConfigIndication" };

	enum { NUM_INSTANCES = 7 };

	Instance * const _instances[NUM_INSTANCES] {
		&_modem, &_sim, &_network, &_messaging, &_voice, &_data, &_cfg };

	bool _connected    = false;   /* all sessions open, Logic::connected() done */
	bool _failed       = false;   /* a transaction failed, drop pending */
	bool _rild_running = true;    /* liveness property (always true without) */

	int32_t _serial = 1;

	bool          _open_failed_logged = false;
	unsigned long _open_failed_ms     = 0;

	int32_t _allowed_types = 0;   /* last setAllowedNetworkTypesBitmap value */

	char _sim_aid[64] { };        /* AID of the SIM's GSM/UMTS application */

	/* sendSms serial -> config <send> id */
	struct Sms_serial { int32_t serial; unsigned id; bool used; };
	enum { SMS_SERIALS = 16 };
	Sms_serial _sms_serials[SMS_SERIALS] { };
	unsigned   _sms_serial_next = 0;

	State::Pin _pin_logged = State::Pin::NONE;

	unsigned _undecodable_logged = 0;
	unsigned _duplicates_logged  = 0;

	State _reported { };          /* content of the last report */
	bool  _reported_valid = false;

	/*
	 * Optional rild liveness watch
	 */
	String<Android_prop::NAME_MAX_LEN> _liveness_property { };

	Constructible<Prop_conn>              _prop          { };
	Constructible<Attached_dataspace>     _prop_table_ds { };
	Constructible<Attached_dataspace>     _prop_xfer_ds  { };
	Constructible<Android_prop::Table>    _prop_table    { };
	Constructible<Android_prop::Watcher>  _prop_watcher  { };

	Signal_handler<Main> _timer_handler    { _env.ep(), *this, &Main::_handle_timer };
	Signal_handler<Main> _config_handler   { _env.ep(), *this, &Main::_handle_config };
	Signal_handler<Main> _callback_handler { _env.ep(), *this, &Main::_handle_callbacks };
	Signal_handler<Main> _failure_handler  { _env.ep(), *this, &Main::_handle_failure };
	Signal_handler<Main> _prop_handler     { _env.ep(), *this, &Main::_handle_properties };
	Signal_handler<Main> _settings_handler { _env.ep(), *this, &Main::_handle_settings };

	int32_t _next_serial()
	{
		int32_t const s = _serial;
		_serial = (_serial == 0x7fffffff) ? 1 : _serial + 1;
		return s;
	}

	/*
	 * Connection handling
	 */

	void _drop(char const *reason)
	{
		bool const was_connected = _connected;
		_connected = false;
		_failed    = false;

		/* no further RPC to rild: only the local/parent side is torn down */
		for (Instance *inst : _instances) {
			inst->conn.destruct();
			inst->denied_logged = false;
		}
		for (Sms_serial &s : _sms_serials) s.used = false;
		for (Reg_seen   &r : _reg_seen)    r = Reg_seen { };
		_sim_aid[0] = 0;

		if (was_connected) {
			log("rild_modem: disconnected from rild (", reason, ")");
			_logic.disconnected();
		}
	}

	void _check_interface_version(Instance &inst)
	{
		int32_t version = 0;
		if (!ra::interface_version(*inst.conn, version)) {
			warning("rild_modem: ", inst.name, ": getInterfaceVersion failed");
			return;
		}
		if (version != AIDL_VERSION)
			warning("rild_modem: ", inst.name, ": interface version ", version,
			        " differs from the vendored version ", unsigned(AIDL_VERSION));
		else
			log("rild_modem: ", inst.name, ": interface version ", version);
	}

	void _try_connect()
	{
		if (_connected || !_rild_running) return;

		for (Instance *inst : _instances) {
			if (inst->open()) continue;
			if (!inst->conn.constructed()) inst->conn.construct(_env, inst->name);

			using R = Conn::Open_result;
			switch (inst->conn->open()) {
			case R::OK:
				break;
			case R::DENIED:
				if (!inst->denied_logged)
					log("rild_modem: waiting for ", inst->name);
				inst->denied_logged = true;
				return;   /* retried on the next tick */
			case R::FAILED:
				/* retried every second: warn on the first failure and
				 * every 60 s while it persists */
				if (!_open_failed_logged || now_ms() - _open_failed_ms >= 60*1000) {
					warning("rild_modem: ", inst->name, ": session request failed");
					_open_failed_logged = true;
					_open_failed_ms     = now_ms();
				}
				return;
			}
		}

		for (Instance *inst : _instances) inst->conn->callback_sigh(_callback_handler);

		for (Instance *inst : _instances) _check_interface_version(*inst);

		for (Instance *inst : _instances) {
			if (!inst->set_response(*inst->conn, inst->response, inst->indication)) {
				warning("rild_modem: ", inst->name, ": setResponseFunctions failed");
				_drop("setResponseFunctions failed");
				return;
			}
		}

		for (Instance *inst : _instances)
			if (!inst->open()) { _drop("session lost during connect"); return; }

		log("rild_modem: connected to rild (", unsigned(NUM_INSTANCES), " IRadio instances)");
		_connected          = true;
		_open_failed_logged = false;

		/* before draining: rild sends radioStateChanged right after
		 * setResponseFunctions */
		_logic.connected();
		_drain();
	}

	void _drain()
	{
		for (Instance *inst : _instances)
			if (inst->open()) inst->conn->drain();
	}

	/*
	 * Called at the end of every handler
	 */
	void _update()
	{
		if (_failed) Signal_transmitter(_failure_handler).submit();

		State const &s = _logic.state();
		if (s.undecodable != _undecodable_logged) {
			warning("rild_modem: ", s.undecodable - _undecodable_logged,
			        " received SMS not decodable (8-bit data, compressed or malformed),"
			        " acknowledged and counted");
			_undecodable_logged = s.undecodable;
		}
		if (s.duplicates != _duplicates_logged) {
			log("rild_modem: ", s.duplicates - _duplicates_logged,
			    " redelivered SMS recognised, acknowledged and not shown again");
			_duplicates_logged = s.duplicates;
		}

		if (s.pin != _pin_logged) {
			if (s.pin == State::Pin::ERROR)
				error("rild_modem: the supply of the PIN ended with an error or without"
				      " answer, it is not supplied again until the config has another pin");
			_pin_logged = s.pin;
		}

		_log_data(s.data);

		/*
		 * 'state_changed' also fires when nothing visible changed (e.g. an
		 * identical signal value): compare bytewise with the last report
		 * (a padding difference only costs a redundant report, a real
		 * change is never missed)
		 */
		if (_logic.state_changed()
		 && (!_reported_valid || ::memcmp((void const *)&s, (void const *)&_reported, sizeof(s)))) {
			::memcpy((void *)&_reported, (void const *)&s, sizeof(s));
			_reported_valid = true;
			_reporter.generate([&] (Generator &g) { generate_state(g, s, _epoch); });
		}
	}

	/*
	 * One line per change of the data context's state (also a new address
	 * of an active one)
	 */
	State::Data::State _data_logged_state = State::Data::State::NONE;
	char               _data_logged_address[sizeof(State::Data::address)] { };
	char               _data_logged_cause[sizeof(State::Data::cause)] { };

	void _log_data(State::Data const &d)
	{
		using S = State::Data::State;

		if (d.state == _data_logged_state
		 && !::strcmp(d.address, _data_logged_address)
		 && !::strcmp(d.cause,   _data_logged_cause)) return;

		_data_logged_state = d.state;
		copy_cstring(_data_logged_address, d.address, sizeof(_data_logged_address));
		copy_cstring(_data_logged_cause,   d.cause,   sizeof(_data_logged_cause));

		using Safe = Sanitized<256>;
		Safe const apn(d.apn);

		switch (d.state) {
		case S::NONE:
			log("rild_modem: data context removed");
			break;
		case S::INACTIVE:
			if (!::strcmp(d.cause, "roaming"))
				log("rild_modem: data context apn=", Cstring(apn.string),
				    " inactive while roaming (the context has no roaming: yes)");
			else if (d.cause[0])
				warning("rild_modem: data context apn=", Cstring(apn.string),
				        " inactive, call ended by the modem: ", Cstring(Safe(d.cause).string),
				        " (set up again after the back-off)");
			else
				log("rild_modem: data context apn=", Cstring(apn.string), " inactive");
			break;
		case S::CONNECTING:
			log("rild_modem: data context apn=", Cstring(apn.string), " connecting");
			break;
		case S::ACTIVE:
			log("rild_modem: data context apn=", Cstring(apn.string), " active:"
			    " cid=",     d.cid,
			    " ifname=",  Cstring(Safe(d.ifname).string),
			    " type=",    Cstring(Safe(d.type).string),
			    " address=", Cstring(Safe(d.address).string),
			    " dns=",     Cstring(Safe(d.dns).string),
			    " gateway=", Cstring(Safe(d.gateway).string),
			    " mtu=",     d.mtu);
			break;
		case S::FAILED:
			warning("rild_modem: data context apn=", Cstring(apn.string),
			        " failed: ", Cstring(Safe(d.cause).string),
			        " (retried after the back-off)");
			break;
		}
	}

	void _handle_timer()
	{
		Libc::with_libc([&] {
			if (_connected) {
				_logic.tick();
				_drain();   /* in addition to the ring signal */
			} else {
				/* parts of a concatenated SMS still time out */
				_logic.expire_sms();
				_try_connect();
			}
			_update();
		});
	}

	void _handle_config()
	{
		Libc::with_libc([&] {
			_config_rom.update();

			/*
			 * Apply only real changes (a republished identical ROM is no
			 * event). Compared bytewise: zeroed incl. padding (all defaults
			 * are 0) and copied with memcpy, so padding never differs.
			 */
			Config cfg;
			::memset((void *)&cfg, 0, sizeof(cfg));
			if (!parse_config(_config_rom.node(), cfg)) {
				warning("rild_modem: config not applied, the previous one stays");
				return;
			}

			if (!_config_seen || ::memcmp((void const *)&cfg, (void const *)&_config, sizeof(cfg)) != 0) {
				::memcpy((void *)&_config, (void const *)&cfg, sizeof(cfg));
				_config_seen = true;
				_logic.apply(_config);
			}
			_update();
		});
	}

	void _handle_callbacks()
	{
		Libc::with_libc([&] { _drain(); _update(); });
	}

	void _handle_failure()
	{
		Libc::with_libc([&] {
			if (_failed) _drop("transaction failed");
			_update();
		});
	}

	/*
	 * Liveness property
	 */

	Android_prop::Change_queue::Fetch fetch(Android_prop::Change *, unsigned) override
	{
		Prop_session::Fetch_result const f = _prop->client().changes();
		return { f.count, f.overflow != 0 };
	}

	void _rild_state(char const *value)
	{
		bool const running = !::strcmp(value, "running");
		log("rild_modem: ", _liveness_property, "=", Cstring(Sanitized<256>(value).string));
		if (running == _rild_running) return;
		_rild_running = running;
		if (!running) _drop("rild not running");
		else          _try_connect();
	}

	/* fetch every queued change (advances the session's cursor) */
	void _poll_properties()
	{
		bool ours = false;
		bool const overflowed = _prop_watcher->poll([&] (Android_prop::Slot const &s, char const *value) {
			if (_liveness_property != s.name) return;
			ours = true;
			_rild_state(value); });
		if (overflowed) {
			warning("rild_modem: property queue overflow -- intermediate values lost");

			/* a lost stop/start pair of our property: reconnect to be sure */
			if (ours && _connected && _rild_running) {
				_drop("property queue overflow");
				_try_connect();
			}
		}
	}

	void _handle_properties()
	{
		Libc::with_libc([&] { _poll_properties(); _update(); });
	}

	bool _liveness_failed = false;
	bool _liveness_logged = false;

	/*
	 * 'settings' ROM: requested once at construction; its content is read
	 * until the liveness watch is set up (the ROM may be dynamic and still
	 * empty at first), later updates are ignored -- the settings are static
	 */
	void _open_settings()
	{
		if (_settings_rom.open("settings") != Rom_conn::Result::OK) {
			log("rild_modem: no 'settings' ROM: rild death is not detected");
			_liveness_logged = true;
			return;
		}
		_settings_open = true;
		_settings_rom.client().sigh(_settings_handler);
	}

	void _read_settings()
	{
		if (!_settings_open || _prop_watcher.constructed() || _liveness_failed) return;

		_settings_ds.destruct();
		Dataspace_capability const ds = _settings_rom.client().dataspace();
		if (!ds.valid()) return;   /* empty ROM: nothing configured (yet) */

		_settings_ds.construct(_env.rm(), ds);
		Node const settings { Const_byte_range_ptr(_settings_ds->local_addr<char const>(),
		                                           _settings_ds->size()) };
		_init_liveness(settings);
	}

	/*
	 * Epoch of the received-SMS ids (rild_modem/epoch.h), fixed here for
	 * the life of the component, before the first report. The real-time
	 * clock is asked only if the settings content available at
	 * construction says so: a scenario without an Rtc route would log a
	 * denied session at every start.
	 */
	char _epoch[Epoch::MAX_LEN] { };

	void _init_epoch()
	{
		bool use_rtc = false;
		if (_settings_open) {
			Dataspace_capability const ds = _settings_rom.client().dataspace();
			if (ds.valid()) {
				try {
					Attached_dataspace const attached { _env.rm(), ds };
					Node const settings { Const_byte_range_ptr(attached.local_addr<char const>(),
					                                           attached.size()) };
					settings.with_optional_sub_node("epoch", [&] (Node const &epoch) {
						use_rtc = epoch.attribute_value("rtc", false); });
				}
				catch (...) { warning("rild_modem: cannot attach the settings ROM, sms epoch from the counters"); }
			}
		}

		Epoch::Rtc_time rtc { };
		bool have_rtc = false;
		if (use_rtc) {
			Rtc_conn conn { _env };
			if (conn.open("") == Rtc_conn::Result::OK) {
				Rtc::Timestamp const t = conn.client().current_time();
				rtc = { t.year, t.month, t.day, t.hour, t.minute, t.second };
				have_rtc = true;
				if (!Epoch::plausible(rtc))
					warning("rild_modem: real-time clock not plausible (", t, "), "
					        "sms epoch from the counters");
			} else {
				warning("rild_modem: no Rtc session, sms epoch from the counters");
			}
		}

		Epoch::format(_epoch, sizeof(_epoch), have_rtc ? &rtc : nullptr,
		              _timer.elapsed_us(), Trace::timestamp());
		_logic.epoch(_epoch);
		log("rild_modem: sms epoch ", Cstring(_epoch));
	}

	void _handle_settings()
	{
		Libc::with_libc([&] { _read_settings(); _update(); });
	}

	/*
	 * Set up the watch once the settings name the property
	 */
	void _init_liveness(Node const &settings)
	{
		if (_prop_watcher.constructed() || _liveness_failed) return;

		settings.with_optional_sub_node("rild", [&] (Node const &rild) {
			_liveness_property = rild.attribute_value("liveness_property",
			                                          String<Android_prop::NAME_MAX_LEN>()); });

		if (!chars(_liveness_property)) {
			/* not yet for an empty ROM (a dynamic ROM not reported yet) */
			if (!_liveness_logged && !settings.has_type("empty")) {
				log("rild_modem: no <rild liveness_property> in 'settings': "
				    "rild death is not detected");
				_liveness_logged = true;
			}
			return;
		}

		auto fail = [&] (char const *msg) {
			error("rild_modem: ", msg, " -- rild death is not detected");
			_prop_table_ds.destruct();
			_prop.destruct();
			_liveness_failed   = true;
			_liveness_property = { };
		};

		_prop.construct(_env);
		if (_prop->open("properties") != Prop_conn::Result::OK) {
			fail("Android_property session refused");
			return;
		}

		/* invalid unless the session's policy says watch="yes" */
		Dataspace_capability const xfer = _prop->client().transfer();
		if (!xfer.valid()) {
			fail("Android_property policy without watch=\"yes\"");
			return;
		}
		_prop_table_ds.construct(_env.rm(), _prop->client().table());
		_prop_xfer_ds .construct(_env.rm(), xfer);
		_prop_table.construct(_prop_table_ds->local_addr<void>());
		if (!_prop_table->valid()) {
			_prop_table.destruct();
			_prop_xfer_ds.destruct();
			fail("bad property table");
			return;
		}

		_prop_watcher.construct(*_prop_table, *this, _prop_xfer_ds->local_addr<Android_prop::Change>(),
		                        unsigned(Prop_session::TRANSFER_SIZE / sizeof(Android_prop::Change)));
		_prop_watcher->snapshot();

		/* current value after the snapshot: later changes arrive via poll */
		Android_prop::Slot const *slot = _prop_table->find(_liveness_property.string());
		char value[Android_prop::LONG_VALUE_MAX] { };
		if (slot) _prop_table->read_full(*slot, value);
		log("rild_modem: watching ", _liveness_property, " (now \"", Cstring(value), "\")");

		_rild_running = !::strcmp(value, "running");
		if (!_rild_running) _drop("rild not running");

		_prop->client().wait_sigh(_prop_handler);

		/*
		 * The server signals a watcher only when a change arrives while its
		 * cursor had caught up; a change between the session's creation and
		 * 'wait_sigh' used that edge without a handler. Fetch once now, as
		 * the signal would have, so the cursor catches up (changes after the
		 * snapshot are delivered in order, repeating the current value is
		 * harmless).
		 */
		_poll_properties();
	}

	/*
	 * Radio: requests issued by the Logic (never call back into it here)
	 */

	template <typename FN>
	bool _request(Instance &inst, char const *what, FN const &fn)
	{
		if (!_connected || !inst.open()) return false;
		if (fn(*inst.conn)) return true;

		if (!inst.conn->connected()) {
			if (!_failed) warning("rild_modem: ", what, ": transaction failed");
			_failed = true;   /* dropped from '_handle_failure' */
		} else {
			warning("rild_modem: ", what, ": request not sent");
		}
		return false;
	}

	void enable_modem(bool on) override
	{
		_request(_modem, "enableModem", [&] (Conn &c) {
			return ra::modem::enableModem(c, _next_serial(), on); });
	}

	void set_radio_power(bool on) override
	{
		_request(_modem, "setRadioPower", [&] (Conn &c) {
			return ra::modem::setRadioPower(c, _next_serial(), on, false, false); });
	}

	void get_icc_card_status() override
	{
		_request(_sim, "getIccCardStatus", [&] (Conn &c) {
			return ra::sim::getIccCardStatus(c, _next_serial()); });
	}

	void supply_pin(char const *pin, char const *aid) override
	{
		char const *app = (aid && aid[0]) ? aid : _sim_aid;
		_request(_sim, "supplyIccPinForApp", [&] (Conn &c) {
			return ra::sim::supplyIccPinForApp(c, _next_serial(), pin, app); });
	}

	void set_preferred_data_modem() override
	{
		_request(_cfg, "setPreferredDataModem", [&] (Conn &c) {
			return ra::config::setPreferredDataModem(c, _next_serial(), 0); });
	}

	void set_allowed_network_types(int32_t bitmap) override
	{
		_allowed_types = bitmap;
		_request(_network, "setAllowedNetworkTypesBitmap", [&] (Conn &c) {
			return ra::network::setAllowedNetworkTypesBitmap(c, _next_serial(), bitmap); });
	}

	/*
	 * Bring-up as LineageOS does it at a cold boot: setDataProfile,
	 * setInitialAttachApn with persistent=false (rild skips the initial
	 * attach of a "modem cognitive" profile), then the allowed network
	 * types once more
	 */
	void set_initial_attach_apn(char const *apn) override
	{
		ra::data::DataProfileInfo dp { };
		dp.profileId               = ra::data::DataProfileInfo::ID_DEFAULT;
		dp.apn.set(apn);
		dp.protocol                = ra::data::PdpProtocolType::IPV4V6;
		dp.roamingProtocol         = ra::data::PdpProtocolType::IPV4V6;
		dp.authType                = ra::data::ApnAuthType::NO_PAP_NO_CHAP;
		dp.type                    = ra::data::DataProfileInfo::TYPE_3GPP;
		dp.supportedApnTypesBitmap = 1 /* DEFAULT */ | 16 /* HIPRI */;
		dp.enabled                 = true;
		dp.persistent              = true;
		dp.trafficDescriptor.dnn.set(nullptr);   /* @nullable, NDK default */

		ra::Vec<ra::data::DataProfileInfo, 16> profiles { };   /* ~22 KB of stack */
		profiles.add(dp);
		_request(_data, "setDataProfile", [&] (Conn &c) {
			return ra::data::setDataProfile(c, _next_serial(), profiles); });

		ra::Opt<ra::data::DataProfileInfo> ia { };
		ia.present          = true;
		ia.value            = dp;
		ia.value.persistent = false;
		_request(_data, "setInitialAttachApn", [&] (Conn &c) {
			return ra::data::setInitialAttachApn(c, _next_serial(), ia); });

		if (_allowed_types) set_allowed_network_types(_allowed_types);
	}

	void query_registration() override
	{
		_request(_network, "getVoiceRegistrationState", [&] (Conn &c) {
			return ra::network::getVoiceRegistrationState(c, _next_serial()); });
		_request(_network, "getDataRegistrationState", [&] (Conn &c) {
			return ra::network::getDataRegistrationState(c, _next_serial()); });
		_request(_network, "getOperator", [&] (Conn &c) {
			return ra::network::getOperator(c, _next_serial()); });
		_request(_network, "getSignalStrength", [&] (Conn &c) {
			return ra::network::getSignalStrength(c, _next_serial()); });
	}

	void get_baseband_version() override
	{
		_request(_modem, "getBasebandVersion", [&] (Conn &c) {
			return ra::modem::getBasebandVersion(c, _next_serial()); });
	}

	void send_sms(char const *smsc_pdu_hex, char const *pdu_hex, unsigned id) override
	{
		int32_t const serial = _next_serial();

		Sms_serial &slot = _sms_serials[_sms_serial_next];
		_sms_serial_next = (_sms_serial_next + 1) % SMS_SERIALS;
		slot = { serial, id, true };

		ra::messaging::GsmSmsMessage msg { };
		msg.smscPdu.set(smsc_pdu_hex);
		msg.pdu.set(pdu_hex);
		_request(_messaging, "sendSms", [&] (Conn &c) {
			return ra::messaging::sendSms(c, serial, msg); });
	}

	void ack_sms(bool ok) override
	{
		/* cause 0 on success, like the framework's resultToCause() */
		auto const cause = ok ? ra::messaging::SmsAcknowledgeFailCause(0)
		                      : ra::messaging::SmsAcknowledgeFailCause::UNSPECIFIED_ERROR;
		_request(_messaging, "acknowledgeLastIncomingGsmSms", [&] (Conn &c) {
			return ra::messaging::acknowledgeLastIncomingGsmSms(c, _next_serial(), ok, cause); });
	}

	void dial(char const *number) override
	{
		ra::voice::Dial d { };
		d.address.set(number);
		d.clir = ra::voice::Dial::CLIR_DEFAULT;
		_request(_voice, "dial", [&] (Conn &c) {
			return ra::voice::dial(c, _next_serial(), d); });
	}

	void get_current_calls() override
	{
		_request(_voice, "getCurrentCalls", [&] (Conn &c) {
			return ra::voice::getCurrentCalls(c, _next_serial()); });
	}

	void set_mute(bool on) override
	{
		_request(_voice, "setMute", [&] (Conn &c) {
			return ra::voice::setMute(c, _next_serial(), on); });
	}

	void get_last_call_fail_cause() override
	{
		_request(_voice, "getLastCallFailCause", [&] (Conn &c) {
			return ra::voice::getLastCallFailCause(c, _next_serial()); });
	}

	void accept_call() override
	{
		_request(_voice, "acceptCall", [&] (Conn &c) {
			return ra::voice::acceptCall(c, _next_serial()); });
	}

	void hangup(int32_t index) override
	{
		_request(_voice, "hangup", [&] (Conn &c) {
			return ra::voice::hangup(c, _next_serial(), index); });
	}

	void reject_call() override
	{
		_request(_voice, "rejectCall", [&] (Conn &c) {
			return ra::voice::rejectCall(c, _next_serial()); });
	}

	/*
	 * The request LineageOS sends for the default data call (as captured
	 * on the phone): reason NORMAL, the profile of the
	 * APN with protocol and roaming protocol IPV4V6, types default|hipri,
	 * preferred, not persistent, no addresses and DNS, pduSessionId 0, no
	 * slice, traffic descriptor dnn = apn, matchAllRuleAllowed. The other
	 * profile fields are those of the attach profile above.
	 */
	void setup_data_call(char const *apn, int access_network, bool roaming_allowed) override
	{
		ra::data::DataProfileInfo dp { };
		dp.profileId               = ra::data::DataProfileInfo::ID_DEFAULT;
		dp.apn.set(apn);
		dp.protocol                = ra::data::PdpProtocolType::IPV4V6;
		dp.roamingProtocol         = ra::data::PdpProtocolType::IPV4V6;
		dp.authType                = ra::data::ApnAuthType::NO_PAP_NO_CHAP;
		dp.type                    = ra::data::DataProfileInfo::TYPE_3GPP;
		dp.supportedApnTypesBitmap = 1 /* DEFAULT */ | 16 /* HIPRI */;
		dp.enabled                 = true;
		dp.preferred               = true;
		dp.persistent              = false;
		dp.trafficDescriptor.dnn.set(apn);

		ra::Vec<ra::data::LinkAddress, 1> const no_addresses { };
		ra::Vec<ra::Str, 1>               const no_dnses     { };
		ra::Opt<ra::data::SliceInfo>      const no_slice     { };

		auto const an = ra::radio::AccessNetwork(access_network);

		log("rild_modem: setupDataCall apn=", Cstring(apn), " accessNetwork=",
		    ra::radio::enum_name(an), " roamingAllowed=", roaming_allowed);

		_request(_data, "setupDataCall", [&] (Conn &c) {
			return ra::data::setupDataCall(c, _next_serial(), an, dp, roaming_allowed,
			                               ra::data::DataRequestReason::NORMAL,
			                               no_addresses, no_dnses, 0, no_slice, true); });
	}

	void deactivate_data_call(int32_t cid) override
	{
		log("rild_modem: deactivateDataCall cid=", cid);
		_request(_data, "deactivateDataCall", [&] (Conn &c) {
			return ra::data::deactivateDataCall(c, _next_serial(), cid,
			                                    ra::data::DataRequestReason::NORMAL); });
	}

	void get_data_call_list() override
	{
		_request(_data, "getDataCallList", [&] (Conn &c) {
			return ra::data::getDataCallList(c, _next_serial()); });
	}

	void gave_up(char const *request) override
	{
		warning("rild_modem: ", Cstring(request), ": no response, gave up");
	}

	/*
	 * Responses and indications (from '_drain', on the entrypoint)
	 */

	static bool ok(RadioResponseInfo const &info) { return info.error == RadioError::NONE; }

	void _log_error(char const *what, RadioResponseInfo const &info)
	{
		if (!ok(info))
			warning("rild_modem: ", what, ": ", ra::radio::enum_name(info.error),
			        " (", int(info.error), ")");
	}

	void unhandled(uint32_t, char const *) override { }

	void decode_error(uint32_t code, char const *method) override
	{
		warning("rild_modem: ", Cstring(method), " (", code, "): parcel did not decode");
	}

	/* IRadioModem */

	void radioStateChanged(RadioIndicationType, ra::modem::RadioState st) override
	{
		log("rild_modem: radio state ", ra::modem::enum_name(st));
		switch (st) {
		case ra::modem::RadioState::ON:
			_logic.on_radio_state(true);
			_logic.on_network_changed();
			break;
		case ra::modem::RadioState::OFF:
			_logic.on_radio_state(false);
			break;
		case ra::modem::RadioState::UNAVAILABLE:
			/* modem not ready yet: not a power state of its own, but the
			 * setup is re-sent once it is available */
			_logic.on_radio_unavailable();
			break;
		}
	}

	void enableModemResponse(RadioResponseInfo const &info) override
	{
		_log_error("enableModem", info);
	}

	void setRadioPowerResponse(RadioResponseInfo const &info) override
	{
		_log_error("setRadioPower", info);
	}

	void getBasebandVersionResponse(RadioResponseInfo const &info, ra::Str const &version) override
	{
		_log_error("getBasebandVersion", info);
		if (ok(info)) _logic.on_baseband(version.string());
	}

	/* IRadioSim */

	void simStatusChanged(RadioIndicationType) override { _logic.on_network_changed(); }

	void getIccCardStatusResponse(RadioResponseInfo const &info,
	                              ra::sim::CardStatus const &cs) override
	{
		_log_error("getIccCardStatus", info);
		if (!ok(info)) { _logic.on_card_status_error(); return; }

		/* the GSM/UMTS application's PIN1 (or the universal PIN) */
		ra::sim::PinState pin = cs.universalPinState;
		int32_t const idx = cs.gsmUmtsSubscriptionAppIndex;
		if (idx >= 0 && uint32_t(idx) < cs.applications.count) {
			ra::sim::AppStatus const &app = cs.applications[unsigned(idx)];
			if (!app.pin1Replaced) pin = app.pin1;
			copy_cstring(_sim_aid, app.aidPtr.string(), sizeof(_sim_aid));
		}
		_logic.on_card_status(cs.cardState, int(pin));
	}

	void supplyIccPinForAppResponse(RadioResponseInfo const &info, int32_t remaining) override
	{
		if (!ok(info))
			error("rild_modem: supplyIccPinForApp: ", ra::radio::enum_name(info.error),
			      " (", int(info.error), "), remaining attempts ", remaining,
			      ": this PIN is not supplied again until the config has another pin");
		_logic.on_pin_result(int(info.error), remaining);
	}

	/* IRadioNetwork */

	void networkStateChanged(RadioIndicationType) override { _logic.on_network_changed(); }

	void currentSignalStrength(RadioIndicationType, ra::network::SignalStrength const &ss) override
	{
		_logic.on_signal({ ss.lte.rsrp, ss.wcdma.rscp, ss.gsm.signalStrength });
	}

	/*
	 * PLMN of a registration result: 'registeredPlmn', or else the serving
	 * cell's MCC+MNC (rild leaves 'registeredPlmn' empty in some results)
	 */
	static void _plmn(ra::network::RegStateResult const &r, char *out, size_t cap)
	{
		copy_cstring(out, r.registeredPlmn.string(), cap);
		if (out[0]) return;

		using Tag = ra::network::CellIdentity::Tag;
		ra::network::CellIdentity const &c = r.cellIdentity;
		auto join = [&] (ra::Str const &mcc, ra::Str const &mnc) {
			if (mcc.len == 3 && (mnc.len == 2 || mnc.len == 3))
				copy_cstring(out, String<8>(mcc.string(), mnc.string()).string(), cap); };
		switch (c.tag) {
		case Tag::gsm:     join(c.gsm.mcc,     c.gsm.mnc);     break;
		case Tag::wcdma:   join(c.wcdma.mcc,   c.wcdma.mnc);   break;
		case Tag::tdscdma: join(c.tdscdma.mcc, c.tdscdma.mnc); break;
		case Tag::lte:     join(c.lte.mcc,     c.lte.mnc);     break;
		case Tag::nr:      join(c.nr.mcc,      c.nr.mnc);      break;
		case Tag::cdma:    break;
		case Tag::noinit:  break;
		}
	}

	struct Reg_seen { int reg_state = -1, rat = -1; char plmn[8] { }; };

	Reg_seen _reg_seen[2] { };   /* voice, data: log only changes */

	void _registration(Logic::Reg_domain domain, char const *what,
	                   RadioResponseInfo const &info, ra::network::RegStateResult const &r)
	{
		_log_error(what, info);
		if (!ok(info)) { _logic.on_registration_error(); return; }

		char plmn[8] { };
		_plmn(r, plmn, sizeof(plmn));

		Reg_seen &seen = _reg_seen[domain == Logic::Reg_domain::DATA];
		if (seen.reg_state != int(r.regState) || seen.rat != int(r.rat) || ::strcmp(seen.plmn, plmn)) {
			log("rild_modem: ", domain == Logic::Reg_domain::DATA ? "data" : "voice",
			    " registration ", ra::network::enum_name(r.regState),
			    " rat=", ra::radio::enum_name(r.rat),
			    " plmn=", Cstring(Sanitized<sizeof(plmn)>(plmn).string),
			    (r.registeredPlmn.len || !plmn[0]) ? "" : " (from the cell identity)");
			seen.reg_state = int(r.regState);
			seen.rat       = int(r.rat);
			copy_cstring(seen.plmn, plmn, sizeof(seen.plmn));
		}

		_logic.on_registration(domain, int(r.regState), int(r.rat),
		                       int(r.reasonForDenial), plmn);
	}

	void getVoiceRegistrationStateResponse(RadioResponseInfo const &info,
	                                       ra::network::RegStateResult const &r) override
	{
		_registration(Logic::Reg_domain::VOICE, "getVoiceRegistrationState", info, r);
	}

	void getDataRegistrationStateResponse(RadioResponseInfo const &info,
	                                      ra::network::RegStateResult const &r) override
	{
		_registration(Logic::Reg_domain::DATA, "getDataRegistrationState", info, r);
	}

	void getOperatorResponse(RadioResponseInfo const &info, ra::Str const &long_name,
	                         ra::Str const &, ra::Str const &numeric) override
	{
		_log_error("getOperator", info);
		if (ok(info)) _logic.on_operator(long_name.string(), numeric.string());
	}

	void getSignalStrengthResponse(RadioResponseInfo const &info,
	                               ra::network::SignalStrength const &ss) override
	{
		_log_error("getSignalStrength", info);
		if (ok(info)) _logic.on_signal({ ss.lte.rsrp, ss.wcdma.rscp, ss.gsm.signalStrength });
	}

	void setAllowedNetworkTypesBitmapResponse(RadioResponseInfo const &info) override
	{
		_log_error("setAllowedNetworkTypesBitmap", info);
	}

	/* IRadioMessaging */

	void sendSmsResponse(RadioResponseInfo const &info, ra::messaging::SendSmsResult const &) override
	{
		_log_error("sendSms", info);
		for (Sms_serial &s : _sms_serials) {
			if (!s.used || s.serial != info.serial) continue;
			s.used = false;
			_logic.on_sms_sent(s.id, ok(info), int(info.error));
			return;
		}
		warning("rild_modem: sendSms response for unknown serial ", info.serial);
	}

	void acknowledgeLastIncomingGsmSmsResponse(RadioResponseInfo const &info) override
	{
		_log_error("acknowledgeLastIncomingGsmSms", info);
	}

	void newSms(RadioIndicationType, ra::Vec<uint8_t, 256> const &pdu) override
	{
		/* a PDU cut by the vector's capacity is not the message: undecodable */
		if (pdu.truncated) warning("rild_modem: SMS PDU longer than ", pdu.count, " bytes");
		_logic.on_new_sms(pdu.items, pdu.truncated ? 0 : pdu.count);
	}

	/* IRadioVoice */

	void callStateChanged(RadioIndicationType) override { get_current_calls(); }

	void dialResponse(RadioResponseInfo const &info) override
	{
		_log_error("dial", info);
		_logic.on_dial_result(ok(info));
		if (ok(info)) get_current_calls();
	}

	void getCurrentCallsResponse(RadioResponseInfo const &info,
	                             ra::Vec<ra::voice::Call, 7> const &calls) override
	{
		_log_error("getCurrentCalls", info);
		if (!ok(info)) return;

		Logic::Call_info list[7] { };
		unsigned n = 0;
		for (unsigned i = 0; i < calls.count && n < 7; i++, n++) {
			list[n].index = calls[i].index;
			list[n].state = calls[i].state;
			list[n].is_mt = calls[i].isMT;
			copy_cstring(list[n].number, calls[i].number.string(), sizeof(list[n].number));
		}
		_logic.on_calls(list, n);
	}

	void acceptCallResponse(RadioResponseInfo const &info) override
	{
		_log_error("acceptCall", info);
		_logic.on_accept_result(ok(info));
		get_current_calls();
	}

	void hangupConnectionResponse(RadioResponseInfo const &info) override
	{
		_log_error("hangup", info);
		_logic.on_hangup_result(ok(info));
		get_current_calls();
	}

	void setMuteResponse(RadioResponseInfo const &info) override
	{
		_log_error("setMute", info);
	}

	void getLastCallFailCauseResponse(RadioResponseInfo const &info,
	                                  ra::voice::LastCallFailCauseInfo const &fail) override
	{
		_log_error("getLastCallFailCause", info);
		if (ok(info))
			log("rild_modem: call ended, cause ", int(fail.causeCode), " (",
			    Cstring(ra::voice::enum_name(fail.causeCode)), ") vendor cause \"",
			    Cstring(Sanitized<256>(fail.vendorCause.string()).string), "\"");
	}

	void rejectCallResponse(RadioResponseInfo const &info) override
	{
		_log_error("rejectCall", info);
		_logic.on_hangup_result(ok(info));
		get_current_calls();
	}

	/* IRadioData, IRadioConfig */

	void setDataProfileResponse(RadioResponseInfo const &info) override
	{
		_log_error("setDataProfile", info);
	}

	void setInitialAttachApnResponse(RadioResponseInfo const &info) override
	{
		_log_error("setInitialAttachApn", info);
		if (ok(info)) log("rild_modem: initial-attach APN accepted");
	}

	/*
	 * SetupDataCallResult -> the Logic's reduced form
	 */

	template <unsigned N>
	static void _join(ra::Vec<ra::Str, N> const &list, char *out, size_t cap)
	{
		out[0] = 0;
		size_t len = 0;
		for (unsigned i = 0; i < list.count; i++) {
			char const * const item = list[i].string();
			size_t const n = ::strlen(item);
			if (!n) continue;
			if (len + n + (len ? 1 : 0) + 1 > cap) break;   /* whole items only */
			if (len) out[len++] = ',';
			::memcpy(out + len, item, n);
			len += n;
			out[len] = 0;
		}
	}

	static void _data_call(ra::data::SetupDataCallResult const &r, Logic::Data_call_info &out)
	{
		out.cid        = r.cid;
		out.active     = r.active != ra::data::SetupDataCallResult::DATA_CONNECTION_STATUS_INACTIVE;
		out.cause_none = r.cause == ra::data::DataCallFailCause::NONE;
		out.retry_ms   = r.suggestedRetryTime;
		out.mtu        = r.mtuV4 > 0 ? r.mtuV4 : r.mtuV6;

		if (!out.cause_none) {
			char const * const name = ra::data::enum_name(r.cause);
			if (::strcmp(name, "?"))
				copy_cstring(out.cause, name, sizeof(out.cause));
			else
				copy_cstring(out.cause, String<48>("cause ", int(r.cause)).string(),
				             sizeof(out.cause));
		}

		copy_cstring(out.type,   ra::data::enum_name(r.type), sizeof(out.type));
		copy_cstring(out.ifname, r.ifname.string(),           sizeof(out.ifname));

		ra::Vec<ra::Str, 4> addresses { };
		for (unsigned i = 0; i < r.addresses.count; i++) addresses.add(r.addresses[i].address);
		_join(addresses,  out.address, sizeof(out.address));
		_join(r.dnses,    out.dns,     sizeof(out.dns));
		_join(r.gateways, out.gateway, sizeof(out.gateway));
	}

	void _data_call_list(ra::Vec<ra::data::SetupDataCallResult, 4> const &list)
	{
		if (list.truncated)
			warning("rild_modem: more than 4 data calls listed, the others ignored");

		Logic::Data_call_info calls[4] { };
		unsigned n = 0;
		for (; n < list.count && n < 4; n++) _data_call(list[n], calls[n]);
		_logic.on_data_call_list(calls, n, !list.truncated);
	}

	void setupDataCallResponse(RadioResponseInfo const &info,
	                           ra::data::SetupDataCallResult const &r) override
	{
		_log_error("setupDataCall", info);

		Logic::Data_call_info call { };
		if (ok(info)) {
			_data_call(r, call);
			log("rild_modem: setupDataCall result: cause=", ra::data::enum_name(r.cause),
			    " (", int(r.cause), ") suggestedRetryTime=", r.suggestedRetryTime,
			    " cid=", r.cid, " active=", r.active, " pduSessionId=", r.pduSessionId);
		} else {
			copy_cstring(call.cause, ra::radio::enum_name(info.error), sizeof(call.cause));
		}
		_logic.on_data_call_setup(ok(info), call);
	}

	void deactivateDataCallResponse(RadioResponseInfo const &info) override
	{
		_log_error("deactivateDataCall", info);
		_logic.on_data_call_deactivated(ok(info));
	}

	void getDataCallListResponse(RadioResponseInfo const &info,
	                             ra::Vec<ra::data::SetupDataCallResult, 4> const &list) override
	{
		_log_error("getDataCallList", info);
		if (ok(info)) _data_call_list(list);
	}

	void dataCallListChanged(RadioIndicationType,
	                         ra::Vec<ra::data::SetupDataCallResult, 4> const &list) override
	{
		log("rild_modem: data call list changed: ", list.count, " call(s)");
		for (unsigned i = 0; i < list.count; i++)
			log("rild_modem:   cid=", list[i].cid, " active=", list[i].active,
			    " ifname=", Cstring(Sanitized<64>(list[i].ifname.string()).string),
			    " cause=", ra::data::enum_name(list[i].cause));
		_data_call_list(list);
	}

	void setPreferredDataModemResponse(RadioResponseInfo const &info) override
	{
		_log_error("setPreferredDataModem", info);
	}

	Main(Env &env) : _env(env)
	{
		timer_ptr = &_timer;

		_timer.sigh(_timer_handler);
		_timer.trigger_periodic(1000*1000);

		_config_rom.sigh(_config_handler);

		/* the epoch is part of every report, the first one is made below */
		_open_settings();
		_init_epoch();

		/* the initial config is known to the Logic before the first connect */
		_handle_config();

		Libc::with_libc([&] { _read_settings(); _try_connect(); _update(); });
	}
};


void Libc::Component::construct(Libc::Env &env)
{
	Libc::with_libc([&] { static Rild_modem::Main main(env); });
}
