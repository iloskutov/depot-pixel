/*
 * \brief  Test of the unwinder of 'android_loader'
 * \author Ivan Loskutov
 * \date   2026-11-08
 *
 * An Android program as the loader runs it: built against the bionic ABI
 * (stubs.S), the C++ runtime is the phone's libc++.so, the _Unwind_*
 * functions are the loader's. The test throws inside libc++.so and catches
 * in the program, runs destructors on the way (_Unwind_Resume), rethrows,
 * and throws from two threads at once.
 */

/*
 * SPDX-License-Identifier: MIT
 */

extern "C" {

	int printf(char const *, ...);

	/* libc++abi */
	[[noreturn]] void __cxa_bad_cast();
	void *__cxa_current_exception_type();

	/* bionic's pthread_t is a long */
	int pthread_create(long *, void const *, void *(*)(void *), void *);
	int pthread_join(long, void **);
}


static bool equal(char const *a, char const *b)
{
	for (; *a && *a == *b; a++, b++);
	return *a == *b;
}


/* mangled name of the type of the exception being handled */
static char const *current_type()
{
	/* std::type_info: vtable pointer, name */
	return ((char const * const *)__cxa_current_exception_type())[1];
}


struct Count_on_exit
{
	int &count;
	~Count_on_exit() { count++; }
};


/* throws std::bad_cast inside libc++.so, through a frame with a destructor */
static void __attribute__((noinline)) throw_in_libcxx(int &destructed)
{
	Count_on_exit c { destructed };
	__cxa_bad_cast();
}


static bool libcxx_throw()
{
	int destructed = 0;
	try { throw_in_libcxx(destructed); }
	catch (...) { return equal(current_type(), "St8bad_cast") && destructed == 1; }
	return false;
}


static void __attribute__((noinline)) throw_int(int v) { throw v; }


static bool rethrow()
{
	try {
		try { throw_int(42); }
		catch (int) { throw; }
	}
	catch (int v) { return v == 42; }
	return false;
}


enum { ROUNDS = 1000 };

static void *thread_entry(void *)
{
	long failed = 0;
	for (unsigned i = 0; i < ROUNDS; i++)
		if (!libcxx_throw()) failed++;
	return (void *)failed;
}


static bool threads()
{
	long t[2];
	for (long &id : t)
		if (pthread_create(&id, nullptr, thread_entry, nullptr)) return false;

	bool ok = true;
	for (long id : t) {
		void *failed = nullptr;
		if (pthread_join(id, &failed) || failed) ok = false;
	}
	return ok;
}


extern "C" int main(int, char **, char **)
{
	struct { char const *name; bool (*fn)(); } const tests[] = {
		{ "throw in libc++.so, destructor, catch", libcxx_throw },
		{ "rethrow",                               rethrow      },
		{ "two threads",                           threads      } };

	bool ok = true;
	for (auto const &t : tests) {
		bool const r = t.fn();
		printf("test-android_unwind: %s: %s\n", t.name, r ? "ok" : "failed");
		ok = ok && r;
	}
	printf("test-android_unwind: %s\n", ok ? "passed" : "failed");
	return ok ? 0 : 1;
}
