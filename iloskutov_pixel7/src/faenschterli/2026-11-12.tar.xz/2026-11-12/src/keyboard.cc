/*
 * \brief  On-screen keyboard of Fänschterli
 * \author Ivan Loskutov
 * \date   2026-11-12
 *
 * LVGL's keyboard in a window of its own, placed by the shell. Its keys go
 * into the input chain through an Event session, so they reach the focused
 * app as a hardware keyboard's would: a character as 'Press_char' of its
 * codepoint, Backspace, Enter and the arrows as key codes.
 *
 * A key is sent when the finger leaves it. While a finger is down, the GUI
 * server gives all input to the touched window, the keyboard itself, so a
 * key sent earlier, and the repetition of a held key, would not reach the
 * app.
 */

/*
 * SPDX-License-Identifier: MIT
 */

#include <base/log.h>
#include <event_session/connection.h>
#include <libc/component.h>
#include <util/utf8.h>

#include <lvgl_genode.h>

namespace Faenschterli_keyboard {

	using namespace Genode;

	struct Main;
}


struct Faenschterli_keyboard::Main : Lvgl_genode::Window::Ui
{
	Event::Connection _event;

	lv_obj_t *_keyboard = nullptr;

	String<16> _pending { };   /* key of the current press */

	static bool _equal(char const *a, char const *b) { return strcmp(a, b) == 0; }

	void _send_key(Input::Keycode key)
	{
		_event.with_batch([&] (Event::Session_client::Batch &batch) {
			batch.submit(Input::Press   { key });
			batch.submit(Input::Release { key }); });
	}

	void _send_text(char const *text)
	{
		_event.with_batch([&] (Event::Session_client::Batch &batch) {
			for (Utf8_ptr utf8(text); utf8.complete(); utf8 = utf8.next()) {
				batch.submit(Input::Press_char { Input::KEY_UNKNOWN, utf8.codepoint() });
				batch.submit(Input::Release    { Input::KEY_UNKNOWN });
			} });
	}

	void _send(char const *text)
	{
		/* LVGL's own keys: the layouts and hiding are handled or ignored */
		if (_equal(text, "ABC") || _equal(text, "abc") || _equal(text, "1#")
		 || _equal(text, LV_SYMBOL_KEYBOARD) || _equal(text, LV_SYMBOL_CLOSE))
			return;

		auto key = [&] (Input::Keycode code) {
			log("keyboard: ", Input::key_name(code));
			_send_key(code); };

		if      (_equal(text, LV_SYMBOL_BACKSPACE)) key(Input::KEY_BACKSPACE);
		else if (_equal(text, LV_SYMBOL_NEW_LINE))  key(Input::KEY_ENTER);
		else if (_equal(text, "Enter"))             key(Input::KEY_ENTER);
		else if (_equal(text, LV_SYMBOL_OK))        key(Input::KEY_ENTER);
		else if (_equal(text, LV_SYMBOL_LEFT))      key(Input::KEY_LEFT);
		else if (_equal(text, LV_SYMBOL_RIGHT))     key(Input::KEY_RIGHT);
		else {
			log("keyboard: ", Cstring(text));
			_send_text(text);
		}
	}

	/* a key pressed (or released, for LVGL's control keys) */
	static void _value_changed(lv_event_t *e)
	{
		Main     &main     = *(Main *)lv_event_get_user_data(e);
		lv_obj_t *keyboard = lv_event_get_target_obj(e);

		uint32_t const id = lv_buttonmatrix_get_selected_button(keyboard);
		if (id == LV_BUTTONMATRIX_BUTTON_NONE)
			return;

		char const *text = lv_buttonmatrix_get_button_text(keyboard, id);
		main._pending = text ? text : "";
	}

	/* the finger left the keyboard: send the key, if still on it */
	static void _released(lv_event_t *e)
	{
		Main     &main     = *(Main *)lv_event_get_user_data(e);
		lv_obj_t *keyboard = lv_event_get_target_obj(e);

		bool const on_key = lv_buttonmatrix_get_selected_button(keyboard)
		                 != LV_BUTTONMATRIX_BUTTON_NONE;

		if (on_key && main._pending.length() > 1)
			main._send(main._pending.string());

		main._pending = String<16>();
	}

	void create(lv_display_t &display) override
	{
		lv_theme_t *theme = lv_theme_default_init(&display,
			lv_palette_main(LV_PALETTE_BLUE), lv_palette_main(LV_PALETTE_TEAL),
			true, LV_FONT_DEFAULT);
		lv_display_set_theme(&display, theme);

		lv_obj_t *screen = lv_display_get_screen_active(&display);
		lv_obj_set_scrollable(screen, false);

		_keyboard = lv_keyboard_create(screen);
		lv_obj_set_size(_keyboard, lv_pct(100), lv_pct(100));
		lv_obj_align(_keyboard, LV_ALIGN_TOP_LEFT, 0, 0);

		/* the theme's gaps, scaled for 400 dpi, leave the keys too narrow */
		lv_obj_set_style_pad_all(_keyboard, 8, 0);
		lv_obj_set_style_pad_row(_keyboard, 10, 0);
		lv_obj_set_style_pad_column(_keyboard, 10, 0);

		lv_obj_add_event_cb(_keyboard, _value_changed, LV_EVENT_VALUE_CHANGED, this);
		lv_obj_add_event_cb(_keyboard, _released,      LV_EVENT_RELEASED,      this);
	}

	Lvgl_genode::Runtime _runtime;
	Lvgl_genode::Window  _window;

	Main(Env &env)
	:
		_event(env), _runtime(env), _window(env, _runtime, *this, "")
	{ }

	Main(Main const &) = delete;
	Main &operator = (Main const &) = delete;
};


void Libc::Component::construct(Libc::Env &env)
{
	static Faenschterli_keyboard::Main main(env);
}
