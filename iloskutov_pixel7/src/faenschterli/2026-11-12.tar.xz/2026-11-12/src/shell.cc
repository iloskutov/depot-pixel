/*
 * \brief  Fänschterli, the phone shell of MüesliOS
 * \author Ivan Loskutov
 * \date   2026-11-12
 *
 * The shell draws three windows of 'wm' with LVGL: the status bar, the
 * button bar (launcher, running apps, keyboard), and the pages (launcher
 * and running apps) in the app area between them. It places all windows
 * by the rules it reports to 'window_layouter':
 *
 *   status     fixed height
 *   apps       the rest: the front app, or a page above it
 *   keyboard   fixed height, only while shown
 *   buttons    fixed height
 *
 * The apps come from the ROM "catalog". A tap on an app's tile starts it:
 * the shell reports the config of the init that runs the apps ("apps"),
 * one start node per running app. The running page brings an app to the
 * front or stops it. The front app gets the keyboard focus through the
 * layouter's "focus_request".
 *
 * Above all rows, in the screen's own layer, the shell shows floating
 * windows with an alpha channel, below the status bar:
 *
 * - a notification of telephony (ROM "notifications": a list, each
 *   with an 'id', the 'app', 'title', 'text', and a 'serial' that changes
 *   with every new message or missed call), unless its app is in front;
 *   a tap opens the app;
 * - the incoming call (ROM "call_state" of 'modem_link') with Accept
 *   and Reject, reported as "call_action"; Accept brings the Phone app to
 *   the front;
 * - the volume control, shown by the volume keys (global keys of the GUI
 *   server to the session "keys").
 *
 * The current notifications are also listed on the launcher page, above the
 * apps (a tap opens the app), and counted by a bell in the status bar.
 *
 * The notification and the volume control hide themselves after a few
 * seconds, the call card when the call is no longer ringing. What is shown
 * is reported as "ui_state" ('state: app | active_app: <name>' or 'state:
 * launcher'), so telephony marks what the user sees as read. Telephony
 * reports numbers: the shell shows the contact's name of a number, looked
 * up at 'contacts_service' ('Contacts' session).
 */

/*
 * SPDX-License-Identifier: MIT
 */

#include <base/attached_rom_dataspace.h>
#include <base/log.h>
#include <gui_session/connection.h>
#include <libc/component.h>
#include <os/reporter.h>
#include <contacts_session/connection.h>
#include <util/color.h>

#include <lvgl_genode.h>

namespace Faenschterli {

	using namespace Genode;

	using Name  = String<32>;
	using Title = String<256>;   /* a name, or a notification's text (UTF-8) */
	using Label = String<128>;

	struct App;
	struct Catalog;
	struct Action;
	struct Status_bar;
	struct Button_bar;
	struct Pages;
	struct Overlay;
	struct Notification;
	struct Call;
	struct Volume;
	struct Main;

	static void dark_theme(lv_display_t &display)
	{
		lv_theme_t *theme = lv_theme_default_init(&display,
			lv_palette_main(LV_PALETTE_BLUE), lv_palette_main(LV_PALETTE_TEAL),
			true, LV_FONT_DEFAULT);
		lv_display_set_theme(&display, theme);
	}

	static lv_color_t lv_color(Color c) { return lv_color_make(c.r, c.g, c.b); }
}


struct Faenschterli::App
{
	Name            name    { };
	Title           title   { };
	Name            binary  { };
	Number_of_bytes ram     { };
	unsigned        caps    = 0;
	Color           color   { };
	bool            running = false;

	Title initial() const
	{
		/* the first character, of however many bytes (UTF-8) */
		char const *s = title.string();
		unsigned char const lead = (unsigned char)s[0];
		size_t n = (lead >= 0xf0) ? 4 : (lead >= 0xe0) ? 3 : (lead >= 0xc0) ? 2 : 1;
		if (!lead || strlen(s) < n)
			return Title("?");
		return Title(Cstring(s, n));
	}
};


/*
 * The installed apps, hand-written for now:
 *
 *   catalog
 *   + app phone | title: Phone | binary: phone | ram: 48M | caps: 300
 *               | color: #43a047
 */
struct Faenschterli::Catalog
{
	static constexpr unsigned MAX = 16;

	App      apps[MAX] { };
	unsigned count = 0;

	Catalog(Node const &catalog)
	{
		catalog.for_each_sub_node("app", [&] (Node const &node) {
			if (count == MAX)
				return;
			App &app = apps[count++];
			app.name   = node.attribute_value("name",   Name());
			app.title  = node.attribute_value("title",  Title(app.name));
			app.binary = node.attribute_value("binary", app.name);
			app.ram    = node.attribute_value("ram",    Number_of_bytes(32*1024*1024));
			app.caps   = node.attribute_value("caps",   300u);
			app.color  = node.attribute_value("color",  Color::rgb(0x60, 0x60, 0x60));
		});
	}

	void for_each(auto const &fn)
	{
		for (unsigned i = 0; i < count; i++)
			fn(i, apps[i]);
	}
};


struct Faenschterli::Action : Interface
{
	virtual void launcher_button() = 0;
	virtual void running_button()  = 0;
	virtual void keyboard_button() = 0;
	virtual void start(unsigned app) = 0;
	virtual void front(unsigned app) = 0;
	virtual void stop(unsigned app)  = 0;
	virtual void notification_tapped() = 0;
	virtual void answer(bool accept) = 0;
	virtual void volume(int step) = 0;
};


/*
 * Callback of an LVGL event that carries the action and an app index
 */
template <void (*FN)(Faenschterli::Action &, unsigned)>
static void _app_event(lv_event_t *e)
{
	lv_obj_t *obj = (lv_obj_t *)lv_event_get_current_target(e);
	FN(*(Faenschterli::Action *)lv_event_get_user_data(e),
	   unsigned(uintptr_t(lv_obj_get_user_data(obj))));
}


struct Faenschterli::Status_bar : Lvgl_genode::Window::Ui
{
	lv_obj_t *_title = nullptr, *_network = nullptr, *_bars[4] { }, *_bell = nullptr;

	unsigned _notes = 0;

	/* the number of current notifications, as a bell */
	void notes(unsigned count)
	{
		_notes = count;
		if (!_bell) return;
		lv_obj_set_hidden(_bell, count == 0);
		lv_label_set_text_fmt(_bell, LV_SYMBOL_BELL " %u", count);
	}

	Title _text { };

	/* the network, from 'modem_link' ("network_state") */
	Title _network_text { "No service" };
	int   _signal = -1;   /* bars 0..4, -1: none */

	void _apply_network()
	{
		if (!_network) return;
		lv_label_set_text(_network, _network_text.string());
		for (int i = 0; i < 4; i++)
			lv_obj_set_style_bg_opa(_bars[i], i < _signal ? LV_OPA_COVER : LV_OPA_30, 0);
	}

	void create(lv_display_t &display) override
	{
		dark_theme(display);

		lv_obj_t *screen = lv_display_get_screen_active(&display);
		lv_obj_set_style_bg_color(screen, lv_color_black(), 0);
		lv_obj_set_style_pad_hor(screen, 16, 0);
		lv_obj_set_flex_flow(screen, LV_FLEX_FLOW_ROW);
		lv_obj_set_flex_align(screen, LV_FLEX_ALIGN_SPACE_BETWEEN,
		                      LV_FLEX_ALIGN_CENTER, LV_FLEX_ALIGN_CENTER);
		lv_obj_set_scrollable(screen, false);

		lv_obj_set_style_text_font(screen, &lv_font_montserrat_48, 0);

		_title = lv_label_create(screen);
		lv_label_set_text(_title, _text.string());

		lv_obj_t *right = lv_obj_create(screen);
		lv_obj_set_size(right, LV_SIZE_CONTENT, lv_pct(100));
		lv_obj_set_style_bg_opa(right, LV_OPA_TRANSP, 0);
		lv_obj_set_style_border_width(right, 0, 0);
		lv_obj_set_style_pad_all(right, 0, 0);
		lv_obj_set_style_pad_column(right, 16, 0);
		lv_obj_set_flex_flow(right, LV_FLEX_FLOW_ROW);
		lv_obj_set_flex_align(right, LV_FLEX_ALIGN_END, LV_FLEX_ALIGN_CENTER,
		                      LV_FLEX_ALIGN_CENTER);
		lv_obj_set_scrollable(right, false);

		/* the operator and the technology, then the signal as four bars */
		_network = lv_label_create(right);
		lv_obj_set_style_text_font(_network, LV_FONT_DEFAULT, 0);

		lv_obj_t *bars = lv_obj_create(right);
		lv_obj_set_size(bars, 4*12 + 3*6, 40);
		lv_obj_set_style_bg_opa(bars, LV_OPA_TRANSP, 0);
		lv_obj_set_style_border_width(bars, 0, 0);
		lv_obj_set_style_pad_all(bars, 0, 0);
		lv_obj_set_style_pad_column(bars, 6, 0);
		lv_obj_set_flex_flow(bars, LV_FLEX_FLOW_ROW);
		lv_obj_set_flex_align(bars, LV_FLEX_ALIGN_START, LV_FLEX_ALIGN_END,
		                      LV_FLEX_ALIGN_END);
		lv_obj_set_scrollable(bars, false);
		for (int i = 0; i < 4; i++) {
			_bars[i] = lv_obj_create(bars);
			lv_obj_set_size(_bars[i], 12, 10*(i + 1));
			lv_obj_set_style_radius(_bars[i], 2, 0);
			lv_obj_set_style_border_width(_bars[i], 0, 0);
			lv_obj_set_style_bg_color(_bars[i], lv_color_white(), 0);
		}

		_bell = lv_label_create(right);
		lv_obj_set_style_text_font(_bell, LV_FONT_DEFAULT, 0);

		lv_label_set_text(lv_label_create(right), LV_SYMBOL_BATTERY_FULL);

		_apply_network();
		notes(_notes);
	}

	/**
	 * Show the network state
	 *
	 *   network_state | status: registered | operator: Swisscom
	 *                 | technology: LTE | bars: 3
	 */
	void network(Node const &state)
	{
		using Value = String<32>;
		Value const status = state.attribute_value("status",     Value("off"));
		Value const oper   = state.attribute_value("operator",   Value());
		Value const tech   = state.attribute_value("technology", Value());

		bool const on_network = (status == "registered" || status == "roaming");

		_signal = on_network ? state.attribute_value("bars", 0) : -1;
		_network_text = on_network ? Title(oper, " ", tech, status == "roaming" ? " R" : "")
		              : status == "no sim"    ? Title("No SIM")
		              : status == "pin"       ? Title("SIM PIN")
		              : status == "searching" ? Title("Searching")
		              : status == "denied"    ? Title("Emergency only")
		              :                         Title("No service");
		_apply_network();
	}

	void title(char const *text)
	{
		_text = text;
		if (_title) lv_label_set_text(_title, text);
	}
};


struct Faenschterli::Button_bar : Lvgl_genode::Window::Ui
{
	Action &_action;

	lv_obj_t *_launcher = nullptr, *_running = nullptr, *_keyboard = nullptr;

	bool _launcher_checked = false, _running_checked = false, _keyboard_checked = false;

	Button_bar(Action &action) : _action(action) { }

	Button_bar(Button_bar const &) = delete;
	Button_bar &operator = (Button_bar const &) = delete;

	static void _launcher_clicked(lv_event_t *e) {
		((Action *)lv_event_get_user_data(e))->launcher_button(); }

	static void _running_clicked(lv_event_t *e) {
		((Action *)lv_event_get_user_data(e))->running_button(); }

	static void _keyboard_clicked(lv_event_t *e) {
		((Action *)lv_event_get_user_data(e))->keyboard_button(); }

	lv_obj_t *_button(lv_obj_t *parent, char const *symbol, lv_event_cb_t cb)
	{
		lv_obj_t *button = lv_button_create(parent);
		lv_obj_set_size(button, lv_pct(28), lv_pct(80));
		lv_obj_set_checkable(button, true);
		lv_obj_t *label = lv_label_create(button);
		lv_label_set_text(label, symbol);
		lv_obj_center(label);
		lv_obj_add_event_cb(button, cb, LV_EVENT_CLICKED, &_action);
		return button;
	}

	void create(lv_display_t &display) override
	{
		dark_theme(display);

		lv_obj_t *screen = lv_display_get_screen_active(&display);
		lv_obj_set_style_bg_color(screen, lv_color_black(), 0);
		lv_obj_set_flex_flow(screen, LV_FLEX_FLOW_ROW);
		lv_obj_set_flex_align(screen, LV_FLEX_ALIGN_SPACE_EVENLY,
		                      LV_FLEX_ALIGN_CENTER, LV_FLEX_ALIGN_CENTER);
		lv_obj_set_scrollable(screen, false);

		_launcher = _button(screen, LV_SYMBOL_HOME,     _launcher_clicked);
		_running  = _button(screen, LV_SYMBOL_LIST,     _running_clicked);
		_keyboard = _button(screen, LV_SYMBOL_KEYBOARD, _keyboard_clicked);

		state(_launcher_checked, _running_checked, _keyboard_checked);
	}

	static void _checked(lv_obj_t *button, bool checked)
	{
		if (!button) return;
		if (checked) lv_obj_add_state(button, LV_STATE_CHECKED);
		else         lv_obj_remove_state(button, LV_STATE_CHECKED);
	}

	void state(bool launcher, bool running, bool keyboard)
	{
		_launcher_checked = launcher;
		_running_checked  = running;
		_keyboard_checked = keyboard;

		_checked(_launcher, launcher);
		_checked(_running,  running);
		_checked(_keyboard, keyboard);
	}
};


struct Faenschterli::Pages : Lvgl_genode::Window::Ui
{
	Action  &_action;
	Catalog &_catalog;

	lv_obj_t *_launcher = nullptr, *_running = nullptr, *_running_list = nullptr;
	lv_obj_t *_notes    = nullptr;

	bool _show_launcher = true;

	/* the current notifications, listed above the apps of the launcher */
	struct Note { Title title; Title text; unsigned app; };

	static constexpr unsigned MAX_NOTES = 6;

	Note     _note[MAX_NOTES] { };
	unsigned _note_count = 0;

	Pages(Action &action, Catalog &catalog) : _action(action), _catalog(catalog) { }

	Pages(Pages const &) = delete;
	Pages &operator = (Pages const &) = delete;

	static void _start(Action &action, unsigned app) { action.start(app); }
	static void _front(Action &action, unsigned app) { action.front(app); }
	static void _stop (Action &action, unsigned app) { action.stop(app); }

	static lv_obj_t *_page(lv_obj_t *screen, char const *title)
	{
		lv_obj_t *page = lv_obj_create(screen);
		lv_obj_set_size(page, lv_pct(100), lv_pct(100));
		lv_obj_set_style_border_width(page, 0, 0);
		lv_obj_set_style_radius(page, 0, 0);
		lv_obj_set_flex_flow(page, LV_FLEX_FLOW_COLUMN);
		lv_obj_set_style_pad_all(page, 24, 0);
		lv_obj_set_style_pad_row(page, 24, 0);

		lv_obj_t *label = lv_label_create(page);
		lv_obj_set_style_text_font(label, &lv_font_montserrat_48, 0);
		lv_label_set_text(label, title);
		return page;
	}

	/* a round icon with the app's initial, the title below */
	void _tile(lv_obj_t *grid, unsigned index, App const &app)
	{
		lv_obj_t *tile = lv_obj_create(grid);
		lv_obj_set_size(tile, lv_pct(45), LV_SIZE_CONTENT);
		lv_obj_set_style_bg_opa(tile, LV_OPA_TRANSP, 0);
		lv_obj_set_style_border_width(tile, 0, 0);
		lv_obj_set_flex_flow(tile, LV_FLEX_FLOW_COLUMN);
		lv_obj_set_flex_align(tile, LV_FLEX_ALIGN_START, LV_FLEX_ALIGN_CENTER,
		                      LV_FLEX_ALIGN_CENTER);
		lv_obj_set_scrollable(tile, false);
		lv_obj_set_user_data(tile, (void *)uintptr_t(index));
		lv_obj_add_event_cb(tile, _app_event<_start>, LV_EVENT_CLICKED, &_action);

		lv_obj_t *icon = lv_obj_create(tile);
		lv_obj_set_size(icon, 128, 128);
		lv_obj_set_style_radius(icon, LV_RADIUS_CIRCLE, 0);
		lv_obj_set_style_bg_color(icon, lv_color(app.color), 0);
		lv_obj_set_style_border_width(icon, 0, 0);
		lv_obj_set_clickable(icon, false);
		lv_obj_set_scrollable(icon, false);

		lv_obj_t *initial = lv_label_create(icon);
		lv_obj_set_style_text_font(initial, &lv_font_montserrat_48, 0);
		lv_label_set_text(initial, app.initial().string());
		lv_obj_center(initial);

		lv_obj_t *title = lv_label_create(tile);
		lv_label_set_text(title, app.title.string());
	}

	void create(lv_display_t &display) override
	{
		dark_theme(display);

		lv_obj_t *screen = lv_display_get_screen_active(&display);
		lv_obj_set_scrollable(screen, false);

		_launcher = _page(screen, "Apps");
		lv_obj_t *grid = lv_obj_create(_launcher);
		lv_obj_set_size(grid, lv_pct(100), LV_SIZE_CONTENT);
		lv_obj_set_style_bg_opa(grid, LV_OPA_TRANSP, 0);
		lv_obj_set_style_border_width(grid, 0, 0);
		lv_obj_set_style_pad_all(grid, 0, 0);
		lv_obj_set_flex_flow(grid, LV_FLEX_FLOW_ROW_WRAP);
		lv_obj_set_flex_align(grid, LV_FLEX_ALIGN_SPACE_EVENLY,
		                      LV_FLEX_ALIGN_START, LV_FLEX_ALIGN_START);
		_catalog.for_each([&] (unsigned i, App const &app) { _tile(grid, i, app); });

		_notes = lv_obj_create(_launcher);
		lv_obj_set_size(_notes, lv_pct(100), LV_SIZE_CONTENT);
		lv_obj_set_style_bg_opa(_notes, LV_OPA_TRANSP, 0);
		lv_obj_set_style_border_width(_notes, 0, 0);
		lv_obj_set_style_pad_all(_notes, 0, 0);
		lv_obj_set_style_pad_row(_notes, 16, 0);
		lv_obj_set_flex_flow(_notes, LV_FLEX_FLOW_COLUMN);
		lv_obj_set_scrollable(_notes, false);
		lv_obj_move_to_index(_notes, 1);   /* below the title, above the apps */
		_update_notes();

		_running = _page(screen, "Running");
		_running_list = lv_obj_create(_running);
		lv_obj_set_width(_running_list, lv_pct(100));
		lv_obj_set_flex_grow(_running_list, 1);
		lv_obj_set_style_bg_opa(_running_list, LV_OPA_TRANSP, 0);
		lv_obj_set_style_border_width(_running_list, 0, 0);
		lv_obj_set_style_pad_all(_running_list, 0, 0);
		lv_obj_set_style_pad_row(_running_list, 16, 0);
		lv_obj_set_flex_flow(_running_list, LV_FLEX_FLOW_COLUMN);

		update_running();
		show(_show_launcher);
	}

	void _update_notes()
	{
		if (!_notes) return;

		lv_obj_clean(_notes);
		lv_obj_set_hidden(_notes, _note_count == 0);

		for (unsigned i = 0; i < _note_count; i++) {
			Note const &n = _note[i];

			/* a tap opens the app */
			lv_obj_t *row = lv_button_create(_notes);
			lv_obj_set_size(row, lv_pct(100), LV_SIZE_CONTENT);
			lv_obj_set_style_bg_color(row, lv_color(_catalog.apps[n.app].color), 0);
			lv_obj_set_user_data(row, (void *)uintptr_t(n.app));
			lv_obj_add_event_cb(row, _app_event<_start>, LV_EVENT_CLICKED, &_action);

			lv_obj_t *label = lv_label_create(row);
			lv_obj_set_style_text_font(label, &lv_font_montserrat_48, 0);
			lv_obj_set_width(label, lv_pct(100));
			lv_label_set_long_mode(label, LV_LABEL_LONG_MODE_DOTS);
			lv_label_set_text_fmt(label, LV_SYMBOL_BELL "  %s\n%s",
			                      n.title.string(), n.text.string());
		}
	}

	/**
	 * Set the current notifications
	 *
	 * 'fn' is called with a function to add one (title, text, app index).
	 */
	void notes(auto const &fn)
	{
		_note_count = 0;
		fn([&] (Title const &title, Title const &text, unsigned app) {
			if (_note_count < MAX_NOTES)
				_note[_note_count++] = { title, text, app }; });
		_update_notes();
	}

	void show(bool launcher)
	{
		_show_launcher = launcher;
		if (!_launcher) return;
		if (launcher) {
			lv_obj_set_hidden(_launcher, false);
			lv_obj_set_hidden(_running, true);
		} else {
			lv_obj_set_hidden(_launcher, true);
			lv_obj_set_hidden(_running, false);
		}
	}

	void update_running()
	{
		if (!_running_list) return;

		lv_obj_clean(_running_list);

		bool any = false;
		_catalog.for_each([&] (unsigned i, App const &app) {
			if (!app.running)
				return;
			any = true;

			/* the row brings the app to the front, its button stops it */
			lv_obj_t *row = lv_button_create(_running_list);
			lv_obj_set_size(row, lv_pct(100), LV_SIZE_CONTENT);
			lv_obj_set_flex_flow(row, LV_FLEX_FLOW_ROW);
			lv_obj_set_flex_align(row, LV_FLEX_ALIGN_SPACE_BETWEEN,
			                      LV_FLEX_ALIGN_CENTER, LV_FLEX_ALIGN_CENTER);
			lv_obj_set_user_data(row, (void *)uintptr_t(i));
			lv_obj_add_event_cb(row, _app_event<_front>, LV_EVENT_CLICKED, &_action);

			lv_obj_t *title = lv_label_create(row);
			lv_label_set_text(title, app.title.string());

			lv_obj_t *stop = lv_button_create(row);
			lv_obj_set_user_data(stop, (void *)uintptr_t(i));
			lv_obj_set_style_bg_color(stop, lv_palette_main(LV_PALETTE_RED), 0);
			lv_obj_t *label = lv_label_create(stop);
			lv_label_set_text(label, LV_SYMBOL_CLOSE);
			lv_obj_add_event_cb(stop, _app_event<_stop>, LV_EVENT_CLICKED, &_action);
		});

		if (!any)
			lv_label_set_text(lv_label_create(_running_list), "No app is running");
	}
};


/*
 * A floating window: a card with rounded corners and a shadow, in a
 * translucent window that leaves the margin around it to the windows below
 */
struct Faenschterli::Overlay : Lvgl_genode::Window::Ui
{
	static constexpr int MARGIN = 24;

	Action &_action;

	lv_obj_t *_card = nullptr;

	Overlay(Action &action) : _action(action) { }

	Overlay(Overlay const &) = delete;
	Overlay &operator = (Overlay const &) = delete;

	lv_obj_t *_create_card(lv_display_t &display)
	{
		dark_theme(display);

		lv_obj_t *screen = lv_display_get_screen_active(&display);
		lv_obj_set_scrollable(screen, false);
		lv_obj_set_style_pad_all(screen, MARGIN, 0);

		_card = lv_obj_create(screen);
		lv_obj_set_size(_card, lv_pct(100), lv_pct(100));
		lv_obj_set_style_radius(_card, 40, 0);
		lv_obj_set_style_border_width(_card, 0, 0);
		lv_obj_set_style_bg_color(_card, lv_color_hex(0x2c2f33), 0);
		lv_obj_set_style_bg_opa(_card, LV_OPA_COVER, 0);
		lv_obj_set_style_shadow_width(_card, MARGIN, 0);
		lv_obj_set_style_shadow_opa(_card, LV_OPA_60, 0);
		lv_obj_set_style_shadow_color(_card, lv_color_black(), 0);
		lv_obj_set_style_pad_hor(_card, 32, 0);
		lv_obj_set_style_pad_column(_card, 32, 0);
		lv_obj_set_flex_flow(_card, LV_FLEX_FLOW_ROW);
		lv_obj_set_flex_align(_card, LV_FLEX_ALIGN_START, LV_FLEX_ALIGN_CENTER,
		                      LV_FLEX_ALIGN_CENTER);
		lv_obj_set_scrollable(_card, false);
		return _card;
	}
};


struct Faenschterli::Notification : Overlay
{
	lv_obj_t *_icon = nullptr, *_initial = nullptr, *_title = nullptr, *_text = nullptr;

	App const *_app = nullptr;

	Title _title_text { }, _body_text { };

	using Overlay::Overlay;

	static void _tapped(lv_event_t *e) {
		((Action *)lv_event_get_user_data(e))->notification_tapped(); }

	void _apply()
	{
		if (!_card || !_app) return;
		lv_obj_set_style_bg_color(_icon, lv_color(_app->color), 0);
		lv_label_set_text(_initial, _app->initial().string());
		lv_label_set_text(_title, _title_text.string());
		lv_label_set_text(_text,  _body_text.string());
	}

	void create(lv_display_t &display) override
	{
		lv_obj_t *card = _create_card(display);
		lv_obj_add_event_cb(card, _tapped, LV_EVENT_CLICKED, &_action);

		_icon = lv_obj_create(card);
		lv_obj_set_size(_icon, 112, 112);
		lv_obj_set_style_radius(_icon, LV_RADIUS_CIRCLE, 0);
		lv_obj_set_style_border_width(_icon, 0, 0);
		lv_obj_set_clickable(_icon, false);
		lv_obj_set_scrollable(_icon, false);
		_initial = lv_label_create(_icon);
		lv_obj_set_style_text_font(_initial, &lv_font_montserrat_48, 0);
		lv_obj_center(_initial);

		lv_obj_t *column = lv_obj_create(card);
		lv_obj_set_height(column, LV_SIZE_CONTENT);
		lv_obj_set_flex_grow(column, 1);
		lv_obj_set_style_bg_opa(column, LV_OPA_TRANSP, 0);
		lv_obj_set_style_border_width(column, 0, 0);
		lv_obj_set_style_pad_all(column, 0, 0);
		lv_obj_set_flex_flow(column, LV_FLEX_FLOW_COLUMN);
		lv_obj_set_clickable(column, false);
		lv_obj_set_scrollable(column, false);

		_title = lv_label_create(column);
		lv_obj_set_style_text_font(_title, &lv_font_montserrat_48, 0);
		_text = lv_label_create(column);
		lv_obj_set_style_text_font(_text, &lv_font_montserrat_48, 0);
		lv_obj_set_size(_text, lv_pct(100), lv_font_get_line_height(&lv_font_montserrat_48));
		lv_label_set_long_mode(_text, LV_LABEL_LONG_MODE_DOTS);

		_apply();
	}

	void show(App const &app, char const *title, char const *text)
	{
		_app = &app; _title_text = title; _body_text = text;
		_apply();
	}
};


/*
 * The incoming call: the caller and the buttons Accept and Reject
 */
struct Faenschterli::Call : Overlay
{
	lv_obj_t *_caller = nullptr;

	Title _caller_text { };

	using Overlay::Overlay;

	static void _accept(lv_event_t *e) { ((Action *)lv_event_get_user_data(e))->answer(true); }
	static void _reject(lv_event_t *e) { ((Action *)lv_event_get_user_data(e))->answer(false); }

	lv_obj_t *_button(lv_obj_t *parent, char const *symbol, lv_palette_t color,
	                  lv_event_cb_t cb)
	{
		lv_obj_t *button = lv_button_create(parent);
		lv_obj_set_size(button, 112, 112);
		lv_obj_set_style_radius(button, LV_RADIUS_CIRCLE, 0);
		lv_obj_set_style_bg_color(button, lv_palette_main(color), 0);
		lv_obj_t *label = lv_label_create(button);
		lv_label_set_text(label, symbol);
		lv_obj_center(label);
		lv_obj_add_event_cb(button, cb, LV_EVENT_CLICKED, &_action);
		return button;
	}

	void create(lv_display_t &display) override
	{
		lv_obj_t *card = _create_card(display);

		lv_obj_t *column = lv_obj_create(card);
		lv_obj_set_height(column, LV_SIZE_CONTENT);
		lv_obj_set_flex_grow(column, 1);
		lv_obj_set_style_bg_opa(column, LV_OPA_TRANSP, 0);
		lv_obj_set_style_border_width(column, 0, 0);
		lv_obj_set_style_pad_all(column, 0, 0);
		lv_obj_set_flex_flow(column, LV_FLEX_FLOW_COLUMN);
		lv_obj_set_scrollable(column, false);

		lv_obj_set_style_min_width(column, 0, 0);
		lv_obj_t *what = lv_label_create(column);
		lv_obj_set_width(what, lv_pct(100));
		lv_label_set_long_mode(what, LV_LABEL_LONG_MODE_DOTS);
		lv_label_set_text(what, "Incoming call");
		_caller = lv_label_create(column);
		lv_obj_set_style_text_font(_caller, &lv_font_montserrat_48, 0);
		lv_obj_set_width(_caller, lv_pct(100));
		lv_label_set_long_mode(_caller, LV_LABEL_LONG_MODE_DOTS);

		_button(card, LV_SYMBOL_CALL,  LV_PALETTE_GREEN, _accept);
		_button(card, LV_SYMBOL_CLOSE, LV_PALETTE_RED,   _reject);

		caller(_caller_text.string());
	}

	void caller(char const *text)
	{
		_caller_text = text;
		if (_caller) lv_label_set_text(_caller, text);
	}
};


struct Faenschterli::Volume : Overlay
{
	lv_obj_t *_bar = nullptr;

	int _level = 5;

	using Overlay::Overlay;

	static void _down(lv_event_t *e) { ((Action *)lv_event_get_user_data(e))->volume(-1); }
	static void _up  (lv_event_t *e) { ((Action *)lv_event_get_user_data(e))->volume(+1); }

	lv_obj_t *_button(lv_obj_t *parent, char const *symbol, lv_event_cb_t cb)
	{
		lv_obj_t *button = lv_button_create(parent);
		lv_obj_set_size(button, 112, 112);
		lv_obj_set_style_radius(button, LV_RADIUS_CIRCLE, 0);
		lv_obj_t *label = lv_label_create(button);
		lv_label_set_text(label, symbol);
		lv_obj_center(label);
		lv_obj_add_event_cb(button, cb, LV_EVENT_CLICKED, &_action);
		return button;
	}

	void create(lv_display_t &display) override
	{
		lv_obj_t *card = _create_card(display);

		lv_obj_t *icon = lv_label_create(card);
		lv_obj_set_style_text_font(icon, &lv_font_montserrat_48, 0);
		lv_label_set_text(icon, LV_SYMBOL_VOLUME_MAX);

		_bar = lv_bar_create(card);
		lv_obj_set_height(_bar, 24);
		lv_obj_set_flex_grow(_bar, 1);
		lv_bar_set_range(_bar, 0, 10);

		_button(card, LV_SYMBOL_MINUS, _down);
		_button(card, LV_SYMBOL_PLUS,  _up);

		level(_level);
	}

	void level(int level)
	{
		_level = level;
		if (_bar) lv_bar_set_value(_bar, level, LV_ANIM_OFF);
	}
};


struct Faenschterli::Main : Action
{
	Env &_env;

	Attached_rom_dataspace _config      { _env, "config" };
	Attached_rom_dataspace _catalog_rom { _env, "catalog" };
	Attached_rom_dataspace _window_list { _env, "window_list" };
	Attached_rom_dataspace _notifications_rom { _env, "notifications" };
	Attached_rom_dataspace _call_state_rom    { _env, "call_state" };
	Attached_rom_dataspace _network_rom       { _env, "network_state" };

	/* the names of the numbers telephony reports */
	Contacts::Connection _contacts { _env };

	Title _name(Title const &number)
	{
		Contacts::Lookup const l = _contacts.lookup(Contacts::Number(number));
		return l.found ? Title(l.name) : number;
	}

	Node const _config_node = _config.node();

	unsigned const _status_height   = _config_node.attribute_value("status_height",   64u);
	unsigned const _buttons_height  = _config_node.attribute_value("buttons_height",  110u);
	unsigned const _keyboard_height = _config_node.attribute_value("keyboard_height", 440u);

	unsigned const _notification_height = _config_node.attribute_value("notification_height", 220u);
	unsigned const _volume_height       = _config_node.attribute_value("volume_height",       180u);

	/* the volume keys, global keys of the GUI server to the session "keys" */
	Input::Keycode const _volume_up_key = Input::key_code(
		_config_node.attribute_value("volume_up_key", Input::Key_name("KEY_VOLUMEUP")));
	Input::Keycode const _volume_down_key = Input::key_code(
		_config_node.attribute_value("volume_down_key", Input::Key_name("KEY_VOLUMEDOWN")));

	/* names of the shell, the keyboard, and the init of the apps, as 'wm' sees them */
	Label const _shell_label    = _config_node.attribute_value("shell_label",    Label("faenschterli"));
	Label const _keyboard_label = _config_node.attribute_value("keyboard_label", Label("keyboard"));
	Label const _runtime_label  = _config_node.attribute_value("runtime_label",  Label("runtime"));

	Catalog _catalog { _catalog_rom.node() };

	Expanding_reporter _rules_reporter { _env, "rules",         "rules" };
	Expanding_reporter _focus_reporter { _env, "focus_request", "focus_request" };
	Expanding_reporter _apps_reporter  { _env, "config",        "apps" };
	Expanding_reporter _volume_reporter { _env, "volume",       "volume" };
	Expanding_reporter _call_action     { _env, "call_action",  "call_action" };
	Expanding_reporter _ui_state        { _env, "ui_state",     "ui_state" };

	enum class Page { NONE, LAUNCHER, RUNNING };

	Page     _page          = Page::LAUNCHER;
	int      _front         = -1;   /* index of the front app */
	bool     _keyboard      = false;
	unsigned _focus_request = 0;

	/* the floating windows, shown until their time is up */
	bool     _notification_shown = false;
	int      _notification_app   = -1;
	bool     _ringing            = false;
	unsigned _call_seq           = 0;    /* of the last call_action */
	bool     _answered           = false; /* the ringing call, on the card */
	bool     _volume_shown       = false;
	int      _volume_level       = 5;

	Lvgl_genode::Runtime _runtime { _env };

	Status_bar _status  { };
	Button_bar _buttons { *this };
	Pages      _pages   { *this, _catalog };

	Notification _notification { *this };
	Call         _call         { *this };
	Volume       _volume       { *this };

	Lvgl_genode::Window _status_window  { _env, _runtime, _status,  "status" };
	Lvgl_genode::Window _buttons_window { _env, _runtime, _buttons, "buttons" };
	Lvgl_genode::Window _pages_window   { _env, _runtime, _pages,   "pages" };

	Lvgl_genode::Window _notification_window { _env, _runtime, _notification,
	                                           "notification", false,
	                                           Lvgl_genode::Window::TRANSLUCENT };
	Lvgl_genode::Window _call_window         { _env, _runtime, _call,
	                                           "call", false,
	                                           Lvgl_genode::Window::TRANSLUCENT };
	Lvgl_genode::Window _volume_window       { _env, _runtime, _volume,
	                                           "volume", false,
	                                           Lvgl_genode::Window::TRANSLUCENT };

	/* receives the volume keys, global keys of the GUI server */
	Gui::Connection _keys { _env, "keys" };

	Signal_handler<Main> _keys_handler {
		_env.ep(), *this, &Main::_handle_keys };

	Signal_handler<Main> _notifications_handler {
		_env.ep(), *this, &Main::_handle_notifications };

	Signal_handler<Main> _call_state_handler {
		_env.ep(), *this, &Main::_handle_call_state };

	void _handle_contacts()
	{
		Signal_transmitter(_notifications_handler).submit();
		Signal_transmitter(_call_state_handler).submit();
	}

	Signal_handler<Main> _contacts_handler {
		_env.ep(), *this, &Main::_handle_contacts };

	Signal_handler<Main> _network_handler {
		_env.ep(), *this, &Main::_handle_network };

	void _handle_network()
	{
		if (_runtime.in_lvgl()) {
			Signal_transmitter(_network_handler).submit();
			return;
		}
		_network_rom.update();
		_status.network(_network_rom.node());
		_runtime.run();
	}

	/*
	 * The notifications seen so far, by id, with their serial: a new
	 * serial of a known id (another message of the same chat) is new
	 */
	struct Seen { Title id; unsigned serial; };

	static constexpr unsigned MAX_SEEN = 32;

	Seen     _seen[MAX_SEEN] { };
	unsigned _seen_next = 0;

	bool _new_notification(Title const &id, unsigned serial)
	{
		for (Seen &seen : _seen)
			if (seen.id == id) {
				bool const fresh = seen.serial != serial;
				seen.serial = serial;
				return fresh;
			}
		_seen[_seen_next] = { id, serial };
		_seen_next = (_seen_next + 1) % MAX_SEEN;
		return true;
	}

	/* one-shot LVGL timers that hide the floating windows */
	lv_timer_t *_notification_timer = nullptr, *_volume_timer = nullptr;

	static void _notification_timeout(lv_timer_t *t)
	{
		Main &main = *(Main *)lv_timer_get_user_data(t);
		main._notification_shown = false;
		main._gen_rules();
	}

	static void _volume_timeout(lv_timer_t *t)
	{
		Main &main = *(Main *)lv_timer_get_user_data(t);
		main._volume_shown = false;
		main._gen_rules();
	}

	static lv_timer_t *_one_shot(lv_timer_cb_t cb, Main &main)
	{
		lv_timer_t *timer = lv_timer_create(cb, 1000, &main);
		lv_timer_set_auto_delete(timer, false);
		lv_timer_pause(timer);
		return timer;
	}

	static void _arm(lv_timer_t *timer, uint32_t ms)
	{
		lv_timer_set_period(timer, ms);
		lv_timer_set_repeat_count(timer, 1);
		lv_timer_reset(timer);
		lv_timer_resume(timer);
	}

	unsigned _screen_width()
	{
		lv_display_t *display = _status_window.display();
		return display ? unsigned(lv_display_get_horizontal_resolution(display)) : 1080;
	}

	Signal_handler<Main> _window_list_handler {
		_env.ep(), *this, &Main::_handle_window_list };

	Label _app_label(unsigned i) const {
		return Label(_runtime_label, " -> ", _catalog.apps[i].name); }

	void _gen_rules()
	{
		_rules_reporter.generate([&] (Generator &g) {

			/*
			 * A row of fixed height also gets 'weight: 0': the layouter
			 * of Sculpt 26.10 checks the column, not the row, for a pixel
			 * size and would weigh fixed rows with 1 too.
			 */
			auto row = [&] (char const *name, unsigned height) {
				g.node("row", [&] {
					g.attribute("name", name);
					if (height) {
						g.attribute("h", height);
						g.attribute("weight", 0u);
					} else
						g.attribute("weight", 1u); }); };

			/* the screen is the target of the floating windows, above all rows */
			g.node("screen", [&] {
				g.attribute("name",  "overlay");
				g.attribute("layer", 1u);
				g.node("column", [&] {
					row("status", _status_height);
					row("apps", 0);
					if (_keyboard)
						row("keyboard", _keyboard_height);
					row("buttons", _buttons_height); }); });

			auto assign = [&] (char const *match, Label const &label,
			                   char const *target, bool visible) {
				g.node("assign", [&] {
					g.attribute(match, label);
					g.attribute("target", target);
					if (!visible) g.attribute("visible", false); }); };

			assign("label", Label(_shell_label, " -> status"),  "status",  true);
			assign("label", Label(_shell_label, " -> buttons"), "buttons", true);
			assign("label_prefix", _keyboard_label, "keyboard", _keyboard);
			assign("label", Label(_shell_label, " -> pages"), "apps", _page != Page::NONE);

			auto floating = [&] (char const *name, unsigned y, unsigned h, bool visible) {
				g.node("assign", [&] {
					g.attribute("label",  Label(_shell_label, " -> ", name));
					g.attribute("target", "overlay");
					g.attribute("xpos",   0u);
					g.attribute("ypos",   y);
					g.attribute("width",  _screen_width());
					g.attribute("height", h);
					if (!visible) g.attribute("visible", false); }); };

			floating("notification", _status_height, _notification_height,
			         _notification_shown && !_call_card());
			floating("call", _status_height, _notification_height, _call_card());
			floating("volume", _status_height + _notification_height, _volume_height,
			         _volume_shown);

			_catalog.for_each([&] (unsigned i, App const &app) {
				if (app.running)
					assign("label_prefix", _app_label(i), "apps",
					       _page == Page::NONE && _front == int(i)); });
		});
	}

	void _gen_apps()
	{
		_apps_reporter.generate([&] (Generator &g) {

			g.node("parent-provides", [&] {
				static char const * const services[] = {
					"ROM", "PD", "CPU", "LOG", "Timer", "Gui", "Report", "Contacts" };
				for (char const *service : services)
					g.node("service", [&] { g.attribute("name", service); }); });

			g.node("default-route", [&] {
				g.node("any-service", [&] { g.node("parent", [&] { }); }); });

			g.node("default", [&] { g.attribute("caps", 100u); });

			_catalog.for_each([&] (unsigned, App const &app) {
				if (!app.running)
					return;
				g.node("start", [&] {
					g.attribute("name", app.name);
					g.attribute("caps", app.caps);
					g.attribute("ram",  String<32>(app.ram));
					g.node("binary", [&] { g.attribute("name", app.binary); });
					g.node("config", [&] {
						g.node("libc", [&] {
							g.attribute("stdout", "/dev/log");
							g.attribute("stderr", "/dev/log"); });
						g.node("pthread", [&] { g.attribute("placement", "all-cpus"); });
						g.node("vfs", [&] {
							g.node("dir", [&] {
								g.attribute("name", "dev");
								g.node("log", [&] { }); }); }); }); });
			});
		});
	}

	/* the keys go to what is shown: the front app, or the shell's page */
	void _gen_focus_request()
	{
		bool const app = (_page == Page::NONE && _front >= 0);

		_focus_request++;
		_focus_reporter.generate([&] (Generator &g) {
			g.attribute("label", app ? _app_label(unsigned(_front))
			                         : Label(_shell_label, " -> pages"));
			g.attribute("id", _focus_request); });
	}

	void _gen_ui_state()
	{
		_ui_state.generate([&] (Generator &g) {
			if (_page == Page::NONE && _front >= 0) {
				g.attribute("state", "app");
				g.attribute("active_app", _catalog.apps[_front].name);
			} else
				g.attribute("state", "launcher");
			g.attribute("display", "on"); });
	}

	void _update()
	{
		_gen_rules();
		_gen_ui_state();
		_gen_focus_request();

		if (_page == Page::LAUNCHER)
			_status.title("Apps");
		else if (_page == Page::RUNNING)
			_status.title("Running");
		else if (_front >= 0)
			_status.title(_catalog.apps[_front].title.string());

		if (_page != Page::NONE)
			_pages.show(_page == Page::LAUNCHER);

		_buttons.state(_page == Page::LAUNCHER, _page == Page::RUNNING, _keyboard);
	}

	/* a page button: show the page, or back to the front app */
	void _toggle_page(Page page)
	{
		_page = (_page == page && _front >= 0) ? Page::NONE : page;
		_update();
	}

	/* a window of the front app appeared: it can take the focus now */
	void _handle_window_list()
	{
		_window_list.update();
		_gen_focus_request();
	}

	/* index of an app in the catalog, -1 if there is none of the name */
	int _app_index(Name const &name)
	{
		int index = -1;
		_catalog.for_each([&] (unsigned i, App const &app) {
			if (app.name == name) index = int(i); });
		return index;
	}

	/* a new notification: shown unless its app is in front */
	void _handle_notifications()
	{
		if (_runtime.in_lvgl()) {
			Signal_transmitter(_notifications_handler).submit();
			return;
		}
		_notifications_rom.update();

		/* the list on the launcher and the bell in the status bar */
		unsigned count = 0;
		_pages.notes([&] (auto const &add) {
			_notifications_rom.node().for_each_sub_node("notification", [&] (Node const &node) {
				int const app = _app_index(node.attribute_value("app", Name()));
				if (app < 0)
					return;
				count++;
				add(_name(node.attribute_value("title", Title())),
				    node.attribute_value("text",  Title()), unsigned(app)); }); });
		_status.notes(count);

		_notifications_rom.node().for_each_sub_node("notification", [&] (Node const &node) {
			Title const id = node.attribute_value("id", Title());
			if (!_new_notification(id, node.attribute_value("serial", 0u)))
				return;

			Name  const name  = node.attribute_value("app",   Name());
			Title const title = _name(node.attribute_value("title", Title()));
			Title const text  = node.attribute_value("text",  Title());

			int const i = _app_index(name);
			if (i < 0)
				return;

			if (_page == Page::NONE && _front == i) {
				log("faenschterli: notification of ", name, " (in front, not shown)");
				return;
			}
			log("faenschterli: notification of ", name, ": ", title, ": ", text);
			_notification_app   = i;
			_notification_shown = true;
			_notification.show(_catalog.apps[i], title.string(), text.string());
			_arm(_notification_timer, 5000);
		});
		_gen_rules();
		_runtime.run();
	}

	/* the call card, shown while a call rings, unless the Phone app is in front */
	bool _call_card()
	{
		int const phone = _app_index("phone");
		return _ringing && !(_page == Page::NONE && phone >= 0 && _front == phone);
	}

	void _handle_call_state()
	{
		if (_runtime.in_lvgl()) {
			Signal_transmitter(_call_state_handler).submit();
			return;
		}
		_call_state_rom.update();
		Node const &call = _call_state_rom.node();

		bool const incoming = call.attribute_value("state", Name()) == "incoming";

		/* continue after our last action, also after a restart */
		_call_seq = max(_call_seq, call.attribute_value("action_seq", 0u));

		/* a call answered on the card does not ring again */
		if (!incoming)
			_answered = false;
		bool const ringing = incoming && !_answered;

		if (ringing) {
			Title const name = _name(call.attribute_value("number", Title()));
			_call.caller(name.string());
			if (!_ringing)
				log("faenschterli: incoming call of ", name);
		}
		if (ringing != _ringing) {
			_ringing = ringing;
			_gen_rules();
		}
		_runtime.run();
	}

	void _handle_keys()
	{
		if (_runtime.in_lvgl()) {
			Signal_transmitter(_keys_handler).submit();
			return;
		}
		_keys.input.for_each_event([&] (Input::Event const &ev) {
			if (ev.key_press(_volume_up_key))   volume(+1);
			if (ev.key_press(_volume_down_key)) volume(-1); });
		_runtime.run();
	}

	/**
	 * Action interface
	 */

	void notification_tapped() override
	{
		_notification_shown = false;
		lv_timer_pause(_notification_timer);
		log("faenschterli: notification opened");
		if (_notification_app >= 0)
			start(unsigned(_notification_app));
		else
			_gen_rules();
	}

	void answer(bool accept) override
	{
		log("faenschterli: call ", accept ? "accepted" : "rejected");
		_call_action.generate([&] (Generator &g) {
			g.attribute("seq",    ++_call_seq);
			g.attribute("action", accept ? "accept" : "reject"); });

		_ringing  = false;
		_answered = true;
		int const phone = _app_index("phone");
		if (accept && phone >= 0)
			start(unsigned(phone));
		else
			_gen_rules();
	}

	void volume(int step) override
	{
		_volume_level = max(0, min(10, _volume_level + step));
		_volume.level(_volume_level);
		log("faenschterli: volume ", _volume_level);
		_volume_reporter.generate([&] (Generator &g) {
			g.attribute("level", _volume_level); });

		_arm(_volume_timer, 3000);
		if (!_volume_shown) {
			_volume_shown = true;
			_gen_rules();
		}
	}

	void launcher_button() override { _toggle_page(Page::LAUNCHER); }
	void running_button()  override { _toggle_page(Page::RUNNING); }

	void keyboard_button() override
	{
		_keyboard = !_keyboard;
		log("faenschterli: keyboard ", _keyboard ? "shown" : "hidden");
		_update();
	}

	void start(unsigned i) override
	{
		App &app = _catalog.apps[i];
		if (!app.running) {
			app.running = true;
			log("faenschterli: start ", app.name);
			_gen_apps();
			_pages.update_running();
		}
		front(i);
	}

	void front(unsigned i) override
	{
		_front = int(i);
		_page  = Page::NONE;
		log("faenschterli: front ", _catalog.apps[i].name);
		_update();
		_gen_focus_request();
	}

	void stop(unsigned i) override
	{
		App &app = _catalog.apps[i];
		if (!app.running)
			return;

		app.running = false;
		log("faenschterli: stop ", app.name);

		if (_front == int(i))
			_front = -1;

		_gen_apps();
		_pages.update_running();
		_update();
	}

	Main(Main const &) = delete;
	Main &operator = (Main const &) = delete;

	Main(Env &env) : _env(env)
	{
		_notification_timer = _one_shot(_notification_timeout, *this);
		_volume_timer       = _one_shot(_volume_timeout,       *this);

		_window_list.sigh(_window_list_handler);
		_notifications_rom.sigh(_notifications_handler);
		_call_state_rom   .sigh(_call_state_handler);

		/* the names changed: the cards and the list again */
		_contacts.sigh(_contacts_handler);
		_network_rom      .sigh(_network_handler);
		_handle_network();

		/* what was there before the start is not new, but listed */
		_notifications_rom.node().for_each_sub_node("notification", [&] (Node const &node) {
			_new_notification(node.attribute_value("id", Title()),
			                  node.attribute_value("serial", 0u)); });
		Signal_transmitter(_notifications_handler).submit();
		_keys.input.sigh(_keys_handler);
		_gen_apps();
		_update();
	}
};


void Libc::Component::construct(Libc::Env &env)
{
	static Faenschterli::Main main(env);
}
