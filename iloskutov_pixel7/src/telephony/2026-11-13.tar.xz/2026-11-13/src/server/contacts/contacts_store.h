/*
 * \brief  Contacts with their labelled numbers, kept in name order
 * \author Ivan Loskutov
 * \date   2026-10-01
 *
 * The model of the contacts service, free of session and file code.
 *
 * A number matches another one when their normal forms (digits only,
 * without a leading '00' or a leading national '0') are equal, or when
 * one ends with the other and the shorter one has at least 7
 * digits ('Telephony::same_number'). So '+41 76 000 00 01', '0041760000001' and '076 000 00 01' are
 * one number, while a short number (e.g. 144) matches only itself.
 *
 * Stored as
 *
 *   contacts | next_id: 4
 *   + contact | id: 1 | name: Alice
 *     + number | label: mobile | value: +41760000001
 *     + number | label: work   | value: 0440000002
 *
 * Unknown attributes and nodes are ignored on load.
 */

/*
 * SPDX-License-Identifier: MIT
 */

#ifndef _CONTACTS_STORE_H_
#define _CONTACTS_STORE_H_

/* Genode includes */
#include <base/log.h>
#include <base/node.h>
#include <util/misc_math.h>

/* contacts includes */
#include <contacts_session/types.h>
#include <phone_number.h>

namespace Contacts { struct Contacts_store; }


struct Contacts::Contacts_store
{
	static constexpr unsigned MAX_CONTACTS   = 200;
	static constexpr unsigned MAX_NUMBERS    = 8;
	static constexpr unsigned MAX_NAME_CHARS = 40;

	struct Entry
	{
		Id       id;
		Name     name;
		Phone    numbers[MAX_NUMBERS];
		unsigned num_numbers;
	};

	Entry    _entries[MAX_CONTACTS] { };   /* in name order */
	unsigned _count      = 0;
	unsigned _next_id    = 1;
	unsigned _generation = 0;

	/**
	 * Make text storable as node attribute
	 *
	 * Separators and control characters become spaces, runs of spaces
	 * collapse, the ends are trimmed (as 'Phone_store::sanitize').
	 */
	template <Genode::size_t N>
	static Genode::String<N> sanitized(Genode::String<N> const &text)
	{
		char buf[N] { };
		Genode::size_t n = 0;
		bool space = false;

		for (char const *c = text.string(); *c && n < sizeof(buf) - 1; c++) {
			bool const blank = (*c == '|' || (unsigned char)*c < 0x20 || *c == ' ');
			if (blank) {
				if (!space && n > 0)
					buf[n++] = ' ';
				space = true;
				continue;
			}
			buf[n++] = *c;
			space = false;
		}
		while (n > 0 && buf[n - 1] == ' ')
			n--;
		buf[n] = 0;
		return Genode::String<N>(Genode::Cstring(buf));
	}

	/**
	 * Number of characters (not bytes) of UTF-8 text
	 */
	static unsigned _chars(char const *s)
	{
		unsigned n = 0;
		for (; *s; s++)
			if (((unsigned char)*s & 0xc0) != 0x80)
				n++;
		return n;
	}

	/**
	 * A sanitized name is valid with 1 to MAX_NAME_CHARS characters
	 */
	static bool valid_name(Name const &name)
	{
		unsigned const chars = _chars(name.string());
		return chars >= 1 && chars <= MAX_NAME_CHARS;
	}

	/**
	 * An optional leading '+', then 3 to 32 digits, '*' or '#' (as
	 * 'Phone_store::valid_number')
	 */
	static bool valid_number(Number const &number)
	{
		char const *s = number.string();
		Genode::size_t const len = Genode::strlen(s);
		Genode::size_t digits = 0;

		for (Genode::size_t i = 0; i < len; i++) {
			char const c = s[i];
			if (c == '+' && i == 0)
				continue;
			if ((c >= '0' && c <= '9') || c == '*' || c == '#') {
				digits++;
				continue;
			}
			return false;
		}
		return digits >= 3 && digits <= 32;
	}

	static bool matches(Number const &a, Number const &b)
	{
		return Telephony::same_number(a, b);
	}

	static char _lower(char c) { return (c >= 'A' && c <= 'Z') ? char(c - 'A' + 'a') : c; }

	/**
	 * Name order: letter case ignored, equal names by id
	 */
	static bool _before(Entry const &a, Entry const &b)
	{
		char const *s = a.name.string(), *t = b.name.string();
		for (; *s && *t; s++, t++) {
			unsigned char const x = (unsigned char)_lower(*s),
			                    y = (unsigned char)_lower(*t);
			if (x != y)
				return x < y;
		}
		if (*s || *t)
			return !*s;

		int const exact = Genode::strcmp(a.name.string(), b.name.string());
		return exact ? exact < 0 : a.id.value < b.id.value;
	}

	Entry *_lookup(Id id)
	{
		if (id.value)
			for (unsigned i = 0; i < _count; i++)
				if (_entries[i].id.value == id.value)
					return &_entries[i];
		return nullptr;
	}

	Entry const *_lookup(Id id) const
	{
		return const_cast<Contacts_store *>(this)->_lookup(id);
	}

	void _insert(Entry const &entry)
	{
		unsigned at = _count;
		while (at > 0 && _before(entry, _entries[at - 1])) {
			_entries[at] = _entries[at - 1];
			at--;
		}
		_entries[at] = entry;
		_count++;
	}

	void _remove_at(unsigned at)
	{
		for (unsigned i = at + 1; i < _count; i++)
			_entries[i - 1] = _entries[i];
		_count--;
		_entries[_count] = { };
	}

	/**
	 * Number of changes so far
	 */
	unsigned generation() const { return _generation; }

	unsigned count() const { return _count; }

	/**
	 * Contact at 'index' of the name order
	 */
	Contact contact(unsigned index) const
	{
		if (index >= _count)
			return { };

		Entry const &e = _entries[index];
		return { .valid = true, .id = e.id, .name = e.name, .numbers = e.num_numbers };
	}

	Phone number(Id id, unsigned index) const
	{
		Entry const * const e = _lookup(id);
		if (!e || index >= Genode::min(e->num_numbers, MAX_NUMBERS))
			return { };

		return e->numbers[index];
	}

	/**
	 * First contact in name order with a number matching 'number'
	 */
	Lookup lookup(Number const &number) const
	{
		for (unsigned i = 0; i < _count; i++) {
			Entry const &e = _entries[i];
			for (unsigned j = 0; j < e.num_numbers; j++)
				if (matches(e.numbers[j].number, number))
					return { .found = true, .id = e.id, .name = e.name };
		}
		return { };
	}

	Added add(Name const &name)
	{
		Name const clean = sanitized(name);
		if (!valid_name(clean))
			return { Result::INVALID, { 0 } };

		if (_count == MAX_CONTACTS)
			return { Result::FULL, { 0 } };

		Id const id { _next_id++ };
		_insert({ .id = id, .name = clean, .numbers = { }, .num_numbers = 0 });
		_generation++;
		return { Result::OK, id };
	}

	Result rename(Id id, Name const &name)
	{
		Entry const * const e = _lookup(id);
		if (!e)
			return Result::UNKNOWN;

		Name const clean = sanitized(name);
		if (!valid_name(clean))
			return Result::INVALID;

		if (clean == e->name)
			return Result::OK;

		/* take the contact out and put it back at its new place */
		Entry renamed = *e;
		renamed.name = clean;
		_remove_at(unsigned(e - _entries));
		_insert(renamed);
		_generation++;
		return Result::OK;
	}

	Result remove(Id id)
	{
		Entry const * const e = _lookup(id);
		if (!e)
			return Result::UNKNOWN;

		_remove_at(unsigned(e - _entries));
		_generation++;
		return Result::OK;
	}

	Result add_number(Id id, Label const &label, Number const &number)
	{
		Entry * const e = _lookup(id);
		if (!e)
			return Result::UNKNOWN;

		if (!valid_number(number))
			return Result::INVALID;

		if (e->num_numbers == MAX_NUMBERS)
			return Result::FULL;

		e->numbers[e->num_numbers++] = { .valid  = true,
		                                 .label  = sanitized(label),
		                                 .number = number };
		_generation++;
		return Result::OK;
	}

	Result remove_number(Id id, unsigned index)
	{
		Entry * const e = _lookup(id);
		if (!e || index >= Genode::min(e->num_numbers, MAX_NUMBERS))
			return Result::UNKNOWN;

		for (unsigned i = index + 1; i < e->num_numbers; i++)
			e->numbers[i - 1] = e->numbers[i];
		e->num_numbers--;
		e->numbers[e->num_numbers] = { };
		_generation++;
		return Result::OK;
	}

	/**
	 * Generate the content of the store node (see the file header)
	 */
	void gen_store(Genode::Generator &g) const
	{
		g.attribute("next_id", _next_id);

		for (unsigned i = 0; i < _count; i++) {
			Entry const &e = _entries[i];
			g.node("contact", [&] {
				g.attribute("id",   e.id.value);
				g.attribute("name", e.name);
				for (unsigned j = 0; j < e.num_numbers; j++)
					g.node("number", [&] {
						if (e.numbers[j].label.length() > 1)
							g.attribute("label", e.numbers[j].label);
						g.attribute("value", e.numbers[j].number);
					});
			});
		}
	}

	/**
	 * Call 'fn(Label, Number)' for each valid number of a contact node
	 */
	static void _for_each_number(Genode::Node const &contact, auto const &fn)
	{
		contact.for_each_sub_node("number", [&] (Genode::Node const &n) {
			Number const value = n.attribute_value("value", Number());
			if (valid_number(value))
				fn(sanitized(n.attribute_value("label", Label())), value);
			else
				Genode::warning("contact number '", value, "' ignored");
		});
	}

	/**
	 * Replace the contacts by the ones of a store node
	 *
	 * Contacts keep their ids. A contact without a usable id gets a new
	 * one, a contact without a valid name is dropped.
	 */
	void load(Genode::Node const &store)
	{
		for (unsigned i = 0; i < _count; i++)
			_entries[i] = { };
		_count = 0;

		unsigned max_id = 0, dropped = 0;

		store.for_each_sub_node("contact", [&] (Genode::Node const &c) {

			Entry entry { };
			entry.name = sanitized(c.attribute_value("name", Name()));
			if (!valid_name(entry.name) || _count == MAX_CONTACTS) {
				dropped++;
				return;
			}

			entry.id = { c.attribute_value("id", 0U) };
			if (_lookup(entry.id))
				entry.id = { 0 };   /* used already, replaced below */
			max_id = Genode::max(max_id, entry.id.value);

			_for_each_number(c, [&] (Label const &label, Number const &number) {
				if (entry.num_numbers < MAX_NUMBERS)
					entry.numbers[entry.num_numbers++] = { .valid  = true,
					                                       .label  = label,
					                                       .number = number }; });
			_insert(entry);
		});

		if (dropped)
			Genode::warning(dropped, " stored contacts dropped");

		_next_id = Genode::max(store.attribute_value("next_id", 1U), max_id + 1);

		/*
		 * Contacts that share a name are ordered by id, so an id is given
		 * to a contact while it is out of the list
		 */
		for (bool found = true; found; ) {
			found = false;
			for (unsigned i = 0; i < _count && !found; i++) {
				if (_entries[i].id.value)
					continue;
				Entry entry = _entries[i];
				entry.id = { _next_id++ };
				_remove_at(i);
				_insert(entry);
				found = true;
			}
		}

		_generation++;
	}
};

#endif /* _CONTACTS_STORE_H_ */
