/*
 * \brief  Contacts service: owns the contacts, answers lookups
 * \author Ivan Loskutov
 * \date   2026-10-01
 *
 * The contacts are kept in 'Contacts_store' and in the file
 * 'contacts/store' of the service's VFS ('Store_file': written as a new
 * file and renamed, a file that does not parse is kept as '.bad'). A client's rights come from the
 * policy for its session label:
 *
 *   config
 *   + vfs | + fs
 *   + policy | label_prefix: some_service              (lookup)
 *   + policy | label_prefix: phone | read: yes         (lookup and list)
 *   + policy | label_prefix: contacts | manage: yes    (lookup, list, and manage)
 *
 * A client without policy gets no session. Every session call is
 * answered from memory. The file is written after the call that changed
 * the contacts has returned.
 */

/*
 * SPDX-License-Identifier: MIT
 */

/* Genode includes */
#include <base/component.h>
#include <base/attached_rom_dataspace.h>
#include <base/heap.h>
#include <base/registry.h>
#include <os/session_policy.h>
#include <os/vfs.h>
#include <root/component.h>

/* smartphone includes */
#include <store_file.h>

/* contacts includes */
#include <contacts_session/contacts_session.h>

/* local includes */
#include <contacts_store.h>

namespace Contacts {

	using namespace Genode;

	struct Session_component;
	struct Root;
	struct Main;
}


struct Contacts::Session_component : Rpc_object<Session>
{
	struct Action : Interface
	{
		/**
		 * The contacts changed: store them, tell the clients
		 */
		virtual void contacts_changed() = 0;
	};

	Contacts_store &_store;
	Action         &_action;
	bool     const  _manage;
	bool     const  _read;      /* list the contacts, also without manage */

	Signal_context_capability _sigh { };

	Registry<Session_component>::Element _element;

	/*
	 * A reply travels with every byte of its type, also the bytes behind
	 * the end of a text and between the members. These are cleared so a
	 * client receives nothing but the answer to its question.
	 */

	template <size_t N>
	static String<N> _padded(String<N> const &text)
	{
		String<N> result { Cstring(text.string()) };

		char * const buf = const_cast<char *>(result.string());
		size_t const len = strlen(buf);
		bzero(buf + len, N - len);
		return result;
	}

	template <typename T>
	static T _cleared()
	{
		T reply { };
		bzero((void *)&reply, sizeof(reply));
		return reply;
	}

	static Lookup _reply(Lookup const &lookup)
	{
		Lookup reply = _cleared<Lookup>();
		reply.found = lookup.found;
		reply.id    = lookup.id;
		reply.name  = _padded(lookup.name);
		return reply;
	}

	static Contact _reply(Contact const &contact)
	{
		Contact reply = _cleared<Contact>();
		reply.valid   = contact.valid;
		reply.id      = contact.id;
		reply.name    = _padded(contact.name);
		reply.numbers = contact.numbers;
		return reply;
	}

	static Phone _reply(Phone const &phone)
	{
		Phone reply = _cleared<Phone>();
		reply.valid  = phone.valid;
		reply.label  = _padded(phone.label);
		reply.number = _padded(phone.number);
		return reply;
	}

	/**
	 * Apply 'fn' to the store on behalf of a manage client
	 */
	Result _change(auto const &fn)
	{
		if (!_manage)
			return Result::DENIED;

		unsigned const generation = _store.generation();
		Result   const result     = fn();

		if (_store.generation() != generation)
			_action.contacts_changed();

		return result;
	}

	Session_component(Registry<Session_component> &registry,
	                  Contacts_store &store, Action &action, bool manage, bool read)
	:
		_store(store), _action(action), _manage(manage), _read(manage || read),
		_element(registry, *this)
	{ }

	void notify()
	{
		if (_sigh.valid())
			Signal_transmitter(_sigh).submit();
	}


	/********************************
	 ** Contacts session interface **
	 ********************************/

	Lookup lookup(Number const &number) override
	{
		return _reply(_store.lookup(number));
	}

	void sigh(Signal_context_capability sigh) override { _sigh = sigh; }

	unsigned generation() override { return _store.generation(); }

	unsigned count() override { return _read ? _store.count() : 0; }

	Contact contact(unsigned index) override
	{
		return _reply(_read ? _store.contact(index) : Contact { });
	}

	Phone number(Id id, unsigned index) override
	{
		return _reply(_read ? _store.number(id, index) : Phone { });
	}

	Added add(Name const &name) override
	{
		Id id { 0 };
		Result const result = _change([&] {
			Added const added = _store.add(name);
			id = added.id;
			return added.result; });

		Added reply = _cleared<Added>();
		reply.result = result;
		reply.id     = id;
		return reply;
	}

	Result rename(Id id, Name const &name) override
	{
		return _change([&] { return _store.rename(id, name); });
	}

	Result remove(Id id) override
	{
		return _change([&] { return _store.remove(id); });
	}

	Result add_number(Id id, Number_label const &label, Number const &number) override
	{
		return _change([&] { return _store.add_number(id, label, number); });
	}

	Result remove_number(Id id, unsigned index) override
	{
		return _change([&] { return _store.remove_number(id, index); });
	}
};


struct Contacts::Root : Root_component<Session_component>
{
	private:

		Attached_rom_dataspace const &_config;
		Registry<Session_component>  &_sessions;
		Contacts_store               &_store;
		Session_component::Action    &_action;

	protected:

		Create_result _create_session(const char *args) override
		{
			Session_label const label = label_from_args(args);

			return with_matching_policy(label, _config.node(),
				[&] (Node const &policy) -> Create_result {
					return _alloc_obj(_sessions, _store, _action,
					                  policy.attribute_value("manage", false),
					                  policy.attribute_value("read",   false)); },
				[&] () -> Create_result {
					warning("no policy for '", label, "', session denied");
					return Create_error::DENIED; });
		}

	public:

		Root(Entrypoint &ep, Allocator &md_alloc,
		     Attached_rom_dataspace const &config,
		     Registry<Session_component> &sessions, Contacts_store &store,
		     Session_component::Action &action)
		:
			Root_component<Session_component>(ep, md_alloc),
			_config(config), _sessions(sessions), _store(store), _action(action)
		{ }
};


struct Contacts::Main : Session_component::Action
{
	Env &_env;

	Heap        _heap        { _env.ram(), _env.rm() };
	Sliced_heap _sliced_heap { _env.ram(), _env.rm() };

	Attached_rom_dataspace _config { _env, "config" };

	Root_directory _root_dir = _config.node().with_sub_node("vfs",
		[&] (Node const &vfs) -> Root_directory { return { _env, _heap, vfs }; },
		[&] () -> Root_directory {
			warning("no vfs configured, the contacts are not persistent");
			return { _env, _heap, Node() }; });

	Contacts_store _store { };

	Registry<Session_component> _sessions { };

	Root _root { _env.ep(), _sliced_heap, _config, _sessions, _store, *this };

	static constexpr char const *STORE_PATH = "contacts/store";

	/* MAX_CONTACTS with MAX_NUMBERS each stay below 200 KiB */
	static constexpr size_t STORE_MAX = 256*1024;

	/* written as a new file and renamed, a file that does not parse is kept aside */
	Telephony::Store_file _store_file { _root_dir, _heap, STORE_PATH,
	                                           "contacts", STORE_MAX };

	/* a failed write is logged, the next change tries again */
	void _save()
	{
		static char buf[STORE_MAX];
		Generator::generate(Byte_range_ptr(buf, sizeof(buf)), "contacts",
			[&] (Generator &g) { _store.gen_store(g); }
		).with_result(
			[&] (size_t used) { _store_file.save(Const_byte_range_ptr(buf, used)); },
			[&] (Buffer_error) { warning("contacts exceed ", STORE_MAX, " bytes"); });
	}

	void _load()
	{
		using Load = Telephony::Store_file::Load;

		switch (_store_file.load([&] (Node const &store) { _store.load(store); })) {
		case Load::LOADED: break;
		case Load::NONE:   log("no stored contacts yet");               break;
		case Load::BAD:    warning("starting without stored contacts"); break;
		}
	}

	/* the file is written once the changing call has been answered */
	Signal_handler<Main> _save_handler { _env.ep(), *this, &Main::_save };

	/**
	 * Session_component::Action interface
	 */
	void contacts_changed() override
	{
		_save_handler.local_submit();

		_sessions.for_each([&] (Session_component &session) {
			session.notify(); });
	}

	Main(Env &env) : _env(env)
	{
		_load();

		_env.parent().announce(_env.ep().manage(_root));

		log("contacts_service started, ", _store.count(), " contacts");
	}
};


void Component::construct(Genode::Env &env)
{
	static Contacts::Main main(env);
}
