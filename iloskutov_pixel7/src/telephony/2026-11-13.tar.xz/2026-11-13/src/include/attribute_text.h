/*
 * \brief  Text made fit for a node attribute
 * \author Ivan Loskutov
 * \date   2026-10-01
 *
 * A report drops an attribute with a separator or control character in
 * it. Whatever comes from outside (modem, apps, contacts) passes here
 * before it is stored or reported.
 */

/*
 * SPDX-License-Identifier: MIT
 */

#ifndef _ATTRIBUTE_TEXT_H_
#define _ATTRIBUTE_TEXT_H_

/* Genode includes */
#include <util/string.h>

namespace Telephony {

	/**
	 * Return 'text' with separators and control characters replaced by
	 * spaces, runs of spaces collapsed, the ends trimmed, cut to the
	 * capacity of the result, never inside a character (UTF-8)
	 */
	template <Genode::size_t N>
	static inline Genode::String<N> attribute_text(char const *text)
	{
		char buf[N];
		Genode::size_t n = 0;
		bool space = false;

		for (char const *c = text; *c && n < sizeof(buf) - 1; c++) {
			bool const blank = (*c == '|' || (unsigned char)*c < 0x20 || *c == ' ');
			if (blank) {
				if (!space && n > 0)
					buf[n++] = ' ';
				space = true;
				continue;
			}
			buf[n++] = *c;
			space = false;
		}
		/* a cut may have left the start of a UTF-8 sequence without its end */
		{
			Genode::size_t start = n;
			while (start > 0 && ((unsigned char)buf[start - 1] & 0xc0) == 0x80)
				start--;
			if (start > 0) {
				unsigned char const lead = (unsigned char)buf[start - 1];
				Genode::size_t const need = (lead >= 0xf0) ? 4 : (lead >= 0xe0) ? 3
				                          : (lead >= 0xc0) ? 2 : 1;
				if (need > 1 && n - (start - 1) < need)
					n = start - 1;
			}
		}

		while (n > 0 && buf[n - 1] == ' ')
			n--;
		buf[n] = 0;
		return Genode::String<N>(Genode::Cstring(buf));
	}
}

#endif /* _ATTRIBUTE_TEXT_H_ */
