/*
 * \brief  What of the phone service's data the user is looking at
 * \author Ivan Loskutov
 * \date   2026-10-01
 *
 * A chat is viewed while the messages app is the shown app, the display is
 * not off and the app names that chat ('messages_view | chat: <number>').
 * The call log is viewed while the phone app is shown the same way and
 * names its call-log tab ('phone_view | tab: recent').
 *
 * The shown app comes from the smartphone manager ('ui_state | state: app
 * | active_app: <name> | display: on|off'). Any missing piece means not
 * viewed, so nothing is marked read by accident: an app parked behind the
 * launcher keeps its view report but is not shown.
 *
 * A view counts once it has lasted SETTLE_MS. The shown app and what the
 * app names arrive as separate reports: when a tap on a notification
 * raises the messages app that was parked on another chat, the manager's
 * report is here before the app's. Without the settle time, that other
 * chat would be marked read although it never was on screen.
 */

/*
 * SPDX-License-Identifier: MIT
 */

#ifndef _VIEW_STATE_H_
#define _VIEW_STATE_H_

/* Genode includes */
#include <base/node.h>
#include <util/string.h>

/* local includes */
#include <call_tracker.h>

namespace Telephony { struct View_state; }


struct Telephony::View_state
{
	using Number   = Call_tracker::Number;
	using Name     = Genode::String<32>;
	using uint64_t = Genode::uint64_t;

	static constexpr uint64_t SETTLE_MS = 500;

	Name   _state      { };      /* 'ui_state' of the smartphone manager */
	Name   _active_app { };
	bool   _display_on = true;
	Number _chat       { };      /* chat named by the messages app */
	Name   _tab        { };      /* tab named by the phone app */

	/* what the inputs say is on screen, and since when */
	struct View
	{
		enum class Kind { NONE, CHAT, CALL_LOG };

		Kind   kind { Kind::NONE };
		Number chat { };

		bool operator != (View const &other) const
		{
			return kind != other.kind || chat != other.chat;
		}
	};

	View     _view     { };
	uint64_t _since_ms = 0;

	bool _shown(char const *app) const
	{
		return _display_on && _state == "app" && _active_app == app;
	}

	void _update(uint64_t now_ms)
	{
		View view { };

		if (_shown("messages") && _chat.length() > 1)
			view = { .kind = View::Kind::CHAT, .chat = _chat };

		if (_shown("phone") && _tab == "recent")
			view = { .kind = View::Kind::CALL_LOG, .chat = { } };

		if (view != _view) {
			_view     = view;
			_since_ms = now_ms;
		}
	}

	bool _settled(uint64_t now_ms) const
	{
		return now_ms >= _since_ms && now_ms - _since_ms >= SETTLE_MS;
	}

	void apply_ui_state(Genode::Node const &ui_state, uint64_t now_ms)
	{
		_state      = ui_state.attribute_value("state",      Name());
		_active_app = ui_state.attribute_value("active_app", Name());
		_display_on = ui_state.attribute_value("display",    Name()) != "off";
		_update(now_ms);
	}

	void apply_messages_view(Genode::Node const &view, uint64_t now_ms)
	{
		_chat = view.attribute_value("chat", Number());
		_update(now_ms);
	}

	void apply_phone_view(Genode::Node const &view, uint64_t now_ms)
	{
		_tab = view.attribute_value("tab", Name());
		_update(now_ms);
	}

	/**
	 * Return the number of the chat in view, or an empty number
	 */
	Number viewed_chat(uint64_t now_ms) const
	{
		return (_view.kind == View::Kind::CHAT && _settled(now_ms)) ? _view.chat : Number();
	}

	bool call_log_viewed(uint64_t now_ms) const
	{
		return _view.kind == View::Kind::CALL_LOG && _settled(now_ms);
	}

	/**
	 * Time until what is on screen counts as viewed, 0 if nothing is pending
	 */
	uint64_t settle_remaining_ms(uint64_t now_ms) const
	{
		if (_view.kind == View::Kind::NONE || _settled(now_ms))
			return 0;

		return now_ms >= _since_ms ? SETTLE_MS - (now_ms - _since_ms) : SETTLE_MS;
	}
};

#endif /* _VIEW_STATE_H_ */
