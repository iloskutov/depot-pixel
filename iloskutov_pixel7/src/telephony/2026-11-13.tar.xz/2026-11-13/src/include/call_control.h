/*
 * \brief  What a call request asks the modem for, depending on the call state
 * \author Ivan Loskutov
 * \date   2026-10-01
 *
 * Requests come on two channels: 'call_request' of the phone app and
 * 'call_action' of the smartphone manager, which forwards the buttons of
 * the call banner in the notification panel. Both get the same checks:
 * accept and reject only while a call rings, hangup while a call is going
 * on. Dialing is the phone app's business only.
 */

/*
 * SPDX-License-Identifier: MIT
 */

#ifndef _CALL_CONTROL_H_
#define _CALL_CONTROL_H_

/* local includes */
#include <call_tracker.h>

namespace Telephony { struct Call_control; }


struct Telephony::Call_control
{
	using Action = Genode::String<16>;
	using State  = Call_tracker::State;

	/* what the modem config asks for regarding the call */
	enum class Request { NONE, DIAL, ACCEPT, REJECT };

	enum class Channel { APP, PANEL };

	/**
	 * Return the request for 'action' in call state 'state', NONE if the
	 * action is to be ignored
	 *
	 * \param number_valid  the number to dial is a valid one
	 */
	static Request request(Action const &action, State state, bool number_valid,
	                       Channel channel)
	{
		bool const going_on = (state != State::IDLE && state != State::UNAVAILABLE);

		if (action == "dial")
			return (channel == Channel::APP && state == State::IDLE && number_valid)
			       ? Request::DIAL : Request::NONE;

		if (action == "accept" && state == State::INCOMING)
			return Request::ACCEPT;

		if (action == "reject" && state == State::INCOMING)
			return Request::REJECT;

		/* upstream modems hang up on 'rejected', not on a missing call node */
		if (action == "hangup" && going_on)
			return Request::REJECT;

		return Request::NONE;
	}
};

#endif /* _CALL_CONTROL_H_ */
