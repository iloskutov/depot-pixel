/*
 * \brief  Check of a phone number
 * \author Ivan Loskutov
 * \date   2026-09-26
 */

/*
 * SPDX-License-Identifier: MIT
 */

#ifndef _PHONE_NUMBER_H_
#define _PHONE_NUMBER_H_

#include <util/misc_math.h>
#include <util/string.h>

namespace Telephony {

	using Number = Genode::String<33>;

	/**
	 * Return true for 3 to 32 digits, '*' or '#', with an optional '+' first
	 */
	static inline bool valid_number(Number const &number)
	{
		char const *s = number.string();
		Genode::size_t const len = Genode::strlen(s);
		Genode::size_t digits = 0;

		for (Genode::size_t i = 0; i < len; i++) {
			char const c = s[i];
			if (c == '+' && i == 0)
				continue;
			if ((c >= '0' && c <= '9') || c == '*' || c == '#') {
				digits++;
				continue;
			}
			return false;
		}
		return digits >= 3 && digits <= 32;
	}

	/**
	 * Digits of a number, without a leading '00' or a leading national '0'
	 */
	static inline Number number_digits(Number const &number)
	{
		char digits[Number::capacity()] { };
		Genode::size_t n = 0;

		for (char const *c = number.string(); *c; c++)
			if (*c >= '0' && *c <= '9')
				digits[n++] = *c;

		char const *start = digits;
		if (start[0] == '0')
			start += (start[1] == '0') ? 2 : 1;

		return Number(Genode::Cstring(start));
	}

	/**
	 * Whether two numbers are the same subscriber: equal digits, or one
	 * ends with the other and the shorter has at least 7 digits
	 * ('+41 76 000 00 01', '0041760000001', '076 000 00 01')
	 */
	static inline bool same_number(Number const &a, Number const &b)
	{
		enum { MATCH_DIGITS = 7 };

		if (a.length() <= 1 || b.length() <= 1)
			return false;

		if (a == b)
			return true;

		Number const na = number_digits(a), nb = number_digits(b);

		Genode::size_t const la = Genode::strlen(na.string()),
		                     lb = Genode::strlen(nb.string());
		if (la == 0 || lb == 0)
			return false;

		if (na == nb)
			return true;

		if (Genode::min(la, lb) < MATCH_DIGITS)
			return false;

		char const *longer  = (la > lb) ? na.string() : nb.string();
		char const *shorter = (la > lb) ? nb.string() : na.string();

		return Genode::strcmp(longer + Genode::max(la, lb) - Genode::min(la, lb), shorter) == 0;
	}
}

#endif /* _PHONE_NUMBER_H_ */
