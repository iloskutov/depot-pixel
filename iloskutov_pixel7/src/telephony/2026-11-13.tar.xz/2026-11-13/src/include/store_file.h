/*
 * \brief  A store kept as one file that survives a power cut
 * \author Ivan Loskutov
 * \date   2026-10-01
 *
 * The phone's stores (calls and messages, contacts, settings) are small
 * node-format files, written as a whole on every change. A file system
 * without journal (FAT) can lose a file that is cut off while it is
 * overwritten, so
 *
 * - a store is written to '<file>.new', which is then renamed over
 *   '<file>': at any time one complete version exists;
 * - on load, a missing '<file>' with an existing '<file>.new' uses the
 *   new one (some file systems rename by removing the old file first);
 *   with both present the old one counts, the new one may be cut off;
 * - a file that is no complete node of the expected type is kept aside
 *   as '<file>.bad' (replacing an older one) for a look at it later, and
 *   the component starts with an empty store.
 *
 * Renaming goes through 'Directory::rename', which gives no result: the
 * outcome is checked by looking at what exists afterwards.
 */

/*
 * SPDX-License-Identifier: MIT
 */

#ifndef _INCLUDE__SMARTPHONE_STORE__STORE_FILE_H_
#define _INCLUDE__SMARTPHONE_STORE__STORE_FILE_H_

/* Genode includes */
#include <base/log.h>
#include <base/node.h>
#include <os/vfs.h>

namespace Telephony { struct Store_file; }


struct Telephony::Store_file
{
	using Path    = Genode::Directory::Path;
	using Type    = Genode::String<32>;
	using size_t  = Genode::size_t;

	enum class Load { LOADED, NONE, BAD };

	Genode::Directory &_dir;
	Genode::Allocator &_alloc;

	Path   const _path;
	Path   const _new { _path, ".new" };
	Path   const _bad { _path, ".bad" };
	Type   const _type;      /* type of the store's top-level node */
	size_t const _limit;     /* largest store read or written */

	/**
	 * Constructor
	 *
	 * \param dir    directory the path is relative to
	 * \param alloc  allocator for the content while it is loaded
	 * \param path   the store file, its directory is created on demand
	 * \param type   type of the store's top-level node
	 * \param limit  maximum size of the store in bytes
	 */
	Store_file(Genode::Directory &dir, Genode::Allocator &alloc, Path const &path,
	           Type const &type, size_t limit)
	:
		_dir(dir), _alloc(alloc), _path(path), _type(type), _limit(limit)
	{ }

	void _keep_aside(Path const &path)
	{
		Genode::warning(path, " holds no valid '", _type, "' node, kept as ", _bad);

		_dir.rename(path, _bad);

		/* never read the same bad file again */
		if (_dir.file_exists(path))
			_dir.unlink(path);
	}

	/**
	 * Load the store
	 *
	 * \param fn  called with the store's node if there is a valid one
	 *
	 * \return LOADED, NONE if nothing is stored, BAD if what is stored
	 *         was not usable and has been kept aside
	 */
	Load load(auto const &fn)
	{
		bool const have_file = _dir.file_exists(_path),
		           have_new  = _dir.file_exists(_new);

		if (!have_file && !have_new)
			return Load::NONE;

		auto try_load = [&] (Path const &path)
		{
			bool loaded = false;
			try {
				Genode::File_content content(_alloc, _dir, path,
				                             Genode::File_content::Limit { _limit });

				/* text that is cut off or no node at all parses as an empty node */
				content.node([&] (Genode::Node const &node) {
					if (!node.has_type(_type.string()))
						return;
					fn(node);
					loaded = true; });
			}
			catch (...) { /* too large, or unreadable */ }
			return loaded;
		};

		if (have_file && try_load(_path))
			return Load::LOADED;

		/* the file a save was about to put in place */
		if (have_new && try_load(_new)) {
			if (have_file)
				_keep_aside(_path);
			return Load::LOADED;
		}

		_keep_aside(have_file ? _path : _new);
		return Load::BAD;
	}

	/**
	 * Replace the store by 'content', the node-format text of its node
	 *
	 * \return true if the file holds the new content now. On failure the
	 *         previous file is still in place.
	 */
	bool save(Genode::Const_byte_range_ptr const &content)
	{
		if (content.num_bytes > _limit) {
			Genode::warning(_path, ": store exceeds ", _limit, " bytes, not saved");
			return false;
		}

		bool written = false;
		try {
			Genode::New_file file(_dir, _new, { });
			written = (file.append(content) == Genode::New_file::Append_result::OK);
		}
		catch (...) { }

		if (!written) {
			Genode::warning("could not write ", _new);
			if (_dir.file_exists(_new))
				_dir.unlink(_new);
			return false;
		}

		_dir.rename(_new, _path);

		/* a file system that does not replace on rename: make room first */
		if (_dir.file_exists(_new)) {
			_dir.unlink(_path);
			_dir.rename(_new, _path);
		}

		if (_dir.file_exists(_new) || !_dir.file_exists(_path)) {
			Genode::warning("could not rename ", _new, " to ", _path);
			return false;
		}
		return true;
	}
};

#endif /* _INCLUDE__SMARTPHONE_STORE__STORE_FILE_H_ */
