/*
 * \brief  De-duplication of requests received via ROM
 * \author Ivan Loskutov
 * \date   2026-09-26
 *
 * Clients increment 'seq' with each request so that repeating the same
 * action produces a distinct ROM update.
 */

/*
 * SPDX-License-Identifier: MIT
 */

#ifndef _REQUEST_TRACKER_H_
#define _REQUEST_TRACKER_H_

/* Genode includes */
#include <base/node.h>

namespace Telephony { struct Request_tracker; }


struct Telephony::Request_tracker
{
	unsigned _last_seq = 0;

	bool fresh(Genode::Node const &request)
	{
		unsigned const seq = request.attribute_value("seq", 0U);

		if (seq == 0 || seq == _last_seq)
			return false;

		_last_seq = seq;
		return true;
	}

	unsigned last_seq() const { return _last_seq; }
};

#endif /* _REQUEST_TRACKER_H_ */
