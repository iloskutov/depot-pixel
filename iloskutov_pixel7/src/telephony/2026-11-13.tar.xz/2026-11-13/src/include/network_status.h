/*
 * \brief  Network status for the shell, derived from the modem state
 * \author Ivan Loskutov
 * \date   2026-09-30
 *
 * network_state | status: off|no sim|pin|searching|registered|roaming|denied
 *               | data: on | data_state: inactive|connecting|active|failed
 *
 * 'data' is present only while mobile data is switched on (the switch is
 * the phone service's, see 'data_request'); 'data_state' is the state of
 * the modem's data context as far as the modem reports one.
 *               | operator | technology: GSM|UMTS|LTE|NR | bars: 0..4
 *
 * The modem reports 'strength' 0..100 as (dBm + 140) * 100 / 96 (rild_modem:
 * LTE RSRP, WCDMA RSCP or GSM RSSI of the current technology). Bars use
 * Android's default thresholds per technology, compared in the same
 * encoding (monotonic, so exact at the thresholds).
 */

/*
 * SPDX-License-Identifier: MIT
 */

#ifndef _NETWORK_STATUS_H_
#define _NETWORK_STATUS_H_

/* Genode includes */
#include <base/node.h>
#include <util/string.h>

namespace Telephony { struct Network_status; }


struct Telephony::Network_status
{
	enum class Status { OFF, NO_SIM, PIN, SEARCHING, REGISTERED, ROAMING, DENIED };
	enum class Technology { NONE, GSM, UMTS, LTE, NR };

	using Operator = Genode::String<64>;

	Status     status     = Status::OFF;
	Operator   oper       { };
	Technology technology = Technology::NONE;
	int        bars       = -1;    /* -1: unknown */

	using Data_state = Genode::String<16>;

	bool       data_enabled = false;
	Data_state data_state   { };

	static int _encoded(int dbm) { return ((dbm + 140) * 100) / 96; }

	/**
	 * Bars 0..4 for 'strength' with the thresholds (poor..great, dBm)
	 */
	static int _bars(int strength, int const (&dbm)[4])
	{
		int bars = 0;
		for (int t : dbm)
			if (strength >= _encoded(t)) bars++;
		return bars;
	}

	static int bars_for(Technology t, int strength)
	{
		/* Android defaults: LTE RSRP, WCDMA RSCP, GSM RSSI */
		static int const lte [4] = { -115, -105, -95, -85 };
		static int const wcdma[4] = { -115, -105, -95, -85 };
		static int const gsm [4] = { -107, -103, -97, -89 };

		if (strength < 0)
			return -1;

		switch (t) {
		case Technology::LTE:
		case Technology::NR:   return _bars(strength, lte);
		case Technology::UMTS: return _bars(strength, wcdma);
		case Technology::GSM:  return _bars(strength, gsm);
		case Technology::NONE: break;
		}
		return -1;
	}

	static Network_status from_modem(Genode::Node const &modem, bool data_enabled = false)
	{
		using Value = Genode::String<32>;

		Network_status n { };

		n.data_enabled = data_enabled;
		if (data_enabled)
			modem.with_optional_sub_node("data", [&] (Genode::Node const &data) {
				data.with_optional_sub_node("context", [&] (Genode::Node const &context) {
					n.data_state = context.attribute_value("state", Data_state()); }); });

		if (modem.attribute_value("power", Value()) != "on")
			return n;

		if (modem.attribute_value("sim", Value()) == "no") {
			n.status = Status::NO_SIM;
			return n;
		}

		if (modem.attribute_value("pin", Value("ok")) != "ok") {
			n.status = Status::PIN;
			return n;
		}

		n.status = Status::SEARCHING;
		modem.with_optional_sub_node("network", [&] (Genode::Node const &net) {
			Value const st = net.attribute_value("status", Value());
			if      (st == "registered") n.status = Status::REGISTERED;
			else if (st == "roaming")    n.status = Status::ROAMING;
			else if (st == "denied")     n.status = Status::DENIED;

			if (n.status != Status::REGISTERED && n.status != Status::ROAMING)
				return;

			Value const tech = net.attribute_value("technology", Value());
			n.technology = (tech == "gsm")  ? Technology::GSM
			             : (tech == "umts") ? Technology::UMTS
			             : (tech == "lte")  ? Technology::LTE
			             : (tech == "nr")   ? Technology::NR : Technology::NONE;
			n.oper = net.attribute_value("operator", Operator());
			n.bars = bars_for(n.technology, net.attribute_value("strength", -1));
		});
		return n;
	}

	static char const *status_name(Status s)
	{
		switch (s) {
		case Status::OFF:        return "off";
		case Status::NO_SIM:     return "no sim";
		case Status::PIN:        return "pin";
		case Status::SEARCHING:  return "searching";
		case Status::REGISTERED: return "registered";
		case Status::ROAMING:    return "roaming";
		case Status::DENIED:     return "denied";
		}
		return "off";
	}

	static char const *technology_name(Technology t)
	{
		switch (t) {
		case Technology::GSM:  return "GSM";
		case Technology::UMTS: return "UMTS";
		case Technology::LTE:  return "LTE";
		case Technology::NR:   return "NR";
		case Technology::NONE: break;
		}
		return "";
	}

	void gen(Genode::Generator &g) const
	{
		g.attribute("status", status_name(status));
		if (oper.length() > 1)
			g.attribute("operator", oper);
		if (technology != Technology::NONE)
			g.attribute("technology", technology_name(technology));
		if (bars >= 0)
			g.attribute("bars", bars);
		if (data_enabled) {
			g.attribute("data", "on");
			if (data_state.length() > 1)
				g.attribute("data_state", data_state);
		}
	}

	bool operator != (Network_status const &o) const
	{
		return status != o.status || oper != o.oper
		    || technology != o.technology || bars != o.bars
		    || data_enabled != o.data_enabled || data_state != o.data_state;
	}
};

#endif /* _NETWORK_STATUS_H_ */
