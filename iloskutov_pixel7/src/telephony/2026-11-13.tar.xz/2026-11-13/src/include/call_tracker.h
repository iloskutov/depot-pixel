/*
 * \brief  Call state and call log entries from modem state reports
 * \author Ivan Loskutov
 * \date   2026-09-26
 */

/*
 * SPDX-License-Identifier: MIT
 */

#ifndef _CALL_TRACKER_H_
#define _CALL_TRACKER_H_

/* Genode includes */
#include <base/node.h>
#include <util/string.h>

/* local includes */
#include <phone_number.h>

namespace Telephony { struct Call_tracker; }


struct Telephony::Call_tracker
{
	using Number   = Genode::String<33>;
	using Stamp    = Genode::String<20>;
	using uint64_t = Genode::uint64_t;

	enum class State     { UNAVAILABLE, IDLE, INCOMING, OUTBOUND, ALERTING, ACTIVE };
	enum class Direction { IN, OUT, MISSED };

	/* 'seen' is false for a missed call the user did not look at yet */
	struct Entry
	{
		Number    number;
		Direction direction;
		Stamp     time;
		unsigned  duration_s;
		bool      seen = true;
	};

	State    _state     = State::UNAVAILABLE;
	Number   _number    { };
	Stamp    _started   { };      /* when the call began ringing or dialing */
	bool     _outgoing  = false;
	bool     _answered  = false;
	uint64_t _active_s  = 0;
	bool     _ended     = false;   /* the last apply_modem ended a call */
	bool     _rejected  = false;   /* the user refused the ringing call */
	bool     _from_start = false;  /* the call was seen ringing or dialing */

	State  state()  const { return _state; }
	Number number() const { return _number; }
	Stamp  since()  const { return _started; }

	/**
	 * Return true if the last modem report ended a call
	 */
	bool ended() const { return _ended; }

	/**
	 * The user refused the call that rings: it is not one they missed
	 */
	void rejected() { if (_state == State::INCOMING) _rejected = true; }

	bool _in_call() const
	{
		return _state != State::IDLE && _state != State::UNAVAILABLE;
	}

	void _end_call(uint64_t now_s, auto const &entry_fn)
	{
		if (!_in_call())
			return;

		Direction const dir = _outgoing ? Direction::OUT
		                    : _answered ? Direction::IN : Direction::MISSED;

		_ended = true;

		/* a call first seen when it was active: its direction is unknown */
		if (!_from_start)
			return;

		entry_fn(Entry { .number     = _number,
		                 .direction  = dir,
		                 .time       = _started,
		                 .duration_s = _answered ? unsigned(now_s - _active_s) : 0,
		                 .seen       = (dir != Direction::MISSED) || _rejected });
	}

	void apply_modem(Genode::Node const &modem, Stamp const &now, uint64_t now_s,
	                 auto const &entry_fn)
	{
		_ended = false;

		using Power = Genode::String<16>;
		if (modem.attribute_value("power", Power()) != "on") {
			_end_call(now_s, entry_fn);
			_state = State::UNAVAILABLE;
			return;
		}

		bool has_call = false;
		modem.with_optional_sub_node("call", [&] (Genode::Node const &c) {
			has_call = true;
			using Call_state = Genode::String<16>;
			Call_state const s = c.attribute_value("state", Call_state());

			State const next = (s == "incoming") ? State::INCOMING
			                 : (s == "outbound") ? State::OUTBOUND
			                 : (s == "alerting") ? State::ALERTING
			                 : (s == "active")   ? State::ACTIVE : _state;

			Number const number = c.attribute_value("number", Number());

			/*
			 * Another subscriber, or dialing/ringing again, is a new call.
			 * A number that comes late or in another format is not.
			 */
			bool const restarted = (next == State::OUTBOUND || next == State::INCOMING)
			                    && (_state == State::ALERTING || _state == State::ACTIVE);
			bool const other = number.length() > 1 && _number.length() > 1
			                && !same_number(number, _number);
			if (_in_call() && (other || restarted)) {
				_end_call(now_s, entry_fn);
				_state = State::IDLE;
			}

			if (!_in_call()) {
				_number     = number;
				_started    = now;
				_outgoing   = (next != State::INCOMING);
				_answered   = false;
				_rejected   = false;
				_from_start = (next != State::ACTIVE);
			}
			else if (_number.length() <= 1) {
				_number = number;
			}
			if (next == State::ACTIVE && !_answered) {
				_answered = true;
				_active_s = now_s;
			}
			_state = next;
		});

		if (!has_call) {
			_end_call(now_s, entry_fn);
			_state = State::IDLE;
		}
	}

	/**
	 * Generate the attributes of the 'call_state' report
	 *
	 * call_state | state | number | since | active_s
	 *
	 * Number and time only while a call is going on. 'active_s' is how long
	 * an answered call has been active at the time of the report.
	 */
	void gen_state(Genode::Generator &g, uint64_t now_s) const
	{
		g.attribute("state", state_name(_state));

		if (!_in_call())
			return;

		g.attribute("number", _number);
		g.attribute("since",  _started);

		if (_state == State::ACTIVE && _answered)
			g.attribute("active_s", now_s - Genode::min(_active_s, now_s));
	}

	static char const *state_name(State s)
	{
		switch (s) {
		case State::UNAVAILABLE: return "unavailable";
		case State::IDLE:        return "idle";
		case State::INCOMING:    return "incoming";
		case State::OUTBOUND:    return "outbound";
		case State::ALERTING:    return "alerting";
		case State::ACTIVE:      return "active";
		}
		return "unavailable";
	}

	static char const *direction_name(Direction d)
	{
		switch (d) {
		case Direction::IN:     return "in";
		case Direction::OUT:    return "out";
		case Direction::MISSED: return "missed";
		}
		return "missed";
	}
};

#endif /* _CALL_TRACKER_H_ */
