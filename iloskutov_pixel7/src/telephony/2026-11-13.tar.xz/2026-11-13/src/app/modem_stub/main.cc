/*
 * \brief  Simulated modem for prototyping the phone UI
 * \author Ivan Loskutov
 * \date   2026-09-26
 *
 * F6 rings, F7 delivers an SMS (global keys routed by nitpicker to this
 * component's input session), or the 'stub_control' ROM for scripted tests.
 *
 * The ids of the received messages start at 1 with every start. The
 * state names this id space with an epoch that differs from start to
 * start: the real-time clock at start and the timer's microseconds.
 */

/*
 * SPDX-License-Identifier: MIT
 */

/* Genode includes */
#include <base/component.h>
#include <base/attached_rom_dataspace.h>
#include <os/reporter.h>
#include <rtc_session/connection.h>
#include <timer_session/connection.h>
#include <gui_session/connection.h>

/* local includes */
#include <modem_model.h>

namespace Modem_stub {

	using namespace Genode;

	struct Main;

	static char const *const DEFAULT_PEER = "+491705550101";
	static char const *const DEFAULT_TEXT = "Hello from the stub modem";
}


struct Modem_stub::Main
{
	Env &_env;

	Modem_model _modem { };

	Timer::Connection _timer { _env };

	Expanding_reporter _reporter { _env, "modem", "state" };

	Attached_rom_dataspace _config   { _env, "config" };
	Attached_rom_dataspace _control  { _env, "stub_control" };
	Attached_rom_dataspace _settings { _env, "stub_settings" };

	unsigned _control_seq = 0;

	Constructible<Gui::Connection> _gui { };

	uint64_t _now() { return _timer.elapsed_ms(); }

	/**
	 * Return a string that differs with every start of the component
	 *
	 * Two starts within the same second of the real-time clock differ in
	 * the timer's microseconds. Without a plausible clock (never set),
	 * the timer value is all there is.
	 */
	Modem_model::Epoch _epoch_of_this_start()
	{
		uint64_t const us = _timer.elapsed_us();

		Rtc::Connection rtc { _env };
		Rtc::Timestamp const t = rtc.current_time();
		if (t.year < 2025)
			return Modem_model::Epoch("t-", us);

		auto two = [] (unsigned v) { return String<3>(v < 10 ? "0" : "", v); };
		return Modem_model::Epoch(t.year, two(t.month), two(t.day), "T",
		                          two(t.hour), two(t.minute), two(t.second), "-",
		                          us % 1000000);
	}

	void _report()
	{
		_reporter.generate([&] (Generator &g) { _modem.gen_state(g); });
	}

	void _handle_config()
	{
		_config.update();
		if (_modem.apply_config(_config.node(), _now()))
			_report();
	}

	Signal_handler<Main> _config_handler { _env.ep(), *this, &Main::_handle_config };

	void _handle_control()
	{
		_control.update();
		Node const &c = _control.node();

		unsigned const seq = c.attribute_value("seq", 0U);
		if (!seq || seq == _control_seq)
			return;
		_control_seq = seq;

		using Action = String<16>;
		Action              const action = c.attribute_value("action", Action());
		Modem_model::Number const number = c.attribute_value("number",
		                                     Modem_model::Number(DEFAULT_PEER));
		Modem_model::Text   const text   = c.attribute_value("text",
		                                     Modem_model::Text(DEFAULT_TEXT));

		if (action == "incoming_call" && _modem.incoming_call(number, _now()))
			_report();

		if (action == "incoming_sms") {
			_modem.incoming_sms(number, text);
			_report();
		}
	}

	Signal_handler<Main> _control_handler { _env.ep(), *this, &Main::_handle_control };

	void _handle_input()
	{
		_gui->input.for_each_event([&] (Input::Event const &ev) {
			if (ev.key_press(Input::KEY_F6) && _modem.incoming_call(DEFAULT_PEER, _now()))
				_report();
			if (ev.key_press(Input::KEY_F7)) {
				_modem.incoming_sms(DEFAULT_PEER, DEFAULT_TEXT);
				_report();
			}
		});
	}

	Signal_handler<Main> _input_handler { _env.ep(), *this, &Main::_handle_input };

	void _handle_timer()
	{
		if (_modem.tick(_now()))
			_report();
	}

	Signal_handler<Main> _timer_handler { _env.ep(), *this, &Main::_handle_timer };

	Main(Env &env) : _env(env)
	{
		_config .sigh(_config_handler);
		_control.sigh(_control_handler);

		if (_settings.node().attribute_value("hotkeys", false)) {
			_gui.construct(_env, "input");
			_gui->input.sigh(_input_handler);
		}

		_timer.sigh(_timer_handler);
		_timer.trigger_periodic(100*1000);

		_modem.epoch = _epoch_of_this_start();

		/* a restarted stub must not act on what its predecessor handled */
		_config.update();
		_modem.adopt_initial_config(_config.node());
		_report();

		log("modem_stub started, sms epoch ", _modem.epoch);
	}
};


void Component::construct(Genode::Env &env)
{
	static Modem_stub::Main main(env);
}
