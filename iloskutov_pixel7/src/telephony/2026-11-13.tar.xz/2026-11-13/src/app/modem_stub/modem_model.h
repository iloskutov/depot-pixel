/*
 * \brief  Simulated modem for prototyping the phone UI
 * \author Ivan Loskutov
 * \date   2026-09-26
 *
 * Speaks rild_modem's state/config schema (genode-pixel
 * src/driver/rild_modem): power/sim/pin, a registered 'network', the 'call'
 * node, and SMS as '<sms acknowledged>' + '<send>' (config) and
 * '<received>' + '<sent>' (state). Received ids increase and continue above
 * the acknowledged id after a restart. A sent text containing "#fail" is
 * reported as failed, to exercise that path.
 *
 * As rild_modem, the stub names the id space of its received messages:
 * '<sms epoch>' of the state, a string that differs with every start
 * ('epoch', set by the component). The '<sms>' node is then part of every
 * report, so the client knows the epoch before the first message. The
 * acknowledged id of a config that names another epoch was counted in a
 * former id space and is ignored; a config without epoch is taken as
 * before.
 */

/*
 * SPDX-License-Identifier: MIT
 */

#ifndef _MODEM_MODEL_H_
#define _MODEM_MODEL_H_

/* Genode includes */
#include <base/node.h>
#include <util/string.h>

namespace Modem_stub { struct Modem_model; }


struct Modem_stub::Modem_model
{
	using Number   = Genode::String<33>;
	using Text     = Genode::String<161>;
	using Epoch    = Genode::String<32>;
	using uint64_t = Genode::uint64_t;

	enum class Call { NONE, INCOMING, OUTBOUND, ALERTING, ACTIVE };

	static constexpr uint64_t ALERT_AFTER_MS  = 500;
	static constexpr uint64_t ACTIVE_AFTER_MS = 3000;
	static constexpr uint64_t ECHO_AFTER_MS   = 2000;
	static constexpr unsigned MAX_SMS         = 16;

	struct Sms  { bool used; unsigned id; Number from; Text text; };
	struct Echo { bool used; uint64_t due_ms; Number from; Text text; };
	struct Sent { bool used; unsigned id; bool failed; };

	Call     _call     = Call::NONE;
	Number   _number   { };
	uint64_t _since_ms = 0;

	Sms      _inbox[MAX_SMS]  { };
	Echo     _echoes[MAX_SMS] { };
	Sent     _sent[MAX_SMS]   { };      /* outcomes of the config's send ids */
	unsigned _next_id  = 1;

	/* id space of the received messages, empty: not reported (as old modems) */
	Epoch epoch { };

	/* call node of the previous config: a dial is triggered by a change */
	Number _cfg_number    { };
	bool   _cfg_dial      = false;

	Call   call()   const { return _call; }
	Number number() const { return _number; }

	bool incoming_call(Number const &from, uint64_t now_ms)
	{
		if (_call != Call::NONE)
			return false;

		_call = Call::INCOMING; _number = from; _since_ms = now_ms;
		return true;
	}

	void incoming_sms(Number const &from, Text const &text)
	{
		for (Sms &s : _inbox)
			if (!s.used) {
				s = { .used = true, .id = _next_id++, .from = from, .text = text };
				return;
			}
	}

	bool _sent_already(unsigned id) const
	{
		for (Sent const &s : _sent)
			if (s.used && s.id == id) return true;
		return false;
	}

	void _record_sent(unsigned id, bool failed)
	{
		for (Sent &s : _sent)
			if (!s.used) {
				s = { .used = true, .id = id, .failed = failed };
				return;
			}
	}

	static bool _requests_failure(Text const &text)
	{
		char const *t = text.string();
		for (; *t; t++)
			if (Genode::strcmp(t, "#fail", 5) == 0) return true;
		return false;
	}

	/* ids the config still lists as send, outcomes of others are dropped */
	void _trim_sent(Genode::Node const &config)
	{
		for (Sent &s : _sent) {
			if (!s.used)
				continue;
			bool listed = false;
			config.with_optional_sub_node("sms", [&] (Genode::Node const &sms) {
				sms.for_each_sub_node("send", [&] (Genode::Node const &send) {
					if (send.attribute_value("id", 0U) == s.id) listed = true; }); });
			if (!listed)
				s.used = false;
		}
	}

	bool _apply_acknowledged(Genode::Node const &config)
	{
		bool changed = false;
		config.with_optional_sub_node("sms", [&] (Genode::Node const &sms) {

			/* counted in the id space of a former start */
			if (epoch.length() > 1 && sms.has_attribute("epoch")
			 && sms.attribute_value("epoch", Epoch()) != epoch)
				return;

			unsigned const ack = sms.attribute_value("acknowledged", 0U);
			for (Sms &s : _inbox)
				if (s.used && s.id <= ack) {
					s.used = false; changed = true;
				}
			/* ids continue above what the client has seen */
			_next_id = Genode::max(_next_id, ack + 1);
		});
		return changed;
	}

	void _schedule_echo(Number const &to, Text const &text, uint64_t now_ms)
	{
		for (Echo &e : _echoes)
			if (!e.used) {
				e = { .used = true, .due_ms = now_ms + ECHO_AFTER_MS, .from = to,
				      .text = Text("echo: ", text) };
				return;
			}
	}

	/*
	 * The call part of the phone_manager protocol: a call node without
	 * state dials (when it appears or names a new number), 'accepted'
	 * answers, 'rejected' hangs up or declines. A missing call node changes
	 * nothing, as with upstream modems.
	 */
	bool _apply_call(Genode::Node const &config, uint64_t now_ms)
	{
		bool   changed = false;
		bool   dial    = false;
		Number number  { };

		config.with_optional_sub_node("call", [&] (Genode::Node const &c) {
			using State = Genode::String<16>;
			State const state = c.attribute_value("state", State());
			number = c.attribute_value("number", Number());

			if (state == "rejected" && _call != Call::NONE) {
				_call = Call::NONE; changed = true;
			} else if (state == "accepted" && _call == Call::INCOMING) {
				_call = Call::ACTIVE; _since_ms = now_ms; changed = true;
			} else if (state == "") {
				dial = true;
			}
		});

		bool const new_dial = dial && (!_cfg_dial || number != _cfg_number);
		if (new_dial && _call == Call::NONE && number.length() > 1) {
			_call = Call::OUTBOUND; _number = number; _since_ms = now_ms;
			changed = true;
		}
		_cfg_dial   = dial;
		_cfg_number = number;
		return changed;
	}

	/**
	 * Take the config found at startup as baseline
	 *
	 * A restarted modem must not dial a call or resend messages that its
	 * predecessor already handled.
	 */
	void adopt_initial_config(Genode::Node const &config)
	{
		config.with_optional_sub_node("call", [&] (Genode::Node const &c) {
			_cfg_dial   = c.attribute_value("state", Genode::String<16>()) == "";
			_cfg_number = c.attribute_value("number", Number()); });

		/* messages of the predecessor count as handled (no second echo) */
		config.with_optional_sub_node("sms", [&] (Genode::Node const &sms) {
			sms.for_each_sub_node("send", [&] (Genode::Node const &s) {
				unsigned const id = s.attribute_value("id", 0U);
				if (id && !_sent_already(id))
					_record_sent(id, _requests_failure(s.attribute_value("text", Text()))); }); });

		_apply_acknowledged(config);
	}

	bool apply_config(Genode::Node const &config, uint64_t now_ms)
	{
		bool changed = _apply_call(config, now_ms);

		config.with_optional_sub_node("sms", [&] (Genode::Node const &sms) {
			sms.for_each_sub_node("send", [&] (Genode::Node const &s) {
				unsigned const id = s.attribute_value("id", 0U);
				if (!id || _sent_already(id))
					return;
				Text const text = s.attribute_value("text", Text());
				bool const fail = _requests_failure(text);
				_record_sent(id, fail);
				if (!fail)
					_schedule_echo(s.attribute_value("to", Number()), text, now_ms);
				changed = true;
			});
		});

		_trim_sent(config);

		if (_apply_acknowledged(config))
			changed = true;

		return changed;
	}

	bool tick(uint64_t now_ms)
	{
		bool changed = false;

		if (_call == Call::OUTBOUND && now_ms - _since_ms >= ALERT_AFTER_MS) {
			_call = Call::ALERTING; changed = true;
		}
		if (_call == Call::ALERTING && now_ms - _since_ms >= ACTIVE_AFTER_MS) {
			_call = Call::ACTIVE; changed = true;
		}
		for (Echo &e : _echoes)
			if (e.used && now_ms >= e.due_ms) {
				e.used = false;
				incoming_sms(e.from, e.text);
				changed = true;
			}
		return changed;
	}

	static char const *_call_name(Call call)
	{
		switch (call) {
		case Call::INCOMING: return "incoming";
		case Call::OUTBOUND: return "outbound";
		case Call::ALERTING: return "alerting";
		case Call::ACTIVE:   return "active";
		case Call::NONE:     break;
		}
		return "";
	}

	void gen_state(Genode::Generator &g) const
	{
		g.attribute("power", "on");
		g.attribute("sim",   "yes");
		g.attribute("pin",   "ok");

		g.node("network", [&] {
			g.attribute("status",     "registered");
			g.attribute("technology", "lte");
			g.attribute("operator",   "Stub");
			g.attribute("strength",   70); });

		if (_call != Call::NONE)
			g.node("call", [&] {
				g.attribute("number", _number);
				g.attribute("state",  _call_name(_call)); });

		bool const have_epoch = epoch.length() > 1;

		bool any_sms = false;
		for (Sms  const &s : _inbox) if (s.used) any_sms = true;
		for (Sent const &s : _sent)  if (s.used) any_sms = true;
		if (!any_sms && !have_epoch)
			return;

		g.node("sms", [&] {
			if (have_epoch)
				g.attribute("epoch", epoch);

			for (Sms const &s : _inbox)
				if (s.used)
					g.node("received", [&] {
						g.attribute("id",   s.id);
						g.attribute("from", s.from);
						g.attribute("text", s.text); });

			for (Sent const &s : _sent)
				if (s.used)
					g.node("sent", [&] {
						g.attribute("id", s.id);
						g.attribute("state", s.failed ? "failed" : "sent");
						if (s.failed)
							g.attribute("reason", "stub: requested failure"); });
		});
	}
};

#endif /* _MODEM_MODEL_H_ */
