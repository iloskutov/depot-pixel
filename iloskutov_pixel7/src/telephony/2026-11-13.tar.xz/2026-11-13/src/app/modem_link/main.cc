/*
 * \brief  Modem link: the single writer of the modem's config
 * \author Ivan Loskutov
 * \date   2026-09-26
 *
 * The modem ('rild_modem', or 'modem_stub' on Linux) takes one config ROM.
 * This component writes it ("modem_config"): power, the SIM's PIN, the
 * attach APN, mobile data, the call the Phone app or the shell's call card
 * asks for, and the SMS part of 'sms_store' (ROM "sms_config": the
 * acknowledged id and the messages to send), as it is. From the modem's
 * state ("modem_state") it reports the call state ("call_state") and the
 * network ("network_state").
 *
 * Requests (ROMs, each with a 'seq' the client increments):
 *
 * 'call_state' names the last 'seq' of each call channel ('request_seq',
 * 'action_seq'), for a client that starts anew.
 *
 *   call_request | seq | action: dial|accept|reject|hangup | number   (Phone)
 *   call_action  | seq | action: accept|reject|hangup                 (shell)
 *   data_request | seq | enabled: yes|no                              (Settings)
 *
 * Config:
 *
 *   config | attach_apn: internet | pin: 1234
 */

/*
 * SPDX-License-Identifier: MIT
 */

#include <base/component.h>
#include <base/attached_rom_dataspace.h>
#include <os/reporter.h>
#include <rtc_session/connection.h>
#include <timer_session/connection.h>

#include <call_tracker.h>
#include <call_control.h>
#include <network_status.h>
#include <phone_number.h>
#include <request_tracker.h>

namespace Telephony {

	using namespace Genode;

	struct Main;
}


struct Telephony::Main
{
	Env &_env;

	Attached_rom_dataspace _config { _env, "config" };

	Rtc::Connection   _rtc   { _env };
	Timer::Connection _timer { _env };

	using Apn = String<64>;
	using Pin = String<16>;

	Apn const _attach_apn = _config.node().attribute_value("attach_apn", Apn("internet"));
	Pin const _pin        = _config.node().attribute_value("pin", Pin());

	Call_tracker   _call    { };
	Network_status _network { };
	bool           _network_published = false;

	Request_tracker _call_requests { };
	Request_tracker _call_actions  { };
	Request_tracker _data_requests { };

	bool _data_enabled = false;

	/* what the config asks for regarding the call */
	using Call_config = Call_control::Request;
	Call_config          _call_cfg    = Call_config::NONE;
	Call_tracker::Number _call_number { };

	/*
	 * A dial the modem does not turn into a call within this time is
	 * withdrawn, so it cannot linger in the config
	 */
	static constexpr uint64_t DIAL_TIMEOUT_S = 30;

	uint64_t _dialed_s = 0;

	Expanding_reporter _modem_config  { _env, "config",        "modem_config" };
	Expanding_reporter _call_state    { _env, "call_state",    "call_state" };
	Expanding_reporter _network_state { _env, "network_state", "network_state" };

	Attached_rom_dataspace _modem_state  { _env, "modem_state" };
	Attached_rom_dataspace _call_request { _env, "call_request" };
	Attached_rom_dataspace _call_action  { _env, "call_action" };
	Attached_rom_dataspace _data_request { _env, "data_request" };
	Attached_rom_dataspace _sms_config   { _env, "sms_config" };

	Call_tracker::Stamp _stamp()
	{
		Rtc::Timestamp const t = _rtc.current_time();
		auto two = [] (unsigned v) { return String<3>(v < 10 ? "0" : "", v); };
		return Call_tracker::Stamp(t.year, "-", two(t.month), "-", two(t.day), " ",
		                           two(t.hour), ":", two(t.minute));
	}

	uint64_t _now_s() { return _timer.elapsed_ms() / 1000; }

	void _publish_modem_config()
	{
		_modem_config.generate([&] (Generator &g) {
			g.attribute("power", "on");
			if (_pin.length() > 1)
				g.attribute("pin", _pin);

			g.node("network", [&] { g.attribute("attach_apn", _attach_apn); });

			if (_data_enabled)
				g.node("data", [&] {
					g.node("context", [&] {
						g.attribute("apn",    _attach_apn);
						g.attribute("active", "yes"); }); });

			if (_call_cfg != Call_config::NONE)
				g.node("call", [&] {
					g.attribute("number", _call_number);
					if (_call_cfg == Call_config::ACCEPT) g.attribute("state", "accepted");
					if (_call_cfg == Call_config::REJECT) g.attribute("state", "rejected");
				});

			/* the SMS part of 'sms_store', as it is */
			Node const &sms = _sms_config.node();
			if (sms.type() == "sms")
				g.append_node(sms);
		});
	}

	void _publish_call_state()
	{
		_call_state.generate([&] (Generator &g) {
			_call.gen_state(g, _now_s());

			/* lets a relaunched client continue after its last request */
			g.attribute("request_seq", _call_requests.last_seq());
			g.attribute("action_seq",  _call_actions.last_seq());
		});
	}

	void _publish_network(Node const &modem)
	{
		Network_status const n = Network_status::from_modem(modem, _data_enabled);
		if (_network_published && !(n != _network))
			return;

		_network = n;
		_network_published = true;
		_network_state.generate([&] (Generator &g) { _network.gen(g); });
	}

	void _handle_modem_state()
	{
		_modem_state.update();
		Node const &modem = _modem_state.node();

		/* the entries of ended calls are the call log's business */
		_call.apply_modem(modem, _stamp(), _now_s(), [] (Call_tracker::Entry const &) { });

		/*
		 * The call ended: never re-dial or re-answer from a stale request.
		 * Only an actual end clears the request - an idle report that was
		 * queued before the modem saw a fresh dial must not.
		 */
		bool config_changed = false;

		if ((_call.ended() || _call.state() == Call_tracker::State::UNAVAILABLE)
		 && _call_cfg != Call_config::NONE) {
			_call_cfg = Call_config::NONE;
			config_changed = true;
		}

		_publish_network(modem);
		_publish_call_state();

		/* the config only when it differs: the modem answers each with a state */
		if (config_changed)
			_publish_modem_config();
	}

	/* the dial that never became a call */
	void _handle_dial_timeout()
	{
		if (_call_cfg != Call_config::DIAL
		 || _call.state() != Call_tracker::State::IDLE)
			return;

		if (_now_s() < _dialed_s + DIAL_TIMEOUT_S)
			return;

		warning("the modem did not start the call, dial withdrawn");
		_call_cfg = Call_config::NONE;
		_publish_modem_config();
	}

	Signal_handler<Main> _dial_timeout_handler {
		_env.ep(), *this, &Main::_handle_dial_timeout };

	Signal_handler<Main> _modem_state_handler {
		_env.ep(), *this, &Main::_handle_modem_state };

	void _apply_call_request(Node const &req, Call_control::Channel channel)
	{
		Call_control::Action const action = req.attribute_value("action", Call_control::Action());
		Call_tracker::Number const number = req.attribute_value("number", Call_tracker::Number());

		Call_config const request =
			Call_control::request(action, _call.state(), valid_number(number), channel);

		/* a hang-up of a dial the modem has not reported yet: withdraw it */
		if (request == Call_config::NONE && _call_cfg == Call_config::DIAL
		 && _call.state() == Call_tracker::State::IDLE
		 && (action == "hangup" || action == "reject")) {
			_call_cfg = Call_config::NONE;
			_publish_modem_config();
			return;
		}

		if (request == Call_config::NONE) {
			warning("call request '", action, "' ignored in state ",
			        Call_tracker::state_name(_call.state()));
			return;
		}

		if (request == Call_config::DIAL) {
			/* a stale dial (e.g. modem restarted) is withdrawn first, so the
			 * modem sees a new call node */
			if (_call_cfg != Call_config::NONE) {
				_call_cfg = Call_config::NONE;
				_publish_modem_config();
			}
			_call_number = number;
			_dialed_s    = _now_s();
			_timer.trigger_once(DIAL_TIMEOUT_S*1000*1000);
		} else {
			_call_number = _call.number();
		}
		_call_cfg = request;
		_publish_modem_config();
	}

	void _handle_call_request()
	{
		_call_request.update();
		Node const &req = _call_request.node();
		if (!_call_requests.fresh(req))
			return;

		/* acknowledge the request, even if it is ignored below */
		_publish_call_state();

		_apply_call_request(req, Call_control::Channel::APP);
	}

	Signal_handler<Main> _call_request_handler {
		_env.ep(), *this, &Main::_handle_call_request };

	/* the buttons of the shell's call card: as the app's, but no dialing */
	void _handle_call_action()
	{
		_call_action.update();
		Node const &req = _call_action.node();
		if (!_call_actions.fresh(req))
			return;

		/* acknowledge the request, even if it is ignored below */
		_publish_call_state();

		_apply_call_request(req, Call_control::Channel::PANEL);
	}

	Signal_handler<Main> _call_action_handler {
		_env.ep(), *this, &Main::_handle_call_action };

	/* mobile data: off at every start, switched by a request */
	void _handle_data_request()
	{
		_data_request.update();
		Node const &req = _data_request.node();
		if (!_data_requests.fresh(req))
			return;

		bool const enabled = req.attribute_value("enabled", false);
		if (enabled == _data_enabled)
			return;

		_data_enabled = enabled;
		log("mobile data switched ", enabled ? "on" : "off");
		_publish_modem_config();
		_publish_network(_modem_state.node());
	}

	Signal_handler<Main> _data_request_handler {
		_env.ep(), *this, &Main::_handle_data_request };

	void _handle_sms_config()
	{
		_sms_config.update();
		_publish_modem_config();
	}

	Signal_handler<Main> _sms_config_handler {
		_env.ep(), *this, &Main::_handle_sms_config };

	Main(Env &env) : _env(env)
	{
		_modem_state .sigh(_modem_state_handler);
		_call_request.sigh(_call_request_handler);
		_call_action .sigh(_call_action_handler);
		_data_request.sigh(_data_request_handler);
		_sms_config  .sigh(_sms_config_handler);

		_timer.sigh(_dial_timeout_handler);

		/* requests of before the start are not carried out now */
		_call_requests.fresh(_call_request.node());
		_call_actions .fresh(_call_action.node());
		_data_requests.fresh(_data_request.node());

		_handle_modem_state();
		_publish_modem_config();

		log("modem_link started");
	}
};


void Component::construct(Genode::Env &env)
{
	static Telephony::Main main(env);
}
