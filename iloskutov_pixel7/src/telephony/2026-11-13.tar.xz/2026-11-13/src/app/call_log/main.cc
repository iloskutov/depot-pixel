/*
 * \brief  Call log: the calls of the phone
 * \author Ivan Loskutov
 * \date   2026-09-26
 *
 * Records each call (in, out, missed) as the modem's state ("modem_state")
 * shows it begin and end, newest first, and reports them as "call_log":
 *
 *   call_log | missed_total: 3
 *   + call | number | direction: in|out|missed | time | duration_s | seen
 *
 * A missed call is unseen until the Phone app shows its log ('phone_view
 * | tab: recent' while the shell's "ui_state" names the Phone app as
 * shown). 'missed_total' counts the missed calls ever logged. The calls
 * are kept in the file 'calls' of the component's VFS. A call the user
 * refused ("call_request" of the Phone app, "call_action" of the shell) is
 * logged as missed, but seen. A call that was going on already when the
 * log started is not logged: its direction is unknown.
 *
 *   config
 *   + vfs | + ram
 */

/*
 * SPDX-License-Identifier: MIT
 */

#include <base/component.h>
#include <base/attached_rom_dataspace.h>
#include <base/heap.h>
#include <os/reporter.h>
#include <os/vfs.h>
#include <rtc_session/connection.h>
#include <timer_session/connection.h>

#include <attribute_text.h>
#include <call_tracker.h>
#include <request_tracker.h>
#include <store_file.h>
#include <view_state.h>

namespace Telephony {

	using namespace Genode;

	struct Calls;
	struct Main;
}


struct Telephony::Calls
{
	using Entry     = Call_tracker::Entry;
	using Number    = Call_tracker::Number;
	using Stamp     = Call_tracker::Stamp;
	using Direction = Call_tracker::Direction;

	static constexpr unsigned MAX = 100;

	Entry    _calls[MAX] { };   /* newest first */
	unsigned _count = 0;

	/* missed calls ever logged: changes when the log drops its oldest one */
	unsigned _missed_total = 0;

	void add(Entry const &e)
	{
		unsigned const n = min(_count, MAX - 1);
		for (unsigned i = n; i > 0; i--)
			_calls[i] = _calls[i - 1];
		_calls[0] = e;
		_calls[0].number = Number(attribute_text<Number::capacity()>(e.number.string()));
		_count = n + 1;

		/* only a missed call can be unseen */
		if (e.direction == Direction::MISSED)
			_missed_total++;
		else
			_calls[0].seen = true;
	}

	/**
	 * Mark all missed calls as seen, return true if anything changed
	 */
	bool mark_seen()
	{
		bool changed = false;
		for (unsigned i = 0; i < _count; i++)
			if (!_calls[i].seen) {
				_calls[i].seen = true;
				changed = true;
			}
		return changed;
	}

	void gen(Generator &g) const
	{
		g.attribute("missed_total", _missed_total);
		for (unsigned i = 0; i < _count; i++) {
			Entry const &e = _calls[i];
			g.node("call", [&] {
				g.attribute("number",     e.number);
				g.attribute("direction",  Call_tracker::direction_name(e.direction));
				g.attribute("time",       e.time);
				g.attribute("duration_s", e.duration_s);
				g.attribute("seen",       e.seen ? "yes" : "no"); });
		}
	}

	/* the file: oldest first */
	void gen_store(Generator &g) const
	{
		g.attribute("missed_total", _missed_total);
		for (unsigned i = _count; i-- > 0; ) {
			Entry const &e = _calls[i];
			g.node("call", [&] {
				g.attribute("number",     e.number);
				g.attribute("direction",  Call_tracker::direction_name(e.direction));
				g.attribute("time",       e.time);
				g.attribute("duration_s", e.duration_s);
				g.attribute("seen",       e.seen ? "yes" : "no"); });
		}
	}

	void load(Node const &store)
	{
		_count = 0;
		_missed_total = 0;
		store.for_each_sub_node("call", [&] (Node const &c) {
			using Dir_name = String<8>;
			Dir_name const d = c.attribute_value("direction", Dir_name());
			add({ .number     = c.attribute_value("number", Number()),
			      .direction  = (d == "in")  ? Direction::IN
			                  : (d == "out") ? Direction::OUT : Direction::MISSED,
			      .time       = c.attribute_value("time", Stamp()),
			      .duration_s = c.attribute_value("duration_s", 0U),
			      .seen       = c.attribute_value("seen", true) }); });

		/* never below the missed calls of the log */
		_missed_total = max(_missed_total, store.attribute_value("missed_total", 0U));
	}
};


struct Telephony::Main
{
	Env &_env;

	Heap _heap { _env.ram(), _env.rm() };

	Attached_rom_dataspace _config { _env, "config" };

	Root_directory _root = _config.node().with_sub_node("vfs",
		[&] (Node const &vfs) -> Root_directory { return { _env, _heap, vfs }; },
		[&] () -> Root_directory {
			warning("no vfs configured, the calls are not kept");
			return { _env, _heap, Node() }; });

	Rtc::Connection   _rtc   { _env };
	Timer::Connection _timer { _env };

	Call_tracker _call  { };
	Calls        _calls { };
	View_state   _view  { };

	Expanding_reporter _call_log { _env, "call_log", "call_log" };

	Attached_rom_dataspace _modem_state { _env, "modem_state" };
	Attached_rom_dataspace _ui_state    { _env, "ui_state" };
	Attached_rom_dataspace _phone_view  { _env, "phone_view" };

	/* where the user refuses a call */
	Attached_rom_dataspace _call_request { _env, "call_request" };
	Attached_rom_dataspace _call_action  { _env, "call_action" };

	Request_tracker _call_requests { };
	Request_tracker _call_actions  { };

	void _apply_refusal(Attached_rom_dataspace &rom, Request_tracker &tracker)
	{
		rom.update();
		if (!tracker.fresh(rom.node()))
			return;

		using Action = String<16>;
		Action const action = rom.node().attribute_value("action", Action());
		if (action == "reject" || action == "hangup")
			_call.rejected();
	}

	void _handle_refusal()
	{
		_apply_refusal(_call_request, _call_requests);
		_apply_refusal(_call_action,  _call_actions);
	}

	Signal_handler<Main> _refusal_handler { _env.ep(), *this, &Main::_handle_refusal };

	static constexpr size_t STORE_MAX = 64*1024;

	Store_file _file { _root, _heap, "calls", "calls", STORE_MAX };

	Call_tracker::Stamp _stamp()
	{
		Rtc::Timestamp const t = _rtc.current_time();
		auto two = [] (unsigned v) { return String<3>(v < 10 ? "0" : "", v); };
		return Call_tracker::Stamp(t.year, "-", two(t.month), "-", two(t.day), " ",
		                           two(t.hour), ":", two(t.minute));
	}

	uint64_t _now_s() { return _timer.elapsed_ms() / 1000; }

	void _save()
	{
		static char buf[STORE_MAX];
		Generator::generate(Byte_range_ptr(buf, sizeof(buf)), "calls",
			[&] (Generator &g) { _calls.gen_store(g); }
		).with_result(
			[&] (size_t used) { _file.save(Const_byte_range_ptr(buf, used)); },
			[&] (Buffer_error) { warning("calls exceed ", STORE_MAX, " bytes"); });
	}

	void _publish()
	{
		_call_log.generate([&] (Generator &g) { _calls.gen(g); });
	}

	void _changed()
	{
		_save();
		_publish();
	}

	void _handle_modem_state()
	{
		_modem_state.update();

		bool added = false;
		_call.apply_modem(_modem_state.node(), _stamp(), _now_s(),
			[&] (Call_tracker::Entry const &e) { _calls.add(e); added = true; });

		if (!added)
			return;

		/* a call missed while the log is in view is seen */
		_mark_viewed();
		_changed();
	}

	Signal_handler<Main> _modem_state_handler {
		_env.ep(), *this, &Main::_handle_modem_state };

	bool _mark_viewed()
	{
		return _view.call_log_viewed(_timer.elapsed_ms()) && _calls.mark_seen();
	}

	/* called for the view ROMs and when a view has lasted its settle time */
	void _handle_view()
	{
		_ui_state  .update();
		_phone_view.update();

		uint64_t const now_ms = _timer.elapsed_ms();
		_view.apply_ui_state  (_ui_state.node(),   now_ms);
		_view.apply_phone_view(_phone_view.node(), now_ms);

		/* a view just entered counts later, see 'View_state' */
		if (uint64_t const pending_ms = _view.settle_remaining_ms(_timer.elapsed_ms()))
			_timer.trigger_once(pending_ms*1000);

		if (_mark_viewed())
			_changed();
	}

	Signal_handler<Main> _view_handler { _env.ep(), *this, &Main::_handle_view };

	Main(Env &env) : _env(env)
	{
		using Load = Store_file::Load;
		switch (_file.load([&] (Node const &store) { _calls.load(store); })) {
		case Load::LOADED: break;
		case Load::NONE:   log("no calls logged yet");         break;
		case Load::BAD:    warning("starting without calls"); break;
		}

		_modem_state.sigh(_modem_state_handler);
		_ui_state   .sigh(_view_handler);
		_phone_view .sigh(_view_handler);
		_timer      .sigh(_view_handler);

		_call_request.sigh(_refusal_handler);
		_call_action .sigh(_refusal_handler);

		/* requests of before the start say nothing about a call of now */
		_call_requests.fresh(_call_request.node());
		_call_actions .fresh(_call_action.node());

		_handle_view();
		_publish();
		_handle_modem_state();

		log("call_log started");
	}
};


void Component::construct(Genode::Env &env)
{
	static Telephony::Main main(env);
}
