/*
 * \brief  Notifications: what the user has not looked at yet
 * \author Ivan Loskutov
 * \date   2026-11-14
 *
 * From the reports of 'call_log' and 'sms_store' (ROMs "call_log" and
 * "messages"), the unseen missed calls and the unread chats, newest first
 * ("notifications"):
 *
 *   notifications
 *   + notification | id: sms:<number> | app: messages | kind: sms
 *                  | title: <number> | text: <newest unread text>
 *                  | count: <unread in the chat> | serial: <id of that text>
 *                  | time
 *   + notification | id: call:missed | app: phone | kind: missed_call
 *                  | title: <number of the newest unseen call>
 *                  | text: Missed call
 *                  | count: <unseen> | serial: <missed calls ever logged>
 *                  | time
 *
 * The serial changes whenever something is added to a notification. The
 * title is a number: who shows it looks the name up.
 */

/*
 * SPDX-License-Identifier: MIT
 */

#include <base/component.h>
#include <base/attached_rom_dataspace.h>
#include <os/reporter.h>

namespace Notifications {

	using namespace Genode;

	struct Main;
}


struct Notifications::Main
{
	Env &_env;

	using Number = String<33>;
	using Text   = String<161>;
	using Stamp  = String<20>;   /* "YYYY-MM-DD HH:MM", ordered as text */
	using Id     = String<48>;
	using Kind   = String<16>;

	/* characters of a message shown by a notification */
	static constexpr unsigned NOTIFICATION_CHARS = 60;

	struct Item
	{
		Id       id;
		Kind     app, kind;
		Number   title;
		Text     text;
		unsigned count, serial;
		Stamp    time;
	};

	static constexpr unsigned MAX = 32;

	Item     _items[MAX] { };
	unsigned _count = 0;

	Attached_rom_dataspace _call_log { _env, "call_log" };
	Attached_rom_dataspace _messages { _env, "messages" };

	Expanding_reporter _report { _env, "notifications", "notifications" };

	/* text cut to at most 'max_chars' characters (not bytes) of UTF-8 */
	static Text _cut(Text const &text, unsigned max_chars)
	{
		char const *s = text.string();
		size_t bytes = 0;
		for (unsigned chars = 0; s[bytes]; bytes++) {
			bool const continuation = ((unsigned char)s[bytes] & 0xc0) == 0x80;
			if (!continuation && chars++ == max_chars)
				break;
		}
		return Text(Cstring(s, bytes));
	}

	void _add(Item const &item)
	{
		if (_count < MAX)
			_items[_count++] = item;
	}

	void _collect()
	{
		_count = 0;

		/* the unseen missed calls, the log is newest first */
		Node const &calls = _call_log.node();
		unsigned missed = 0;
		Item item { .id = "call:missed", .app = "phone", .kind = "missed_call",
		            .title = { }, .text = "Missed call", .count = 0,
		            .serial = calls.attribute_value("missed_total", 0u), .time = { } };
		calls.for_each_sub_node("call", [&] (Node const &call) {
			if (call.attribute_value("seen", true))
				return;
			if (!missed++) {
				item.title = call.attribute_value("number", Number());
				item.time  = call.attribute_value("time",   Stamp());
			}
		});
		if (missed) {
			item.count = missed;
			_add(item);
		}

		/* each chat with unread messages: its newest unread one */
		_messages.node().for_each_sub_node("chat", [&] (Node const &chat) {
			unsigned const unread = chat.attribute_value("unread", 0u);
			if (!unread)
				return;
			Number const number = chat.attribute_value("number", Number());
			Item newest { .id = Id("sms:", number), .app = "messages", .kind = "sms",
			              .title = number, .text = { }, .count = unread,
			              .serial = 0, .time = { } };
			chat.for_each_sub_node("msg", [&] (Node const &msg) {
				if (msg.attribute_value("read", true))
					return;
				newest.text   = _cut(msg.attribute_value("text", Text()), NOTIFICATION_CHARS);
				newest.serial = msg.attribute_value("id", 0u);
				newest.time   = msg.attribute_value("time", Stamp()); });
			_add(newest);
		});

		/* newest first, by time, stable */
		for (unsigned i = 1; i < _count; i++)
			for (unsigned j = i; j > 0 && strcmp(_items[j].time.string(),
			                                      _items[j - 1].time.string()) > 0; j--) {
				Item const t = _items[j]; _items[j] = _items[j - 1]; _items[j - 1] = t; }
	}

	void _handle()
	{
		_call_log.update();
		_messages.update();
		_collect();

		_report.generate([&] (Generator &g) {
			for (unsigned i = 0; i < _count; i++) {
				Item const &n = _items[i];
				g.node("notification", [&] {
					g.attribute("id",     n.id);
					g.attribute("app",    n.app);
					g.attribute("kind",   n.kind);
					g.attribute("title",  n.title);
					g.attribute("text",   n.text);
					g.attribute("count",  n.count);
					g.attribute("serial", n.serial);
					g.attribute("time",   n.time); });
			}
		});
	}

	Signal_handler<Main> _handler { _env.ep(), *this, &Main::_handle };

	Main(Env &env) : _env(env)
	{
		_call_log.sigh(_handler);
		_messages.sigh(_handler);
		_handle();
	}
};


void Component::construct(Genode::Env &env)
{
	static Notifications::Main main(env);
}
