/*
 * \brief  SMS part of the modem protocol (rild_modem's state/config schema)
 * \author Ivan Loskutov
 * \date   2026-09-30
 *
 * Incoming: the modem reports every received SMS with an increasing id and
 * keeps it until the config's '<sms acknowledged>' reaches the id. Each id
 * above the acknowledged one is handed out once; 'acknowledged' then rises
 * to the highest handed-out id. It is kept in sms_store's file, so a
 * restarted sms_store does not duplicate messages.
 *
 * The ids are the modem's and start at 1 whenever the modem component
 * starts, while the store, and with it the acknowledged id, may outlive
 * that (a persistent store across a reboot). The modem therefore names
 * its id space: '<sms epoch>' of the state report, an opaque string that
 * differs after every start of the modem and is compared for equality
 * only. It is stored with the acknowledged id. A report with another
 * epoch starts the counter at 0 again, so every listed message is handed
 * out; the store drops the ones it has already ('Messages::add_received'). The config names the epoch its counter belongs to, so a
 * modem can tell a counter of its own id space from a stale one. A report
 * without epoch is taken as before.
 *
 * Outgoing: a message is a '<send>' node of the config until the modem
 * reports its id as 'sent' or 'failed'.
 */

/*
 * SPDX-License-Identifier: MIT
 */

#ifndef _SMS_LINK_H_
#define _SMS_LINK_H_

/* local includes */
#include <attribute_text.h>
#include <call_tracker.h>

namespace Telephony { struct Sms_link; }


struct Telephony::Sms_link
{
	using Number       = Call_tracker::Number;
	/*
	 * A whole SMS as UTF-8: 160 characters of the GSM alphabet take up to 3
	 * bytes each. A longer text is cut, at a character.
	 */
	using Text         = Genode::String<481>;
	using Reason       = Genode::String<48>;
	using Epoch        = Genode::String<32>;
	using Network_time = Genode::String<32>;

	static constexpr unsigned MAX_OUTBOX = 16;

	struct Send { bool used; unsigned id; Number to; Text text; Genode::uint64_t since_ms; };

	Send     _outbox[MAX_OUTBOX] { };
	unsigned _acknowledged = 0;   /* handed out */
	unsigned _confirmed    = 0;   /* told to the modem: what is stored for good */
	Epoch    _epoch { };     /* id space '_acknowledged' counts in, empty if unknown */

	unsigned acknowledged() const { return _acknowledged; }

	Epoch epoch() const { return _epoch; }

	/**
	 * Restore the acknowledged id from the store
	 */
	void acknowledged(unsigned id) { _acknowledged = _confirmed = id; }

	/**
	 * What was handed out is stored: the modem may drop it
	 */
	void confirm() { _confirmed = _acknowledged; }

	/**
	 * Restore the epoch of the acknowledged id from the store
	 */
	void epoch(Epoch const &epoch) { _epoch = epoch; }

	/**
	 * Queue an outgoing message, return false if the outbox is full
	 */
	bool add_send(unsigned id, Number const &to, Text const &text,
	              Genode::uint64_t now_ms)
	{
		for (Send const &s : _outbox)
			if (s.used && s.id == id)
				return true;

		for (Send &s : _outbox)
			if (!s.used) {
				s = { .used = true, .id = id, .to = to, .text = text,
				      .since_ms = now_ms };
				return true;
			}
		return false;
	}

	bool outbox_empty() const
	{
		for (Send const &s : _outbox)
			if (s.used) return false;
		return true;
	}

	/**
	 * Give up the messages the modem did not finish within 'timeout_ms'
	 *
	 * \param fn  called as (unsigned id) per message given up
	 * \return true if any was given up
	 */
	bool expire(Genode::uint64_t now_ms, Genode::uint64_t timeout_ms, auto const &fn)
	{
		bool any = false;
		for (Send &s : _outbox)
			if (s.used && now_ms - s.since_ms >= timeout_ms) {
				s.used = false;
				fn(s.id);
				any = true;
			}
		return any;
	}

	bool outbox_full() const
	{
		for (Send const &s : _outbox)
			if (!s.used) return false;
		return true;
	}

	/**
	 * Apply the modem's state report
	 *
	 * \param on_received  called as (Number from, Text text, Network_time
	 *                     time) once per received message above the
	 *                     acknowledged id, in increasing id order; 'time'
	 *                     is the network's time stamp, empty if the modem
	 *                     reports none
	 * \param on_sent      called as (unsigned id, bool ok, Reason reason)
	 *                     once per outbox message the modem finished
	 *
	 * \return true if anything was handed out or the epoch changed: the
	 *         acknowledged id and its epoch are to be stored
	 */
	bool apply_state(Genode::Node const &modem, auto const &on_received,
	                 auto const &on_sent)
	{
		bool changed = false;

		modem.with_optional_sub_node("sms", [&] (Genode::Node const &sms) {

			/* another id space: nothing of it is acknowledged yet */
			if (sms.has_attribute("epoch")) {
				Epoch const epoch = attribute_text<Epoch::capacity()>(
					sms.attribute_value("epoch", Epoch()).string());

				if (epoch != _epoch) {
					_epoch        = epoch;
					_acknowledged = 0;
					_confirmed    = 0;
					changed       = true;
				}
			}

			/*
			 * Received messages in increasing id order: the report is
			 * not required to be sorted.
			 */
			for (;;) {
				unsigned next = 0;
				sms.for_each_sub_node("received", [&] (Genode::Node const &r) {
					unsigned const id = r.attribute_value("id", 0U);
					if (id > _acknowledged && (!next || id < next))
						next = id; });
				if (!next)
					break;

				sms.for_each_sub_node("received", [&] (Genode::Node const &r) {
					if (r.attribute_value("id", 0U) != next)
						return;
					on_received(r.attribute_value("from", Number()),
					            r.attribute_value("text", Text()),
					            r.attribute_value("time", Network_time()));
				});
				_acknowledged = next;
				changed = true;
			}

			sms.for_each_sub_node("sent", [&] (Genode::Node const &s) {
				using State = Genode::String<16>;
				unsigned const id    = s.attribute_value("id", 0U);
				State    const state = s.attribute_value("state", State());
				if (state != "sent" && state != "failed")
					return;

				for (Send &o : _outbox)
					if (o.used && o.id == id) {
						o.used = false;
						on_sent(id, state == "sent", s.attribute_value("reason", Reason()));
						changed = true;
					}
			});
		});
		return changed;
	}

	/**
	 * Generate the content of the modem config's 'sms' node
	 */
	void gen_sms_config(Genode::Generator &g) const
	{
		g.attribute("acknowledged", _confirmed);
		if (_epoch.length() > 1)
			g.attribute("epoch", _epoch);
		for (Send const &s : _outbox)
			if (s.used)
				g.node("send", [&] {
					g.attribute("id",   s.id);
					g.attribute("to",   s.to);
					g.attribute("text", s.text); });
	}
};

#endif /* _SMS_LINK_H_ */
