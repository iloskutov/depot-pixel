/*
 * \brief  SMS store: the messages of the phone
 * \author Ivan Loskutov
 * \date   2026-09-26
 *
 * Keeps the received messages (from the modem's state, "modem_state") and
 * the sent ones (requests of the Messages app, "sms_request"), and reports
 * them as chats, newest first ("messages"):
 *
 *   messages | request_seq | request_chat
 *   + chat | number | unread
 *     + msg | id | dir: in|out | time | text | state: sending|sent|failed
 *           | read: yes|no
 *
 * The SMS part of the modem's config is reported as "sms_config" for
 * 'modem_link', which writes it into the modem's config as it is: the
 * acknowledged id of the received messages and the messages to send.
 *
 *   sms_request | seq | to | text
 *
 * A chat is read while the Messages app shows it ('messages_view | chat:
 * <number>' while the shell's "ui_state" names the app as shown). The
 * messages are kept in the file 'messages' of the component's VFS.
 *
 *   config
 *   + vfs | + ram
 */

/*
 * SPDX-License-Identifier: MIT
 */

#include <base/component.h>
#include <base/attached_rom_dataspace.h>
#include <base/heap.h>
#include <os/reporter.h>
#include <os/vfs.h>
#include <rtc_session/connection.h>
#include <timer_session/connection.h>

#include <attribute_text.h>
#include <phone_number.h>
#include <request_tracker.h>
#include <store_file.h>
#include <view_state.h>
#include <sms_link.h>

namespace Telephony {

	using namespace Genode;

	struct Messages;
	struct Main;
}


struct Telephony::Messages
{
	using Stamp        = Call_tracker::Stamp;
	using Text         = Sms_link::Text;
	using Epoch        = Sms_link::Epoch;
	using Network_time = Sms_link::Network_time;

	static constexpr unsigned MAX = 300;

	/* outgoing: sending until the modem reports it sent or failed */
	enum class State { SENDING, SENT, FAILED };

	struct Message
	{
		unsigned id;
		Number   peer;
		bool     incoming;
		Stamp    time;
		Text     text;
		State    state;
		bool     read;      /* outgoing messages are always read */

		/* of a received message, empty if the modem reported none */
		Network_time network_time { };
	};

	static char const *state_name(State s)
	{
		switch (s) {
		case State::SENDING: return "sending";
		case State::SENT:    return "sent";
		case State::FAILED:  return "failed";
		}
		return "sending";
	}

	static State state_from(String<8> const &name)
	{
		if (name == "sent")   return State::SENT;
		if (name == "failed") return State::FAILED;
		return State::SENDING;
	}

	Message  _msgs[MAX] { };   /* chronological */
	unsigned _count   = 0;
	unsigned _next_id = 1;

	/* highest modem SMS id stored, and the modem's id space it counts in */
	unsigned acknowledged = 0;
	Epoch    epoch { };

	/*
	 * Messages below this id were stored before the start or under another
	 * epoch: only those can be listed again by the modem
	 */
	unsigned _relist_below = 1;
	Epoch    _relist_epoch { };

	/* the number a chat goes by: the one of its first message */
	Number chat_peer(Number const &number) const
	{
		for (unsigned i = 0; i < _count; i++)
			if (same_number(_msgs[i].peer, number))
				return _msgs[i].peer;
		return number;
	}

	static Text sanitize(char const *text) {
		return attribute_text<Text::capacity()>(text); }

	unsigned add(Number const &peer, bool incoming, Stamp const &time,
	             Text const &text, bool sent)
	{
		if (_count == MAX) {
			for (unsigned i = 1; i < MAX; i++)
				_msgs[i - 1] = _msgs[i];
			_count--;
		}
		unsigned const id = _next_id++;
		_msgs[_count++] = { .id = id,
		                    .peer = chat_peer(Number(attribute_text<Number::capacity()>(peer.string()))),
		                    .incoming = incoming,
		                    .time = time, .text = sanitize(text.string()),
		                    .state = sent ? State::SENT : State::SENDING,
		                    .read  = !incoming };
		return id;
	}

	/**
	 * Store a message received by the modem, unless it is stored already
	 *
	 * The modem lists a message again when its acknowledgement got lost
	 * with a restart (ours, or the modem's: another 'modem_epoch'): among
	 * the messages stored before that, the one with the same sender,
	 * network time stamp and text is the same message. Without a time
	 * stamp a message cannot be recognised and is stored.
	 *
	 * \return true if the message was stored
	 */
	bool add_received(Number const &from, Stamp const &time, Text const &text,
	                  Network_time const &network_time, Epoch const &modem_epoch)
	{
		if (modem_epoch != _relist_epoch) {
			_relist_epoch = modem_epoch;
			_relist_below = _next_id;
		}

		Number       const peer    = Number(attribute_text<Number::capacity()>(from.string()));
		Text         const content = sanitize(text.string());
		Network_time const sent    =
			attribute_text<Network_time::capacity()>(network_time.string());

		if (sent.length() > 1)
			for (unsigned i = 0; i < _count; i++) {
				Message const &m = _msgs[i];
				if (m.id < _relist_below && m.incoming && m.network_time == sent
				 && same_number(m.peer, peer) && m.text == content)
					return false;
			}

		add(from, true, time, text, true);
		_msgs[_count - 1].network_time = sent;
		return true;
	}

	/**
	 * Mark the incoming messages of the chat with 'peer' as read
	 *
	 * \return true if anything changed
	 */
	bool mark_read(Number const &peer)
	{
		bool changed = false;
		for (unsigned i = 0; i < _count; i++)
			if (!_msgs[i].read && same_number(_msgs[i].peer, peer)) {
				_msgs[i].read = true;
				changed = true;
			}
		return changed;
	}

	unsigned unread(Number const &peer) const
	{
		unsigned n = 0;
		for (unsigned i = 0; i < _count; i++)
			if (!_msgs[i].read && same_number(_msgs[i].peer, peer))
				n++;
		return n;
	}

	void for_each_unsent(auto const &fn) const
	{
		for (unsigned i = 0; i < _count; i++)
			if (!_msgs[i].incoming && _msgs[i].state == State::SENDING)
				fn(_msgs[i].id, _msgs[i].peer, _msgs[i].text);
	}

	void mark(unsigned id, State state)
	{
		for (unsigned i = 0; i < _count; i++)
			if (_msgs[i].id == id)
				_msgs[i].state = state;
	}

	void _gen_msg(Generator &g, Message const &m) const
	{
		g.node("msg", [&] {
			g.attribute("id",    m.id);
			g.attribute("dir",   m.incoming ? "in" : "out");
			g.attribute("time",  m.time);
			g.attribute("text",  m.text);
			g.attribute("state", state_name(m.state));
			g.attribute("read",  m.read ? "yes" : "no"); });
	}

	/* chats ordered by their most recent message, newest first */
	void gen_chats(Generator &g) const
	{
		bool done[MAX] { };
		for (unsigned i = _count; i-- > 0; ) {
			if (done[i])
				continue;
			Number const peer = _msgs[i].peer;
			g.node("chat", [&] {
				g.attribute("number", peer);
				if (unsigned const n = unread(peer))
					g.attribute("unread", n);
				for (unsigned j = 0; j < _count; j++) {
					if (_msgs[j].peer != peer)
						continue;
					done[j] = true;
					_gen_msg(g, _msgs[j]);
				}
			});
		}
	}

	void gen_store(Generator &g) const
	{
		g.attribute("acknowledged", acknowledged);
		if (epoch.length() > 1)
			g.attribute("epoch", epoch);

		for (unsigned i = 0; i < _count; i++) {
			Message const &m = _msgs[i];
			g.node("msg", [&] {
				g.attribute("id",    m.id);
				g.attribute("peer",  m.peer);
				g.attribute("dir",   m.incoming ? "in" : "out");
				g.attribute("time",  m.time);
				g.attribute("text",  m.text);
				g.attribute("state", state_name(m.state));
				g.attribute("read",  m.read ? "yes" : "no");
				if (m.network_time.length() > 1)
					g.attribute("network_time", m.network_time);
			});
		}
	}

	void load(Node const &store)
	{
		_count = 0;

		acknowledged = store.attribute_value("acknowledged", 0U);
		epoch        = attribute_text<Epoch::capacity()>(
			store.attribute_value("epoch", Epoch()).string());

		/* ids are kept: pending messages are resent under the same id */
		_next_id = 1;
		store.for_each_sub_node("msg", [&] (Node const &m) {
			using Name = String<8>;
			unsigned const stored_id = m.attribute_value("id", 0U);
			unsigned const id = add(m.attribute_value("peer", Number()),
			                        m.attribute_value("dir", Name()) == "in",
			                        m.attribute_value("time", Stamp()),
			                        m.attribute_value("text", Text()), false);
			Message &last = _msgs[_count - 1];
			last.state = state_from(m.attribute_value("state", Name()));
			if (last.incoming)
				last.read = m.attribute_value("read", true);
			last.network_time = attribute_text<Network_time::capacity()>(
				m.attribute_value("network_time", Network_time()).string());
			if (stored_id)
				last.id = stored_id;
			_next_id = max(_next_id, max(id, stored_id) + 1);
		});

		_relist_below = _next_id;
		_relist_epoch = epoch;
	}
};


struct Telephony::Main
{
	Env &_env;

	Heap _heap { _env.ram(), _env.rm() };

	Attached_rom_dataspace _config { _env, "config" };

	Root_directory _root = _config.node().with_sub_node("vfs",
		[&] (Node const &vfs) -> Root_directory { return { _env, _heap, vfs }; },
		[&] () -> Root_directory {
			warning("no vfs configured, the messages are not kept");
			return { _env, _heap, Node() }; });

	/* without a VFS nothing is kept, by intent */
	bool const _persistent = _config.node().has_sub_node("vfs");

	Rtc::Connection   _rtc   { _env };
	Timer::Connection _timer { _env };

	/*
	 * A message the modem does not report as sent or failed within this
	 * time has failed: it leaves the outbox, which would fill up otherwise
	 */
	static constexpr uint64_t SEND_TIMEOUT_MS = 5*60*1000;

	Timer::Connection _outbox_timer { _env };

	Messages   _messages { };
	Sms_link   _link     { };
	View_state _view     { };

	Request_tracker _requests { };

	Number _request_chat { };

	Expanding_reporter _messages_report { _env, "messages", "messages" };
	Expanding_reporter _sms_config      { _env, "sms",      "sms_config" };

	Attached_rom_dataspace _modem_state   { _env, "modem_state" };
	Attached_rom_dataspace _sms_request   { _env, "sms_request" };
	Attached_rom_dataspace _ui_state      { _env, "ui_state" };
	Attached_rom_dataspace _messages_view { _env, "messages_view" };

	/* 300 messages of at most 480 bytes of text */
	static constexpr size_t STORE_MAX = 256*1024;

	Store_file _file { _root, _heap, "messages", "messages", STORE_MAX };

	Call_tracker::Stamp _stamp()
	{
		Rtc::Timestamp const t = _rtc.current_time();
		auto two = [] (unsigned v) { return String<3>(v < 10 ? "0" : "", v); };
		return Call_tracker::Stamp(t.year, "-", two(t.month), "-", two(t.day), " ",
		                           two(t.hour), ":", two(t.minute));
	}

	/**
	 * \return true if the file holds the messages now
	 */
	bool _save()
	{
		static char buf[STORE_MAX];
		bool saved = false;
		Generator::generate(Byte_range_ptr(buf, sizeof(buf)), "messages",
			[&] (Generator &g) { _messages.gen_store(g); }
		).with_result(
			[&] (size_t used) { saved = _file.save(Const_byte_range_ptr(buf, used)); },
			[&] (Buffer_error) { warning("messages exceed ", STORE_MAX, " bytes"); });
		return saved;
	}

	void _publish()
	{
		_messages_report.generate([&] (Generator &g) {
			/* lets a relaunched client continue after the last request */
			g.attribute("request_seq", _requests.last_seq());

			/* the chat the message of that request went to */
			if (_request_chat.length() > 1)
				g.attribute("request_chat", _request_chat);
			_messages.gen_chats(g); });

		/* the attributes and sends of the modem config's '<sms>' node */
		_sms_config.generate([&] (Generator &g) {
			_link.gen_sms_config(g); });
	}

	bool _mark_viewed()
	{
		Number const chat = _view.viewed_chat(_timer.elapsed_ms());
		return chat.length() > 1 && _messages.mark_read(chat);
	}

	void _handle_modem_state()
	{
		_modem_state.update();

		/* incoming messages: stored once, then acknowledged; outgoing outcomes */
		bool const changed = _link.apply_state(_modem_state.node(),
			[&] (Number const &from, Messages::Text const &text,
			     Messages::Network_time const &time) {
				if (!_messages.add_received(from, _stamp(), text, time, _link.epoch()))
					log("sms listed again by the modem, stored already"); },
			[&] (unsigned id, bool sent, Sms_link::Reason const &reason) {
				if (sent) {
					_messages.mark(id, Messages::State::SENT);
				} else {
					_messages.mark(id, Messages::State::FAILED);
					warning("sms ", id, " not sent: ", reason);
				}
			});

		if (!changed)
			return;

		_messages.acknowledged = _link.acknowledged();
		_messages.epoch        = _link.epoch();

		/* what arrives in view is read before anyone hears of it */
		_mark_viewed();

		/* the modem drops a message only once it is stored for good */
		if (_save() || !_persistent)
			_link.confirm();
		else
			warning("messages not saved, the modem keeps them");

		_publish();
	}

	void _handle_outbox_timeout()
	{
		bool const expired = _link.expire(_timer.elapsed_ms(), SEND_TIMEOUT_MS,
			[&] (unsigned id) {
				_messages.mark(id, Messages::State::FAILED);
				warning("sms ", id, " not sent: no answer of the modem"); });

		if (expired) {
			_save();
			_publish();
		}
		if (!_link.outbox_empty())
			_outbox_timer.trigger_once(30*1000*1000);
	}

	Signal_handler<Main> _outbox_timeout_handler {
		_env.ep(), *this, &Main::_handle_outbox_timeout };

	Signal_handler<Main> _modem_state_handler {
		_env.ep(), *this, &Main::_handle_modem_state };

	void _handle_sms_request()
	{
		_sms_request.update();
		Node const &req = _sms_request.node();
		if (!_requests.fresh(req))
			return;

		Number         const to   = req.attribute_value("to", Number());
		Messages::Text const text = Messages::sanitize(
			req.attribute_value("text", Messages::Text()).string());

		_request_chat = Number();

		if (!valid_number(to) || text.length() <= 1) {
			warning("sms to '", to, "' ignored");
			_publish();   /* the request is answered nevertheless */
			return;
		}
		unsigned const id = _messages.add(to, false, _stamp(), text, false);

		_request_chat = _messages.chat_peer(to);

		/* shown in its chat as failed */
		if (_link.outbox_full()) {
			warning("outbox full, sms to '", to, "' not sent");
			_messages.mark(id, Messages::State::FAILED);
		} else {
			_link.add_send(id, to, text, _timer.elapsed_ms());
			_outbox_timer.trigger_once(30*1000*1000);
		}
		_save();
		_publish();
	}

	Signal_handler<Main> _sms_request_handler {
		_env.ep(), *this, &Main::_handle_sms_request };

	/* called for the view ROMs and when a view has lasted its settle time */
	void _handle_view()
	{
		_ui_state     .update();
		_messages_view.update();

		uint64_t const now_ms = _timer.elapsed_ms();
		_view.apply_ui_state     (_ui_state.node(),      now_ms);
		_view.apply_messages_view(_messages_view.node(), now_ms);

		/* a view just entered counts later, see 'View_state' */
		if (uint64_t const pending_ms = _view.settle_remaining_ms(_timer.elapsed_ms()))
			_timer.trigger_once(pending_ms*1000);

		if (_mark_viewed()) {
			_save();
			_publish();
		}
	}

	Signal_handler<Main> _view_handler { _env.ep(), *this, &Main::_handle_view };

	Main(Env &env) : _env(env)
	{
		using Load = Store_file::Load;
		switch (_file.load([&] (Node const &store) { _messages.load(store); })) {
		case Load::LOADED: break;
		case Load::NONE:   log("no messages stored yet");        break;
		case Load::BAD:    warning("starting without messages"); break;
		}

		/* incoming messages up to this modem id of this epoch are stored already */
		_link.acknowledged(_messages.acknowledged);
		_link.epoch(_messages.epoch);

		/* messages that were still being sent are sent again, same id */
		_messages.for_each_unsent([&] (unsigned id, Number const &to,
		                               Messages::Text const &text) {
			_link.add_send(id, to, text, _timer.elapsed_ms()); });

		_outbox_timer.sigh(_outbox_timeout_handler);
		if (!_link.outbox_empty())
			_outbox_timer.trigger_once(30*1000*1000);

		/* a request of before the start is not carried out again */
		_requests.fresh(_sms_request.node());

		_modem_state  .sigh(_modem_state_handler);
		_sms_request  .sigh(_sms_request_handler);
		_ui_state     .sigh(_view_handler);
		_messages_view.sigh(_view_handler);
		_timer        .sigh(_view_handler);

		_handle_view();
		_publish();
		_handle_modem_state();

		log("sms_store started");
	}
};


void Component::construct(Genode::Env &env)
{
	static Telephony::Main main(env);
}
