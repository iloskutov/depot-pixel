/*
 * \brief  Console front end of the modem: answers calls, logs SMS
 * \author Ivan Loskutov
 * \date   2026-11-07
 *
 * A client of rild_modem: it watches the modem's state (ROM "state", the
 * 'modem' report of rild_modem) and writes rild_modem's config (report
 * "config"). It switches the modem on, accepts every incoming call, and
 * logs every received SMS once, which it then acknowledges. Changes of the
 * power, the SIM, the network registration, the call, and the mobile data
 * are logged too.
 *
 * Config:
 *
 *   config | pin: 1234 | attach_apn: internet | data_apn: internet
 *
 * All attributes are optional: the PIN of the SIM, the APN of the initial
 * attach to an LTE network, and the APN of a mobile-data context to set up
 * (not while roaming). Its packets take the modem driver's interface that
 * the state names.
 *
 * With 'data_apn', the context is also reported as "data" whenever it
 * changes, for the configs of the data path (the modem driver's uplink,
 * the router), which the full state would update with every change of the
 * signal strength:
 *
 *   data | state: active | ifname: rmnet1 | address: 100.64.12.34/32
 *        | dns: 1.1.1.1
 *
 * 'ifname' to 'dns' are present while the context is active, 'address' and
 * 'dns' are its IPv4 ones.
 */

/*
 * SPDX-License-Identifier: MIT
 */

#include <base/attached_rom_dataspace.h>
#include <base/component.h>
#include <os/reporter.h>
#include <util/reconstructible.h>
#include <util/string.h>

namespace Modem_console {

	using namespace Genode;

	struct Main;
}


struct Modem_console::Main
{
	Env &_env;

	using Text   = String<64>;
	using Number = String<32>;

	Attached_rom_dataspace _config { _env, "config" };
	Attached_rom_dataspace _state  { _env, "state"  };

	Expanding_reporter _modem_config { _env, "config", "config" };

	/* the data context, reported with 'data_apn' only */
	Constructible<Expanding_reporter> _data_report { };

	/* what was logged last, to log changes only */
	Text   _power { }, _sim { }, _network { }, _call { };
	String<128> _data { };

	/* the call to accept: its number (empty for a caller without one) */
	bool   _accepting = false;
	Number _accept { };

	/* received messages: the epoch of their ids, the highest id logged */
	Text     _epoch { };
	unsigned _last_sms = 0;

	template <size_t N>
	void _log_change(String<N> &last, String<N> const &now, char const *what)
	{
		if (now == last)
			return;

		last = now;
		log(what, ": ", now);
	}

	void _generate_config()
	{
		Node const &config = _config.node();

		_modem_config.generate([&] (Generator &g) {
			g.attribute("power", "on");

			Text const pin = config.attribute_value("pin", Text());
			if (pin.length() > 1)
				g.attribute("pin", pin);

			Text const apn = config.attribute_value("attach_apn", Text());
			if (apn.length() > 1)
				g.node("network", [&] { g.attribute("attach_apn", apn); });

			if (_accepting)
				g.node("call", [&] {
					if (_accept.length() > 1)
						g.attribute("number", _accept);
					g.attribute("state",  "accepted"); });

			Text const data_apn = config.attribute_value("data_apn", Text());
			if (data_apn.length() > 1)
				g.node("data", [&] {
					g.node("context", [&] {
						g.attribute("apn",    data_apn);
						g.attribute("active", true); }); });

			g.node("sms", [&] {
				g.attribute("acknowledged", _last_sms);
				if (_epoch.length() > 1)
					g.attribute("epoch", _epoch); });
		});
	}

	void _handle_state()
	{
		_state.update();

		Node const &modem = _state.node();

		_log_change(_power, modem.attribute_value("power", Text("unavailable")), "power");
		_log_change(_sim,   modem.attribute_value("sim",   Text("unknown")),     "SIM");

		Text network { "unavailable" };
		modem.with_optional_sub_node("network", [&] (Node const &n) {
			network = Text(n.attribute_value("status",   Text()), " ",
			               n.attribute_value("operator", Text()), " ",
			               n.attribute_value("technology", Text())); });
		_log_change(_network, network, "network");

		/* the call: accept it while it is incoming, forget it when gone */
		bool   accepting = false;
		Number number { };
		Text   call   { "none" };
		modem.with_optional_sub_node("call", [&] (Node const &c) {
			accepting = true;
			number = c.attribute_value("number", Number());
			call   = Text(c.attribute_value("state", Text()), " ", number); });
		_log_change(_call, call, "call");

		/* the data context: its state, and the interface and address while active */
		Text state { "none" }, ifname { }, address { }, dns { }, cause { };
		modem.with_optional_sub_node("data", [&] (Node const &d) {
			d.with_optional_sub_node("context", [&] (Node const &c) {
				state  = c.attribute_value("state",  Text());
				ifname = c.attribute_value("ifname", Text());
				cause  = c.attribute_value("cause",  Text());
				c.with_optional_sub_node("ipv4", [&] (Node const &ip) {
					address = ip.attribute_value("address", Text());
					dns     = ip.attribute_value("dns",     Text()); }); }); });

		String<128> data { state };
		auto append = [&] (Text const &part) {
			if (part.length() > 1) data = String<128>(data, " ", part); };
		append(ifname); append(address); append(dns); append(cause);
		if (data != _data && _data_report.constructed())
			_data_report->generate([&] (Generator &g) {
				g.attribute("state", state);
				auto optional = [&] (char const *name, Text const &value) {
					if (value.length() > 1) g.attribute(name, value); };
				optional("ifname",  ifname);
				optional("address", address);
				optional("dns",     dns); });
		_log_change(_data, data, "data");

		Number const accept = number;

		/* received messages, each logged once */
		Text     epoch    = _epoch;
		unsigned last_sms = _last_sms;
		modem.with_optional_sub_node("sms", [&] (Node const &sms) {
			epoch = sms.attribute_value("epoch", Text());

			/* a new epoch restarts the ids */
			if (epoch != _epoch)
				last_sms = 0;

			sms.for_each_sub_node("received", [&] (Node const &r) {
				unsigned const id = r.attribute_value("id", 0U);
				if (id <= last_sms)
					return;

				last_sms = id;
				log("SMS from ", r.attribute_value("from", Number()),
				    " at ", r.attribute_value("time", Text()), ": ",
				    r.attribute_value("text", String<1024>()));
			});
		});

		if (accepting == _accepting && accept == _accept
		 && epoch == _epoch && last_sms == _last_sms)
			return;

		if (accepting && (!_accepting || accept != _accept))
			log("accepting the call of ", accept.length() > 1 ? accept : Number("an unknown number"));

		_accepting = accepting;
		_accept    = accept;
		_epoch    = epoch;
		_last_sms = last_sms;
		_generate_config();
	}

	Signal_handler<Main> _state_handler {
		_env.ep(), *this, &Main::_handle_state };

	Main(Env &env) : _env(env)
	{
		if (_config.node().attribute_value("data_apn", Text()).length() > 1)
			_data_report.construct(_env, "data", "data");

		_state.sigh(_state_handler);
		_generate_config();
		_handle_state();
	}
};


void Component::construct(Genode::Env &env)
{
	static Modem_console::Main main(env);
}
