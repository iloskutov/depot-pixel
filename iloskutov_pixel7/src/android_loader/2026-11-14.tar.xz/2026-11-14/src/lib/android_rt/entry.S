/*
 * \brief  Assembly helpers of the Android runtime
 * \author Ivan Loskutov
 * \date   2026-09-25
 */

/*
 * SPDX-License-Identifier: MIT
 */

.section .text

/*
 * TLSDESC resolver for static TLS: the descriptor's second word already
 * holds the tp-relative offset (x0 points to the descriptor)
 */
.global art_tlsdesc_static
.type art_tlsdesc_static, %function
art_tlsdesc_static:
	ldr x0, [x0, #8]
	ret

/*
 * Enter bionic's _start (x0 = entry, x1 = Linux-style argument block)
 *
 * _start expects sp to point at argc; the block lives on the calling
 * thread's own stack, so the thread stays a proper Genode thread.
 */
.global art_enter
.type art_enter, %function
art_enter:
	mov sp,  x1
	mov x29, xzr
	mov x30, xzr
	br  x0
