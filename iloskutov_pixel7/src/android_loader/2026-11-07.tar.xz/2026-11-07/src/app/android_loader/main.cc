/*
 * \brief  Android loader: runs an unmodified Android (bionic) program
 * \author Ivan Loskutov
 * \date   2026-09-25
 *
 * Config:
 *
 *   config | program: /vendor/bin/android_hello
 *   + arg | value: android_hello                  argv[0..]
 *   + env | value: KEY=value
 *   + property | name: ro.foo | value: bar        initial properties
 *   + properties | file: /etc/getprop.txt         ... or a getprop dump
 *   + property_service                            shared properties (android_prop)
 *   + chardev | prefix: /dev/umts_                paths served by Android_chardev
 *   + net_interfaces | prefix: rmnet | count: 30  interfaces besides lo
 *   + profile | lib: android_profile_cbd.lib.so   in-process profile
 *   + export_binder                               announce Android_binder
 *   + binder | trace: yes                         log every binder transaction
 *   + vfs                                         program, libraries under
 *     ...                                         /vendor, /system, ...
 *
 * The attribute 'object_map: yes' of the config logs each object's load
 * address.
 */

/*
 * SPDX-License-Identifier: MIT
 */

#include <base/attached_rom_dataspace.h>
#include <base/heap.h>
#include <base/log.h>
#include <cpu/cache.h>
#include <libc/component.h>
#include <util/string.h>

#include <android_rt/runtime.h>
#include <android_rt/chardev.h>
#include <android_rt/dev.h>

#include <fcntl.h>
#include <pthread.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <unistd.h>

using namespace Genode;


/**
 * Zeroed RWX memory from RAM dataspaces, small requests from a bump arena
 */
struct Loader_memory : Android_elf::Memory
{
	Env &_env;

	enum { CHUNK = 1024*1024, MAX_REGIONS = 256 };

	struct Region { addr_t start; size_t size; };
	Region   _regions[MAX_REGIONS] { };
	unsigned _region_count = 0;

	addr_t _arena = 0;
	size_t _arena_left = 0;

	Loader_memory(Env &env) : _env(env) { }

	addr_t _attach(size_t size)
	{
		if (_region_count == MAX_REGIONS) return 0;
		Ram_dataspace_capability ds { };
		_env.pd().alloc_ram(size).with_result(
			[&] (Ram_dataspace_capability cap) { ds = cap; },
			[&] (Alloc_error) { });
		if (!ds.valid()) return 0;

		addr_t const at = _env.rm().attach(ds, {
			.size = { }, .offset = { }, .use_at = { }, .at = { },
			.executable = true, .writeable = true
		}).convert<addr_t>(
			[&] (Env::Local_rm::Attachment &a) { a.deallocate = false; return addr_t(a.ptr); },
			[&] (Env::Local_rm::Error)          { return addr_t(0); });
		if (at) _regions[_region_count++] = { at, size };
		else    _env.pd().free_ram(ds);
		return at;
	}

	uint8_t *alloc(size_t size, size_t align) override
	{
		if (align < 16) align = 16;

		/* no sum below wraps */
		if (size > ~size_t(0) / 4 || align > ~size_t(0) / 4) return nullptr;

		/* large objects get their own dataspace, aligned inside it */
		if (size + align > CHUNK / 4) {
			addr_t const at = _attach(size + align);
			return at ? (uint8_t *)((at + align - 1) & ~(align - 1)) : nullptr;
		}

		addr_t p = (_arena + align - 1) & ~(align - 1);
		if (!_arena || p + size > _arena + _arena_left) {
			_arena = _attach(CHUNK);
			_arena_left = _arena ? CHUNK : 0;
			if (!_arena) return nullptr;
			p = (_arena + align - 1) & ~(align - 1);
		}
		_arena_left -= (p + size) - _arena;
		_arena = p + size;
		return (uint8_t *)p;
	}

	/**
	 * Make loaded code visible to instruction fetch
	 */
	void make_coherent()
	{
		for (unsigned i = 0; i < _region_count; i++)
			cache_coherent(_regions[i].start, _regions[i].size);
	}
};


/**
 * Library and program files from the component's VFS
 *
 * A file is read once for loading and freed as soon as its segments are in
 * the image.
 */
struct Vfs_files : Android_elf::File_source
{
	bool exists(char const *path) override
	{
		struct stat st { };
		return ::stat(path, &st) == 0 && S_ISREG(st.st_mode);
	}

	void release(uint8_t const *content) override { ::free(const_cast<uint8_t *>(content)); }

	uint8_t const *read(char const *path, size_t &size) override
	{
		int const fd = ::open(path, O_RDONLY);
		if (fd < 0) return nullptr;

		struct stat st { };
		if (::fstat(fd, &st) < 0 || st.st_size <= 0) { ::close(fd); return nullptr; }

		uint8_t *buf = (uint8_t *)::malloc(size_t(st.st_size));
		size_t done = 0;
		while (buf && done < size_t(st.st_size)) {
			ssize_t const n = ::read(fd, buf + done, size_t(st.st_size) - done);
			if (n <= 0) break;
			done += size_t(n);
		}
		::close(fd);
		if (!buf || done != size_t(st.st_size)) { ::free(buf); return nullptr; }

		size = done;
		return buf;
	}
};


/**
 * Attributes of <profile>, copied at construction (the profile may ask later)
 */
struct Profile_attrs : Android_rt::Profile_config
{
	enum { MAX = 16 };
	using Name  = String<64>;
	using Value = String<256>;

	Name     names[MAX]  { };
	Value    values[MAX] { };
	unsigned count = 0;

	void capture(Node const &n)
	{
		n.for_each_attribute([&] (Node::Attribute const &a) {
			Name const name { Cstring(a.tag.start, a.tag.num_bytes) };
			if (count == MAX) {
				warning("android_loader: <profile> attribute '", name, "' dropped "
				        "(more than ", unsigned(MAX), " attributes)");
				return;
			}
			names[count]  = name;
			values[count] = Value(Cstring(a.value.start, a.value.num_bytes));
			count++;
		});
	}

	int attr(char const *name, char *buf, unsigned len) override
	{
		for (unsigned i = 0; i < count; i++)
			if (names[i] == name) {
				copy_cstring(buf, values[i].string(), len);
				return int(strlen(buf));
			}
		return -1;
	}
};


struct Loader : Noncopyable
{
	using Path  = String<128>;
	using Value = String<256>;

	enum { MAX_ARGS = 32 };

	Env          &_env;
	Heap          _heap  { _env.ram(), _env.rm() };
	Loader_memory _mem   { _env };
	Vfs_files     _files { };

	Android_rt::Overrides _overrides { _mem };
	Android_elf::Linker   _linker { _mem, _files, _overrides, (void *)art_tlsdesc_static };

	Path     _program { };
	Path     _properties_file { };
	Path     _profile_lib { };
	bool     _export_binder = false;
	bool     _object_map    = false;
	bool     _property_service = false;
	bool     _local_properties = false;   /* <property>/<properties> present */
	Value    _arg_str[MAX_ARGS] { };
	Value    _env_str[MAX_ARGS] { };
	char const *_argv[MAX_ARGS + 1] { };
	char const *_envp[MAX_ARGS + 1] { };
	int      _argc = 0, _envc = 0;

	Profile_attrs _profile_attrs { };

	pthread_t _thread { };

	Loader(Loader const &) = delete;
	Loader &operator = (Loader const &) = delete;

	/* Android log priority of config log_level (0: everything) */
	static int _log_level(Node const &config)
	{
		auto const l = config.attribute_value("log_level", String<16>());
		if (l == "debug") return 3;
		if (l == "info")  return 4;
		if (l == "warn")  return 5;
		if (l == "error") return 6;
		return 0;
	}

	Loader(Libc::Env &env) : _env(env)
	{
		env.with_config([&] (Node const &config) {
			_property_service = config.has_sub_node("property_service");
			_program = config.attribute_value("program", Path());
			Android_rt::verbose(config.attribute_value("verbose", false));
			Android_rt::log_level(_log_level(config));
			_object_map = config.attribute_value("object_map", false);
			config.for_each_sub_node("arg", [&] (Node const &n) {
				if (_argc < MAX_ARGS) _arg_str[_argc++] = n.attribute_value("value", Value()); });
			config.for_each_sub_node("env", [&] (Node const &n) {
				if (_envc < MAX_ARGS) _env_str[_envc++] = n.attribute_value("value", Value()); });
			config.with_optional_sub_node("properties", [&] (Node const &n) {
				_local_properties = true;
				_properties_file = n.attribute_value("file", Path()); });
			config.for_each_sub_node("chardev", [&] (Node const &n) {
				Android_rt::add_chardev_prefix(
					n.attribute_value("prefix", Path()).string()); });
			config.with_optional_sub_node("net_interfaces", [&] (Node const &n) {
				Android_rt::set_net_interfaces(
					n.attribute_value("prefix", String<12>("rmnet")).string(),
					n.attribute_value("count", 0U)); });
			config.with_optional_sub_node("profile", [&] (Node const &n) {
				_profile_lib = n.attribute_value("lib", Path());
				_profile_attrs.capture(n); });
			config.for_each_sub_node("property", [&] (Node const &n) {
				_local_properties = true;
				if (!_property_service)
					Android_rt::set_property(n.attribute_value("name",  Value()).string(),
					                         n.attribute_value("value", Value()).string()); });
			config.with_optional_sub_node("export_binder", [&] (Node const &) {
				_export_binder = true; });
			config.with_optional_sub_node("binder", [&] (Node const &n) {
				Android_rt::binder_trace(n.attribute_value("trace", false)); });
		});

		/* the runtime opens/announces Android_binder sessions with this env */
		Android_rt::init_genode(_env);
		if (_property_service) {
			if (_local_properties) {
				error("android_loader: <property>/<properties> are not allowed with "
				      "<property_service/> (initial values belong to android_prop)");
				::exit(1);
			}
			if (!Android_rt::use_property_service())
				::exit(1);
		}
		if (_profile_lib.length() > 1 &&
		    !Android_rt::load_profile(_env, _heap, _profile_lib.string(), _profile_attrs))
			::exit(1);
		if (_export_binder)
			Android_rt::export_binder_service();
		if (_argc == 0) _arg_str[_argc++] = Value(_program);
		for (int i = 0; i < _argc; i++) _argv[i] = _arg_str[i].string();
		for (int i = 0; i < _envc; i++) _envp[i] = _env_str[i].string();

		_linker.add_vendor_path("/vendor/lib64/hw");
		_linker.add_vendor_path("/vendor/lib64");
		_linker.add_system_path("/system/lib64");
		_linker.add_system_path("/apex/com.android.runtime/lib64/bionic");
		_linker.add_system_path("/apex/com.android.runtime/lib64");
		static char const * const replaced[] = {
			"libc.so", "libm.so", "libdl.so", "libdl_android.so", "liblog.so",
			"libbinder_ndk.so" };
		for (char const *r : replaced) _linker.replace(r);

		pthread_attr_t attr;
		pthread_attr_init(&attr);
		pthread_attr_setstacksize(&attr, 768*1024);
		if (pthread_create(&_thread, &attr, _entry, this))
			error("android_loader: cannot create the program thread");
	}

	static void *_entry(void *arg) { ((Loader *)arg)->_run(); return nullptr; }

	void _run()
	{
		/* files are only readable from a libc thread: load them here */
		if (_properties_file.length() > 1)
			Android_rt::load_properties_file(_properties_file.string());

		log("android_loader: loading ", _program);

		Android_elf::Linker::Result const r = _linker.load_program(_program.string());
		if (r != Android_elf::Linker::Result::OK) {
			error("android_loader: ", Cstring(_linker.error()));
			::exit(1);
		}
		log("android_loader: ", _linker.object_count(), " objects, ",
		    _linker.stub_count(), " unimplemented imports");
		/* to attribute a fault address: the object with the highest base below it */
		if (_object_map)
			for (unsigned i = 0; i < _linker.object_count(); i++)
				log("android_loader:   ", (void *)_linker.object(i)->base(), " ",
				    Cstring(_linker.path(i)));
		for (unsigned i = 0; i < _linker.stub_count(); i++)
			log("android_loader:   stub ", Cstring(_linker.stub_name(i)));

		_mem.make_coherent();
		Android_rt::start_program(_linker, _mem, _overrides, _argc, _argv, _envp);
	}
};


void Libc::Component::construct(Libc::Env &env)
{
	Libc::with_libc([&] { static Loader loader(env); });
}
