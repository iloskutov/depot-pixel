/*
 * \brief  Android loader profile for cbd: its system() command shapes
 * \author Ivan Loskutov
 * \date   2026-09-26
 *
 * There is no shell. cbd uses system() in these shapes only:
 *
 *   [timeout N] /vendor/bin/tar -cvf <out> <dir>/<star>   ustar of <dir>
 *   echo <text> > <file>   /  echo <text> >> <file>
 *
 * Anything else is logged and fails with status 127.
 *
 * LOAD_CP_IMAGE (0x401c6f40) passes cbd's 28-byte 'struct cp_image { u64
 * binary; u32 size, m_offset, b_offset, mode, len; }' whose 'binary' points
 * to the BOOT image in cbd's own memory; android_rt only sends the encoded
 * struct, so an 'ioctl_payload' hook appends the 'size' bytes at 'binary'
 * right after it (chardev_ioctl.h 'compose_ioctl_input'). The backend
 * expects exactly 'in_len == 28 + cp_image.size' and answers EINVAL if
 * they are missing.
 *
 * HANDOVER_BLOCK_INFO (0x6f57) is '_IO' -- no size in the command -- but
 * the Linux driver copies 'sizeof(struct t_handover_block_info)' = 161
 * bytes from 'arg' (link_device.c 'update_handover_block_info'); a second
 * hook sends them.
 */

/*
 * SPDX-License-Identifier: MIT
 */

#include <android_rt/profile.h>

#include <dirent.h>
#include <fcntl.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>

namespace {

	Android_profile_api const *profile_api;

	void note(char const *fmt, ...) __attribute__((format(printf, 1, 2)));
	void note(char const *fmt, ...)
	{
		char line[256];
		va_list ap; va_start(ap, fmt);
		vsnprintf(line, sizeof(line), fmt, ap);
		va_end(ap);
		profile_api->log(line);
	}

	void write_all(int fd, void const *p, size_t n)
	{
		char const *c = (char const *)p;
		while (n) {
			ssize_t const w = ::write(fd, c, n);
			if (w <= 0) return;
			c += w; n -= size_t(w);
		}
	}

	/* one ustar header block */
	void tar_header(uint8_t hdr[512], char const *name, size_t size, time_t mtime)
	{
		memset(hdr, 0, 512);
		size_t const n = strlen(name) < 99 ? strlen(name) : 99;   /* ustar name field */
		memcpy(hdr, name, n);
		snprintf((char *)hdr + 100, 8,  "%07o", 0644);
		snprintf((char *)hdr + 108, 8,  "%07o", 1001);          /* radio */
		snprintf((char *)hdr + 116, 8,  "%07o", 1001);
		snprintf((char *)hdr + 124, 12, "%011lo", (unsigned long)size);
		snprintf((char *)hdr + 136, 12, "%011lo", (unsigned long)mtime);
		hdr[156] = '0';
		memcpy(hdr + 257, "ustar", 6);
		memcpy(hdr + 263, "00", 2);
		strcpy((char *)hdr + 265, "radio");
		strcpy((char *)hdr + 297, "radio");
		memset(hdr + 148, ' ', 8);
		unsigned sum = 0;
		for (unsigned i = 0; i < 512; i++) sum += hdr[i];
		snprintf((char *)hdr + 148, 8, "%06o", sum);
	}

	int tar_create(char const *out, char const *dir)
	{
		DIR *d = opendir(dir);
		if (!d) { note("system: tar: no directory %s", dir); return 1; }
		int const fd = ::open(out, O_WRONLY | O_CREAT | O_TRUNC, 0664);
		if (fd < 0) { closedir(d); return 1; }

		unsigned files = 0;
		while (dirent *e = readdir(d)) {
			if (e->d_name[0] == '.') continue;
			char path[600], name[600];
			snprintf(path, sizeof(path), "%s/%s", dir, e->d_name);
			snprintf(name, sizeof(name), "%s/%s", dir, e->d_name);
			struct stat st { };
			if (stat(path, &st) || !S_ISREG(st.st_mode)) continue;

			uint8_t hdr[512];
			tar_header(hdr, name, size_t(st.st_size), st.st_mtim.tv_sec);
			write_all(fd, hdr, 512);

			int const in = ::open(path, O_RDONLY);
			size_t total = 0;
			char buf[4096];
			for (ssize_t n; in >= 0 && (n = ::read(in, buf, sizeof(buf))) > 0; total += size_t(n))
				write_all(fd, buf, size_t(n));
			if (in >= 0) ::close(in);
			static char const zeros[512] = { };
			if (total % 512) write_all(fd, zeros, 512 - total % 512);
			files++;
		}
		static char const end[1024] = { };
		write_all(fd, end, sizeof(end));
		::close(fd);
		closedir(d);
		note("system: tar %s <- %s (%u files)", out, dir, files);
		return 0;
	}

	int echo_redirect(char const *text, size_t text_len, char const *file, bool append)
	{
		int const fd = ::open(file, O_WRONLY | O_CREAT | (append ? O_APPEND : O_TRUNC), 0664);
		if (fd < 0) { note("system: echo: cannot open %s", file); return 1; }
		write_all(fd, text, text_len);
		write_all(fd, "\n", 1);
		::close(fd);
		return 0;
	}

	int cbd_system(char const *cmd)
	{
		if (!cmd) return 1;
		note("system: %s", cmd);

		char const *c = cmd;
		while (*c == ' ') c++;
		if (!strncmp(c, "timeout ", 8)) {                /* drop "timeout N " */
			c += 8;
			while (*c && *c != ' ') c++;
			while (*c == ' ') c++;
		}

		char out[256], dir[256];
		if (sscanf(c, "/vendor/bin/tar -cvf %255s %255s", out, dir) == 2) {
			size_t const n = strlen(dir);
			if (n > 2 && !strcmp(dir + n - 2, "/*")) {
				dir[n - 2] = 0;
				return tar_create(out, dir) << 8;
			}
		}

		if (!strncmp(c, "echo ", 5)) {
			char const *gt = strchr(c, '>');
			if (gt) {
				bool const append = gt[1] == '>';
				char const *f = gt + (append ? 2 : 1);
				while (*f == ' ') f++;
				char file[256];
				if (sscanf(f, "%255s", file) == 1) {
					char const *t = c + 5;
					char const *t_end = gt;
					while (t_end > t && t_end[-1] == ' ') t_end--;
					return echo_redirect(t, size_t(t_end - t), file, append) << 8;
				}
			}
		}

		note("system: unsupported command, not run");
		return 127 << 8;
	}

	enum { LOAD_CP_IMAGE = 0x401c6f40, BINARY_OFFSET = 0, SIZE_OFFSET = 8,
	       HANDOVER_BLOCK_INFO = 0x6f57, HANDOVER_LEN = 161 };

	/*
	 * 'arg' is cbd's own 'struct cp_image' (28 bytes: u64 binary, u32 size,
	 * m_offset, b_offset, mode, len). Read 'binary'/'size' by byte offset
	 * (never through a local struct type -- alignment of 'arg' is cbd's,
	 * not ours) and copy the BOOT image at 'binary' into 'out'. A size of 0
	 * or larger than 'cap' fails (returns 0); the backend then answers
	 * EINVAL instead of booting a truncated image.
	 */
	unsigned long load_cp_image_payload(void const *arg, void *out, unsigned long cap)
	{
		uint8_t const *a = (uint8_t const *)arg;

		uint64_t binary; memcpy(&binary, a + BINARY_OFFSET, sizeof(binary));
		uint32_t size;   memcpy(&size,   a + SIZE_OFFSET,   sizeof(size));

		if (!size || size > cap) {
			note("ioctl LOAD_CP_IMAGE: cp_image.size %u exceeds the %lu-byte "
			     "buffer, no BOOT payload sent", size, cap);
			return 0;
		}
		memcpy(out, (void const *)binary, size);
		return size;
	}

	/*
	 * 'arg' points to cbd's 161-byte handover block (the command encodes no
	 * size); copy it as the ioctl's input
	 */
	unsigned long handover_block_payload(void const *arg, void *out, unsigned long cap)
	{
		if (!arg || cap < HANDOVER_LEN) {
			note("ioctl HANDOVER_BLOCK_INFO: no block or buffer too small, not sent");
			return 0;
		}
		memcpy(out, arg, HANDOVER_LEN);
		return HANDOVER_LEN;
	}
}


extern "C" int android_profile_init(Android_profile_api const *api)
{
	if (!api || api->major != ANDROID_PROFILE_API_MAJOR) return 1;
	profile_api = api;

	if (int const r = api->override("system", (void *)cbd_system)) return r;

	/* minor 0 runtimes have no 'ioctl_payload' member -- skip, not fatal */
	if (api->minor >= 1 && api->size >= sizeof(Android_profile_api)) {
		api->ioctl_payload(LOAD_CP_IMAGE,       load_cp_image_payload);
		api->ioctl_payload(HANDOVER_BLOCK_INFO, handover_block_payload);
	}

	return 0;
}
