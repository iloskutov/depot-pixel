/*
 * \brief  bionic pthread ABI on Genode libc threads
 * \author Ivan Loskutov
 * \date   2026-09-25
 *
 * bionic's pthread types are larger than Genode's (FreeBSD) ones, and
 * PTHREAD_*_INITIALIZER is all zeros. Every bionic object therefore keeps
 * its first word (bionic type bits) and holds a lazily created Genode
 * object in the first 8-byte aligned slot after it: the bionic types are
 * int32 arrays, i.e. only 4-byte aligned (an 8-byte atomic on a 4-byte
 * aligned address raises an alignment fault). Each thread gets its own bionic thread block
 * (tpidr_el0) before its start routine runs.
 *
 * Limitation: the Genode object is freed by the bionic object's *_destroy
 * only. bionic's objects own no memory, so a program that uses a mutex,
 * condition variable or rwlock and drops it without *_destroy, or calls
 * *_init on a used one, leaks the Genode object here.
 */

/*
 * SPDX-License-Identifier: MIT
 */

#include <android_rt/runtime.h>
#include <android_rt/linux_abi.h>
#include <android_rt/deadline.h>
#include <base/log.h>

#include <errno.h>
#include <pthread.h>
#include <sched.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

using namespace Android_rt;

namespace {

	/* bionic LP64 layouts (sizes from bionic's pthread.h) */
	struct Bionic_attr
	{
		uint32_t flags;
		void    *stack_base;
		size_t   stack_size;
		size_t   guard_size;
		int32_t  sched_policy, sched_priority;
		char     reserved[16];
	};
	static_assert(sizeof(Bionic_attr) == 56, "bionic pthread_attr_t");

	struct Bionic_mutex  { int32_t type_bits; int32_t rest[9];  };
	struct Bionic_cond   { int32_t word;      int32_t rest[11]; };
	struct Bionic_rwlock { int32_t word;      int32_t rest[13]; };
	static_assert(sizeof(Bionic_mutex)  == 40, "bionic pthread_mutex_t");
	static_assert(sizeof(Bionic_cond)   == 48, "bionic pthread_cond_t");
	static_assert(sizeof(Bionic_rwlock) == 56, "bionic pthread_rwlock_t");

	/* slot for the Genode object: first 8-byte aligned address after word 0 */
	void *&slot(void *obj)
	{
		uintptr_t const a = ((uintptr_t)obj + 4 + 7) & ~uintptr_t(7);
		return *(void **)a;
	}

	enum { ATTR_FLAG_DETACHED = 1,
	       MUTEX_TYPE_SHIFT = 14, MUTEX_RECURSIVE = 1, MUTEX_ERRORCHECK = 2,
	       DEFAULT_STACK = 1024*1024,
	       MAX_STACK = 768*1024 };      /* what a Genode stack slot allows */

	/**
	 * Genode object behind a bionic one, created on first use
	 */
	template <typename T, typename CREATE, typename DESTROY>
	T lazy(void *&slot, CREATE const &create, DESTROY const &destroy)
	{
		T cur = (T)__atomic_load_n(&slot, __ATOMIC_ACQUIRE);
		if (cur) return cur;

		T fresh = create();
		void *expected = nullptr;
		if (__atomic_compare_exchange_n(&slot, &expected, (void *)fresh, false,
		                                __ATOMIC_ACQ_REL, __ATOMIC_ACQUIRE))
			return fresh;
		destroy(fresh);
		return (T)expected;
	}

	pthread_mutex_t *genode_mutex(Bionic_mutex *m)
	{
		return lazy<pthread_mutex_t *>(slot(m),
			[&] {
				pthread_mutexattr_t a;
				pthread_mutexattr_init(&a);
				int const type = (m->type_bits >> MUTEX_TYPE_SHIFT) & 3;
				pthread_mutexattr_settype(&a, type == MUTEX_RECURSIVE  ? PTHREAD_MUTEX_RECURSIVE
				                            : type == MUTEX_ERRORCHECK ? PTHREAD_MUTEX_ERRORCHECK
				                                                       : PTHREAD_MUTEX_NORMAL);
				pthread_mutex_t *g = (pthread_mutex_t *)malloc(sizeof(pthread_mutex_t));
				pthread_mutex_init(g, &a);
				pthread_mutexattr_destroy(&a);
				return g; },
			[&] (pthread_mutex_t *g) { pthread_mutex_destroy(g); free(g); });
	}

	pthread_cond_t *genode_cond(Bionic_cond *c)
	{
		return lazy<pthread_cond_t *>(slot(c),
			[&] {
				/* deadlines are passed as CLOCK_MONOTONIC (art_pthread_cond_clockwait) */
				pthread_condattr_t a;
				pthread_condattr_init(&a);
				pthread_condattr_setclock(&a, CLOCK_MONOTONIC);
				pthread_cond_t *g = (pthread_cond_t *)malloc(sizeof(pthread_cond_t));
				pthread_cond_init(g, &a);
				pthread_condattr_destroy(&a);
				return g; },
			[&] (pthread_cond_t *g) { pthread_cond_destroy(g); free(g); });
	}

	pthread_rwlock_t *genode_rwlock(Bionic_rwlock *l)
	{
		return lazy<pthread_rwlock_t *>(slot(l),
			[&] {
				pthread_rwlock_t *g = (pthread_rwlock_t *)malloc(sizeof(pthread_rwlock_t));
				pthread_rwlock_init(g, nullptr);
				return g; },
			[&] (pthread_rwlock_t *g) { pthread_rwlock_destroy(g); free(g); });
	}

	int linux_err(int freebsd_err) { return Linux::errno_from_freebsd(freebsd_err); }

	struct Start
	{
		void *(*fn)(void *);
		void   *arg;
		uint8_t *tp;
	};

	void *thread_entry(void *p)
	{
		Start const s = *(Start *)p;
		free(p);
		set_tp(s.tp);
		return s.fn(s.arg);
	}
}


extern "C" {

	/* attributes */

	int art_pthread_attr_init(Bionic_attr *a)
	{
		memset(a, 0, sizeof(*a));
		a->stack_size = DEFAULT_STACK;
		a->guard_size = 4096;
		return 0;
	}

	int art_pthread_attr_destroy(Bionic_attr *) { return 0; }

	int art_pthread_attr_setstacksize(Bionic_attr *a, size_t size) { a->stack_size = size; return 0; }
	int art_pthread_attr_getstacksize(Bionic_attr const *a, size_t *size) { *size = a->stack_size; return 0; }
	int art_pthread_attr_setguardsize(Bionic_attr *a, size_t size) { a->guard_size = size; return 0; }
	int art_pthread_attr_getguardsize(Bionic_attr const *a, size_t *size) { *size = a->guard_size; return 0; }

	int art_pthread_attr_setdetachstate(Bionic_attr *a, int state)
	{
		if (state) a->flags |= ATTR_FLAG_DETACHED; else a->flags &= ~ATTR_FLAG_DETACHED;
		return 0;
	}

	int art_pthread_attr_getdetachstate(Bionic_attr const *a, int *state)
	{
		*state = (a->flags & ATTR_FLAG_DETACHED) ? 1 : 0;
		return 0;
	}

	int art_pthread_attr_setschedparam(Bionic_attr *a, int const *prio) { a->sched_priority = *prio; return 0; }
	int art_pthread_attr_getschedparam(Bionic_attr const *a, int *prio) { *prio = a->sched_priority; return 0; }
	int art_pthread_attr_setschedpolicy(Bionic_attr *a, int p) { a->sched_policy = p; return 0; }

	/* threads */

	int art_pthread_create(long *thread, Bionic_attr const *battr,
	                       void *(*fn)(void *), void *arg)
	{
		size_t stack = battr ? battr->stack_size : size_t(DEFAULT_STACK);
		if (stack > MAX_STACK) {
			static size_t logged;
			/* bionic's 1 MiB default is capped silently */
			if (stack > DEFAULT_STACK && logged != stack) {
				Genode::log("android_rt: thread stack ", stack, " requested, ", (size_t)MAX_STACK, " granted");
				logged = stack;
			}
			stack = MAX_STACK;
		}

		pthread_attr_t attr;
		pthread_attr_init(&attr);
		pthread_attr_setstacksize(&attr, stack);
		if (battr && (battr->flags & ATTR_FLAG_DETACHED))
			pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);

		Start *s = (Start *)malloc(sizeof(Start));
		*s = { fn, arg, create_thread_block() };

		pthread_t t;
		int const err = pthread_create(&t, &attr, thread_entry, s);
		pthread_attr_destroy(&attr);
		if (err) { free(s); return linux_err(err); }
		*thread = (long)t;
		return 0;
	}

	int  art_pthread_join(long t, void **ret) { return linux_err(pthread_join((pthread_t)t, ret)); }
	int  art_pthread_detach(long t)           { return linux_err(pthread_detach((pthread_t)t)); }
	long art_pthread_self()                   { return (long)pthread_self(); }
	int  art_pthread_equal(long a, long b)    { return a == b; }

	[[noreturn]] void art_pthread_exit(void *ret) { pthread_exit(ret); }

	int art_pthread_setname_np(long, char const *) { return 0; }
	int art_pthread_getname_np(long, char *buf, size_t len)
	{
		if (len) buf[0] = 0;
		return 0;
	}

	int art_gettid() { return int(((long)pthread_self() >> 4) & 0x7fffffff); }
	int art_pthread_gettid_np(long t) { return int((t >> 4) & 0x7fffffff); }

	/* mutexes */

	int art_pthread_mutexattr_init(long *a)           { *a = 0; return 0; }
	int art_pthread_mutexattr_destroy(long *)         { return 0; }
	int art_pthread_mutexattr_settype(long *a, int t) { *a = t; return 0; }
	int art_pthread_mutexattr_gettype(long const *a, int *t) { *t = int(*a); return 0; }

	int art_pthread_mutex_init(Bionic_mutex *m, long const *attr)
	{
		memset(m, 0, sizeof(*m));
		m->type_bits = attr ? int32_t((*attr & 3) << MUTEX_TYPE_SHIFT) : 0;
		return 0;
	}

	int art_pthread_mutex_destroy(Bionic_mutex *m)
	{
		if (void *&g = slot(m)) { pthread_mutex_destroy((pthread_mutex_t *)g); free(g); g = nullptr; }
		return 0;
	}

	int art_pthread_mutex_lock(Bionic_mutex *m)    { return linux_err(pthread_mutex_lock(genode_mutex(m))); }

	int art_pthread_mutex_unlock(Bionic_mutex *m)
	{
		int const err = pthread_mutex_unlock(genode_mutex(m));

		/* bionic unlocks a normal mutex for any thread, Genode's libc only for the owner */
		if (err == EPERM && ((m->type_bits >> MUTEX_TYPE_SHIFT) & 3) == 0) {
			static bool logged;
			if (!logged) {
				logged = true;
				Genode::warning("android_rt: pthread_mutex_unlock of a normal mutex by a "
				                "thread that does not own it: stays locked");
			}
		}
		return linux_err(err);
	}

	int art_pthread_mutex_trylock(Bionic_mutex *m) { return linux_err(pthread_mutex_trylock(genode_mutex(m))); }

	/* condition variables */

	/*
	 * The clock of a condition variable (bionic: bit 1 of the attribute and
	 * of the cond's first word, CLOCK_MONOTONIC = 1 set, CLOCK_REALTIME = 0
	 * clear) decides how 'pthread_cond_timedwait' reads its deadline. Word 0
	 * of the cond is ours; the Genode object lives in the slot behind it.
	 */
	enum { LINUX_CLOCK_REALTIME = 0, LINUX_CLOCK_MONOTONIC = 1, COND_CLOCK_MONOTONIC = 2 };

	int art_pthread_condattr_init(long *a)    { *a = 0; return 0; }
	int art_pthread_condattr_destroy(long *)  { return 0; }

	int art_pthread_condattr_setclock(long *a, int clock)
	{
		if (clock != LINUX_CLOCK_REALTIME && clock != LINUX_CLOCK_MONOTONIC) return 22;   /* EINVAL */
		*a = (*a & ~long(COND_CLOCK_MONOTONIC)) | (clock == LINUX_CLOCK_MONOTONIC ? COND_CLOCK_MONOTONIC : 0);
		return 0;
	}

	int art_pthread_cond_init(Bionic_cond *c, long const *a)
	{
		memset(c, 0, sizeof(*c));
		if (a) c->word = int32_t(*a & COND_CLOCK_MONOTONIC);
		return 0;
	}

	int art_pthread_cond_clockwait(Bionic_cond *, Bionic_mutex *, int, timespec const *);

	int art_pthread_cond_destroy(Bionic_cond *c)
	{
		if (void *&g = slot(c)) { pthread_cond_destroy((pthread_cond_t *)g); free(g); g = nullptr; }
		return 0;
	}

	int art_pthread_cond_wait(Bionic_cond *c, Bionic_mutex *m)
	{
		return linux_err(pthread_cond_wait(genode_cond(c), genode_mutex(m)));
	}

	/* the deadline is of the cond's clock */
	int art_pthread_cond_timedwait(Bionic_cond *c, Bionic_mutex *m, timespec const *abstime)
	{
		int const clock = (c->word & COND_CLOCK_MONOTONIC) ? LINUX_CLOCK_MONOTONIC : LINUX_CLOCK_REALTIME;
		return art_pthread_cond_clockwait(c, m, clock, abstime);
	}

	/* the deadline is CLOCK_MONOTONIC, as the Genode condition variable measures */
	static int cond_timedwait_monotonic(Bionic_cond *c, Bionic_mutex *m, timespec const *abstime)
	{
		return linux_err(pthread_cond_timedwait(genode_cond(c), genode_mutex(m), abstime));
	}

	/*
	 * bionic's pthread_cond_clockwait (libc++ condition_variable waits on
	 * steady_clock with it): CLOCK_REALTIME or CLOCK_MONOTONIC, anything
	 * else is EINVAL, a null deadline waits untimed (bionic). The Genode
	 * condition variable measures CLOCK_MONOTONIC (genode_cond), so only a
	 * REALTIME deadline is moved to another clock, which needs the libc's
	 * real-time clock (EINVAL without one). 'convert_deadline'
	 * (android_rt/deadline.h) also validates like bionic and turns
	 * far-future deadlines (time_point::max()) into an untimed wait instead
	 * of overflowing.
	 */
	int art_pthread_cond_clockwait(Bionic_cond *c, Bionic_mutex *m, int clock,
	                               timespec const *abstime)
	{
		enum { LINUX_REALTIME = 0, LINUX_MONOTONIC = 1, EINVAL_ = 22, ETIMEDOUT_ = 110 };

		if (clock != LINUX_REALTIME && clock != LINUX_MONOTONIC) return EINVAL_;
		if (!abstime) return art_pthread_cond_wait(c, m);

		timespec mono { }, src { };
		if (clock_gettime(CLOCK_MONOTONIC, &mono)) return EINVAL_;
		if (clock == LINUX_MONOTONIC)                   src = mono;
		else if (clock_gettime(CLOCK_REALTIME, &src))   return EINVAL_;

		Deadline const d = convert_deadline({ abstime->tv_sec, abstime->tv_nsec },
		                                    { src.tv_sec,  src.tv_nsec },
		                                    { mono.tv_sec, mono.tv_nsec });
		switch (d.kind) {
		case Deadline::INVALID: return EINVAL_;
		case Deadline::EXPIRED: return ETIMEDOUT_;
		case Deadline::UNTIMED: return art_pthread_cond_wait(c, m);
		case Deadline::AT:      break;
		}
		timespec const deadline { .tv_sec = time_t(d.at.sec), .tv_nsec = d.at.nsec };
		return cond_timedwait_monotonic(c, m, &deadline);
	}

	int art_pthread_cond_signal(Bionic_cond *c)    { return linux_err(pthread_cond_signal(genode_cond(c))); }
	int art_pthread_cond_broadcast(Bionic_cond *c) { return linux_err(pthread_cond_broadcast(genode_cond(c))); }

	/* rwlocks */

	int art_pthread_rwlock_init(Bionic_rwlock *l, void const *) { memset(l, 0, sizeof(*l)); return 0; }

	int art_pthread_rwlock_destroy(Bionic_rwlock *l)
	{
		if (void *&g = slot(l)) { pthread_rwlock_destroy((pthread_rwlock_t *)g); free(g); g = nullptr; }
		return 0;
	}

	int art_pthread_rwlock_rdlock(Bionic_rwlock *l) { return linux_err(pthread_rwlock_rdlock(genode_rwlock(l))); }
	int art_pthread_rwlock_wrlock(Bionic_rwlock *l) { return linux_err(pthread_rwlock_wrlock(genode_rwlock(l))); }
	int art_pthread_rwlock_unlock(Bionic_rwlock *l) { return linux_err(pthread_rwlock_unlock(genode_rwlock(l))); }

	/* once: bionic's pthread_once_t is an int, 0 initially */

	int art_pthread_once(int *once, void (*fn)())
	{
		enum { INIT = 0, RUNNING = 1, DONE = 2 };
		int expected = INIT;
		if (__atomic_compare_exchange_n(once, &expected, RUNNING, false,
		                                __ATOMIC_ACQ_REL, __ATOMIC_ACQUIRE)) {
			fn();
			__atomic_store_n(once, DONE, __ATOMIC_RELEASE);
			return 0;
		}
		while (__atomic_load_n(once, __ATOMIC_ACQUIRE) != DONE) sched_yield();
		return 0;
	}

	/* keys: int on both sides */

	int   art_pthread_key_create(int *k, void (*d)(void *)) { return linux_err(pthread_key_create((pthread_key_t *)k, d)); }
	int   art_pthread_key_delete(int k)                     { return linux_err(pthread_key_delete(k)); }
	void *art_pthread_getspecific(int k)                    { return pthread_getspecific(k); }
	int   art_pthread_setspecific(int k, void const *v)     { return linux_err(pthread_setspecific(k, v)); }

	int art_sched_yield() { return sched_yield(); }

	/*
	 * thread_local destructors (libc++): run at exit for the main thread;
	 * other threads' objects are small and live as long as the process
	 */
	int art___cxa_thread_atexit_impl(void (*dtor)(void *), void *obj, void *dso);
}


extern "C" int art___cxa_atexit(void (*)(void *), void *, void *);

void Android_rt::start_thread(void *(*fn)(void *), void *arg)
{
	long t;
	if (art_pthread_create(&t, nullptr, fn, arg))
		Genode::error("android_rt: cannot start a runtime thread");
	else
		art_pthread_detach(t);
}


int art___cxa_thread_atexit_impl(void (*dtor)(void *), void *obj, void *dso)
{
	return art___cxa_atexit(dtor, obj, dso);
}


static Export const exports[] = {
	{ "pthread_attr_init",          (void *)art_pthread_attr_init },
	{ "pthread_attr_destroy",       (void *)art_pthread_attr_destroy },
	{ "pthread_attr_setstacksize",  (void *)art_pthread_attr_setstacksize },
	{ "pthread_attr_getstacksize",  (void *)art_pthread_attr_getstacksize },
	{ "pthread_attr_setguardsize",  (void *)art_pthread_attr_setguardsize },
	{ "pthread_attr_getguardsize",  (void *)art_pthread_attr_getguardsize },
	{ "pthread_attr_setdetachstate",(void *)art_pthread_attr_setdetachstate },
	{ "pthread_attr_getdetachstate",(void *)art_pthread_attr_getdetachstate },
	{ "pthread_attr_setschedparam", (void *)art_pthread_attr_setschedparam },
	{ "pthread_attr_getschedparam", (void *)art_pthread_attr_getschedparam },
	{ "pthread_attr_setschedpolicy",(void *)art_pthread_attr_setschedpolicy },
	{ "pthread_create",             (void *)art_pthread_create },
	{ "pthread_join",               (void *)art_pthread_join },
	{ "pthread_detach",             (void *)art_pthread_detach },
	{ "pthread_self",               (void *)art_pthread_self },
	{ "pthread_equal",              (void *)art_pthread_equal },
	{ "pthread_exit",               (void *)art_pthread_exit },
	{ "pthread_setname_np",         (void *)art_pthread_setname_np },
	{ "pthread_getname_np",         (void *)art_pthread_getname_np },
	{ "gettid",                     (void *)art_gettid },
	{ "pthread_gettid_np",          (void *)art_pthread_gettid_np },
	{ "pthread_mutexattr_init",     (void *)art_pthread_mutexattr_init },
	{ "pthread_mutexattr_destroy",  (void *)art_pthread_mutexattr_destroy },
	{ "pthread_mutexattr_settype",  (void *)art_pthread_mutexattr_settype },
	{ "pthread_mutexattr_gettype",  (void *)art_pthread_mutexattr_gettype },
	{ "pthread_mutex_init",         (void *)art_pthread_mutex_init },
	{ "pthread_mutex_destroy",      (void *)art_pthread_mutex_destroy },
	{ "pthread_mutex_lock",         (void *)art_pthread_mutex_lock },
	{ "pthread_mutex_unlock",       (void *)art_pthread_mutex_unlock },
	{ "pthread_mutex_trylock",      (void *)art_pthread_mutex_trylock },
	{ "pthread_condattr_init",      (void *)art_pthread_condattr_init },
	{ "pthread_condattr_destroy",   (void *)art_pthread_condattr_destroy },
	{ "pthread_condattr_setclock",  (void *)art_pthread_condattr_setclock },
	{ "pthread_cond_init",          (void *)art_pthread_cond_init },
	{ "pthread_cond_destroy",       (void *)art_pthread_cond_destroy },
	{ "pthread_cond_wait",          (void *)art_pthread_cond_wait },
	{ "pthread_cond_timedwait",     (void *)art_pthread_cond_timedwait },
	{ "pthread_cond_clockwait",     (void *)art_pthread_cond_clockwait },
	{ "pthread_cond_signal",        (void *)art_pthread_cond_signal },
	{ "pthread_cond_broadcast",     (void *)art_pthread_cond_broadcast },
	{ "pthread_rwlock_init",        (void *)art_pthread_rwlock_init },
	{ "pthread_rwlock_destroy",     (void *)art_pthread_rwlock_destroy },
	{ "pthread_rwlock_rdlock",      (void *)art_pthread_rwlock_rdlock },
	{ "pthread_rwlock_wrlock",      (void *)art_pthread_rwlock_wrlock },
	{ "pthread_rwlock_unlock",      (void *)art_pthread_rwlock_unlock },
	{ "pthread_once",               (void *)art_pthread_once },
	{ "pthread_key_create",         (void *)art_pthread_key_create },
	{ "pthread_key_delete",         (void *)art_pthread_key_delete },
	{ "pthread_getspecific",        (void *)art_pthread_getspecific },
	{ "pthread_setspecific",        (void *)art_pthread_setspecific },
	{ "sched_yield",                (void *)art_sched_yield },
	{ "__cxa_thread_atexit_impl",   (void *)art___cxa_thread_atexit_impl },
};

Export_group Android_rt::thread_exports() { return { exports, sizeof(exports) / sizeof(exports[0]) }; }
