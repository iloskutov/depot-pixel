/*
 * \brief  bionic locale and wide-character functions (C locale only)
 * \author Ivan Loskutov
 * \date   2026-09-25
 *
 * libc++ creates locales at static-initialisation time. Only the C/POSIX
 * locale is provided: every locale_t is the same handle and the *_l
 * variants ignore it. Multibyte and wide-character functions are those of
 * Genode's libc (wchar_t is 4 bytes on both). bionic's mbstate_t is smaller
 * than the libc's (8 instead of 128 bytes): passing it is safe only because
 * the conversions of the C locale, the only one the libc runs in here, do
 * not use the state.
 */

/*
 * SPDX-License-Identifier: MIT
 */

#include <android_rt/runtime.h>

#include <ctype.h>
#include <locale.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <wchar.h>
#include <wctype.h>

using namespace Android_rt;

namespace { char c_locale_object; }

extern "C" {

	void *art_newlocale(int, char const *, void *) { return &c_locale_object; }
	void  art_freelocale(void *) { }
	void *art_uselocale(void *) { return &c_locale_object; }
	char *art_setlocale(int, char const *) { static char c[] = "C"; return c; }
	size_t art___ctype_get_mb_cur_max() { return 1; }

	int art_strcoll_l(char const *a, char const *b, void *) { return strcoll(a, b); }
	size_t art_strxfrm_l(char *d, char const *s, size_t n, void *) { return strxfrm(d, s, n); }
	int art_wcscoll_l(wchar_t const *a, wchar_t const *b, void *) { return wcscoll(a, b); }
	size_t art_wcsxfrm_l(wchar_t *d, wchar_t const *s, size_t n, void *) { return wcsxfrm(d, s, n); }

	int art_iswlower_l (wint_t c, void *) { return iswlower(c);  }
	int art_iswupper_l (wint_t c, void *) { return iswupper(c);  }
	int art_iswspace_l (wint_t c, void *) { return iswspace(c);  }
	int art_iswprint_l (wint_t c, void *) { return iswprint(c);  }
	int art_iswcntrl_l (wint_t c, void *) { return iswcntrl(c);  }
	int art_iswalpha_l (wint_t c, void *) { return iswalpha(c);  }
	int art_iswdigit_l (wint_t c, void *) { return iswdigit(c);  }
	int art_iswpunct_l (wint_t c, void *) { return iswpunct(c);  }
	int art_iswxdigit_l(wint_t c, void *) { return iswxdigit(c); }
	int art_iswblank_l (wint_t c, void *) { return iswblank(c);  }
	wint_t art_towupper_l(wint_t c, void *) { return towupper(c); }
	wint_t art_towlower_l(wint_t c, void *) { return towlower(c); }

	long long art_strtoll_l(char const *s, char **e, int b, void *) { return strtoll(s, e, b); }
	unsigned long long art_strtoull_l(char const *s, char **e, int b, void *) { return strtoull(s, e, b); }
	float art_strtof_l(char const *s, char **e, void *) { return strtof(s, e); }
	double art_strtod_l(char const *s, char **e, void *) { return strtod(s, e); }
	long double art_strtold_l(char const *s, char **e, void *) { return strtold(s, e); }

	size_t art_strftime_l(char *s, size_t n, char const *f, tm const *t, void *) { return strftime(s, n, f, t); }

	/* bionic's struct lconv follows the C standard's member order */
	void *art_localeconv()
	{
		static char dot[] = ".", empty[] = "";
		static struct {
			char *decimal_point, *thousands_sep, *grouping, *int_curr_symbol,
			     *currency_symbol, *mon_decimal_point, *mon_thousands_sep,
			     *mon_grouping, *positive_sign, *negative_sign;
			char int_frac_digits, frac_digits, p_cs_precedes, p_sep_by_space,
			     n_cs_precedes, n_sep_by_space, p_sign_posn, n_sign_posn,
			     int_p_cs_precedes, int_p_sep_by_space, int_n_cs_precedes,
			     int_n_sep_by_space, int_p_sign_posn, int_n_sign_posn;
		} lc = { dot, empty, empty, empty, empty, empty, empty, empty, empty, empty,
		         127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127, 127 };
		return &lc;
	}
}


#define EXPORT(name) { #name, (void *)name }
#define ART(name)    { #name, (void *)art_##name }

static Export const exports[] = {
	ART(newlocale), ART(freelocale), ART(uselocale), ART(setlocale),
	ART(__ctype_get_mb_cur_max), ART(localeconv),
	ART(strcoll_l), ART(strxfrm_l), ART(wcscoll_l), ART(wcsxfrm_l),
	ART(iswlower_l), ART(iswupper_l), ART(iswspace_l), ART(iswprint_l), ART(iswcntrl_l),
	ART(iswalpha_l), ART(iswdigit_l), ART(iswpunct_l), ART(iswxdigit_l), ART(iswblank_l),
	ART(towupper_l), ART(towlower_l),
	ART(strtoll_l), ART(strtoull_l), ART(strtof_l), ART(strtod_l), ART(strtold_l),
	ART(strftime_l),
	EXPORT(btowc), EXPORT(wctob), EXPORT(mbrtowc), EXPORT(wcrtomb), EXPORT(mbtowc),
	EXPORT(mbrlen), EXPORT(mbsrtowcs), EXPORT(mbsnrtowcs), EXPORT(wcsnrtombs),
	EXPORT(wcstol), EXPORT(wcstoul), EXPORT(wcstoll), EXPORT(wcstoull),
	EXPORT(wcstof), EXPORT(wcstod), EXPORT(wcstold), EXPORT(swprintf),
	EXPORT(strftime), EXPORT(strxfrm),
};

#undef EXPORT
#undef ART

Export_group Android_rt::locale_exports() { return { exports, sizeof(exports) / sizeof(exports[0]) }; }
