/*
 * \brief  ioctl argument transfer derived from the Linux encoding
 * \author Ivan Loskutov
 * \date   2026-09-26
 *
 * asm-generic ioctl numbers: nr bits 0..7, type 8..15, size 16..29,
 * direction 30..31 (1 = write: user -> device, 2 = read: device -> user).
 * A command with a size and a direction points to that many bytes; one
 * without (e.g. cpif's _IO('o', 0x27)) passes its argument by value.
 *
 * 'compose_ioctl_input' builds the bytes actually sent to the session: the
 * command's own input, plus a profile-registered payload appended after it
 * (cbd's LOAD_CP_IMAGE sends its BOOT image this way -- see
 * android_rt/profile.h 'ioctl_payload').
 */

/*
 * SPDX-License-Identifier: MIT
 */

#ifndef _ANDROID_RT__CHARDEV_IOCTL_H_
#define _ANDROID_RT__CHARDEV_IOCTL_H_

#include <stddef.h>

namespace Android_rt {

	struct Ioctl_transfer { bool by_value; size_t in_len, out_len; };

	inline Ioctl_transfer ioctl_transfer(unsigned long cmd)
	{
		size_t   const size = (cmd >> 16) & 0x3fff;
		unsigned const dir  = unsigned(cmd >> 30) & 3;
		if (!size || !dir) return { true, 0, 0 };
		return { false, (dir & 1) ? size : 0, (dir & 2) ? size : 0 };
	}

	/*
	 * A profile's extra-input hook for one ioctl command (see
	 * android_rt/profile.h 'ioctl_payload'): writes at most 'cap' bytes to
	 * 'out', returns how many.
	 */
	using Ioctl_payload_fn = unsigned long (*)(void const *arg, void *out, unsigned long cap);

	/*
	 * No <string.h> here: this header is pulled into Genode components
	 * through android_rt/runtime.h, and libc's plain 'strlen' there once
	 * clashed with 'using namespace Genode' pulling in 'Genode::strlen'.
	 */
	inline void copy_bytes(void *dst, void const *src, size_t n)
	{
		char       *d = static_cast<char *>(dst);
		char const *s = static_cast<char const *>(src);
		for (size_t i = 0; i < n; i++) d[i] = s[i];
	}

	/*
	 * Build a chardev ioctl's input in 'buf' (capacity 'cap'): the 'cmd'-
	 * encoded bytes copied from 'arg', followed -- when 'payload_fn' is not
	 * null -- by whatever it writes right after. Returns the total number
	 * of bytes placed in 'buf', which never exceeds 'cap' even if
	 * 'payload_fn' misreports its own length.
	 */
	inline size_t compose_ioctl_input(unsigned long cmd, void const *arg,
	                                  void *buf, size_t cap,
	                                  Ioctl_payload_fn payload_fn)
	{
		size_t const in_len = ioctl_transfer(cmd).in_len;
		size_t const copied = in_len < cap ? in_len : cap;
		if (copied) copy_bytes(buf, arg, copied);
		if (!payload_fn) return copied;

		unsigned long const room = (unsigned long)(cap - copied);
		unsigned long       n    = payload_fn(arg, static_cast<char *>(buf) + copied, room);
		if (n > room) n = room;
		return copied + n;
	}
}

#endif /* _ANDROID_RT__CHARDEV_IOCTL_H_ */
