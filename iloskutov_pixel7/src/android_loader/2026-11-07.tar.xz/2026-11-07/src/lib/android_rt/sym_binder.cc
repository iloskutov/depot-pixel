/*
 * \brief  libbinder_ndk replacement: AIBinder / AServiceManager / transport
 * \author Ivan Loskutov
 * \date   2026-09-25
 *
 * Implements the AIBinder_*, AServiceManager_* and ABinderProcess_* functions
 * that the vendor AIDL libraries import from libbinder_ndk. No Android
 * libbinder, servicemanager or binder driver is involved:
 * a telephony interface is a Genode 'Android_binder' service whose session
 * label names the instance; init routing decides which component serves which
 * name.
 *
 * Binder kinds:
 *   LOCAL        an object of this process; 'transact' calls 'onTransact'
 *                directly (used for the server dispatcher and for a client's
 *                own callback objects).
 *   CLIENT_ROOT  a client's proxy of a remote instance (handle 0) over an
 *                'Android_binder::Client_conn' (lib/android_binder).
 *   CLIENT_CB    the server's proxy of a client callback object (oneway
 *                only) -- a transaction is pushed into the session's callback
 *                ring, the client drains it and runs the local object.
 *
 * The parcel format (lib/android_binder, parcel.cc) is shared by both ends.
 * Binder objects in a parcel are encoded by a 'Binder_codec' set on the
 * parcel: client->server passes {kind 1, sender-local id}, which the server
 * turns into a CLIENT_CB proxy per (session, id). Server->client binder
 * objects are unsupported (written as null). The client role is
 * lib/android_binder's 'Client_conn'; this file adds the vendor-object
 * adapters and the draining thread (vendor callbacks need bionic TLS).
 */

/*
 * SPDX-License-Identifier: MIT
 */

#include <android_rt/runtime.h>
#include <android_rt/io.h>
#include <android_binder_session/android_binder_session.h>
#include <android_binder_session/connection.h>

#include <base/attached_dataspace.h>
#include <base/attached_ram_dataspace.h>
#include <base/blockade.h>
#include <base/env.h>
#include <base/heap.h>
#include <base/log.h>
#include <base/mutex.h>
#include <base/semaphore.h>
#include <base/session_label.h>
#include <root/component.h>
#include <base/session_object.h>
#include <base/signal.h>
#include <session/session.h>
#include <util/fifo.h>

#include <android_binder/client.h>
#include <android_binder/parcel.h>
#include <android_binder/ring.h>

#include <util/construct_at.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

using namespace Android_rt;

using Genode::error;
using Genode::warning;
using Genode::log;
using Genode::Cstring;


/*******************************************
 ** Class and death-recipient definitions **
 *******************************************/

/* generated-code callback signatures (frameworks/native ... ndk/ibinder.h) */
extern "C" {
	typedef void *(*AIBinder_onCreate)(void *args);
	typedef void  (*AIBinder_onDestroy)(void *user_data);
	typedef binder_status_t (*AIBinder_onTransact)(AIBinder *, transaction_code_t,
	                                               AParcel const *, AParcel *);
	typedef void (*AIBinder_DeathRecipient_onBinderDied)(void *cookie);
}


struct AIBinder_Class
{
	char const         *descriptor;
	AIBinder_onCreate   on_create;
	AIBinder_onDestroy  on_destroy;
	AIBinder_onTransact on_transact;
};


struct AIBinder_DeathRecipient
{
	AIBinder_DeathRecipient_onBinderDied on_died;
};


namespace {

	enum Kind { LOCAL, CLIENT_ROOT, CLIENT_CB };

	enum {
		TXN_SIZE  = Android_binder_session::Session::TXN_SIZE,
		RING_SIZE = Android_binder_session::Session::RING_SIZE,
	};
}


/*
 * The binder object. Pointers to the transport helpers are kept as 'void *'
 * (cast in this translation unit) so the externally-visible 'AIBinder' does
 * not depend on internally-linked types.
 */
struct AIBinder
{
	int                   kind    = LOCAL;
	AIBinder_Class const *clazz   = nullptr;
	void                 *user    = nullptr;   /* LOCAL: onCreate result */
	unsigned              strong  = 0;
	bool                  destroyed = false;

	void    *conn = nullptr;   /* CLIENT_ROOT: Rt_conn *      */
	void    *sc   = nullptr;   /* CLIENT_CB:   Session_component * */
	unsigned id   = 0;         /* CLIENT_CB:   sender-local object id */

	enum { MAX_DEATH = 4 };
	AIBinder_DeathRecipient *death_rcp[MAX_DEATH] { };
	void                    *death_cookie[MAX_DEATH] { };
	unsigned                 death_n = 0;
};


struct AIBinder_Weak { AIBinder *b; };

/* used inside this translation unit before the extern "C" definitions below */
extern "C" void AIBinder_incStrong(AIBinder *);
extern "C" void AIBinder_decStrong(AIBinder *);


namespace {

	AIBinder *make_binder(int kind)
	{
		/* calloc zeroes the struct, matching every default member initializer */
		AIBinder *b = (AIBinder *)calloc(1, sizeof(AIBinder));
		if (b) b->kind = kind;
		return b;
	}
}


/*******************
 ** Binder trace  **
 *******************/

namespace {

	bool     trace_enabled = false;
	unsigned trace_seq     = 0;

	/*
	 * Log one transaction (loader config <binder trace="yes"/>)
	 *
	 *   binder-trace #<seq> <instance> <dir> id=<n> code=<n> len=<n> off=<n> <hex>
	 *
	 * A Genode log message is limited to 232 characters, so the parcel is
	 * split into 48-byte lines of the same '#<seq>' with their offsets.
	 * <dir>: req-out (client sends), req-in (server receives), cb-out
	 * (server pushes to callback <id>), cb-in (client runs callback <id>).
	 */
	void trace(char const *instance, char const *dir, unsigned id,
	           uint32_t code, void const *data, uint32_t len)
	{
		if (!trace_enabled) return;

		unsigned const seq = __atomic_add_fetch(&trace_seq, 1, __ATOMIC_RELAXED);
		uint8_t const *b = (uint8_t const *)data;
		static char const digit[] = "0123456789abcdef";
		enum { CHUNK = 48 };
		uint32_t off = 0;
		do {
			char hex[2*CHUNK + 1];
			uint32_t const n = (len - off < uint32_t(CHUNK)) ? len - off : uint32_t(CHUNK);
			for (uint32_t i = 0; i < n; i++) {
				hex[2*i]     = digit[b[off + i] >> 4];
				hex[2*i + 1] = digit[b[off + i] & 15];
			}
			hex[2*n] = 0;
			log("binder-trace #", seq, " ", Cstring(instance), " ", dir, " id=", id,
			    " code=", code, " len=", len, " off=", off, " ", Cstring(hex));
			off += n;
		} while (off < len);
	}
}


/*******************
 ** Genode plumbing **
 *******************/

namespace {

	using namespace Genode;

	class Session_component;

	Env &env() { return Android_rt::env(); }

	/*
	 * Guards the 'sc' pointer of every CLIENT_CB proxy: a vendor thread may
	 * push a callback (e.g. a late response) while the entrypoint destroys
	 * the session the proxy belongs to (the client closed it). The
	 * session's destructor detaches its proxies under this mutex, a push to
	 * a detached proxy fails with STATUS_DEAD_OBJECT.
	 */
	Mutex &cb_mutex()
	{
		static Mutex m { };
		return m;
	}


	/*
	 * Server-side codec: a binder read from a client request becomes a
	 * CLIENT_CB proxy for (this session, sender id); a binder written into a
	 * reply (server->client) is unsupported and encoded as null.
	 */
	struct Server_codec : Android_binder::Binder_codec
	{
		Session_component &sc;

		Server_codec(Session_component &sc) : sc(sc) { }

		binder_status_t write(AParcel *p, AIBinder *b) override
		{
			if (b) {
				static bool logged = false;
				if (!logged) { warning("android_rt: server->client binder unsupported, sending null");
				               logged = true; }
			}
			AParcel_writeInt32(p, 0);
			return AParcel_writeInt32(p, 0);
		}

		binder_status_t read(AParcel const *p, AIBinder **out) override;
	};


	/*
	 * One exported service instance served over one session
	 */
	class Session_component : public Session_object<Android_binder_session::Session>
	{
		private:

			Session_component(Session_component const &) = delete;
			Session_component &operator = (Session_component const &) = delete;

			Env                        &_env;
			AIBinder                   *_root;   /* handle 0 */

			/* the dataspace is paid by the session's quota */
			Accounted_ram_allocator     _ram { _env.ram(), _ram_quota_guard(), _cap_quota_guard() };
			Attached_ram_dataspace      _ds { _ram, _env.rm(), TXN_SIZE + RING_SIZE };
			Android_binder::Ring        _ring { _ds.local_addr<uint8_t>() + TXN_SIZE, RING_SIZE };
			Mutex                       _ring_mutex { };
			Signal_context_capability   _cb_sigh { };
			Server_codec                _codec { *this };

			enum { MAX_PROXY = 64 };
			unsigned  _proxy_id[MAX_PROXY] { };
			AIBinder *_proxy[MAX_PROXY]    { };
			unsigned  _proxy_n = 0;

		public:

			Session_component(Env &env, Resources const &res, Label const &label,
			                  AIBinder *root)
			:
				Session_object(env.ep(), res, label), _env(env), _root(root)
			{
				_ring.init();
			}

			/* drops/awaits this session's work, then detaches its proxies */
			~Session_component();

			Dataspace_capability dataspace() override { return _ds.cap(); }

			uint8_t     *txn()   { return _ds.local_addr<uint8_t>(); }
			AIBinder    *root()  { return _root; }
			Server_codec &codec() { return _codec; }

			Transact_result transact(uint32_t handle, uint32_t code,
			                         uint32_t flags, uint32_t len) override;

			void callback_sigh(Signal_context_capability sigh) override
			{
				/* 'push_callback' reads the capability on a vendor thread */
				Mutex::Guard guard(_ring_mutex);
				_cb_sigh = sigh;
			}

			/**
			 * Server -> client oneway transaction on a callback object
			 */
			void push_callback(unsigned id, uint32_t code, void const *data, uint32_t len)
			{
				trace(label().string(), "cb-out", id, code, data, len);
				Mutex::Guard guard(_ring_mutex);
				if (!_ring.push(id, code, data, len))
					warning("android_rt: callback ring full, dropped (id ", id, ")");
				if (_cb_sigh.valid())
					Signal_transmitter(_cb_sigh).submit();
			}

			/**
			 * CLIENT_CB proxy for a client-local object id (cached per session)
			 *
			 * \return a strong reference owned by the caller (the cache keeps
			 *         its own)
			 */
			AIBinder *cb_proxy(unsigned id)
			{
				/* the proxy array is only touched under 'cb_mutex' (created
				 * here on the dispatcher, detached on the entrypoint) */
				auto cached = [&] () -> AIBinder * {
					for (unsigned i = 0; i < _proxy_n; i++)
						if (_proxy_id[i] == id) { AIBinder_incStrong(_proxy[i]); return _proxy[i]; }
					return nullptr;
				};

				{
					Mutex::Guard guard(cb_mutex());
					if (AIBinder *b = cached()) return b;
				}

				/* allocated outside the mutex, inserted (or discarded) under it */
				AIBinder *b = make_binder(CLIENT_CB);
				if (!b) return nullptr;
				b->sc = this; b->id = id; b->strong = 1;            /* the caller's */

				Mutex::Guard guard(cb_mutex());
				if (AIBinder *other = cached()) { free(b); return other; }

				/* only cached proxies can be detached on session close */
				if (_proxy_n == MAX_PROXY) {
					free(b);
					error("android_rt: more than ", unsigned(MAX_PROXY),
					      " callback objects on one session");
					return nullptr;
				}
				_proxy_id[_proxy_n] = id; _proxy[_proxy_n] = b; _proxy_n++;
				AIBinder_incStrong(b);                                /* the cache's */
				return b;
			}

			/**
			 * Detach the proxies and drop the cache's references
			 *
			 * A proxy the vendor code still refers to stays, detached, until
			 * its last reference goes ('AIBinder_decStrong' frees it).
			 */
			void detach_proxies()
			{
				Mutex::Guard guard(cb_mutex());
				for (unsigned i = 0; i < _proxy_n; i++) {
					_proxy[i]->sc = nullptr;
					AIBinder_decStrong(_proxy[i]);
				}
				_proxy_n = 0;
			}
	};


	binder_status_t Server_codec::read(AParcel const *p, AIBinder **out)
	{
		int32_t kind = 0, id = 0;
		binder_status_t r = AParcel_readInt32(p, &kind);
		if (r == STATUS_OK) r = AParcel_readInt32(p, &id);
		if (r != STATUS_OK) return r;
		*out = (kind == 0) ? nullptr : sc.cb_proxy(unsigned(id));
		return STATUS_OK;
	}


	/*
	 * A dispatched transaction, handed from the entrypoint to the runtime
	 * dispatcher thread (vendor code must not run on the entrypoint: no TLS).
	 */
	struct Work : Fifo<Work>::Element
	{
		enum { BUF = 8*1024 };
		Session_component *sc = nullptr;
		transaction_code_t code = 0;
		bool     from_txn = false;
		uint32_t len = 0;
		int32_t  status = STATUS_OK;
		uint32_t reply_len = 0;
		Blockade *done = nullptr;   /* two-way only */
		uint8_t   buf[BUF];
	};


	/*
	 * Server role: announces the 'Android_binder' service, keeps the export
	 * table and runs the single dispatcher thread.
	 */
	class Server
	{
		private:

			Server(Server const &) = delete;
			Server &operator = (Server const &) = delete;

			Env  &_env;
			Heap  _heap { _env.ram(), _env.rm() };

			Mutex _mutex { };

			enum { MAX_EXPORTS = 32 };
			char const *_name[MAX_EXPORTS] { };
			AIBinder   *_binder[MAX_EXPORTS] { };
			unsigned    _exports = 0;

			/* one session cannot take the whole pool from the others */
			enum { MAX_WORK = 48, MAX_WORK_PER_SESSION = MAX_WORK/4 };
			Work      _pool[MAX_WORK] { };
			bool      _used[MAX_WORK] { };
			Fifo<Work> _fifo { };
			Semaphore  _items { };

			bool _dispatcher_started = false;
			bool _announced = false;

			/* session of the work item '_run' is busy with (guarded by '_mutex') */
			Session_component *_running      = nullptr;
			Blockade          *_idle_waiter  = nullptr;

			struct Root : Root_component<Session_component>
			{
				Server &s;

				Create_result _create_session(char const *args) override
				{
					Session_label const label = label_from_args(args);
					Session_label const inst  = label.last_element();

					AIBinder *root = s.lookup(inst.string());
					if (!root) {
						s.note_denied(inst.string());   /* clients retry: log once */
						return Session_error::DENIED;
					}
					return *new (md_alloc())
						Session_component(s._env, session_resources_from_args(args),
						                  inst, root);
				}

				Root(Server &s)
				: Root_component<Session_component>(s._env.ep(), s._heap), s(s) { }
			} _root { *this };

			static Session_label label_from_args(char const *args)
			{
				return Session_label(session_label_from_args(args));
			}

			static void *_dispatch_entry(void *self)
			{
				((Server *)self)->_dispatch();
				return nullptr;
			}

			void _dispatch()
			{
				for (;;) {
					_items.down();
					Work *w = nullptr;
					{
						Mutex::Guard guard(_mutex);
						_fifo.dequeue([&] (Work &e) { w = &e; });
						if (w) _running = w->sc;
					}
					if (!w) continue;   /* cancelled by a session close */

					_run(*w);

					Mutex::Guard guard(_mutex);
					_running = nullptr;
					if (_idle_waiter) { _idle_waiter->wakeup(); _idle_waiter = nullptr; }
				}
			}

			void _run(Work &w)
			{
				uint8_t const *req = w.from_txn ? w.sc->txn() : w.buf;
				AParcel *in  = Android_binder::parcel_from(req, w.len);
				AParcel *out = Android_binder::parcel_create();
				if (in)  Android_binder::set_binder_codec(in,  &w.sc->codec());
				if (out) Android_binder::set_binder_codec(out, &w.sc->codec());

				binder_status_t st = STATUS_UNKNOWN_TRANSACTION;
				AIBinder *root = w.sc->root();
				if (in && out && root && root->clazz && root->clazz->on_transact)
					st = root->clazz->on_transact(root, w.code, in, out);

				if (w.done) {   /* two-way: place the reply back into the txn area */
					uint32_t const rl = out ? uint32_t(Android_binder::parcel_size(out)) : 0;
					if (rl <= TXN_SIZE) {
						if (rl) ::memcpy(w.sc->txn(), Android_binder::parcel_data(out), rl);
						w.reply_len = rl; w.status = st;
					} else {
						error("android_rt: binder reply too large (", rl, ")");
						w.reply_len = 0; w.status = STATUS_FAILED_TRANSACTION;
					}
				}

				if (in)  AParcel_delete(in);
				if (out) AParcel_delete(out);

				if (w.done) w.done->wakeup();
				else        free_work(&w);
			}

		public:

			Server(Env &env) : _env(env) { }

			/* runs on the entrypoint: no libc allocation here */
			void note_denied(char const *name)
			{
				enum { MAX = 16, LEN = 96 };
				static char seen[MAX][LEN]; static unsigned n;
				for (unsigned i = 0; i < n; i++) if (!::strncmp(seen[i], name, LEN - 1)) return;
				if (n < MAX) Genode::copy_cstring(seen[n++], name, LEN);
				log("android_rt: binder session denied until exported: '", Cstring(name), "'");
			}

			AIBinder *lookup(char const *name)
			{
				Mutex::Guard guard(_mutex);
				for (unsigned i = 0; i < _exports; i++)
					if (!::strcmp(_name[i], name)) return _binder[i];
				return nullptr;
			}

			void add(char const *name, AIBinder *b)
			{
				{
					Mutex::Guard guard(_mutex);
					if (_exports < MAX_EXPORTS) { _name[_exports] = strdup(name);
					                              _binder[_exports] = b; _exports++; }
					else error("android_rt: binder export table full");
				}
				_ensure_dispatcher();
				log("android_rt: addService ", Cstring(name));
			}

			void announce()
			{
				if (_announced) return;
				_announced = true;
				_env.parent().announce(_env.ep().manage(_root));
				log("android_rt: Android_binder service announced");
			}

			void _ensure_dispatcher()
			{
				Mutex::Guard guard(_mutex);
				if (_dispatcher_started) return;
				_dispatcher_started = true;
				Android_rt::start_thread(_dispatch_entry, this);
			}

			/**
			 * Work item of session 'sc' ('Work::sc' is set)
			 *
			 * \return nullptr if the pool is used up, or the session has
			 *         MAX_WORK_PER_SESSION items queued or running
			 */
			Work *alloc_work(Session_component &sc)
			{
				Mutex::Guard guard(_mutex);
				unsigned of_session = 0;
				for (unsigned i = 0; i < MAX_WORK; i++)
					if (_used[i] && _pool[i].sc == &sc) of_session++;
				if (of_session >= MAX_WORK_PER_SESSION) return nullptr;

				for (unsigned i = 0; i < MAX_WORK; i++)
					if (!_used[i]) { _used[i] = true; _pool[i].sc = &sc; return &_pool[i]; }
				return nullptr;
			}

			void free_work(Work *w)
			{
				Mutex::Guard guard(_mutex);
				_used[w - _pool] = false;
			}

			void enqueue(Work *w)
			{
				{ Mutex::Guard guard(_mutex); _fifo.enqueue(*w); }
				_items.up();
			}

			/**
			 * Drop the queued work of a closing session and wait until the
			 * dispatcher is no longer running one of its items (only oneway
			 * items can be pending: a two-way transact blocks the entrypoint
			 * that would close the session). Runs on the entrypoint.
			 *
			 * Constraint on vendor oneway handlers: while its session closes,
			 * the entrypoint waits here for a running handler of that
			 * session. In a libc component, regular-file (VFS) I/O of a
			 * pthread and timer-driven timeouts are executed by the
			 * entrypoint (libc monitor), so a handler that does such I/O or
			 * waits for such a timeout at that moment deadlocks the close
			 * (entrypoint and dispatcher both stuck). android_rt's pipes,
			 * eventfds, epoll and chardevs do not need the entrypoint; a
			 * two-way transact already blocks the entrypoint the same way.
			 */
			void cancel_work(Session_component const &sc)
			{
				/* outside the loop: the dispatcher's 'wakeup' may still touch
				 * it until it releases '_mutex', which the next iteration (or
				 * the return) has to take first */
				Blockade idle { };

				for (;;) {
					{
						Mutex::Guard guard(_mutex);
						Fifo<Work> keep { };
						_fifo.dequeue_all([&] (Work &w) {
							if (w.sc == &sc) _used[&w - _pool] = false;
							else             keep.enqueue(w); });
						keep.dequeue_all([&] (Work &w) { _fifo.enqueue(w); });

						if (_running != &sc) return;
						_idle_waiter = &idle;
					}
					idle.block();
				}
			}
	};


	/*
	 * The singletons are created by whichever vendor thread comes first and
	 * are never destructed (their threads and sessions live until the
	 * program ends).
	 */
	Server &server()
	{
		alignas(Server) static char space[sizeof(Server)];
		static Server &s = *Genode::construct_at<Server>(space, env());
		return s;
	}


	/*
	 * Order matters: once 'cancel_work' returned, no item of this session is
	 * queued or running (only the entrypoint enqueues, and it is here), so
	 * no request (e.g. a setResponseFunctions being dispatched) can create
	 * a new proxy for this session after 'detach_proxies' walked the array.
	 */
	Session_component::~Session_component()
	{
		server().cancel_work(*this);
		detach_proxies();
	}


	Android_binder_session::Session::Transact_result
	Session_component::transact(uint32_t handle, uint32_t code,
	                                            uint32_t flags, uint32_t len)
	{
		if (handle != 0)
			warning("android_rt: binder transact on non-root handle ", handle);

		bool const oneway = flags & FLAG_ONEWAY;

		/* the client chose 'len', the request lives in the transaction area */
		if (len > TXN_SIZE) {
			warning("android_rt: binder request of ", len, " bytes exceeds the transaction area");
			return { STATUS_BAD_VALUE, 0 };
		}

		trace(label().string(), "req-in", 0, code, txn(), len);

		Work *w = server().alloc_work(*this);
		if (!w) {
			error("android_rt: binder work pool or the session's share of it exhausted");
			return { STATUS_NO_MEMORY, 0 };
		}

		w->code = code; w->len = len;
		w->done = nullptr; w->from_txn = false; w->reply_len = 0; w->status = STATUS_OK;

		if (len <= Work::BUF) {
			if (len) ::memcpy(w->buf, txn(), len);
		} else if (!oneway) {
			w->from_txn = true;   /* client stays blocked, the txn area is stable */
		} else {
			warning("android_rt: oneway request too large (", len, "), dropped");
			server().free_work(w);
			return { STATUS_FAILED_TRANSACTION, 0 };
		}

		if (oneway) {
			server().enqueue(w);
			return { STATUS_OK, 0 };
		}

		Blockade blockade { };
		w->done = &blockade;
		server().enqueue(w);
		blockade.block();

		Transact_result const r { w->status, w->reply_len };
		server().free_work(w);
		return r;
	}


	/*******************
	 ** Client role   **
	 *******************/

	/*
	 * A vendor callback object (LOCAL AIBinder) registered at a connection:
	 * runs the class's onTransact for the connection's ring entries
	 */
	struct Cb_adapter : Android_binder::Callback
	{
		AIBinder   *binder   = nullptr;   /* set before the adapter is registered */
		char const *instance = "";        /* of the connection, for the trace */
		unsigned    id       = 0;

		void on_transact(uint32_t code, AParcel const &in) override
		{
			trace(instance, "cb-in", id, code, Android_binder::parcel_data(&in),
			      uint32_t(Android_binder::parcel_size(&in)));

			AIBinder_Class const *c = binder->clazz;
			if (!c || !c->on_transact) {
				warning("android_rt: callback object without onTransact (code ", code, ")");
				return;
			}
			AParcel *out = Android_binder::parcel_create();
			if (out) c->on_transact(binder, code, &in, out);
			AParcel_delete(out);
		}
	};


	struct Rt_conn;


	/*
	 * Client-side codec of vendor parcels: a vendor callback object is
	 * registered at the connection on first use and written by the
	 * connection's codec as {kind 1, id}; binders in replies are unsupported
	 */
	struct Rt_codec : Android_binder::Binder_codec
	{
		Rt_conn &rt;

		Rt_codec(Rt_conn &rt) : rt(rt) { }

		binder_status_t write(AParcel *p, AIBinder *b) override;
		binder_status_t read(AParcel const *p, AIBinder **out) override;
	};


	/*
	 * A vendor client's connection to one instance (CLIENT_ROOT)
	 */
	struct Rt_conn
	{
		Rt_conn(Rt_conn const &) = delete;
		Rt_conn &operator = (Rt_conn const &) = delete;

		Android_binder::Client_conn conn;
		Rt_codec                    codec { *this };

		enum { MAX_CB = Android_binder::Client_core::MAX_CB };
		Mutex      adapter_mutex { };
		Cb_adapter adapter[MAX_CB] { };
		unsigned   adapter_n = 0;

		Rt_conn(Env &env, char const *instance) : conn(env, instance) { }

		/**
		 * Connection token of a vendor callback object (registered and
		 * referenced on first use), nullptr if the table is full
		 */
		AIBinder *token_for(AIBinder *b)
		{
			Mutex::Guard guard(adapter_mutex);
			for (unsigned i = 0; i < adapter_n; i++)
				if (adapter[i].binder == b)
					return Android_binder::Client_conn::binder(adapter[i]);

			if (adapter_n < MAX_CB) {
				Cb_adapter &a = adapter[adapter_n];
				a.binder   = b;
				a.instance = conn.instance().string();
				int const id = conn.register_callback(a);
				if (id > 0) {
					a.id = unsigned(id);
					adapter_n++;
					AIBinder_incStrong(b);
					return Android_binder::Client_conn::binder(a);
				}
				a.binder = nullptr;
			}
			error("android_rt: per-connection callback table full");
			return nullptr;
		}
	};


	binder_status_t Rt_codec::write(AParcel *p, AIBinder *b)
	{
		AIBinder *token = b ? rt.token_for(b) : nullptr;
		if (b && !token) return STATUS_NO_MEMORY;
		return rt.conn.codec().write(p, token);
	}


	binder_status_t Rt_codec::read(AParcel const *p, AIBinder **out)
	{
		return rt.conn.codec().read(p, out);
	}


	/*
	 * Client role: keeps the open connections and drains their callback rings
	 * on a runtime thread (bionic TLS present). The rings are polled -- the
	 * server also submits a signal, but polling keeps all entrypoint-managed
	 * objects on the entrypoint thread.
	 */
	class Client
	{
		private:

			Client(Client const &) = delete;
			Client &operator = (Client const &) = delete;

			Env &_env;

			enum { MAX_CONNS = 32 };
			Rt_conn     *_conns[MAX_CONNS] { };
			unsigned     _conn_n = 0;
			Mutex        _mutex { };

			bool _drain_started = false;

			static void *_drain_entry(void *self) { ((Client *)self)->_drain(); return nullptr; }

			void _drain()
			{
				for (;;) {
					/* the callbacks run without '_mutex': they may call
					 * 'wait_for_service'. Entries [0, n) never change. */
					unsigned n = 0;
					{
						Mutex::Guard guard(_mutex);
						n = _conn_n;
					}
					bool any = false;
					for (unsigned i = 0; i < n; i++)
						any |= _conns[i]->conn.drain() > 0;
					if (!any) ::usleep(2000);
				}
			}

			/* under '_mutex' */
			void _ensure_drain()
			{
				if (_drain_started) return;
				_drain_started = true;
				Android_rt::start_thread(_drain_entry, this);
			}

		public:

			Client(Env &env) : _env(env) { }

			/**
			 * Open (retrying) a connection to 'name' and return its root proxy
			 */
			AIBinder *wait_for_service(char const *name)
			{
				void *m = ::malloc(sizeof(Rt_conn));
				if (!m) { error("android_rt: waitForService: out of memory"); return nullptr; }
				Rt_conn *c = Genode::construct_at<Rt_conn>(m, _env, name);

				/* the server denies an instance until its program exported it */
				for (unsigned attempt = 0;; attempt++) {
					using Result = Android_binder::Client_conn::Open_result;
					Result const r = c->conn.open();
					if (r == Result::OK) break;
					if (r == Result::FAILED) {
						error("android_rt: waitForService('", Cstring(name), "'): session request failed");
						return nullptr;
					}
					if ((attempt % 50) == 0)
						log("android_rt: waitForService('", Cstring(name), "') waiting...");
					::usleep(100*1000);
				}
				{
					Mutex::Guard guard(_mutex);
					if (_conn_n < MAX_CONNS) _conns[_conn_n++] = c;
					else error("android_rt: client connection table full");
					_ensure_drain();
				}

				AIBinder *b = make_binder(CLIENT_ROOT);
				if (b) { b->conn = c; b->strong = 1; }
				log("android_rt: waitForService('", Cstring(name), "') connected");
				return b;
			}
	};


	Client &client()
	{
		alignas(Client) static char space[sizeof(Client)];
		static Client &c = *Genode::construct_at<Client>(space, env());
		return c;
	}
}


/****************************************
 ** libbinder_ndk C API (the exports) **
 ****************************************/

extern "C" {

	/* --- AIBinder_Class --- */

	AIBinder_Class *AIBinder_Class_define(char const *descriptor,
	                                      AIBinder_onCreate on_create,
	                                      AIBinder_onDestroy on_destroy,
	                                      AIBinder_onTransact on_transact)
	{
		AIBinder_Class *c = (AIBinder_Class *)calloc(1, sizeof(AIBinder_Class));
		if (!c) return nullptr;
		c->descriptor = descriptor ? strdup(descriptor) : nullptr;
		c->on_create  = on_create;
		c->on_destroy = on_destroy;
		c->on_transact = on_transact;
		return c;
	}

	char const *AIBinder_Class_getDescriptor(AIBinder_Class const *c) { return c ? c->descriptor : ""; }
	void AIBinder_Class_setOnDump(AIBinder_Class *, void *) { }
	void AIBinder_Class_setHandleShellCommand(AIBinder_Class *, void *) { }
	void AIBinder_Class_setTransactionCodeToFunctionNameMap(AIBinder_Class *, void const *, size_t) { }

	/* --- AIBinder --- */

	AIBinder *AIBinder_new(AIBinder_Class const *clazz, void *args)
	{
		AIBinder *b = make_binder(LOCAL);
		if (!b) return nullptr;
		b->clazz = clazz;
		b->strong = 1;
		if (clazz && clazz->on_create) b->user = clazz->on_create(args);
		return b;
	}

	void AIBinder_incStrong(AIBinder *b)
	{
		if (b) __atomic_add_fetch(&b->strong, 1, __ATOMIC_ACQ_REL);
	}

	void AIBinder_decStrong(AIBinder *b)
	{
		if (!b) return;
		if (__atomic_sub_fetch(&b->strong, 1, __ATOMIC_ACQ_REL) == 0) {
			/*
			 * A callback proxy is freed once its session is gone (the
			 * session's cache held a reference until then, weak
			 * references hold one too).
			 */
			if (b->kind == CLIENT_CB) {
				if (!b->sc) free(b);
				return;
			}
			if (b->kind == LOCAL && !b->destroyed) {
				b->destroyed = true;
				if (b->clazz && b->clazz->on_destroy) b->clazz->on_destroy(b->user);
			}
			/* the struct of a local object or a root proxy is intentionally
			   leaked: weak refs may still reference it in this bring-up
			   runtime */
		}
	}

	AIBinder_Class const *AIBinder_getClass(AIBinder *b) { return b ? b->clazz : nullptr; }
	void *AIBinder_getUserData(AIBinder *b) { return b ? b->user : nullptr; }
	bool  AIBinder_isRemote(AIBinder const *b) { return b && b->kind != LOCAL; }

	bool AIBinder_associateClass(AIBinder *b, AIBinder_Class const *clazz)
	{
		if (!b) return false;
		if (!b->clazz) b->clazz = clazz;
		return true;   /* both ends share the generated descriptor */
	}

	void AIBinder_markVintfStability(AIBinder *) { }

	binder_status_t AIBinder_dump(AIBinder *, int, char const **, uint32_t) { return STATUS_OK; }

	binder_status_t AIBinder_prepareTransaction(AIBinder *b, AParcel **in)
	{
		if (!b) return STATUS_UNEXPECTED_NULL;
		AParcel *p = Android_binder::parcel_create();
		if (!p) return STATUS_NO_MEMORY;
		if (b->kind == CLIENT_ROOT && b->conn)
			Android_binder::set_binder_codec(p, &((Rt_conn *)b->conn)->codec);
		*in = p;
		return STATUS_OK;
	}

	binder_status_t AIBinder_transact(AIBinder *b, transaction_code_t code,
	                                  AParcel **in, AParcel **out, binder_flags_t flags)
	{
		if (!b || !in || !*in || !out) return STATUS_UNEXPECTED_NULL;

		AParcel *ip = *in; *in = nullptr;
		bool const oneway = flags & FLAG_ONEWAY;
		binder_status_t st = STATUS_OK;

		if (b->kind == CLIENT_ROOT) {
			/* a two-way reply replaces the content of *out */
			Rt_conn &rc = *(Rt_conn *)b->conn;
			trace(rc.conn.instance().string(), "req-out", 0, code,
			      Android_binder::parcel_data(ip), uint32_t(Android_binder::parcel_size(ip)));
			*out = Android_binder::parcel_create();
			rc.conn.transact(code, *ip, oneway, *out, &st);

		} else if (b->kind == CLIENT_CB) {
			if (!oneway) {
				warning("android_rt: two-way transaction on a callback object");
				AParcel_delete(ip);
				*out = Android_binder::parcel_create();
				return STATUS_INVALID_OPERATION;
			}
			{
				/* the client may have closed the session meanwhile */
				Mutex::Guard guard(cb_mutex());
				if (b->sc)
					((Session_component *)b->sc)->push_callback(
						b->id, code, Android_binder::parcel_data(ip),
						uint32_t(Android_binder::parcel_size(ip)));
				else
					st = STATUS_DEAD_OBJECT;
			}
			*out = Android_binder::parcel_create();

		} else {   /* LOCAL: run directly */
			*out = Android_binder::parcel_create();
			if (b->clazz && b->clazz->on_transact && *out)
				st = b->clazz->on_transact(b, code, ip, *out);
		}

		AParcel_delete(ip);
		return st;
	}

	/* --- weak refs --- */

	AIBinder_Weak *AIBinder_Weak_new(AIBinder *b)
	{
		AIBinder_Weak *w = (AIBinder_Weak *)calloc(1, sizeof(AIBinder_Weak));
		if (!w) return nullptr;
		w->b = b;
		/* a callback proxy is freed with its last reference, so the weak
		 * reference to one keeps it */
		if (b && b->kind == CLIENT_CB) AIBinder_incStrong(b);
		return w;
	}

	AIBinder *AIBinder_Weak_promote(AIBinder_Weak *w)
	{
		if (!w || !w->b || w->b->destroyed) return nullptr;
		AIBinder_incStrong(w->b);
		return w->b;
	}

	void AIBinder_Weak_delete(AIBinder_Weak *w)
	{
		if (w && w->b && w->b->kind == CLIENT_CB) AIBinder_decStrong(w->b);
		free(w);
	}

	/* --- death recipients --- */

	AIBinder_DeathRecipient *AIBinder_DeathRecipient_new(AIBinder_DeathRecipient_onBinderDied cb)
	{
		AIBinder_DeathRecipient *r = (AIBinder_DeathRecipient *)calloc(1, sizeof(*r));
		if (r) r->on_died = cb;
		return r;
	}

	void AIBinder_DeathRecipient_delete(AIBinder_DeathRecipient *r) { free(r); }

	binder_status_t AIBinder_linkToDeath(AIBinder *b, AIBinder_DeathRecipient *r, void *cookie)
	{
		if (!b || !r) return STATUS_UNEXPECTED_NULL;
		if (b->death_n < AIBinder::MAX_DEATH) {
			b->death_rcp[b->death_n] = r;
			b->death_cookie[b->death_n] = cookie;
			b->death_n++;
		}
		/* the first MAX_DEATH links of a binder are recorded, the others
		 * accepted without a record ('unlinkToDeath' does not find them);
		 * nothing fires death recipients (a closed session just detaches
		 * its proxies, see '~Session_component') */
		return STATUS_OK;
	}

	binder_status_t AIBinder_unlinkToDeath(AIBinder *b, AIBinder_DeathRecipient *r, void *cookie)
	{
		if (!b) return STATUS_UNEXPECTED_NULL;
		for (unsigned i = 0; i < b->death_n; i++)
			if (b->death_rcp[i] == r && b->death_cookie[i] == cookie) {
				for (unsigned j = i + 1; j < b->death_n; j++) {
					b->death_rcp[j-1]    = b->death_rcp[j];
					b->death_cookie[j-1] = b->death_cookie[j];
				}
				b->death_n--;
				return STATUS_OK;
			}
		return STATUS_NAME_NOT_FOUND;
	}

	/* --- AServiceManager --- */

	binder_status_t AServiceManager_addService(AIBinder *binder, char const *instance)
	{
		if (!binder || !instance) return STATUS_UNEXPECTED_NULL;

		/*
		 * The export table owns a strong reference, like servicemanager
		 * does via the driver: an NDK service keeps only a weak one to its
		 * own AIBinder (BnCInterface::asBinder), so without it the binder
		 * is destroyed right after this call (onDestroy frees the
		 * interface data the first transaction then uses).
		 */
		AIBinder_incStrong(binder);
		server().add(instance, binder);
		return STATUS_OK;
	}

	bool AServiceManager_isDeclared(char const *) { return true; }

	AIBinder *AServiceManager_waitForService(char const *instance)
	{
		return client().wait_for_service(instance);
	}

	/* --- process thread pool --- */

	void ABinderProcess_joinThreadPool(void)
	{
		static Genode::Semaphore forever { };
		log("android_rt: joinThreadPool -- parking the calling thread");
		forever.down();   /* the entrypoint and dispatcher keep the process alive */
	}

	void ABinderProcess_startThreadPool(void) { }
	bool ABinderProcess_setThreadPoolMaxThreadCount(uint32_t) { return true; }
}


/*******************************
 ** Runtime hooks and exports **
 *******************************/

void Android_rt::export_binder_service() { server().announce(); }

void Android_rt::binder_trace(bool on) { trace_enabled = on; }


#define EXPORT(name) { #name, (void *)name }

static Export const exports[] = {
	EXPORT(AIBinder_Class_define), EXPORT(AIBinder_Class_getDescriptor),
	EXPORT(AIBinder_Class_setOnDump), EXPORT(AIBinder_Class_setHandleShellCommand),
	EXPORT(AIBinder_Class_setTransactionCodeToFunctionNameMap),
	EXPORT(AIBinder_new), EXPORT(AIBinder_incStrong), EXPORT(AIBinder_decStrong),
	EXPORT(AIBinder_getClass), EXPORT(AIBinder_getUserData), EXPORT(AIBinder_isRemote),
	EXPORT(AIBinder_associateClass), EXPORT(AIBinder_markVintfStability), EXPORT(AIBinder_dump),
	EXPORT(AIBinder_prepareTransaction), EXPORT(AIBinder_transact),
	EXPORT(AIBinder_Weak_new), EXPORT(AIBinder_Weak_promote), EXPORT(AIBinder_Weak_delete),
	EXPORT(AIBinder_DeathRecipient_new), EXPORT(AIBinder_DeathRecipient_delete),
	EXPORT(AIBinder_linkToDeath), EXPORT(AIBinder_unlinkToDeath),
	EXPORT(AServiceManager_addService), EXPORT(AServiceManager_isDeclared),
	EXPORT(AServiceManager_waitForService),
	EXPORT(ABinderProcess_joinThreadPool), EXPORT(ABinderProcess_startThreadPool),
	EXPORT(ABinderProcess_setThreadPoolMaxThreadCount),
};

#undef EXPORT

Export_group Android_rt::binder_exports() { return { exports, sizeof(exports) / sizeof(exports[0]) }; }
