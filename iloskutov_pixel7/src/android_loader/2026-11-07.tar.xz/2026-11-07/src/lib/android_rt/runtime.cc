/*
 * \brief  bionic-ABI runtime of the Android loader -- core
 * \author Ivan Loskutov
 * \date   2026-09-25
 *
 * Override table, stubs for unimplemented imports, the bionic TLS block,
 * program start (__libc_init) and exit.
 */

/*
 * SPDX-License-Identifier: MIT
 */

#include <android_rt/runtime.h>
#include <android_rt/linux_abi.h>
#include <base/log.h>
#include <base/mutex.h>
#include <util/string.h>
#include <cpu/cache.h>
#include <trace/timestamp.h>

#include <errno.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

using namespace Android_rt;
using namespace Android_elf;


/*****************************
 ** Program state and exit **
 *****************************/

namespace {

	struct Atexit { void (*fn)(void *); void *arg; };

	enum { MAX_ATEXIT = 4096 };   /* rild's closure registers several hundred */

	Atexit        atexit_list[MAX_ATEXIT];
	unsigned      atexit_count;
	Genode::Mutex atexit_mutex;   /* static initialisers register from any thread */

	Linker    *program_linker;
	Memory    *program_memory;
	Android_rt::Overrides *program_overrides;
	bool       exiting;
	bool       verbose_start;
	char const *argv0 = "android";
	uint64_t   canary;

	/*
	 * Thread blocks: 64 bytes below tp (tp-8 = bionic slot -1, tp-16 =
	 * errno), eight slots at tp[0..7], static TLS, dlopen surplus
	 */
	enum { BELOW_TP = 64, SLOT_STACK_GUARD = 5, ERRNO_OFFSET = -16, MAX_THREADS = 256 };

	Genode::Mutex blocks_mutex;
	uint8_t      *blocks[MAX_THREADS];
	unsigned      block_count;
}


Linker &Android_rt::linker() { return *program_linker; }

char const *Android_rt::program_name() { return argv0; }

void Android_rt::verbose(bool v) { verbose_start = v; }
Memory &Android_rt::memory() { return *program_memory; }
Android_rt::Overrides &Android_rt::overrides() { return *program_overrides; }


void Android_rt::set_tp(void *tp) { asm volatile ("msr tpidr_el0, %0" :: "r"(tp)); }


static uint8_t *current_tp()
{
	uint8_t *tp;
	asm volatile ("mrs %0, tpidr_el0" : "=r"(tp));
	return tp;
}


int *Android_rt::errno_location()
{
	static int early_errno;          /* before the first thread block exists */
	uint8_t *tp = current_tp();
	return tp ? (int *)(tp + ERRNO_OFFSET) : &early_errno;
}


void Android_rt::set_errno(int e) { *errno_location() = e; }

void Android_rt::set_errno_from_libc() { set_errno(Linux::errno_from_freebsd(errno)); }


uint8_t *Android_rt::create_thread_block()
{
	/* a dlopen at the same time adds objects and copies their TLS images */
	Dl_guard dl_guard { };

	Linker &l = *program_linker;
	uint8_t *block = program_memory->alloc(BELOW_TP + l.tls_area_size(), 64);
	if (!block) { Genode::error("android_rt: no memory for a thread block"); ::_exit(1); }
	uint8_t *tp = block + BELOW_TP;

	for (unsigned i = 0; i < l.object_count(); i++) {
		Object const &o = *l.object(i);
		if (!o.has_tls()) continue;
		Tls_image const t = o.tls();
		memcpy(tp + l.tls_offset(i), t.init, t.filesz);
	}
	((uint64_t *)tp)[SLOT_STACK_GUARD] = canary;

	Genode::Mutex::Guard guard(blocks_mutex);
	if (block_count < MAX_THREADS) blocks[block_count++] = tp;
	else Genode::warning("android_rt: thread-block registry full (dlopen TLS may miss threads)");
	return tp;
}


void Android_rt::init_tls_of_new_objects(unsigned first)
{
	Linker &l = *program_linker;
	Genode::Mutex::Guard guard(blocks_mutex);
	for (unsigned b = 0; b < block_count; b++)
		for (unsigned i = first; i < l.object_count(); i++) {
			Object const &o = *l.object(i);
			if (!o.has_tls()) continue;
			Tls_image const t = o.tls();
			memcpy(blocks[b] + l.tls_offset(i), t.init, t.filesz);
			memset(blocks[b] + l.tls_offset(i) + t.filesz, 0, t.memsz - t.filesz);
		}
}

void Android_rt::exit_program(int status)
{
	bool first = false;
	{
		Genode::Mutex::Guard guard(atexit_mutex);
		first = !exiting;
		exiting = true;
	}
	if (first) {
		/* a handler may register another one: pop one at a time */
		for (;;) {
			Atexit a { };
			{
				Genode::Mutex::Guard guard(atexit_mutex);
				if (!atexit_count) break;
				a = atexit_list[--atexit_count];
			}
			a.fn(a.arg);
		}

		/* fini arrays in reverse constructor order */
		if (program_linker) {
			unsigned order[Linker::MAX_OBJECTS], n = 0;
			program_linker->for_each_init_order([&] (unsigned i) { order[n++] = i; });
			while (n--) {
				void (**arr)(); size_t count;
				program_linker->object(order[n])->fini_array(arr, count);
				for (size_t k = count; k-- > 0; )
					if (arr[k] && arr[k] != (void (*)())-1) arr[k]();
			}
		}
	}
	flush_stdio();
	::exit(status);
}


/****************************************
 ** Core exports (startup, exit, guard) **
 ****************************************/

extern "C" {

	/* bionic's __stack_chk_guard; the same value sits in TLS slot 5 */
	uintptr_t art___stack_chk_guard;

	int art___cxa_atexit(void (*fn)(void *), void *arg, void *)
	{
		Genode::Mutex::Guard guard(atexit_mutex);
		if (atexit_count == MAX_ATEXIT) {
			Genode::error("android_rt: too many atexit handlers");
			return -1;
		}
		atexit_list[atexit_count++] = { fn, arg };
		return 0;
	}

	static void call_plain(void *fn) { ((void (*)())fn)(); }

	int art_atexit(void (*fn)()) { return art___cxa_atexit(call_plain, (void *)fn, nullptr); }

	int art___register_atfork(void (*)(), void (*)(), void (*)(), void *) { return 0; }

	[[noreturn]] void art_exit(int status) { exit_program(status); }

	[[noreturn]] void art__exit(int status) { flush_stdio(); ::_exit(status); }

	[[noreturn]] void art_abort()
	{
		Genode::error("android_rt: abort() called");
		flush_stdio();
		::_exit(134);
	}

	[[noreturn]] void art___stack_chk_fail()
	{
		Genode::error("android_rt: stack corruption detected (__stack_chk_fail)");
		flush_stdio();
		::_exit(134);
	}

	/*
	 * bionic's dynamic-executable entry, called by crtbegin's _start_main:
	 * raw_args = { argc, argv..., 0, envp..., 0, auxv... }
	 */
	[[noreturn]] void art___libc_init(void *raw_args, void (*)(),
	                                  int (*slingshot)(int, char **, char **),
	                                  void const *)
	{
		uintptr_t *raw  = (uintptr_t *)raw_args;
		int const  argc = int(raw[0]);
		char     **argv = (char **)(raw + 1);
		char     **envp = argv + argc + 1;

		exit_program(slingshot(argc, argv, envp));
	}

	int *art___errno() { return errno_location(); }

	/* called by every stub (see Overrides::stub) */
	[[noreturn]] void art_unimplemented(char const *name)
	{
		Genode::error("android_rt: unimplemented: ", name);
		flush_stdio();
		::_exit(127);
	}
}


static Export const core_exports[] = {
	{ "__stack_chk_guard",  (void *)&art___stack_chk_guard },
	{ "__stack_chk_fail",   (void *)art___stack_chk_fail },
	{ "__cxa_atexit",       (void *)art___cxa_atexit },
	{ "atexit",             (void *)art_atexit },
	{ "__register_atfork",  (void *)art___register_atfork },
	{ "__libc_init",        (void *)art___libc_init },
	{ "exit",               (void *)art_exit },
	{ "_exit",              (void *)art__exit },
	{ "abort",              (void *)art_abort },
	{ "__errno",            (void *)art___errno },
};


/***************
 ** Overrides **
 ***************/

void *Android_rt::Overrides::find(char const *name)
{
	if (void *p = profile_override(name)) return p;

	Export_group const groups[] = {
		{ core_exports, sizeof(core_exports) / sizeof(core_exports[0]) },
		stdio_exports(), log_exports(), string_exports(), thread_exports(),
		file_exports(), prop_exports(), dl_exports(), locale_exports(), system_exports(), fortify_exports(),
		parcel_exports(), binder_exports(), signal_exports(), platform_exports(), unwind_exports() };

	for (Export_group const &g : groups)
		for (unsigned i = 0; i < g.count; i++)
			if (!strcmp(g.exports[i].name, name)) return g.exports[i].addr;
	return nullptr;
}


/*
 * A stub is 32 bytes of code:  x0 = <name>; branch to art_unimplemented
 *
 *   0: ldr x0,  #16      58000080
 *   4: ldr x16, #20      580000b0   (literal at 24)
 *   8: br  x16           d61f0200
 *  12: nop               d503201f
 *  16: .quad name
 *  24: .quad art_unimplemented
 */
void *Android_rt::Overrides::stub(char const *name)
{
	uint32_t *code = (uint32_t *)_code.alloc(32, 16);
	if (!code) return nullptr;

	code[0] = 0x58000080;
	code[1] = 0x580000b0;
	code[2] = 0xd61f0200;
	code[3] = 0xd503201f;
	((uint64_t *)code)[2] = uint64_t(name);
	((uint64_t *)code)[3] = uint64_t(art_unimplemented);

	Genode::cache_coherent(Genode::addr_t(code), 32);
	return code;
}


/*******************
 ** Program start **
 *******************/

void Android_rt::start_program(Linker &linker, Memory &mem, Android_rt::Overrides &ov, int argc,
                               char const * const *argv, char const * const *envp)
{
	program_linker    = &linker;
	program_memory    = &mem;
	program_overrides = &ov;

	/* stack-guard canary: slot 5 and __stack_chk_guard hold the same value */
	canary = Genode::Trace::timestamp();
	canary ^= canary << 21; canary ^= canary >> 35; canary ^= canary << 4;
	canary &= ~0xffull;                     /* like glibc: a zero low byte */
	art___stack_chk_guard = canary;

	set_environment(envp);
	if (argc > 0 && argv[0]) argv0 = argv[0];
	set_tp(create_thread_block());

	/* constructors, dependencies first, the program last */
	linker.for_each_init_order([&] (unsigned i) {
		void (**arr)(); size_t count;
		linker.object(i)->init_array(arr, count);
		if (verbose_start && count)
			Genode::log("android_rt: constructors of ", Genode::Cstring(linker.path(i)), " (", count, ")");
		for (size_t k = 0; k < count; k++)
			if (arr[k] && arr[k] != (void (*)())-1) {
				if (verbose_start)
					Genode::log("android_rt:   ctor ", k, " at +", Genode::Hex((uint8_t *)arr[k] - linker.object(i)->base()));
				((void (*)(int, char const * const *, char const * const *))arr[k])(argc, argv, envp);
			}
	});

	/* Linux-style argument block for _start, on this thread's stack */
	enum { AT_NULL = 0, AT_PAGESZ = 6, AT_RANDOM = 25 };
	static uint8_t at_random[16];
	memcpy(at_random, &canary, 8);

	alignas(16) uintptr_t args[256];
	unsigned n = 0;
	args[n++] = uintptr_t(argc);
	for (int i = 0; i < argc && n < 200; i++) args[n++] = uintptr_t(argv[i]);
	args[n++] = 0;
	for (unsigned i = 0; envp && envp[i] && n < 240; i++) args[n++] = uintptr_t(envp[i]);
	args[n++] = 0;
	args[n++] = AT_PAGESZ; args[n++] = 4096;
	args[n++] = AT_RANDOM; args[n++] = uintptr_t(at_random);
	args[n++] = AT_NULL;   args[n++] = 0;

	Object const &prog = *linker.program();
	if (verbose_start) Genode::log("android_rt: entering _start");
	art_enter(prog.base() + prog.entry(), args);
}
