/*
 * \brief  Android platform pieces absent on Genode: HIDL without hwbinder, wake locks, fdsan, network interfaces
 * \author Ivan Loskutov
 * \date   2026-09-26
 *
 * HIDL carries none of the telephony interfaces,
 * but rild registers ISap and rilExternal through it. libhidlbase itself
 * stays loaded; only the calls that would open /dev/hwbinder are replaced:
 * without the driver, ProcessState asserts ("Binder driver could not be
 * opened. Terminating."). defaultServiceManager() is not overridden -- the
 * real one already returns null gracefully and clients (e.g. the audio HAL
 * lookup) handle that.
 */

/*
 * SPDX-License-Identifier: MIT
 */

#include <android_rt/runtime.h>
#include <android_rt/sock.h>
#include <base/log.h>
#include <util/string.h>

#include <arpa/inet.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>

using namespace Android_rt;

namespace {

	/*
	 * Name from an Android libc++ std::string (standard layout, little
	 * endian): short strings keep size << 1 in byte 0 and the characters from
	 * byte 1; long strings set bit 0 and keep size at +8, data at +16.
	 */
	void string_view(void const *s, char const *&data, unsigned long &len)
	{
		uint8_t const *b = (uint8_t const *)s;
		if (b[0] & 1) {
			len  = *(unsigned long const *)(b + 8);
			data = *(char const * const *)(b + 16);
		} else {
			len  = b[0] >> 1;
			data = (char const *)(b + 1);
		}
	}
}


extern "C" {

	/* status_t configureRpcThreadpool(size_t maxThreads, bool callerWillJoin) */
	int art_hidl_configureRpcThreadpool(unsigned long, bool) { return 0; }

	/* status_t details::registerAsServiceInternal(sp<IBase> const &, std::string const &) */
	int art_hidl_registerAsServiceInternal(void const *, void const *name)
	{
		char const *data; unsigned long len;
		string_view(name, data, len);
		char buf[128];
		unsigned long const n = len < sizeof(buf) - 1 ? len : sizeof(buf) - 1;
		for (unsigned long i = 0; i < n; i++) buf[i] = data[i];
		buf[n] = 0;
		Genode::log("android_rt: HIDL registerAsService '", Genode::Cstring(buf),
		            "' accepted (not exported)");
		return 0;
	}

	/*
	 * fdsan without ownership checks. Weak imports: AOSP sqlite calls the
	 * tag functions unguarded after open() (a null import jumped to 0), and
	 * libbase's unique_fd closes through close_with_tag once it exists.
	 */
	int art_close(int);

	uint64_t art_android_fdsan_get_owner_tag(int) { return 0; }

	uint64_t art_android_fdsan_create_owner_tag(int type, uint64_t tag)
	{
		return (uint64_t(type) << 56) | (tag & 0x00ffffffffffffffull);
	}

	void art_android_fdsan_exchange_owner_tag(int, uint64_t, uint64_t) { }

	int art_android_fdsan_close_with_tag(int fd, uint64_t) { return art_close(fd); }

	/*
	 * Wake locks (libhardware_legacy, used by libril_sitril): the real ones
	 * wait for Android's ISystemSuspend service, which blocks rild's request
	 * threads forever. Genode does not suspend -- nothing to hold.
	 */
	int art_acquire_wake_lock(int, char const *) { return 0; }
	int art_release_wake_lock(char const *)      { return 0; }

	/*
	 * Sockets are not provided: logged, EACCES. The exception are the
	 * sockets rild's NetIfController configures rmnetN through (sock.h):
	 * AF_INET / AF_INET6 datagram sockets as ioctl handles and a
	 * NETLINK_ROUTE socket for (empty) dumps. Nothing can be sent or
	 * received on a datagram socket, and bind, connect, the socket options
	 * and names are refused on every socket.
	 */
	int art_socket(int domain, int type, int protocol)
	{
		int const fd = sock_socket(domain, type, protocol);
		if (fd != -2) return fd;

		Genode::warning("android_rt: socket(", domain, ", ", type, ", ", protocol, ") denied");
		set_errno(13);
		return -1;
	}

	int art_socket_op(int fd, ...)
	{
		Genode::warning("android_rt: socket operation on fd ", fd, " denied");
		set_errno(13);
		return -1;
	}

	/* Linux arm64 struct msghdr, struct sockaddr_nl */
	struct Linux_iovec  { void *base; size_t len; };
	struct Linux_msghdr
	{
		void        *name;
		uint32_t     namelen;
		Linux_iovec *iov;
		size_t       iovlen;
		void        *control;
		size_t       controllen;
		int          flags;
	};
	struct Linux_sockaddr_nl { uint16_t family; uint16_t pad; uint32_t pid; uint32_t groups; };

	/* the sender of everything a netlink socket receives: the kernel */
	static void netlink_peer(void *addr, uint32_t *addrlen)
	{
		if (!addr || !addrlen) return;
		Linux_sockaddr_nl const kernel { 16 /* AF_NETLINK */, 0, 0, 0 };
		memcpy(addr, &kernel, *addrlen < sizeof(kernel) ? *addrlen : sizeof(kernel));
		*addrlen = sizeof(kernel);
	}

	ssize_t art_sendto(int fd, void const *buf, size_t n, int, void const *, uint32_t)
	{
		if (!is_sock_fd(fd)) return art_socket_op(fd);
		return sock_send(fd, buf, n);
	}

	ssize_t art_send(int fd, void const *buf, size_t n, int)
	{
		return art_sendto(fd, buf, n, 0, nullptr, 0);
	}

	ssize_t art_sendmsg(int fd, Linux_msghdr const *msg, int)
	{
		if (!is_sock_fd(fd)) return art_socket_op(fd);
		if (!msg || msg->iovlen != 1 || !msg->iov) { set_errno(22); return -1; }
		return sock_send(fd, msg->iov[0].base, msg->iov[0].len);
	}

	ssize_t art_recvfrom(int fd, void *buf, size_t n, int flags, void *addr, uint32_t *addrlen)
	{
		if (!is_sock_fd(fd)) return art_socket_op(fd);
		ssize_t const r = sock_recv(fd, buf, n, flags);
		if (r >= 0) netlink_peer(addr, addrlen);
		return r;
	}

	ssize_t art_recv(int fd, void *buf, size_t n, int flags)
	{
		return art_recvfrom(fd, buf, n, flags, nullptr, nullptr);
	}

	ssize_t art_recvmsg(int fd, Linux_msghdr *msg, int flags)
	{
		if (!is_sock_fd(fd)) return art_socket_op(fd);
		if (!msg || msg->iovlen < 1 || !msg->iov) { set_errno(22); return -1; }
		ssize_t const r = sock_recv(fd, msg->iov[0].base, msg->iov[0].len, flags);
		if (r < 0) return r;
		netlink_peer(msg->name, &msg->namelen);
		msg->controllen = 0;
		msg->flags      = size_t(r) > msg->iov[0].len ? 0x20 /* MSG_TRUNC */ : 0;
		return r;
	}
}


namespace {

	/* lo + <prefix>0..<prefix><count-1> (loader <net_interfaces>) */
	enum { MAX_IFS = 64, IF_NAME_LEN = 16 };

	constexpr unsigned decimal_digits(unsigned v) { return v < 10 ? 1 : 1 + decimal_digits(v / 10); }

	char     if_prefix[IF_NAME_LEN - 4];
	unsigned if_extra;                       /* interfaces after lo */
	char     if_names[MAX_IFS + 1][IF_NAME_LEN];
	bool     if_names_built;

	/* bound relied on by CC_OPT_sym_platform's -Wno-format-truncation below */
	static_assert(sizeof(if_prefix) - 1 + decimal_digits(MAX_IFS - 1) + 1 <= IF_NAME_LEN,
	              "if_prefix (minus NUL) + digits of MAX_IFS-1 + NUL must fit in if_names[i]");

	unsigned if_count() { return 1 + if_extra; }

	char const *if_name(unsigned i)          /* i: 0 .. if_count()-1 */
	{
		if (!if_names_built) {
			strcpy(if_names[0], "lo");
			for (unsigned r = 0; r < if_extra; r++)
				snprintf(if_names[r + 1], IF_NAME_LEN, "%s%u", if_prefix, r);
			if_names_built = true;
		}
		return if_names[i];
	}
}


void Android_rt::set_net_interfaces(char const *prefix, unsigned count)
{
	Genode::copy_cstring(if_prefix, prefix, sizeof(if_prefix));
	if_extra = count < unsigned(MAX_IFS) ? count : unsigned(MAX_IFS);
	if_names_built = false;
}


unsigned Android_rt::net_interface_count() { return if_count(); }


unsigned Android_rt::net_interface_index(char const *name)
{
	for (unsigned i = 0; name && i < if_count(); i++)
		if (!strcmp(name, if_name(i))) return i + 1;
	return 0;
}


char const *Android_rt::net_interface_name(unsigned index)
{
	return (index >= 1 && index <= if_count()) ? if_name(index - 1) : nullptr;
}


extern "C" {

	struct Linux_if_nameindex { unsigned if_index; char *if_name; };

	Linux_if_nameindex *art_if_nameindex()
	{
		Linux_if_nameindex *l = (Linux_if_nameindex *)calloc(if_count() + 1, sizeof(*l));
		for (unsigned i = 0; l && i < if_count(); i++)
			l[i] = { i + 1, (char *)if_name(i) };      /* names are static */
		return l;
	}

	void art_if_freenameindex(Linux_if_nameindex *l) { free(l); }

	unsigned art_if_nametoindex(char const *name)
	{
		unsigned const index = net_interface_index(name);
		if (!index) set_errno(19);                       /* ENODEV */
		return index;
	}

	int art_getifaddrs(void **list) { *list = nullptr; return 0; }

	/*
	 * Address text <-> binary (rild checks and converts the address of a
	 * data call with them). Linux AF_INET is 2 as here, AF_INET6 is 10.
	 */
	static int genode_af(int linux_af)
	{
		return linux_af == 2 ? AF_INET : linux_af == 10 ? AF_INET6 : -1;
	}

	int art_inet_pton(int af, char const *src, void *dst)
	{
		int const g = genode_af(af);
		if (g < 0) { set_errno(97); return -1; }                 /* EAFNOSUPPORT */
		return inet_pton(g, src, dst);
	}

	char const *art_inet_ntop(int af, void const *src, char *dst, uint32_t size)
	{
		int const g = genode_af(af);
		if (g < 0) { set_errno(97); return nullptr; }
		char const * const r = inet_ntop(g, src, dst, size);
		if (!r) set_errno(28);                                   /* ENOSPC */
		return r;
	}

	uint32_t art_inet_addr(char const *text) { return inet_addr(text); }
	void art_freeifaddrs(void *) { }
}


#define ART(name) { #name, (void *)art_##name }

static Export const exports[] = {
	{ "_ZN7android8hardware22configureRpcThreadpoolEmb",
	  (void *)art_hidl_configureRpcThreadpool },
	{ "_ZN7android8hardware7details25registerAsServiceInternalERKNS_2spINS_4hidl4base4V1_05IBaseEEERKNSt3__112basic_stringIcNSA_11char_traitsIcEENSA_9allocatorIcEEEE",
	  (void *)art_hidl_registerAsServiceInternal },
	ART(android_fdsan_get_owner_tag), ART(android_fdsan_create_owner_tag),
	ART(android_fdsan_exchange_owner_tag), ART(android_fdsan_close_with_tag),
	ART(acquire_wake_lock), ART(release_wake_lock),
	ART(if_nameindex), ART(if_freenameindex), ART(if_nametoindex),
	ART(getifaddrs), ART(freeifaddrs),
	ART(inet_pton), ART(inet_ntop), ART(inet_addr),
	{ "socket",      (void *)art_socket },
	{ "connect",     (void *)art_socket_op },
	{ "bind",        (void *)art_socket_op },
	{ "listen",      (void *)art_socket_op },
	{ "accept",      (void *)art_socket_op },
	{ "accept4",     (void *)art_socket_op },
	{ "setsockopt",  (void *)art_socket_op },
	{ "getsockopt",  (void *)art_socket_op },
	{ "getsockname", (void *)art_socket_op },
	{ "sendmsg",     (void *)art_sendmsg },
	{ "recvmsg",     (void *)art_recvmsg },
	{ "send",        (void *)art_send },
	{ "recv",        (void *)art_recv },
	{ "sendto",      (void *)art_sendto },
	{ "recvfrom",    (void *)art_recvfrom },
};

#undef ART

Export_group Android_rt::platform_exports() { return { exports, sizeof(exports) / sizeof(exports[0]) }; }
