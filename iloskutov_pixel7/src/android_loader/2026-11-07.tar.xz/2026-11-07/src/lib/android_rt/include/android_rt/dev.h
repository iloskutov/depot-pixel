/*
 * \brief  Device nodes of the Android runtime (/dev/umts_*, /dev/kmsg, ...)
 * \author Ivan Loskutov
 * \date   2026-09-25
 *
 * Descriptors of runtime-served device nodes live above DEV_FD_BASE. Genode
 * libc descriptors are allocated from 0 upwards (up to 1023), so the two
 * collide only if the program holds DEV_FD_BASE VFS files open at once.
 */

/*
 * SPDX-License-Identifier: MIT
 */

#ifndef _ANDROID_RT__DEV_H_
#define _ANDROID_RT__DEV_H_

#include <stddef.h>
#include <stdint.h>
#include <sys/types.h>

namespace Android_rt {

	enum { DEV_FD_BASE = 512 };   /* < FD_SETSIZE, so select() can see them */

	/* device descriptors are DEV_FD_BASE .. DEV_FD_BASE + DEV_FD_COUNT - 1;
	 * the runtime's sockets follow (sock.h) */
	enum { DEV_FD_COUNT = 256 };

	/**
	 * Open 'path' if the runtime serves it
	 *
	 * \return fd >= DEV_FD_BASE, -1 with errno set if it fails, or
	 *         -2 if 'path' is not a runtime device node
	 */
	int dev_open(char const *path, int linux_flags);

	inline bool is_dev_fd(int fd) { return fd >= DEV_FD_BASE; }

	ssize_t dev_read (int fd, void *buf, size_t n);
	ssize_t dev_write(int fd, void const *buf, size_t n);
	int     dev_ioctl(int fd, unsigned long cmd, void *arg);
	int     dev_close(int fd);

	/**
	 * Remove a descriptor of any kind from every epoll set (its last close)
	 */
	void    dev_forget_fd(int fd);

	/**
	 * poll() readiness: bit 0 readable, bit 1 writeable, bit 2 hang-up,
	 * bit 3 not an open descriptor
	 *
	 * \param probe    re-read a chardev's readiness from its server even
	 *                 without a readiness signal (see 'Chardev_slice')
	 * \param chardev  set to true if 'fd' is a chardev session
	 */
	unsigned dev_ready(int fd, bool probe, bool &chardev);

	/**
	 * Hang-up detection for waits on chardev sessions
	 *
	 * A server that vanished sends no readiness signal, so a wait that
	 * involves chardevs is cut into slices: after 'MS' of timed-out waiting
	 * (accumulated, wake-ups by other changes don't count) 'probe' is set and
	 * the next readiness check re-reads the chardevs from their servers -- an
	 * RPC to a dead server fails, which reports HANGUP. Only waits that
	 * involve chardevs become timed (a timed wait reads the clock, i.e. opens
	 * the Timer session).
	 */
	struct Chardev_slice
	{
		enum { MS = 1000 };

		int  left  = MS;
		bool probe = false;   /* set when a slice expired, cleared by the user */

		/**
		 * Cap 'wait' (ms, -1 forever) to the rest of the slice
		 */
		int cap(bool chardevs, int wait) const
		{
			return (chardevs && (wait < 0 || wait > left)) ? left : wait;
		}

		/**
		 * Account an 'io_wait(gen, wait)' that returned 'changed'
		 */
		void waited(bool chardevs, bool changed, int wait)
		{
			if (!chardevs || changed || wait < 0) return;
			left -= wait;
			if (left <= 0) { probe = true; left = MS; }
		}
	};

	int dev_eventfd(unsigned initval, int flags);

	/**
	 * pipe2(): out[0] read end, out[1] write end (flags: Linux O_NONBLOCK)
	 */
	int dev_pipe(int out[2], int flags);

	/**
	 * fcntl F_GETFL / F_SETFL on a runtime descriptor (Linux flag values)
	 */
	int dev_flags(int fd);
	int dev_set_flags(int fd, int flags);
	int dev_epoll_create();
	int dev_epoll_ctl(int epfd, int op, int fd, uint32_t events, uint64_t data);

	/**
	 * Wait for readiness, fill up to 'max' entries
	 */
	int dev_epoll_wait(int epfd, uint32_t *events, uint64_t *datas, int max, int timeout_ms);
}

#endif /* _ANDROID_RT__DEV_H_ */
