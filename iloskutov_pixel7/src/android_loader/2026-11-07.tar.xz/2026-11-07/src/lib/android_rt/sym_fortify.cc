/*
 * \brief  bionic _FORTIFY_SOURCE entry points and small libc leftovers
 * \author Ivan Loskutov
 * \date   2026-09-25
 *
 * The __*_chk variants carry the compiler-known buffer size; an overflow
 * aborts the component like bionic's __fortify_fatal does.
 */

/*
 * SPDX-License-Identifier: MIT
 */

#include <android_rt/runtime.h>
#include <android_rt/linux_abi.h>
#include <base/log.h>
#include <util/string.h>

#include <fnmatch.h>
#include <getopt.h>
#include <inttypes.h>
#include <pthread.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <time.h>
#include <unistd.h>

using namespace Android_rt;

extern "C" {

	ssize_t art_read(int, void *, size_t);
	ssize_t art_write(int, void const *, size_t);
	ssize_t art_pread(int, void *, size_t, off_t);
	ssize_t art_pwrite(int, void const *, size_t, off_t);
	int     art_open(char const *, int, ...);
	int     art_openat(int, char const *, int, ...);
	size_t  art_fwrite(void const *, size_t, size_t, void *);
	size_t  art_fread(void *, size_t, size_t, void *);
	int     art_stat(char const *, Linux::Stat *);

	[[noreturn]] static void fortify_fail(char const *fn)
	{
		Genode::error("android_rt: FORTIFY: ", fn, ": buffer overflow detected");
		flush_stdio();
		::_exit(134);
	}

	static void check_size(char const *fn, size_t need, size_t have)
	{
		if (have != size_t(-1) && need > have) fortify_fail(fn);
	}

	void *art___memcpy_chk(void *d, void const *s, size_t n, size_t dn)
	{ check_size("memcpy", n, dn); return memcpy(d, s, n); }

	void *art___memmove_chk(void *d, void const *s, size_t n, size_t dn)
	{ check_size("memmove", n, dn); return memmove(d, s, n); }

	void *art___memset_chk(void *d, int c, size_t n, size_t dn)
	{ check_size("memset", n, dn); return memset(d, c, n); }

	size_t art___strlen_chk(char const *s, size_t sn)
	{ size_t const n = strlen(s); check_size("strlen", n + 1, sn); return n; }

	char *art___strcpy_chk(char *d, char const *s, size_t dn)
	{ check_size("strcpy", strlen(s) + 1, dn); return strcpy(d, s); }

	char *art___strcat_chk(char *d, char const *s, size_t dn)
	{ check_size("strcat", strlen(d) + strlen(s) + 1, dn); return strcat(d, s); }

	char *art___strncat_chk(char *d, char const *s, size_t n, size_t dn)
	{ size_t const sl = strnlen(s, n); check_size("strncat", strlen(d) + sl + 1, dn); return strncat(d, s, n); }

	char *art___strncpy_chk(char *d, char const *s, size_t n, size_t dn)
	{ check_size("strncpy", n, dn); return strncpy(d, s, n); }

	char *art___strncpy_chk2(char *d, char const *s, size_t n, size_t dn, size_t)
	{ check_size("strncpy", n, dn); return strncpy(d, s, n); }

	size_t art___strlcpy_chk(char *d, char const *s, size_t n, size_t dn)
	{ check_size("strlcpy", n, dn); return strlcpy(d, s, n); }

	size_t art___strlcat_chk(char *d, char const *s, size_t n, size_t dn)
	{ check_size("strlcat", n, dn); return strlcat(d, s, n); }

	char *art___strchr_chk(char const *s, int c, size_t)  { return (char *)strchr(s, c); }
	char *art___strrchr_chk(char const *s, int c, size_t) { return (char *)strrchr(s, c); }

	int art___vsnprintf_chk(char *d, size_t n, int, size_t dn, char const *fmt, va_list ap)
	{ check_size("vsnprintf", n, dn); return vsnprintf(d, n, fmt, ap); }

	int art___vsprintf_chk(char *d, int, size_t dn, char const *fmt, va_list ap)
	{
		int const n = vsnprintf(d, dn == size_t(-1) ? size_t(0x7fffffff) : dn, fmt, ap);
		if (dn != size_t(-1) && n >= 0 && size_t(n) >= dn) fortify_fail("vsprintf");
		return n;
	}

	ssize_t art___read_chk(int fd, void *b, size_t n, size_t bn)
	{ check_size("read", n, bn); return art_read(fd, b, n); }

	ssize_t art___write_chk(int fd, void const *b, size_t n, size_t bn)
	{ check_size("write", n, bn); return art_write(fd, b, n); }

	ssize_t art___pread_chk(int fd, void *b, size_t n, off_t o, size_t bn)
	{ check_size("pread", n, bn); return art_pread(fd, b, n, o); }

	ssize_t art___pwrite_chk(int fd, void const *b, size_t n, off_t o, size_t bn)
	{ check_size("pwrite", n, bn); return art_pwrite(fd, b, n, o); }

	size_t art___fwrite_chk(void const *p, size_t sz, size_t n, void *f, size_t bn)
	{ check_size("fwrite", sz * n, bn); return art_fwrite(p, sz, n, f); }

	size_t art___fread_chk(void *p, size_t sz, size_t n, void *f, size_t bn)
	{ check_size("fread", sz * n, bn); return art_fread(p, sz, n, f); }

	mode_t art___umask_chk(mode_t m) { return umask(m); }

	int art___openat_2(int dirfd, char const *path, int flags) { return art_openat(dirfd, path, flags); }

	/* select() on Linux' fd_set: 1024 bits */
	static void check_fd(char const *fn, int fd, size_t set_size)
	{
		if (fd < 0 || fd >= 1024 || set_size < 128) fortify_fail(fn);
	}

	void art___FD_SET_chk(int fd, void *set, size_t n)
	{ check_fd("FD_SET", fd, n); ((unsigned long *)set)[fd / 64] |= 1ul << (fd % 64); }

	int  art___FD_ISSET_chk(int fd, void const *set, size_t n)
	{ check_fd("FD_ISSET", fd, n); return (((unsigned long const *)set)[fd / 64] >> (fd % 64)) & 1; }

	void art___FD_CLR_chk(int fd, void *set, size_t n)
	{ check_fd("FD_CLR", fd, n); ((unsigned long *)set)[fd / 64] &= ~(1ul << (fd % 64)); }

	/* strerror on Linux errno values */
	char *art_strerror(int linux_errno)
	{
		for (int e = 1; e < 128; e++)
			if (Linux::errno_from_freebsd(e) == linux_errno) return strerror(e);
		static char buf[32];
		snprintf(buf, sizeof(buf), "Unknown error %d", linux_errno);
		return buf;
	}

	int art_strerror_r(int e, char *buf, size_t n) { snprintf(buf, n, "%s", art_strerror(e)); return 0; }
	char *art___gnu_strerror_r(int e, char *buf, size_t n) { snprintf(buf, n, "%s", art_strerror(e)); return buf; }

	/*
	 * basename and dirname as in bionic: the argument stays as it is (the
	 * libc's own functions modify it), the result is in a buffer of the
	 * calling thread
	 */
	enum { PATH_BUF = 4096 };

	static pthread_key_t  path_key;
	static pthread_once_t path_once = PTHREAD_ONCE_INIT;

	static void path_key_create() { pthread_key_create(&path_key, free); }

	/* copy 'len' characters of 's' to buffer 0 (basename) or 1 (dirname) */
	static char *path_result(unsigned i, char const *s, size_t len)
	{
		pthread_once(&path_once, path_key_create);
		char *b = (char *)pthread_getspecific(path_key);
		if (!b) {
			b = (char *)malloc(2*PATH_BUF);
			if (!b) return nullptr;
			pthread_setspecific(path_key, b);
		}
		b += i*PATH_BUF;
		if (len > PATH_BUF - 1) len = PATH_BUF - 1;
		memcpy(b, s, len);
		b[len] = 0;
		return b;
	}

	char *art_basename(char const *path)
	{
		if (!path || !*path) return path_result(0, ".", 1);

		char const *end = path + strlen(path) - 1;              /* last character */
		while (end > path && *end == '/') end--;
		if (end == path && *end == '/') return path_result(0, "/", 1);

		char const *start = end;
		while (start > path && start[-1] != '/') start--;
		return path_result(0, start, size_t(end - start) + 1);
	}

	char *art_dirname(char const *path)
	{
		if (!path || !*path) return path_result(1, ".", 1);

		char const *end = path + strlen(path) - 1;
		while (end > path && *end == '/') end--;                /* trailing slashes */
		while (end > path && *end != '/') end--;                /* last component */
		if (end == path) return path_result(1, *end == '/' ? "/" : ".", 1);

		do { end--; } while (end > path && *end == '/');        /* slashes before it */
		return path_result(1, path, size_t(end - path) + 1);
	}

	char const *art_getprogname()
	{
		static char const name[] = "android";
		return name;
	}

	int art_dprintf(int fd, char const *fmt, ...)
	{
		char buf[1024];
		va_list ap; va_start(ap, fmt);
		int const n = vsnprintf(buf, sizeof(buf), fmt, ap);
		va_end(ap);
		if (n > 0) art_write(fd, buf, size_t(n) < sizeof(buf) ? size_t(n) : sizeof(buf) - 1);
		return n;
	}

	void art_sync() { }
	int  art_klogctl(int, char *, int) { set_errno(38); return -1; }
	int  art_sched_setaffinity(int, size_t, void const *) { return 0; }
	int  art_sched_getaffinity(int, size_t n, void *mask)
	{
		memset(mask, 0, n);
		if (n) ((uint8_t *)mask)[0] = 1;
		return 0;
	}
	int  art_prctl(int, unsigned long, unsigned long, unsigned long, unsigned long) { return 0; }
	int  art_setpriority(int, int, int) { return 0; }
	int  art_getpriority(int, int) { return 0; }

	int art_statfs(char const *, void *buf) { memset(buf, 0, 120); return 0; }
	int art_statvfs(char const *, void *buf) { memset(buf, 0, 112); return 0; }

	void *art_android_get_exported_namespace(char const *) { return nullptr; }

	/* syslog */
	void art_openlog(char const *, int, int) { }
	void art_closelog() { }
	void art_vsyslog(int, char const *fmt, va_list ap)
	{
		char buf[512];
		vsnprintf(buf, sizeof(buf), fmt, ap);
		Genode::log("syslog: ", Genode::Cstring(buf));
	}
	void art_syslog(int prio, char const *fmt, ...)
	{
		va_list ap; va_start(ap, fmt);
		art_vsyslog(prio, fmt, ap);
		va_end(ap);
	}

	/* bionic assert(): log and abort like the device */
	[[noreturn]] void art___assert2(char const *file, int line, char const *func, char const *expr)
	{
		Genode::error("android_rt: assertion \"", Genode::Cstring(expr), "\" failed in ",
		              Genode::Cstring(func ? func : "?"), " at ", Genode::Cstring(file), ":", line);
		abort();
	}
	[[noreturn]] void art___assert(char const *file, int line, char const *expr)
	{
		art___assert2(file, line, nullptr, expr);
	}

	int art___system_property_get(char const *, char *);

	/* API level of the device the binaries come from (ro.build.version.sdk) */
	int art_android_get_device_api_level()
	{
		char v[92] { };
		return art___system_property_get("ro.build.version.sdk", v) > 0 ? atoi(v) : -1;
	}

	/* in6addr_any: 16 zero bytes */
	uint8_t art_in6addr_any[16];
}


#define EXPORT(name) { #name, (void *)name }
#define ART(name)    { #name, (void *)art_##name }

static Export const exports[] = {
	ART(__memcpy_chk), ART(__memmove_chk), ART(__memset_chk), ART(__strlen_chk),
	ART(__strcpy_chk), ART(__strcat_chk), ART(__strncat_chk), ART(__strncpy_chk),
	ART(__strncpy_chk2), ART(__strlcpy_chk), ART(__strlcat_chk), ART(__assert), ART(__assert2),
	ART(android_get_device_api_level), ART(__strchr_chk), ART(__strrchr_chk),
	ART(__vsnprintf_chk), ART(__vsprintf_chk), ART(__read_chk), ART(__write_chk),
	ART(__pread_chk), ART(__pwrite_chk), ART(__fwrite_chk), ART(__fread_chk), ART(__umask_chk),
	ART(__openat_2), ART(__FD_SET_chk), ART(__FD_ISSET_chk), ART(__FD_CLR_chk),
	ART(strerror), ART(strerror_r), ART(__gnu_strerror_r), ART(getprogname),
	ART(basename), ART(dirname),
	ART(dprintf), ART(sync), ART(klogctl), ART(sched_setaffinity), ART(sched_getaffinity),
	ART(prctl), ART(setpriority), ART(getpriority), ART(statfs), ART(statvfs),
	ART(android_get_exported_namespace),
	ART(openlog), ART(closelog), ART(vsyslog), ART(syslog),
	{ "in6addr_any", (void *)art_in6addr_any },
	{ "optarg",      (void *)&optarg },
	{ "optind",      (void *)&optind },
	{ "opterr",      (void *)&opterr },
	EXPORT(getopt), EXPORT(getopt_long), EXPORT(localtime_r), EXPORT(localtime), EXPORT(gmtime_r),
	EXPORT(mktime), EXPORT(fnmatch),
	EXPORT(strtoimax), EXPORT(strtoumax), EXPORT(mkstemp), EXPORT(umask),
};

#undef EXPORT
#undef ART

Export_group Android_rt::fortify_exports() { return { exports, sizeof(exports) / sizeof(exports[0]) }; }
