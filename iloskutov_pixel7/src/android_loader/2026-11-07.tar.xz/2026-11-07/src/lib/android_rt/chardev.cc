/*
 * \brief  Runtime client of Android_chardev sessions
 * \author Ivan Loskutov
 * \date   2026-09-26
 */

/*
 * SPDX-License-Identifier: MIT
 */

#include <android_rt/runtime.h>
#include <android_rt/chardev.h>
#include <base/log.h>
#include <util/string.h>

#include <string.h>

using namespace Android_rt;

namespace {

	enum { MAX_PREFIXES = 4, PREFIX_LEN = 32,
	       EINVAL_ = 22, ENOENT_ = 2, EIO_ = 5, EAGAIN_ = 11, EPIPE_ = 32 };

	char     prefixes[MAX_PREFIXES][PREFIX_LEN];
	unsigned prefix_count;
}


void Android_rt::add_chardev_prefix(char const *prefix)
{
	if (!prefix || !prefix[0]) {
		Genode::warning("android_rt: empty <chardev prefix=\"...\"/> ignored "
		                 "(would match every path)");
		return;
	}
	if (prefix_count == MAX_PREFIXES) { Genode::warning("android_rt: too many <chardev> prefixes"); return; }
	if (strlen(prefix) >= PREFIX_LEN)
		Genode::warning("android_rt: <chardev> prefix '", Genode::Cstring(prefix),
		                "' truncated to ", (unsigned)PREFIX_LEN - 1, " characters");
	Genode::copy_cstring(prefixes[prefix_count++], prefix, PREFIX_LEN);
}


bool Android_rt::is_chardev_path(char const *path)
{
	for (unsigned i = 0; i < prefix_count; i++)
		if (!strncmp(path, prefixes[i], strlen(prefixes[i]))) return true;
	return false;
}


Chardev_file::~Chardev_file()
{
	if (_managed) io_dissolve(_signal);
}


int Chardev_file::open(char const *node, int linux_flags)
{
	using Result = Connection::Result;

	Genode::String<32> const args("flags=", linux_flags);
	Result const r = _conn.open(node, args.string());
	if (r == Result::DENIED) return ENOENT_;
	if (r != Result::OK) {
		Genode::error("android_rt: chardev open of '", Genode::Cstring(node),
		              "' failed (Android_chardev session request failed)");
		return EIO_;
	}

	try {
		_ds.construct(Android_rt::env().rm(), _conn.client().dataspace());
		Genode::Signal_context_capability const sigh = io_manage(_signal);
		_managed = true;                       /* dissolve on any later failure */
		_conn.client().readiness_sigh(sigh);
	} catch (...) {
		Genode::error("android_rt: chardev open of '", Genode::Cstring(node),
		              "' failed (dataspace attach or signal registration)");
		return EIO_;
	}
	return 0;
}


Chardev_file::Status Chardev_file::_status(int32_t result, int32_t err_in, int &err)
{
	probe();   /* own operation: the server's state changed */
	switch (result) {
	case Session::OK:          return Status::OK;
	case Session::WOULD_BLOCK: return Status::WOULD_BLOCK;
	default:                   err = err_in ? err_in : EIO_; return Status::ERROR;
	}
}


Chardev_file::Status Chardev_file::read(void *buf, size_t n, size_t &count, int &err)
{
	/* read(fd, buf, 0) returns 0 -- a server read(0) would drop a message */
	if (n == 0) { count = 0; return Status::OK; }

	Genode::Mutex::Guard guard(_mutex);
	if (_hung_up()) return Status::HANGUP;
	uint32_t const max = n < Session::BUFFER_SIZE ? uint32_t(n) : uint32_t(Session::BUFFER_SIZE);
	Session::Io_result r { };
	try { r = _conn.client().read(max); }
	catch (...) { _set_hangup(); return Status::HANGUP; }

	Status const s = _status(r.result, r.err, err);
	if (s == Status::OK) {
		count = r.count <= max ? r.count : max;
		memcpy(buf, _buf(), count);
	}
	return s;
}


Chardev_file::Status Chardev_file::write(void const *buf, size_t n, size_t &count, int &err)
{
	Genode::Mutex::Guard guard(_mutex);
	if (_hung_up()) { err = EPIPE_; return Status::ERROR; }
	if (n > Session::BUFFER_SIZE) {
		Genode::error("android_rt: chardev write of ", n, " bytes exceeds the ",
		              (unsigned)Session::BUFFER_SIZE, "-byte session buffer");
		err = EINVAL_;
		return Status::ERROR;
	}
	memcpy(_buf(), buf, n);
	Session::Io_result r { };
	try { r = _conn.client().write(uint32_t(n)); }
	catch (...) { _set_hangup(); err = EPIPE_; return Status::ERROR; }

	Status const s = _status(r.result, r.err, err);
	if (s == Status::OK) count = r.count <= n ? r.count : n;   /* never report more than requested */
	return s;
}


Chardev_file::Status Chardev_file::ioctl(unsigned long cmd, void *arg, long &ret, int &err)
{
	Genode::Mutex::Guard guard(_mutex);
	if (_hung_up()) { err = EIO_; return Status::ERROR; }

	Ioctl_transfer const t = ioctl_transfer(cmd);
	if (t.in_len > Session::BUFFER_SIZE || t.out_len > Session::BUFFER_SIZE) {
		Genode::error("android_rt: ioctl ", Genode::Hex(cmd), " argument too large");
		err = EINVAL_;
		return Status::ERROR;
	}

	size_t const in_len = compose_ioctl_input(cmd, arg, _buf(), Session::BUFFER_SIZE,
	                                          ioctl_payload_hook(cmd));

	/* the ioctl may block in the server: 'ready()' must not wait for it */
	auto in_ioctl = [&] (bool v) { Genode::Mutex::Guard g(_ready_mutex); _in_ioctl = v; };

	Session::Ioctl_result r { };
	in_ioctl(true);
	try {
		r = _conn.client().ioctl(cmd, t.by_value ? uint64_t(arg) : 0,
		                         uint32_t(in_len), uint32_t(t.out_len)); }
	catch (...) { in_ioctl(false); _set_hangup(); err = EIO_; return Status::ERROR; }
	in_ioctl(false);

	Status const s = _status(r.result, r.err, err);
	if (s == Status::OK) {
		ret = long(r.ret);
		size_t const out = r.out_len < t.out_len ? r.out_len : t.out_len;
		if (out) memcpy(arg, _buf(), out);
	}
	if (s == Status::WOULD_BLOCK) { err = EAGAIN_; return Status::ERROR; }
	return s;
}


unsigned Chardev_file::ready()
{
	Genode::Mutex::Guard guard(_ready_mutex);
	if (_hung_up()) return Session::HANGUP | Session::READABLE;
	if (_in_ioctl) return _ready;   /* re-read after the ioctl, which marks the state stale */
	if (io_take_stale(_signal)) {
		try { _ready = _conn.client().ready(); }
		catch (...) { _set_hangup(); return Session::HANGUP | Session::READABLE; }
	}
	return _ready;
}
