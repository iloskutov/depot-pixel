/*
 * \brief  Linux regular-file read semantics on top of a clipping reader
 * \author Ivan Loskutov
 * \date   2026-09-29
 *
 * Linux returns the full count from read()/pread() on a regular file unless
 * EOF is reached, and the vendor daemons rely on it: cbd reads modem.bin's
 * 92160-byte BOOT section with one read() and fails on "read 63968 !=
 * img.size 92160". Genode's VFS 'fs' plugin clips a read to half its packet
 * buffer. 'read_full' repeats a short read until the count is reached, EOF
 * (0) or an error; bytes already read are returned even if a later call
 * fails. The caller applies it to regular files only (pipes, sockets and
 * character devices keep their short reads).
 */

/*
 * SPDX-License-Identifier: MIT
 */

#ifndef _ANDROID_RT__FULL_READ_H_
#define _ANDROID_RT__FULL_READ_H_

namespace Android_rt {

	/**
	 * Complete a read that returned 'first' bytes of 'count'
	 *
	 * \param first  result of the first read (> 0, < count)
	 * \param more   callable 'long (unsigned long done)' reading the
	 *               remaining bytes starting at offset 'done' of the
	 *               request; returns bytes read, 0 at EOF, < 0 on error
	 * \return       total bytes read
	 */
	template <typename FN>
	long read_full(long first, unsigned long count, FN const &more)
	{
		unsigned long done = (unsigned long)first;
		while (done < count) {
			long const n = more(done);
			if (n <= 0) break;
			done += (unsigned long)n;
		}
		return (long)done;
	}
}

#endif /* _ANDROID_RT__FULL_READ_H_ */
