/*
 * \brief  Runtime client of Android_chardev sessions (one per open /dev node)
 * \author Ivan Loskutov
 * \date   2026-09-26
 */

/*
 * SPDX-License-Identifier: MIT
 */

#ifndef _ANDROID_RT__CHARDEV_H_
#define _ANDROID_RT__CHARDEV_H_

#include <android_chardev_session/android_chardev_session.h>
#include <android_rt/chardev_ioctl.h>
#include <android_rt/io.h>
#include <base/attached_dataspace.h>
#include <base/mutex.h>
#include <try_connection.h>

namespace Android_rt {

	/**
	 * Paths starting with 'prefix' (e.g. "/dev/umts_") are chardev sessions
	 */
	void add_chardev_prefix(char const *prefix);
	bool is_chardev_path(char const *path);

	class Chardev_file;
}


/*
 * Lock order (never violate): dev.cc's own 'mutex' -> '_ready_mutex' here,
 * and '_mutex' -> '_ready_mutex'. dev.cc releases its mutex before calling
 * into read()/write()/ioctl(), which take '_mutex' and may hold it for long:
 * the server's ioctl may block. 'ready()' is called from dev.cc's
 * ready_locked() with the dev mutex still held (and from chardev_io() without
 * it), so it must never wait: it takes only '_ready_mutex', which is held
 * across nothing but the server's ready() RPC (never blocks) and the marking
 * of an ioctl in flight. While an ioctl is in flight -- the session's
 * entrypoint is busy with it -- 'ready()' returns the last known state without
 * an RPC.
 */
class Android_rt::Chardev_file : Genode::Noncopyable
{
	public:

		enum class Status { OK, WOULD_BLOCK, ERROR, HANGUP };

		using Session = Android_chardev_session::Session;

	private:

		using Connection = Genode_pixel::Try_connection<Session, Android_chardev_session::Session_client>;

		Connection                                      _conn { Android_rt::env() };
		Genode::Constructible<Genode::Attached_dataspace> _ds { };
		Io_signal                                       _signal { };
		bool                                            _managed = false;
		unsigned                                        _ready   = 0;
		bool                                            _hangup  = false;   /* see _hung_up() */
		bool                                            _in_ioctl = false;  /* guarded by _ready_mutex */

		/*
		 * Serializes read()/write()/ioctl() against each other: the
		 * shared dataspace buffer (_buf()) is reused for every call's payload,
		 * and rild has independent reader/writer threads on the same fd, so
		 * two calls racing on the same Chardev_file would otherwise stomp on
		 * one another's in-flight buffer contents.
		 */
		Genode::Mutex _mutex { };

		/* guards '_ready' and '_in_ioctl', see the lock order above */
		Genode::Mutex _ready_mutex { };

		/* '_hangup' is set and read under either mutex */
		bool _hung_up()       { return __atomic_load_n(&_hangup, __ATOMIC_ACQUIRE); }
		void _set_hangup()    { __atomic_store_n(&_hangup, true, __ATOMIC_RELEASE); }

		uint8_t *_buf() { return _ds->local_addr<uint8_t>(); }

		Status _status(int32_t result, int32_t err_in, int &err);

	public:

		Chardev_file() { }
		~Chardev_file();

		Chardev_file(Chardev_file const &) = delete;
		Chardev_file &operator = (Chardev_file const &) = delete;

		/**
		 * \return 0 or a Linux errno
		 */
		int open(char const *node, int linux_flags);

		Status read (void *buf, size_t n, size_t &count, int &err);
		Status write(void const *buf, size_t n, size_t &count, int &err);

		/**
		 * 'cmd's own encoded input, plus any profile-registered payload
		 * bytes appended after it (Android_rt::ioctl_payload_hook)
		 */
		Status ioctl(unsigned long cmd, void *arg, long &ret, int &err);

		/**
		 * READABLE | WRITABLE | HANGUP, re-read from the server only after a
		 * readiness signal, an own operation or a 'probe()', and not while
		 * an ioctl is in flight
		 */
		unsigned ready();

		/**
		 * Make the next 'ready()' re-read the server's state (a server that
		 * vanished sends no signal; the RPC to it fails -> HANGUP)
		 */
		void probe() { __atomic_store_n(&_signal.stale, 1u, __ATOMIC_RELEASE); }
};

#endif /* _ANDROID_RT__CHARDEV_H_ */
