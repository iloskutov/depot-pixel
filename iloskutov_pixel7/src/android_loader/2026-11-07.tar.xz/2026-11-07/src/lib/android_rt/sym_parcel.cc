/*
 * \brief  Export table of the parcel part of libbinder_ndk
 * \author Ivan Loskutov
 * \date   2026-09-25
 *
 * The functions live in lib/android_binder (parcel.cc, host-tested).
 * AIBinder_* and AServiceManager_* are exported by sym_binder.cc.
 */

/*
 * SPDX-License-Identifier: MIT
 */

#include <android_rt/runtime.h>
#include <android_binder/parcel.h>

using namespace Android_rt;

#define EXPORT(name) { #name, (void *)name }

static Export const exports[] = {
	EXPORT(AStatus_newOk), EXPORT(AStatus_fromExceptionCode),
	EXPORT(AStatus_fromExceptionCodeWithMessage), EXPORT(AStatus_fromServiceSpecificError),
	EXPORT(AStatus_fromServiceSpecificErrorWithMessage), EXPORT(AStatus_fromStatus),
	EXPORT(AStatus_isOk), EXPORT(AStatus_getExceptionCode), EXPORT(AStatus_getServiceSpecificError),
	EXPORT(AStatus_getStatus), EXPORT(AStatus_getMessage), EXPORT(AStatus_getDescription),
	EXPORT(AStatus_deleteDescription), EXPORT(AStatus_delete),
	EXPORT(AParcel_delete), EXPORT(AParcel_getDataPosition), EXPORT(AParcel_setDataPosition),
	EXPORT(AParcel_writeInt32), EXPORT(AParcel_writeInt64), EXPORT(AParcel_writeBool),
	EXPORT(AParcel_writeByte), EXPORT(AParcel_writeChar), EXPORT(AParcel_readInt32),
	EXPORT(AParcel_readInt64), EXPORT(AParcel_readBool), EXPORT(AParcel_readByte),
	EXPORT(AParcel_readChar), EXPORT(AParcel_writeString), EXPORT(AParcel_readString),
	EXPORT(AParcel_writeInt32Array), EXPORT(AParcel_readInt32Array),
	EXPORT(AParcel_writeByteArray), EXPORT(AParcel_readByteArray),
	EXPORT(AParcel_writeStringArray), EXPORT(AParcel_readStringArray),
	EXPORT(AParcel_writeParcelableArray), EXPORT(AParcel_readParcelableArray),
	EXPORT(AParcel_writeStatusHeader), EXPORT(AParcel_readStatusHeader),
	EXPORT(AParcel_writeStrongBinder), EXPORT(AParcel_readStrongBinder),
};

#undef EXPORT

Export_group Android_rt::parcel_exports() { return { exports, sizeof(exports) / sizeof(exports[0]) }; }
