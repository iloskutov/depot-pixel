/*
 * \brief  POSIX signals for the Android runtime
 * \author Ivan Loskutov
 * \date   2026-09-25
 *
 * Genode has no asynchronous signal delivery. Handlers are recorded per
 * process (bionic arm64 'struct sigaction' layout) and run only for signals
 * the program sends to itself (raise, kill on its own pid). Nothing else
 * ever arrives -- e.g. SIGPIPE on a closed pipe is not raised, write()
 * fails with EPIPE instead (what a SIG_IGN'd SIGPIPE gives on Linux).
 *
 * The one exception are POSIX timers (timer_create, timer_settime,
 * timer_delete): rild's services arm a one-shot timer with a real-time
 * signal for every request that has a time-out (Service::StartTimer, e.g.
 * the data-call setup). The notification of an expired timer -- the
 * recorded handler of its signal with si_value, or the SIGEV_THREAD
 * function -- runs on one runtime thread, i.e. next to the program's
 * threads instead of interrupting one of them. A timer signal without a
 * handler is dropped.
 */

/*
 * SPDX-License-Identifier: MIT
 */

#include <android_rt/runtime.h>
#include <android_rt/posix_timer.h>
#include <base/log.h>
#include <base/mutex.h>

#include <pthread.h>
#include <string.h>
#include <time.h>

using namespace Android_rt;

namespace {

	/* bionic LP64: sigset_t is one unsigned long, signals 1..64 */
	typedef unsigned long Sigset;

	typedef void (*Handler)(int);
	typedef void (*Action)(int, void *, void *);

	struct Bionic_sigaction
	{
		int     sa_flags;
		union { Handler sa_handler; Action sa_sigaction; };
		Sigset  sa_mask;
		void  (*sa_restorer)();
	};
	static_assert(sizeof(Bionic_sigaction) == 32, "bionic arm64 struct sigaction");

	enum { NSIG_ = 65, SA_SIGINFO_ = 4, EINVAL_ = 22, ESRCH_ = 3,
	       SIGKILL_ = 9, SIGCHLD_ = 17, SIGCONT_ = 18, SIGSTOP_ = 19,
	       SIGURG_ = 23, SIGWINCH_ = 28 };

	Handler const SIG_DFL_ = (Handler)0;
	Handler const SIG_IGN_ = (Handler)1;

	Genode::Mutex    mutex;
	Bionic_sigaction actions[NSIG_];

	bool valid(int sig) { return sig > 0 && sig < NSIG_; }

	int einval() { set_errno(EINVAL_); return -1; }

	void note_no_delivery()
	{
		static bool logged;
		if (logged) return;
		logged = true;
		Genode::log("android_rt: signal handlers are recorded; only self-sent signals are delivered");
	}
}


extern "C" {

	int art_sigemptyset(Sigset *s) { if (!s) return einval(); *s = 0;  return 0; }
	int art_sigfillset (Sigset *s) { if (!s) return einval(); *s = ~0UL; return 0; }

	int art_sigaddset(Sigset *s, int sig)
	{
		if (!s || !valid(sig)) return einval();
		*s |= 1UL << (sig - 1);
		return 0;
	}

	int art_sigdelset(Sigset *s, int sig)
	{
		if (!s || !valid(sig)) return einval();
		*s &= ~(1UL << (sig - 1));
		return 0;
	}

	int art_sigismember(Sigset const *s, int sig)
	{
		if (!s || !valid(sig)) return einval();
		return (*s >> (sig - 1)) & 1;
	}

	/* nothing is ever delivered asynchronously: masks have no effect */
	int art_sigprocmask(int, Sigset const *, Sigset *old)
	{
		if (old) *old = 0;
		return 0;
	}

	int art_pthread_sigmask(int how, Sigset const *set, Sigset *old)
	{
		art_sigprocmask(how, set, old);
		return 0;                        /* returns the error, not -1/errno */
	}

	int art_sigaction(int sig, Bionic_sigaction const *act, Bionic_sigaction *old)
	{
		if (!valid(sig) || (act && (sig == SIGKILL_ || sig == SIGSTOP_))) return einval();
		Genode::Mutex::Guard guard(mutex);
		if (old) *old = actions[sig];
		if (act) { actions[sig] = *act; note_no_delivery(); }
		return 0;
	}

	Handler art_signal(int sig, Handler h)
	{
		Bionic_sigaction act { }, old { };
		act.sa_handler = h;
		if (art_sigaction(sig, &act, &old) < 0) return (Handler)-1;   /* SIG_ERR */
		return old.sa_handler;
	}

	int art_raise(int sig)
	{
		if (!valid(sig)) return einval();

		Bionic_sigaction a;
		{
			Genode::Mutex::Guard guard(mutex);
			a = actions[sig];
		}
		if (a.sa_handler == SIG_IGN_) return 0;

		if (a.sa_handler == SIG_DFL_) {
			if (sig == SIGCHLD_ || sig == SIGCONT_ || sig == SIGURG_ || sig == SIGWINCH_)
				return 0;                                              /* default: ignore */
			Genode::error("android_rt: terminated by signal ", sig);
			exit_program(128 + sig);
		}

		if (a.sa_flags & SA_SIGINFO_) {
			uint8_t info[128] { };                                     /* siginfo_t */
			memcpy(info, &sig, sizeof(sig));                           /* si_signo */
			a.sa_sigaction(sig, info, nullptr);
		} else
			a.sa_handler(sig);
		return 0;
	}

	/*
	 * bionic reserves the first __SIGRT_RESERVED (10 in LOS 23.2's
	 * bionic/libc/platform/bionic/reserved_signals.h) real-time signals
	 * for itself: SIGRTMIN is 32 + 10. Programs compute their own signals
	 * from it (shared_modem_platform: SIGRTMIN + 4 stops a worker thread).
	 */
	int art___libc_current_sigrtmin() { return 32 + 10; }
	int art___libc_current_sigrtmax() { return NSIG_ - 1; }

	/*
	 * POSIX timers
	 */

	/* bionic LP64 struct sigevent (64 bytes) */
	struct Bionic_sigevent
	{
		uint64_t value;                    /* union sigval */
		int      signo;
		int      notify;                   /* 0 signal, 1 none, 2 thread, 4 thread id */
		void   (*function)(uint64_t);      /* SIGEV_THREAD */
		void    *attributes;
		uint8_t  pad[32];
	};
	static_assert(sizeof(Bionic_sigevent) == 64, "bionic arm64 struct sigevent");

	/* Linux arm64 siginfo_t of a timer signal (128 bytes) */
	struct Timer_siginfo
	{
		int      signo, error, code, pad;
		int      timer_id, overrun;
		uint64_t value;                    /* si_value */
		uint8_t  rest[96];
	};
	static_assert(sizeof(Timer_siginfo) == 128, "siginfo_t");

	enum { SIGEV_SIGNAL_ = 0, SIGEV_NONE_ = 1, SIGEV_THREAD_ = 2, SIGALRM_ = 14, SI_TIMER_ = -2 };

	static pthread_mutex_t timer_mutex = PTHREAD_MUTEX_INITIALIZER;
	static Posix_timers    timers;
	static int             timer_clock[Posix_timers::MAX];   /* Linux clock id per timer */
	static bool            timer_thread_running;
	static pthread_t       timer_thread_self;                /* valid while timer_notifying */
	static int             timer_notifying;                  /* id of the timer being notified, 0: none */

	/*
	 * Wakes the timer thread on a change of the table and the threads in
	 * timer_delete at the end of a notification. Deadlines are
	 * CLOCK_MONOTONIC: the waits need no real-time clock.
	 */
	static pthread_cond_t *timer_cond()
	{
		static pthread_cond_t cond;
		static bool const initialized = [] {
			pthread_condattr_t attr;
			pthread_condattr_init(&attr);
			pthread_condattr_setclock(&attr, CLOCK_MONOTONIC);
			pthread_cond_init(&cond, &attr);
			pthread_condattr_destroy(&attr);
			return true; }();
		(void)initialized;
		return &cond;
	}

	static int64_t clock_ms(clockid_t clock)
	{
		timespec ts { };
		clock_gettime(clock, &ts);
		return int64_t(ts.tv_sec) * 1000 + ts.tv_nsec / 1000000;
	}

	static void timer_notify(Posix_timers::Notify const &n)
	{
		if (n.function) { n.function(n.value); return; }
		if (!valid(n.signo)) return;

		Bionic_sigaction a;
		{
			Genode::Mutex::Guard guard(mutex);
			a = actions[n.signo];
		}
		if (a.sa_handler == SIG_IGN_ || a.sa_handler == SIG_DFL_) {
			Genode::warning("android_rt: timer signal ", n.signo, " without a handler, dropped");
			return;
		}
		if (a.sa_flags & SA_SIGINFO_) {
			Timer_siginfo info { };
			info.signo = n.signo;
			info.code  = SI_TIMER_;
			info.value = n.value;
			a.sa_sigaction(n.signo, &info, nullptr);
		} else
			a.sa_handler(n.signo);
	}

	/* waits for the next expiry (or a change of the table) and notifies */
	static void *timer_thread(void *)
	{
		pthread_mutex_lock(&timer_mutex);
		timer_thread_self = pthread_self();
		for (;;) {
			timespec until { };
			clock_gettime(CLOCK_MONOTONIC, &until);
			int64_t const now = int64_t(until.tv_sec) * 1000 + until.tv_nsec / 1000000;

			Posix_timers::Notify n { };
			int id = 0;
			if (timers.expired(now, n, &id)) {
				timer_notifying = id;
				pthread_mutex_unlock(&timer_mutex);
				timer_notify(n);
				pthread_mutex_lock(&timer_mutex);
				timer_notifying = 0;
				pthread_cond_broadcast(timer_cond());   /* timer_delete may wait for it */
				continue;
			}

			int64_t const wait_ms = timers.next_in(now);
			if (wait_ms < 0) {
				pthread_cond_wait(timer_cond(), &timer_mutex);
				continue;
			}
			until.tv_sec  += wait_ms / 1000;
			until.tv_nsec += (wait_ms % 1000) * 1000000;
			if (until.tv_nsec >= 1000000000) { until.tv_sec++; until.tv_nsec -= 1000000000; }
			pthread_cond_timedwait(timer_cond(), &timer_mutex, &until);
		}
		return nullptr;
	}

	int art_timer_create(int clock, Bionic_sigevent const *sev, void **timer_id)
	{
		if (!timer_id) return einval();

		Posix_timers::Notify n { };
		if (!sev) {
			n.signo = SIGALRM_;
		} else if (sev->notify == SIGEV_THREAD_) {
			if (!sev->function) return einval();
			n.function = sev->function;
			n.value    = sev->value;
		} else if (sev->notify != SIGEV_NONE_) {
			if (!valid(sev->signo)) return einval();
			n.signo = sev->signo;
			n.value = sev->value;
		}

		pthread_mutex_lock(&timer_mutex);
		int const id = timers.create(n);
		if (id) timer_clock[id - 1] = clock;
		bool const start = id && !timer_thread_running;
		if (start) timer_thread_running = true;
		pthread_mutex_unlock(&timer_mutex);

		if (!id) { set_errno(11); return -1; }                         /* EAGAIN */
		if (start) start_thread(timer_thread, nullptr);

		*timer_id = (void *)(long)id;
		return 0;
	}

	int art_timer_settime(void *timer_id, int flags, itimerspec const *value, itimerspec *old)
	{
		enum { TIMER_ABSTIME_ = 1 };
		if (!value) return einval();

		auto ms = [] (timespec const &ts) {
			return int64_t(ts.tv_sec) * 1000 + (ts.tv_nsec + 999999) / 1000000; };

		int const id = int((long)timer_id);

		pthread_mutex_lock(&timer_mutex);

		int64_t value_ms = ms(value->it_value);
		if (value_ms > 0 && (flags & TIMER_ABSTIME_) && id >= 1 && id <= Posix_timers::MAX) {
			/* Linux clock ids: 0 and 5 are the wall clock */
			int const c = timer_clock[id - 1];
			timespec now { };
			if (clock_gettime((c == 0 || c == 5) ? CLOCK_REALTIME : CLOCK_MONOTONIC, &now)) {
				pthread_mutex_unlock(&timer_mutex);
				return einval();                                       /* no real-time clock */
			}
			value_ms -= int64_t(now.tv_sec) * 1000 + now.tv_nsec / 1000000;
			if (value_ms < 1) value_ms = 1;                            /* already due */
		}

		int64_t left = 0;
		bool const ok = timers.set(id, clock_ms(CLOCK_MONOTONIC), value_ms,
		                           ms(value->it_interval), &left);
		pthread_cond_broadcast(timer_cond());
		pthread_mutex_unlock(&timer_mutex);

		if (!ok) return einval();
		if (old) {
			*old = itimerspec { };
			old->it_value.tv_sec  = left / 1000;
			old->it_value.tv_nsec = (left % 1000) * 1000000;
		}
		return 0;
	}

	/*
	 * A notification of the timer that is in flight has ended when this
	 * returns, so the caller may free what its sigev_value points to --
	 * unless the notification itself deletes the timer.
	 */
	int art_timer_delete(void *timer_id)
	{
		int const id = int((long)timer_id);

		pthread_mutex_lock(&timer_mutex);
		bool const ok = timers.destroy(id);
		pthread_cond_broadcast(timer_cond());
		while (ok && timer_notifying == id && !pthread_equal(pthread_self(), timer_thread_self))
			pthread_cond_wait(timer_cond(), &timer_mutex);
		pthread_mutex_unlock(&timer_mutex);
		return ok ? 0 : einval();
	}

	int art_getpid();

	int art_kill(int pid, int sig)
	{
		if (pid != 0 && pid != art_getpid() && pid != -1) {
			set_errno(ESRCH_);                                         /* no other processes */
			return -1;
		}
		if (sig == 0) return 0;                                        /* existence check */
		return art_raise(sig);
	}
}


#define ART(name) { #name, (void *)art_##name }

static Export const exports[] = {
	ART(sigemptyset), ART(sigfillset), ART(sigaddset), ART(sigdelset), ART(sigismember),
	ART(sigprocmask), ART(pthread_sigmask), ART(sigaction), ART(signal), ART(raise),
	ART(kill), ART(__libc_current_sigrtmin), ART(__libc_current_sigrtmax),
	ART(timer_create), ART(timer_settime), ART(timer_delete),
};

#undef ART

Export_group Android_rt::signal_exports() { return { exports, sizeof(exports) / sizeof(exports[0]) }; }
