/*
 * \brief  liblog subset: Android log output to the Genode log
 * \author Ivan Loskutov
 * \date   2026-09-25
 *
 * Includes liblog's API-30 logger interface (default tag, logger and
 * aborter hooks, minimum priority). Vendor code imports it weakly, but
 * libbase calls it unguarded once the SDK level is >= 30 (e.g.
 * android::base::SetDefaultTag -> __android_log_set_default_tag): an
 * unresolved weak import binds to 0 and the call faults at ip 0.
 */

/*
 * SPDX-License-Identifier: MIT
 */

#include <android_rt/runtime.h>
#include <base/log.h>
#include <util/string.h>

#include <stdarg.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>

using namespace Android_rt;

enum { ANDROID_LOG_DEFAULT = 1, ANDROID_LOG_WARN = 5, ANDROID_LOG_ERROR = 6,
       ANDROID_LOG_FATAL = 7 };

static char tag_buf[64];

/* the loader config's log_level: lower priorities are not written */
static int config_floor = 0;

void Android_rt::log_level(int min_priority) { config_floor = min_priority; }


static char const *default_tag()
{
	/* liblog uses the program name when the tag is null */
	if (!tag_buf[0]) {
		char const *p = Android_rt::program_name();
		char const *s = strrchr(p, '/');
		snprintf(tag_buf, sizeof(tag_buf), "%s", s ? s + 1 : p);
	}
	return tag_buf;
}


/* liblog's struct __android_log_message (API 30) */
struct Android_log_message
{
	size_t      struct_size;
	int32_t     buffer_id;
	int32_t     priority;
	char const *tag;
	char const *file;
	uint32_t    line;
	char const *message;
};

typedef void (*Logger)(Android_log_message const *);
typedef void (*Aborter)(char const *);


static int log_message(int prio, char const *tag, char const *msg)
{
	if (prio < config_floor) return 1;

	char const *t = tag ? tag : default_tag();

	/* one log line per message: drop trailing newlines */
	char line[1024];
	snprintf(line, sizeof(line), "%s", msg ? msg : "");
	for (size_t n = strlen(line); n && (line[n - 1] == '\n' || line[n - 1] == '\r'); n--)
		line[n - 1] = 0;
	msg = line;
	if (prio >= ANDROID_LOG_ERROR)     Genode::error  (t, ": ", Genode::Cstring(msg));
	else if (prio == ANDROID_LOG_WARN) Genode::warning(t, ": ", Genode::Cstring(msg));
	else                               Genode::log    (t, ": ", Genode::Cstring(msg));
	return 1;
}


extern "C" {

	/* --- API 30: logger/aborter hooks, default tag, minimum priority --- */

	void art___android_log_logd_logger(Android_log_message const *m)
	{
		if (m) log_message(m->priority, m->tag, m->message);
	}

	[[noreturn]] void art___android_log_default_aborter(char const *msg)
	{
		Genode::error(default_tag(), ": abort: ", Genode::Cstring(msg ? msg : ""));
		flush_stdio();
		::_exit(134);
	}
}

static Logger  logger       = art___android_log_logd_logger;
static Aborter aborter      = art___android_log_default_aborter;
static int32_t minimum_prio = ANDROID_LOG_DEFAULT;

extern "C" {

	void art___android_log_set_logger(Logger l)
	{
		logger = l ? l : art___android_log_logd_logger;
	}

	void art___android_log_write_log_message(Android_log_message *m)
	{
		if (!m) return;
		if (!m->tag) m->tag = default_tag();
		logger(m);
	}

	void art___android_log_set_aborter(Aborter a)
	{
		aborter = a ? a : art___android_log_default_aborter;
	}

	void art___android_log_call_aborter(char const *msg) { aborter(msg); }

	void art___android_log_set_default_tag(char const *tag)
	{
		if (tag) snprintf(tag_buf, sizeof(tag_buf), "%s", tag);
	}

	int32_t art___android_log_set_minimum_priority(int32_t prio)
	{
		int32_t const old = minimum_prio;
		minimum_prio = prio;
		return old;
	}

	int32_t art___android_log_get_minimum_priority() { return minimum_prio; }

	int art___android_log_write(int prio, char const *tag, char const *msg)
	{
		return log_message(prio, tag, msg);
	}

	int art___android_log_vprint(int prio, char const *tag, char const *fmt, va_list ap)
	{
		char buf[1024];
		vsnprintf(buf, sizeof(buf), fmt, ap);
		return log_message(prio, tag, buf);
	}

	int art___android_log_buf_write(int, int prio, char const *tag, char const *msg)
	{
		return log_message(prio, tag, msg);
	}

	int art___android_log_buf_print(int, int prio, char const *tag, char const *fmt, ...)
	{
		va_list ap; va_start(ap, fmt);
		int const r = art___android_log_vprint(prio, tag, fmt, ap);
		va_end(ap);
		return r;
	}

	[[noreturn]] void art___android_log_assert(char const *cond, char const *tag, char const *fmt, ...)
	{
		char buf[512] = "";
		if (fmt) { va_list ap; va_start(ap, fmt); vsnprintf(buf, sizeof(buf), fmt, ap); va_end(ap); }
		Genode::error(tag ? tag : "?", ": assertion failed: ", Genode::Cstring(cond ? cond : ""),
		              " ", Genode::Cstring(buf));
		flush_stdio();
		::_exit(134);
	}

	int art___android_log_error_write(int, char const *, int, char const *, uint32_t) { return 0; }

	/* no per-tag "log.tag.<tag>" properties: a set minimum wins over 'def' */
	int art___android_log_is_loggable(int prio, char const *, int def)
	{
		int const min = minimum_prio != ANDROID_LOG_DEFAULT ? minimum_prio : def;
		return prio >= (min > config_floor ? min : config_floor);
	}

	int art___android_log_is_loggable_len(int prio, char const *tag, size_t, int def)
	{
		return art___android_log_is_loggable(prio, tag, def);
	}

	int art___android_log_print(int prio, char const *tag, char const *fmt, ...)
	{
		va_list ap; va_start(ap, fmt);
		int const r = art___android_log_vprint(prio, tag, fmt, ap);
		va_end(ap);
		return r;
	}
}


static Export const exports[] = {
	{ "__android_log_write",  (void *)art___android_log_write },
	{ "__android_log_vprint", (void *)art___android_log_vprint },
	{ "__android_log_print",  (void *)art___android_log_print },
	{ "__android_log_buf_write",   (void *)art___android_log_buf_write },
	{ "__android_log_buf_print",   (void *)art___android_log_buf_print },
	{ "__android_log_assert",      (void *)art___android_log_assert },
	{ "__android_log_error_write", (void *)art___android_log_error_write },
	{ "__android_log_is_loggable", (void *)art___android_log_is_loggable },
	{ "__android_log_is_loggable_len",      (void *)art___android_log_is_loggable_len },
	{ "__android_log_logd_logger",          (void *)art___android_log_logd_logger },
	{ "__android_log_stderr_logger",        (void *)art___android_log_logd_logger },
	{ "__android_log_default_aborter",      (void *)art___android_log_default_aborter },
	{ "__android_log_set_logger",           (void *)art___android_log_set_logger },
	{ "__android_log_write_log_message",    (void *)art___android_log_write_log_message },
	{ "__android_log_set_aborter",          (void *)art___android_log_set_aborter },
	{ "__android_log_call_aborter",         (void *)art___android_log_call_aborter },
	{ "__android_log_set_default_tag",      (void *)art___android_log_set_default_tag },
	{ "__android_log_set_minimum_priority", (void *)art___android_log_set_minimum_priority },
	{ "__android_log_get_minimum_priority", (void *)art___android_log_get_minimum_priority },
};

Export_group Android_rt::log_exports() { return { exports, sizeof(exports) / sizeof(exports[0]) }; }
