/*
 * \brief  Unwinder of the Android objects
 * \author Ivan Loskutov
 * \date   2026-11-08
 *
 * bionic's libc contains LLVM's libunwind, and the C++ code of the Android
 * objects imports its _Unwind_* functions from there. These are the Itanium
 * C++ ABI, which the unwinder of GCC implements as well: the runtime exports
 * the one of the tool chain's libgcc_eh, linked into the loader with renamed
 * functions (Makefile).
 */

/*
 * SPDX-License-Identifier: MIT
 */

#include <android_rt/runtime.h>
#include <base/mutex.h>

#include <link.h>

using namespace Android_rt;

using Phdr_callback = int (*)(dl_phdr_info *, size_t, void *);

/* the Android objects (sym_dl.cc), bionic's struct dl_phdr_info */
extern "C" int art_dl_iterate_phdr(Phdr_callback, void *);

/*
 * dl_iterate_phdr of the unwinder: the Android objects, then those of
 * Genode, the loader among them. The unwinder runs in the loader's code and
 * starts with unwinding its own frames. The walks are serialized as by the
 * dynamic linker of Linux, the unwinder updates its cache of the frame
 * tables in the callback.
 */
extern "C" int art_unwind_iterate_phdr(Phdr_callback cb, void *data)
{
	static Genode::Mutex mutex;
	Genode::Mutex::Guard guard(mutex);

	if (int const r = art_dl_iterate_phdr(cb, data)) return r;
	return dl_iterate_phdr(cb, data);
}

/* only their addresses are taken */
#define UNWIND_FN(fn) extern "C" void android_unwind_##fn();

UNWIND_FN(RaiseException)
UNWIND_FN(Resume)
UNWIND_FN(DeleteException)
UNWIND_FN(GetIP)
UNWIND_FN(GetIPInfo)
UNWIND_FN(GetLanguageSpecificData)
UNWIND_FN(GetRegionStart)
UNWIND_FN(SetGR)
UNWIND_FN(SetIP)
UNWIND_FN(GetDataRelBase)
UNWIND_FN(GetTextRelBase)

#undef UNWIND_FN

#define UNWIND(fn) { "_Unwind_" #fn, (void *)android_unwind_##fn }

static Export const exports[] = {
	UNWIND(RaiseException),
	UNWIND(Resume),
	UNWIND(DeleteException),
	UNWIND(GetIP),
	UNWIND(GetIPInfo),
	UNWIND(GetLanguageSpecificData),
	UNWIND(GetRegionStart),
	UNWIND(SetGR),
	UNWIND(SetIP),
	UNWIND(GetDataRelBase),
	UNWIND(GetTextRelBase),
};

#undef UNWIND

Export_group Android_rt::unwind_exports() { return { exports, sizeof(exports) / sizeof(exports[0]) }; }
