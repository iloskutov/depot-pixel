/*
 * \brief  bionic directories and a shell-less system()
 * \author Ivan Loskutov
 * \date   2026-09-25
 */

/*
 * SPDX-License-Identifier: MIT
 */

#include <android_rt/runtime.h>
#include <base/log.h>
#include <util/string.h>

#include <dirent.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

using namespace Android_rt;

namespace {

	/* bionic's struct dirent (d_name at offset 19) */
	struct Bionic_dirent
	{
		uint64_t d_ino;
		int64_t  d_off;
		uint16_t d_reclen;
		uint8_t  d_type;
		char     d_name[256];
	} __attribute__((packed));

	struct Art_dir { DIR *genode; Bionic_dirent ent; };
}


extern "C" {

	void *art_opendir(char const *path)
	{
		DIR *g = opendir(path);
		if (!g) { set_errno_from_libc(); return nullptr; }
		Art_dir *d = (Art_dir *)calloc(1, sizeof(Art_dir));
		d->genode = g;
		return d;
	}

	void *art_readdir(void *dir)
	{
		Art_dir *d = (Art_dir *)dir;
		dirent *e = readdir(d->genode);
		if (!e) return nullptr;
		d->ent.d_ino    = e->d_fileno;
		d->ent.d_off    = 0;
		d->ent.d_reclen = sizeof(Bionic_dirent);
		d->ent.d_type   = e->d_type;              /* DT_* values are identical */
		snprintf(d->ent.d_name, sizeof(d->ent.d_name), "%s", e->d_name);
		return &d->ent;
	}

	int art_closedir(void *dir)
	{
		Art_dir *d = (Art_dir *)dir;
		int const r = closedir(d->genode);
		free(d);
		return r;
	}

	int art_system(char const *cmd)
	{
		Genode::warning("system: no shell -- '", Genode::Cstring(cmd ? cmd : ""),
		                "' not run (a profile may provide command shapes)");
		return 127 << 8;
	}
}


static Export const exports[] = {
	{ "opendir",  (void *)art_opendir },
	{ "readdir",  (void *)art_readdir },
	{ "closedir", (void *)art_closedir },
	{ "system",   (void *)art_system },
};

Export_group Android_rt::system_exports() { return { exports, sizeof(exports) / sizeof(exports[0]) }; }
