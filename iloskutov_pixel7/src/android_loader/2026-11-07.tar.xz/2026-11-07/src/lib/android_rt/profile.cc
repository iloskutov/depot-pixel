/*
 * \brief  Profile libraries: loading, the override table, ioctl payload hooks
 * \author Ivan Loskutov
 * \date   2026-09-26
 */

/*
 * SPDX-License-Identifier: MIT
 */

#include <android_rt/runtime.h>
#include <android_rt/profile.h>
#include <base/log.h>
#include <base/shared_object.h>
#include <rom_session/client.h>
#include <try_connection.h>
#include <util/reconstructible.h>
#include <util/string.h>

#include <string.h>

using namespace Android_rt;

extern "C" int art___system_property_get(char const *name, char *value);

namespace {

	enum { MAX_OVERRIDES = 64, MAX_PAYLOAD_HOOKS = 8, NAME_LEN = 96, PROP_VALUE_MAX = 92 };

	struct Override     { char name[NAME_LEN]; void *fn; };
	struct Payload_hook { unsigned long cmd; Ioctl_payload_fn fn; };

	Override        override_table[MAX_OVERRIDES];
	unsigned        override_count;
	Payload_hook    payload_hooks[MAX_PAYLOAD_HOOKS];
	unsigned        payload_hook_count;
	Profile_config *profile_config;

	/*
	 * Set once android_profile_init() returned: the override table is read
	 * lock-free by Overrides::find while linking and on later dlopen()s, so
	 * it must not change any more.
	 */
	bool overrides_sealed;

	Genode::Constructible<Genode::Shared_object> profile_lib;

	void api_log(char const *msg) { Genode::log(Genode::Cstring(msg)); }

	int api_config_attr(char const *name, char *buf, unsigned len)
	{
		return profile_config ? profile_config->attr(name, buf, len) : -1;
	}

	void api_set_errno(int e) { set_errno(e); }

	int api_override(char const *symbol, void *fn)
	{
		if (overrides_sealed) {
			Genode::error("android_rt: profile override of '",
			              Genode::Cstring(symbol ? symbol : "(null)"),
			              "' after android_profile_init returned -- ignored");
			return -1;
		}
		if (!symbol || !fn || strlen(symbol) >= NAME_LEN) return -1;
		if (override_count == MAX_OVERRIDES) {
			Genode::error("android_rt: profile override table full");
			return -1;
		}
		Genode::copy_cstring(override_table[override_count].name, symbol, NAME_LEN);
		override_table[override_count].fn = fn;
		override_count++;
		return 0;
	}

	int api_property_get(char const *name, char *buf, unsigned len)
	{
		char value[PROP_VALUE_MAX] { };
		int const n = art___system_property_get(name, value);
		if (n <= 0 || !len) return -1;
		Genode::copy_cstring(buf, value, len);
		return int(strlen(buf));
	}

	int api_ioctl_payload(unsigned long cmd, Ioctl_payload_fn fn)
	{
		if (overrides_sealed) {
			Genode::error("android_rt: ioctl_payload registration for ",
			              Genode::Hex(cmd), " after android_profile_init "
			              "returned -- ignored");
			return -1;
		}
		if (!fn) return -1;
		if (payload_hook_count == MAX_PAYLOAD_HOOKS) {
			Genode::error("android_rt: ioctl_payload hook table full");
			return -1;
		}
		payload_hooks[payload_hook_count].cmd = cmd;
		payload_hooks[payload_hook_count].fn  = fn;
		payload_hook_count++;
		return 0;
	}

	Android_profile_api const api {
		ANDROID_PROFILE_API_MAJOR, ANDROID_PROFILE_API_MINOR, sizeof(Android_profile_api),
		api_log, api_config_attr, api_set_errno, api_override, api_property_get,
		api_ioctl_payload };
}


void *Android_rt::profile_override(char const *name)
{
	for (unsigned i = 0; i < override_count; i++)
		if (!strcmp(override_table[i].name, name)) return override_table[i].fn;
	return nullptr;
}


Android_rt::Ioctl_payload_fn Android_rt::ioctl_payload_hook(unsigned long cmd)
{
	for (unsigned i = 0; i < payload_hook_count; i++)
		if (payload_hooks[i].cmd == cmd) return payload_hooks[i].fn;
	return nullptr;
}


bool Android_rt::load_profile(Genode::Env &env, Genode::Allocator &alloc,
                              char const *lib, Profile_config &config)
{
	profile_config = &config;

	/*
	 * Env::session() sleeps forever when the parent denies a session
	 * (base/src/lib/base/component.cc) -- probe the same ROM label first so
	 * a missing profile stops the loader instead of hanging it.
	 */
	{
		using Probe = Genode_pixel::Try_connection<Genode::Rom_session, Genode::Rom_session_client>;
		Probe probe(env);
		if (probe.open(lib) != Probe::Result::OK) {
			Genode::error("android_loader: cannot load profile '", Genode::Cstring(lib),
			              "' (no ROM module)");
			return false;
		}
	}

	using Init = int (*)(Android_profile_api const *);
	Init init = nullptr;
	try {
		profile_lib.construct(env, alloc, lib, Genode::Shared_object::BIND_NOW,
		                      Genode::Shared_object::KEEP);
		init = profile_lib->lookup<Init>("android_profile_init");
	} catch (...) { }

	if (!init) {
		Genode::error("android_loader: cannot load profile '", Genode::Cstring(lib),
		              "' (missing ROM or no android_profile_init)");
		return false;
	}
	int const r = init(&api);
	overrides_sealed = true;
	if (r) {
		Genode::error("android_loader: profile '", Genode::Cstring(lib), "' rejected the runtime (", r, ")");
		return false;
	}
	Genode::log("android_loader: profile ", Genode::Cstring(lib), " (", override_count, " overrides)");
	return true;
}
