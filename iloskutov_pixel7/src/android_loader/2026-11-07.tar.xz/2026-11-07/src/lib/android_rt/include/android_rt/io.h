/*
 * \brief  Runtime-wide io condition and readiness signals
 * \author Ivan Loskutov
 * \date   2026-09-26
 *
 * Every readiness change of a runtime descriptor (pipe, eventfd, chardev
 * session signal) bumps one generation counter and wakes all waiters.
 * Waiters snapshot the generation BEFORE checking readiness, so a change in
 * between is never lost. Chardev readiness signals arrive at the io thread
 * through a Signal_receiver (contexts can be managed from any thread).
 */

/*
 * SPDX-License-Identifier: MIT
 */

#ifndef _ANDROID_RT__IO_H_
#define _ANDROID_RT__IO_H_

#include <base/env.h>
#include <base/signal.h>

namespace Android_rt {

	/**
	 * Genode environment (valid after init_genode)
	 */
	Genode::Env &env();

	unsigned io_generation();

	/**
	 * Readiness may have changed: wake all waiters
	 */
	void io_notify();

	/**
	 * Wait until the generation differs from 'seen'
	 *
	 * \param timeout_ms  -1 forever, 0 no wait
	 * \return true if the generation changed
	 */
	bool io_wait(unsigned seen, int timeout_ms);

	/**
	 * Monotonic milliseconds
	 */
	long io_now_ms();

	/**
	 * Readiness signal of one chardev session
	 */
	struct Io_signal : Genode::Signal_context
	{
		unsigned stale = 1;   /* set by the io thread, cleared by the reader */
	};

	Genode::Signal_context_capability io_manage(Io_signal &);
	void io_dissolve(Io_signal &);

	/**
	 * \return true if 'stale' was set (and clear it)
	 */
	inline bool io_take_stale(Io_signal &s)
	{
		return __atomic_exchange_n(&s.stale, 0u, __ATOMIC_ACQ_REL) != 0;
	}
}

#endif /* _ANDROID_RT__IO_H_ */
