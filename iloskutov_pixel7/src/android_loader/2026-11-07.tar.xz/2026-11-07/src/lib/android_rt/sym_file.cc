/*
 * \brief  bionic file, environment and process functions
 * \author Ivan Loskutov
 * \date   2026-09-25
 *
 * File descriptors are Genode libc descriptors on the component's VFS;
 * flags, struct stat and errno are converted to/from the Linux ABI.
 */

/*
 * SPDX-License-Identifier: MIT
 */

#include <android_rt/runtime.h>
#include <android_rt/linux_abi.h>
#include <android_rt/dev.h>
#include <android_rt/io.h>
#include <android_rt/full_read.h>
#include <base/log.h>
#include <util/string.h>

#include <dirent.h>
#include <errno.h>
#include <fcntl.h>
#include <poll.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <time.h>
#include <unistd.h>
#include <wchar.h>

using namespace Android_rt;

namespace {

	enum { MAX_ENV = 128 };

	char *env_storage[MAX_ENV + 1];
}

extern "C" { char **art_environ = env_storage; }


void Android_rt::set_environment(char const * const *envp)
{
	unsigned n = 0;
	for (; envp && envp[n] && n < MAX_ENV; n++) env_storage[n] = strdup(envp[n]);
	env_storage[n] = nullptr;
}


static int genode_open_flags(int l)
{
	int f = l & Linux::OPEN_ACCMODE;
	if (l & Linux::OPEN_CREAT)     f |= O_CREAT;
	if (l & Linux::OPEN_EXCL)      f |= O_EXCL;
	if (l & Linux::OPEN_NOCTTY)    f |= O_NOCTTY;
	if (l & Linux::OPEN_TRUNC)     f |= O_TRUNC;
	if (l & Linux::OPEN_APPEND)    f |= O_APPEND;
	if (l & Linux::OPEN_NONBLOCK)  f |= O_NONBLOCK;
	if (l & Linux::OPEN_DIRECTORY) f |= O_DIRECTORY;
	if (l & Linux::OPEN_NOFOLLOW)  f |= O_NOFOLLOW;
	if (l & Linux::OPEN_CLOEXEC)   f |= O_CLOEXEC;
	return f;
}


static void to_linux(struct stat const &g, Linux::Stat &l)
{
	memset(&l, 0, sizeof(l));
	l.st_dev = g.st_dev; l.st_ino = g.st_ino; l.st_mode = g.st_mode;
	l.st_nlink = uint32_t(g.st_nlink); l.st_uid = g.st_uid; l.st_gid = g.st_gid;
	l.st_rdev = g.st_rdev; l.st_size = g.st_size; l.st_blksize = int32_t(g.st_blksize);
	l.st_blocks = g.st_blocks;
	l.st_atime_sec = g.st_atim.tv_sec; l.st_atime_nsec = g.st_atim.tv_nsec;
	l.st_mtime_sec = g.st_mtim.tv_sec; l.st_mtime_nsec = g.st_mtim.tv_nsec;
	l.st_ctime_sec = g.st_ctim.tv_sec; l.st_ctime_nsec = g.st_ctim.tv_nsec;
}


template <typename T> static T check(T r) { if (r < 0) set_errno_from_libc(); return r; }


extern "C" {

	int art_open(char const *path, int flags, ...)
	{
		mode_t mode = 0;
		if (flags & Linux::OPEN_CREAT) { va_list ap; va_start(ap, flags); mode = mode_t(va_arg(ap, int)); va_end(ap); }
		int const dev = dev_open(path, flags);
		if (dev != -2) return dev;
		return check(open(path, genode_open_flags(flags), mode));
	}

	int art___open_2(char const *path, int flags) { return art_open(path, flags); }

	int art_close(int fd)
	{
		if (is_dev_fd(fd)) return dev_close(fd);
		dev_forget_fd(fd);   /* out of the epoll sets, like Linux */
		return check(close(fd));
	}

	/* a short read of a regular file continues like Linux (full_read.h) */
	bool regular_file(int fd)
	{
		struct stat st { };
		return fstat(fd, &st) == 0 && S_ISREG(st.st_mode);
	}

	ssize_t art_read(int fd, void *b, size_t n)
	{
		if (is_dev_fd(fd)) return dev_read(fd, b, n);
		ssize_t const first = read(fd, b, n);
		if (first <= 0 || size_t(first) == n || !regular_file(fd))
			return check(first);
		return read_full(first, n, [&] (unsigned long done) -> long {
			return read(fd, (char *)b + done, n - done); });
	}

	ssize_t art_write(int fd, void const *b, size_t n)
	{
		return is_dev_fd(fd) ? dev_write(fd, b, n) : check(write(fd, b, n));
	}

	ssize_t art_pread(int fd, void *b, size_t n, off_t o)
	{
		if (is_dev_fd(fd)) { set_errno(29); return -1; }       /* ESPIPE */
		ssize_t const first = pread(fd, b, n, o);
		if (first <= 0 || size_t(first) == n || !regular_file(fd))
			return check(first);
		return read_full(first, n, [&] (unsigned long done) -> long {
			return pread(fd, (char *)b + done, n - done, o + off_t(done)); });
	}

	ssize_t art_pwrite(int fd, void const *b, size_t n, off_t o)
	{
		if (is_dev_fd(fd)) { set_errno(29); return -1; }       /* ESPIPE */
		return check(pwrite(fd, b, n, o));
	}

	off_t art_lseek(int fd, off_t o, int w)
	{
		if (is_dev_fd(fd)) { set_errno(29); return -1; }
		return check(lseek(fd, o, w));
	}

	int art_ioctl(int fd, unsigned long cmd, void *arg)
	{
		cmd = uint32_t(cmd);   /* bionic's request is an int: the upper half is undefined */
		if (is_dev_fd(fd)) return dev_ioctl(fd, cmd, arg);
		Genode::warning("android_rt: ioctl(", fd, ", ", Genode::Hex(cmd), ") on a VFS file");
		set_errno(25);                                         /* ENOTTY */
		return -1;
	}

	/* Linux struct pollfd == FreeBSD's; POLLIN 1, POLLOUT 4 on both */
	int art_poll(pollfd *pfd, unsigned long n, int timeout_ms)
	{
		/*
		 * 'io_now_ms()' opens the process' Genode Timer connection on first
		 * use, so it must stay untouched on the common path where readiness
		 * resolves without ever waiting -- callers that never pass a
		 * positive timeout must not gain a Timer dependency.
		 */
		long start = 0;
		bool have_start = false;
		Chardev_slice slice { };

		for (;;) {
			unsigned const gen = io_generation();
			int  ready = 0;
			bool vfs_fds = false, chardevs = false;
			for (unsigned long i = 0; i < n; i++) {
				pfd[i].revents = 0;
				if (pfd[i].fd < 0) continue;
				if (is_dev_fd(pfd[i].fd)) {
					bool c = false;
					unsigned const r = dev_ready(pfd[i].fd, slice.probe, c);
					chardevs |= c;
					if ((pfd[i].events & POLLIN)  && (r & 1)) pfd[i].revents |= POLLIN;
					if ((pfd[i].events & POLLOUT) && (r & 2)) pfd[i].revents |= POLLOUT;
					if (r & 4) pfd[i].revents |= POLLHUP;
					if (r & 8) pfd[i].revents |= POLLNVAL;
				} else {
					vfs_fds = true;
					pollfd one = pfd[i];
					if (::poll(&one, 1, 0) > 0) pfd[i].revents = one.revents;
				}
				if (pfd[i].revents) ready++;
			}
			slice.probe = false;
			if (ready || timeout_ms == 0) return ready;

			int wait = -1;
			if (timeout_ms > 0) {
				if (!have_start) { start = io_now_ms(); have_start = true; }
				long const left = timeout_ms - (io_now_ms() - start);
				if (left <= 0) return 0;
				wait = int(left);
			}
			if (vfs_fds && (wait < 0 || wait > 10)) wait = 10;
			wait = slice.cap(chardevs, wait);
			slice.waited(chardevs, io_wait(gen, wait), wait);
		}
	}

	int art_chdir(char const *p) { return check(chdir(p)); }

	char *art_getcwd(char *buf, size_t size)
	{
		char *r = getcwd(buf, size);
		if (!r) set_errno_from_libc();
		return r;
	}

	ssize_t art_readlink(char const *p, char *buf, size_t n) { return check(readlink(p, buf, n)); }

	char *art_realpath(char const *p, char *resolved)
	{
		char *r = realpath(p, resolved);
		if (!r) set_errno_from_libc();
		return r;
	}

	int art_rename(char const *a, char const *b) { return check(rename(a, b)); }
	int art_remove(char const *p)                { return check(remove(p)); }
	int art_fsync(int fd)                        { return is_dev_fd(fd) ? 0 : check(fsync(fd)); }
	int art_ftruncate(int fd, off_t len)         { return check(ftruncate(fd, len)); }

	/*
	 * Genode's VFS keeps no permission bits and its libc answers chmod
	 * with ENOSYS; like chown, a mode change of an existing file succeeds
	 * as a no-op (rfsd "protects" nv_protected.bin with chmod and logs
	 * an error on failure). A missing file still fails.
	 */
	int art_chmod(char const *p, mode_t)
	{
		struct stat st { };
		return check(stat(p, &st));
	}

	int art_fchmod(int fd, mode_t)
	{
		struct stat st { };
		return is_dev_fd(fd) ? 0 : check(fstat(fd, &st));
	}

	int art_chown(char const *, unsigned, unsigned) { return 0; }
	int art_fchown(int, unsigned, unsigned)         { return 0; }

	int art_fcntl(int fd, int cmd, ...)
	{
		enum { F_GETFD_ = 1, F_SETFD_ = 2, F_GETFL_ = 3, F_SETFL_ = 4 };
		va_list ap; va_start(ap, cmd); long const arg = va_arg(ap, long); va_end(ap);
		if (fd < 0) { set_errno(9); return -1; }                               /* EBADF, as Linux */
		if (cmd == F_GETFL_ && is_dev_fd(fd)) return dev_flags(fd);
		if (cmd == F_SETFL_ && is_dev_fd(fd)) return dev_set_flags(fd, int(arg));
		if (cmd == F_GETFD_ || cmd == F_SETFD_) return 0;

		/* VFS descriptors: O_NONBLOCK and O_APPEND reach the libc */
		if (cmd == F_SETFL_) return check(fcntl(fd, F_SETFL, genode_open_flags(int(arg))));
		if (cmd == F_GETFL_) {
			int const f = fcntl(fd, F_GETFL);
			if (f < 0) return check(f);
			return (f & Linux::OPEN_ACCMODE) | ((f & O_NONBLOCK) ? Linux::OPEN_NONBLOCK : 0)
			                                 | ((f & O_APPEND)   ? Linux::OPEN_APPEND   : 0);
		}

		/*
		 * Record locks (sqlite): this process is the only user of its files,
		 * so every lock is granted and F_GETLK reports none. Linux arm64
		 * struct flock starts with 'short l_type'; F_UNLCK = 2.
		 */
		enum { F_GETLK_ = 5, F_SETLK_ = 6, F_SETLKW_ = 7, F_UNLCK_ = 2 };
		if (cmd == F_SETLK_ || cmd == F_SETLKW_) return 0;
		if (cmd == F_GETLK_) { *(short *)arg = F_UNLCK_; return 0; }
		Genode::warning("android_rt: fcntl(", fd, ", ", cmd, ") unsupported");
		set_errno(22);
		return -1;
	}

	int art_stat (char const *, Linux::Stat *);
	int art_lstat(char const *, Linux::Stat *);
	int art_mkdir(char const *, mode_t);

	/* Linux arm64 struct epoll_event: u32 events, 4 bytes padding, u64 data */
	struct Linux_epoll_event { uint32_t events; uint32_t pad; uint64_t data; };

	int art_eventfd(unsigned initval, int flags) { return dev_eventfd(initval, flags); }
	int art_pipe2(int fds[2], int flags)         { return dev_pipe(fds, flags); }
	int art_pipe(int fds[2])                     { return dev_pipe(fds, 0); }
	int art_epoll_create1(int)                   { return dev_epoll_create(); }
	int art_epoll_create(int)                    { return dev_epoll_create(); }

	int art_epoll_ctl(int ep, int op, int fd, Linux_epoll_event *ev)
	{
		return dev_epoll_ctl(ep, op, fd, ev ? ev->events : 0, ev ? ev->data : 0);
	}

	int art_epoll_wait(int ep, Linux_epoll_event *ev, int max, int timeout_ms)
	{
		enum { MAX = 16 };
		if (max <= 0) { set_errno(22); return -1; }                            /* EINVAL, as Linux */
		uint32_t e[MAX]; uint64_t d[MAX];
		int const n = dev_epoll_wait(ep, e, d, max < MAX ? max : MAX, timeout_ms);
		for (int i = 0; i < n; i++) { ev[i].events = e[i]; ev[i].pad = 0; ev[i].data = d[i]; }
		return n;
	}

	int art_epoll_pwait(int ep, Linux_epoll_event *ev, int max, int timeout_ms, void const *)
	{
		return art_epoll_wait(ep, ev, max, timeout_ms);
	}

	/* select() on Linux' 1024-bit fd_set, built on poll() */
	int art_select(int nfds, unsigned long *rd, unsigned long *wr, unsigned long *ex, timeval *tv)
	{
		long long const tv_ms = tv ? (long long)tv->tv_sec * 1000 + tv->tv_usec / 1000 : -1;
		int const timeout_ms = tv_ms > 0x7fffffff ? 0x7fffffff : int(tv_ms);

		/*
		 * 'io_now_ms()' opens the process' Genode Timer connection on first
		 * use, so it must stay untouched on the common path where readiness
		 * resolves without ever waiting -- callers that never pass a
		 * positive timeout must not gain a Timer dependency.
		 */
		long start = 0;
		bool have_start = false;
		Chardev_slice slice { };

		for (;;) {
			unsigned const gen = io_generation();
			int  ready    = 0;
			bool vfs_fds  = false;
			bool chardevs = false;
			unsigned long r_out[16] = { }, w_out[16] = { };
			for (int fd = 0; fd < nfds && fd < 1024; fd++) {
				bool const want_r = rd && ((rd[fd / 64] >> (fd % 64)) & 1);
				bool const want_w = wr && ((wr[fd / 64] >> (fd % 64)) & 1);
				if (!want_r && !want_w) continue;
				unsigned r;
				if (is_dev_fd(fd)) {
					bool c = false;
					r = dev_ready(fd, slice.probe, c);
					chardevs |= c;
				} else {
					vfs_fds = true;
					pollfd p { fd, short((want_r ? POLLIN : 0) | (want_w ? POLLOUT : 0)), 0 };
					r = (::poll(&p, 1, 0) > 0) ? (((p.revents & POLLIN) ? 1u : 0u) | ((p.revents & POLLOUT) ? 2u : 0u)) : 0u;
				}
				if (want_r && (r & 5)) { r_out[fd / 64] |= 1ul << (fd % 64); ready++; }   /* hang-up reads as readable */
				if (want_w && (r & 2)) { w_out[fd / 64] |= 1ul << (fd % 64); ready++; }
			}

			slice.probe = false;

			int  wait    = -1;
			bool expired = timeout_ms == 0;
			if (!ready && !expired && timeout_ms > 0) {
				if (!have_start) { start = io_now_ms(); have_start = true; }
				long const left = timeout_ms - (io_now_ms() - start);
				expired = left <= 0;
				wait = int(left);
			}
			if (ready || expired) {
				if (rd) memcpy(rd, r_out, 128);
				if (wr) memcpy(wr, w_out, 128);
				if (ex) memset(ex, 0, 128);
				return ready;
			}
			if (vfs_fds && (wait < 0 || wait > 10)) wait = 10;
			wait = slice.cap(chardevs, wait);
			slice.waited(chardevs, io_wait(gen, wait), wait);
		}
	}

	/*
	 * Mappings are heap blocks of whole pages: 'munmap' of exactly one of
	 * them (lengths rounded up to pages, as Linux does) frees it, anything
	 * else (a part of one, as allocators trim) would corrupt the heap and
	 * is refused
	 */
	static size_t page_round(size_t len) { return (len + 4095) & ~size_t(4095); }

	enum { MAX_MAPPINGS = 256 };
	struct Mapping { void *p; size_t len; } mappings[MAX_MAPPINGS];
	Genode::Mutex mappings_mutex;

	static bool remember_mapping(void *p, size_t len)
	{
		Genode::Mutex::Guard guard(mappings_mutex);
		for (Mapping &m : mappings)
			if (!m.p) { m = { p, len }; return true; }
		return false;
	}

	/* true if (p, len) was one mapping, which is forgotten */
	static bool forget_mapping(void *p, size_t len)
	{
		Genode::Mutex::Guard guard(mappings_mutex);
		for (Mapping &m : mappings)
			if (m.p == p && m.len == len) { m = { }; return true; }
		return false;
	}

	/*
	 * mmap: Linux MAP_SHARED 1, MAP_PRIVATE 2, MAP_FIXED 0x10, MAP_ANONYMOUS 0x20,
	 * PROT_WRITE 2. A file is mapped as a private copy, so a shared writeable
	 * mapping of one, whose writes would be lost, is refused.
	 */
	void *art_mmap(void *addr, size_t len, int prot, int flags, int fd, off_t off)
	{
		if ((flags & 0x10) || addr) {
			Genode::warning("android_rt: mmap at a fixed address unsupported");
			set_errno(22);
			return (void *)-1;
		}
		size_t const size = page_round(len);
		if (!len || size < len) { set_errno(22); return (void *)-1; }           /* EINVAL */

		bool const file = !(flags & 0x20);
		if (file && is_dev_fd(fd)) { set_errno(19); return (void *)-1; }        /* ENODEV */
		if (file && (flags & 1) && (prot & 2)) {
			Genode::warning("android_rt: writeable MAP_SHARED of fd ", fd, " unsupported");
			set_errno(19);                                                     /* ENODEV */
			return (void *)-1;
		}

		void *p = nullptr;
		if (posix_memalign(&p, 4096, size)) { set_errno(12); return (void *)-1; }
		if (!remember_mapping(p, size)) { free(p); set_errno(12); return (void *)-1; }
		memset(p, 0, size);
		if (file) {                                  /* private copy */
			size_t done = 0;
			while (done < len) {
				ssize_t const n = pread(fd, (char *)p + done, len - done, off + off_t(done));
				if (n <= 0) break;
				done += size_t(n);
			}
			if (flags & 1)
				Genode::warning("android_rt: MAP_SHARED of fd ", fd, " is a private copy");
		}
		return p;
	}

	int art_munmap(void *p, size_t len)
	{
		if (forget_mapping(p, page_round(len))) { free(p); return 0; }
		Genode::warning("android_rt: munmap(", p, ", ", len, ") is not a whole mapping -- kept");
		return 0;
	}
	int art_madvise(void *, size_t, int) { return 0; }
	int art_mprotect(void *, size_t, int) { return 0; }

	struct Iovec { void *base; size_t len; };

	ssize_t art_writev(int fd, Iovec const *iov, int n)
	{
		ssize_t total = 0;
		for (int i = 0; i < n; i++) {
			ssize_t const w = art_write(fd, iov[i].base, iov[i].len);
			if (w < 0) return total ? total : w;
			total += w;
		}
		return total;
	}

	int art_dup2(int a, int b)
	{
		if (is_dev_fd(a) || is_dev_fd(b)) { set_errno(22); return -1; }
		return check(dup2(a, b));
	}

	/* *at variants: only AT_FDCWD (-100 on Linux and FreeBSD) */
	int art_openat(int dirfd, char const *path, int flags, ...)
	{
		mode_t mode = 0;
		if (flags & Linux::OPEN_CREAT) { va_list ap; va_start(ap, flags); mode = mode_t(va_arg(ap, int)); va_end(ap); }
		if (dirfd != -100 && path[0] != '/') { set_errno(22); return -1; }
		return art_open(path, flags, mode);
	}

	int art_fstatat(int dirfd, char const *path, Linux::Stat *st, int flags)
	{
		if (dirfd != -100 && path[0] != '/') { set_errno(22); return -1; }
		return (flags & 0x100) ? art_lstat(path, st) : art_stat(path, st);   /* AT_SYMLINK_NOFOLLOW */
	}

	int art_mkdirat(int dirfd, char const *path, mode_t m)
	{
		if (dirfd != -100 && path[0] != '/') { set_errno(22); return -1; }
		return art_mkdir(path, m);
	}

	int art_dup(int fd)
	{
		if (is_dev_fd(fd)) { set_errno(22); return -1; }
		return check(dup(fd));
	}
	int     art_access(char const *p, int m)           { return check(access(p, m)); }
	int     art_unlink(char const *p)                  { return check(unlink(p)); }
	int     art_mkdir(char const *p, mode_t m)         { return check(mkdir(p, m)); }
	int     art_rmdir(char const *p)                   { return check(rmdir(p)); }
	int     art_isatty(int)                            { return 0; }

	int art_stat(char const *path, Linux::Stat *l)
	{
		struct stat g;
		if (check(stat(path, &g)) < 0) return -1;
		to_linux(g, *l);
		return 0;
	}

	int art_lstat(char const *path, Linux::Stat *l)
	{
		struct stat g;
		if (check(lstat(path, &g)) < 0) return -1;
		to_linux(g, *l);
		return 0;
	}

	int art_fstat(int fd, Linux::Stat *l)
	{
		if (is_dev_fd(fd)) {
			memset(l, 0, sizeof(*l));
			l->st_mode = 0020666;                                  /* char device */
			return 0;
		}
		struct stat g;
		if (check(fstat(fd, &g)) < 0) return -1;
		to_linux(g, *l);
		return 0;
	}

	/* environment */

	char *art_getenv(char const *name)
	{
		size_t const n = strlen(name);
		for (char **e = art_environ; e && *e; e++)
			if (!strncmp(*e, name, n) && (*e)[n] == '=') return *e + n + 1;
		return nullptr;
	}

	int art_setenv(char const *name, char const *value, int overwrite)
	{
		size_t const n = strlen(name);
		unsigned i = 0;
		for (; art_environ[i]; i++)
			if (!strncmp(art_environ[i], name, n) && art_environ[i][n] == '=') {
				if (!overwrite) return 0;
				break;
			}
		if (i >= MAX_ENV) { set_errno(12); return -1; }
		char *entry = (char *)malloc(n + strlen(value) + 2);
		strcpy(entry, name); entry[n] = '='; strcpy(entry + n + 1, value);
		bool const append = !art_environ[i];
		art_environ[i] = entry;
		if (append) art_environ[i + 1] = nullptr;
		return 0;
	}

	int art_unsetenv(char const *name)
	{
		size_t const n = strlen(name);
		for (unsigned i = 0; art_environ[i]; i++)
			if (!strncmp(art_environ[i], name, n) && art_environ[i][n] == '=') {
				for (unsigned k = i; art_environ[k]; k++) art_environ[k] = art_environ[k + 1];
				return 0;
			}
		return 0;
	}

	/* process */

	int  art_getpid()  { return 1000; }
	int  art_getppid() { return 1; }
	unsigned art_getuid()  { return 1001; }   /* AID_RADIO */
	unsigned art_geteuid() { return 1001; }
	unsigned art_getgid()  { return 1001; }
	unsigned art_getegid() { return 1001; }

	long art_sysconf(int name)
	{
		enum { SC_PAGESIZE = 0x0028, SC_PAGE_SIZE = 0x0027,
		       SC_NPROCESSORS_CONF = 0x0060, SC_NPROCESSORS_ONLN = 0x0061 };
		switch (name) {
		case SC_PAGESIZE: case SC_PAGE_SIZE: return 4096;
		case SC_NPROCESSORS_CONF: case SC_NPROCESSORS_ONLN: return 1;
		}
		Genode::warning("android_rt: sysconf(", Genode::Hex(name), ") unsupported");
		set_errno(22);
		return -1;
	}

	int art_getpagesize() { return 4096; }

	unsigned long art_getauxval(unsigned long type)
	{
		enum { AT_PAGESZ = 6, AT_HWCAP = 16, AT_RANDOM = 25, AT_HWCAP2 = 26 };
		static uint8_t random_bytes[16] = { 0x5a, 0xa5, 0x3c, 0xc3 };
		switch (type) {
		case AT_PAGESZ: return 4096;
		case AT_HWCAP:  return 0;
		case AT_HWCAP2: return 0;
		case AT_RANDOM: return (unsigned long)random_bytes;
		}
		set_errno(2);                           /* ENOENT */
		return 0;
	}

	/* Linux clock ids: REALTIME 0, MONOTONIC 1, *_RAW 4, *_COARSE 5/6, BOOTTIME 7 */
	int art_clock_gettime(int clock, timespec *ts)
	{
		clockid_t const g = (clock == 0 || clock == 5) ? CLOCK_REALTIME : CLOCK_MONOTONIC;
		return check(clock_gettime(g, ts));
	}

	int art_clock_getres(int, timespec *ts)
	{
		ts->tv_sec = 0; ts->tv_nsec = 1000;
		return 0;
	}

	int art_nanosleep(timespec const *req, timespec *rem) { return check(nanosleep(req, rem)); }

	int art_usleep(unsigned us) { return check(usleep(us)); }

	unsigned art_sleep(unsigned s) { return sleep(s); }

	time_t art_time(time_t *t) { return time(t); }

	int art_gettimeofday(timeval *tv, void *) { return check(gettimeofday(tv, nullptr)); }

	int art___cxa_finalize(void *) { return 0; }

	void art_android_set_abort_message(char const *msg)
	{
		Genode::error("android_rt: abort message: ", Genode::Cstring(msg ? msg : ""));
	}

	int art_gettid();

	long art_syscall(long number, ...)
	{
		enum { SYS_gettid = 178 };
		if (number == SYS_gettid) return art_gettid();

		Genode::warning("android_rt: syscall(", number, ") not supported");
		set_errno(38);                          /* ENOSYS */
		return -1;
	}
}


static Export const exports[] = {
	{ "environ",     (void *)&art_environ },
	{ "open",        (void *)art_open },
	{ "open64",      (void *)art_open },
	{ "__open_2",    (void *)art___open_2 },
	{ "close",       (void *)art_close },
	{ "read",        (void *)art_read },
	{ "write",       (void *)art_write },
	{ "lseek",       (void *)art_lseek },
	{ "lseek64",     (void *)art_lseek },
	{ "access",      (void *)art_access },
	{ "unlink",      (void *)art_unlink },
	{ "mkdir",       (void *)art_mkdir },
	{ "rmdir",       (void *)art_rmdir },
	{ "isatty",      (void *)art_isatty },
	{ "pread",       (void *)art_pread },
	{ "pread64",     (void *)art_pread },
	{ "pwrite",      (void *)art_pwrite },
	{ "pwrite64",    (void *)art_pwrite },
	{ "ioctl",       (void *)art_ioctl },
	{ "poll",        (void *)art_poll },
	{ "chdir",       (void *)art_chdir },
	{ "getcwd",      (void *)art_getcwd },
	{ "readlink",    (void *)art_readlink },
	{ "realpath",    (void *)art_realpath },
	{ "rename",      (void *)art_rename },
	{ "remove",      (void *)art_remove },
	{ "fsync",       (void *)art_fsync },
	{ "fdatasync",   (void *)art_fsync },
	{ "ftruncate",   (void *)art_ftruncate },
	{ "chmod",       (void *)art_chmod },
	{ "fchmod",      (void *)art_fchmod },
	{ "chown",       (void *)art_chown },
	{ "fchown",      (void *)art_fchown },
	{ "fcntl",       (void *)art_fcntl },
	{ "dup",         (void *)art_dup },
	{ "dup2",        (void *)art_dup2 },
	{ "eventfd",     (void *)art_eventfd },
	{ "pipe2",       (void *)art_pipe2 },
	{ "pipe",        (void *)art_pipe },
	{ "epoll_create1", (void *)art_epoll_create1 },
	{ "epoll_create",  (void *)art_epoll_create },
	{ "epoll_ctl",   (void *)art_epoll_ctl },
	{ "epoll_wait",  (void *)art_epoll_wait },
	{ "epoll_pwait", (void *)art_epoll_pwait },
	{ "select",      (void *)art_select },
	{ "mmap",        (void *)art_mmap },
	{ "mmap64",      (void *)art_mmap },
	{ "munmap",      (void *)art_munmap },
	{ "madvise",     (void *)art_madvise },
	{ "mprotect",    (void *)art_mprotect },
	{ "writev",      (void *)art_writev },
	{ "openat",      (void *)art_openat },
	{ "fstatat",     (void *)art_fstatat },
	{ "fstatat64",   (void *)art_fstatat },
	{ "mkdirat",     (void *)art_mkdirat },
	{ "stat",        (void *)art_stat },
	{ "stat64",      (void *)art_stat },
	{ "lstat",       (void *)art_lstat },
	{ "lstat64",     (void *)art_lstat },
	{ "fstat",       (void *)art_fstat },
	{ "fstat64",     (void *)art_fstat },
	{ "getenv",      (void *)art_getenv },
	{ "setenv",      (void *)art_setenv },
	{ "unsetenv",    (void *)art_unsetenv },
	{ "getpid",      (void *)art_getpid },
	{ "getppid",     (void *)art_getppid },
	{ "getuid",      (void *)art_getuid },
	{ "geteuid",     (void *)art_geteuid },
	{ "getgid",      (void *)art_getgid },
	{ "getegid",     (void *)art_getegid },
	{ "sysconf",     (void *)art_sysconf },
	{ "getpagesize", (void *)art_getpagesize },
	{ "syscall",     (void *)art_syscall },
	{ "getauxval",   (void *)art_getauxval },
	{ "clock_gettime", (void *)art_clock_gettime },
	{ "clock_getres",  (void *)art_clock_getres },
	{ "nanosleep",   (void *)art_nanosleep },
	{ "usleep",      (void *)art_usleep },
	{ "sleep",       (void *)art_sleep },
	{ "time",        (void *)art_time },
	{ "gettimeofday",(void *)art_gettimeofday },
	{ "__cxa_finalize", (void *)art___cxa_finalize },
	{ "android_set_abort_message", (void *)art_android_set_abort_message },
};

Export_group Android_rt::file_exports() { return { exports, sizeof(exports) / sizeof(exports[0]) }; }
