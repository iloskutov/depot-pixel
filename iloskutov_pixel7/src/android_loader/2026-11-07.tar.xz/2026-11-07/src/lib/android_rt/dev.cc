/*
 * \brief  Device nodes of the Android runtime
 * \author Ivan Loskutov
 * \date   2026-09-25
 */

/*
 * SPDX-License-Identifier: MIT
 */

#include <android_rt/runtime.h>
#include <android_rt/chardev.h>
#include <android_rt/dev.h>
#include <android_rt/io.h>
#include <android_rt/sock.h>
#include <base/log.h>
#include <base/mutex.h>
#include <util/construct_at.h>
#include <util/string.h>

#include <fcntl.h>
#include <poll.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

using namespace Android_rt;

namespace {

	enum { MAX_DEV_FDS = DEV_FD_COUNT, LINE_MAX = 512 };   /* rild: ~32 pipes + epolls + channels */

	enum { MAX_WATCH = 32 };

	struct Epoll_watch { int fd; uint32_t events; uint64_t data; };

	/* pipe(2): ring buffer shared by a PIPE_R and a PIPE_W descriptor */
	enum { MAX_PIPES = 128, PIPE_SIZE = 16*1024 };

	struct Pipe
	{
		bool     used;
		unsigned readers, writers;
		size_t   head, count;       /* ring position of the oldest byte, bytes queued */
		uint8_t *buf;               /* allocated on first use, kept */
	};

	struct Dev_fd
	{
		enum Kind { FREE, LOG, EVENTFD, EPOLL, PIPE_R, PIPE_W,
		            CHARDEV       /* Android_chardev session */
		} kind;
		char line[LINE_MAX];      /* LOG: pending partial line */
		unsigned line_len;
		uint64_t counter;         /* EVENTFD */
		bool     nonblock;        /* EVENTFD, PIPE_R, PIPE_W, CHARDEV */
		unsigned pipe;            /* PIPE_R, PIPE_W: index into 'pipes' */
		Epoll_watch watch[MAX_WATCH];   /* EPOLL */
		unsigned    watch_count;
		Chardev_file *chardev;       /* CHARDEV */
		unsigned      users;         /* CHARDEV: in-flight read/write/ioctl calls */
		bool          closing;       /* CHARDEV: close() while users > 0; last user frees */
	};

	Genode::Mutex mutex;
	Dev_fd        fds[MAX_DEV_FDS];
	Pipe          pipes[MAX_PIPES];

	Dev_fd *lookup(int fd)
	{
		int const i = fd - DEV_FD_BASE;
		return (i >= 0 && i < MAX_DEV_FDS && fds[i].kind != Dev_fd::FREE) ? &fds[i] : nullptr;
	}
}


static int alloc_fd_locked(Dev_fd::Kind kind)
{
	for (int i = 0; i < MAX_DEV_FDS; i++)
		if (fds[i].kind == Dev_fd::FREE) {
			memset(&fds[i], 0, sizeof(fds[i]));
			fds[i].kind = kind;
			return DEV_FD_BASE + i;
		}
	set_errno(24);                               /* EMFILE */
	return -1;
}


int Android_rt::dev_eventfd(unsigned initval, int flags)
{
	Genode::Mutex::Guard guard(mutex);
	int const fd = alloc_fd_locked(Dev_fd::EVENTFD);
	if (fd < 0) return fd;
	Dev_fd &d = fds[fd - DEV_FD_BASE];
	d.counter  = initval;
	d.nonblock = flags & 04000;                  /* EFD_NONBLOCK = O_NONBLOCK */
	return fd;
}


int Android_rt::dev_pipe(int out[2], int flags)
{
	Genode::Mutex::Guard guard(mutex);

	unsigned p = 0;
	while (p < MAX_PIPES && pipes[p].used) p++;
	if (p == MAX_PIPES) { set_errno(23); return -1; }        /* ENFILE */
	if (!pipes[p].buf) pipes[p].buf = (uint8_t *)malloc(PIPE_SIZE);
	if (!pipes[p].buf) { set_errno(12); return -1; }        /* ENOMEM */

	int const r = alloc_fd_locked(Dev_fd::PIPE_R);
	if (r < 0) return -1;
	int const w = alloc_fd_locked(Dev_fd::PIPE_W);
	if (w < 0) { fds[r - DEV_FD_BASE].kind = Dev_fd::FREE; return -1; }

	bool const nonblock = flags & 04000;                     /* O_NONBLOCK */
	int const ends[2] = { r, w };
	for (int fd : ends) {
		fds[fd - DEV_FD_BASE].pipe     = p;
		fds[fd - DEV_FD_BASE].nonblock = nonblock;
	}
	pipes[p].used = true; pipes[p].readers = 1; pipes[p].writers = 1;
	pipes[p].head = 0;    pipes[p].count = 0;
	out[0] = r; out[1] = w;
	return 0;
}


int Android_rt::dev_flags(int fd)
{
	if (is_sock_fd(fd)) return 2;                /* O_RDWR, blocking */
	Genode::Mutex::Guard guard(mutex);
	Dev_fd *d = lookup(fd);
	if (!d) { set_errno(9); return -1; }
	int const access = d->kind == Dev_fd::PIPE_R ? 0 : d->kind == Dev_fd::PIPE_W ? 1 : 2;
	return access | (d->nonblock ? 04000 : 0);
}


int Android_rt::dev_set_flags(int fd, int flags)
{
	if (is_sock_fd(fd)) return 0;                /* nothing on them ever blocks */
	Genode::Mutex::Guard guard(mutex);
	Dev_fd *d = lookup(fd);
	if (!d) { set_errno(9); return -1; }
	d->nonblock = flags & 04000;
	return 0;
}


int Android_rt::dev_epoll_create()
{
	Genode::Mutex::Guard guard(mutex);
	return alloc_fd_locked(Dev_fd::EPOLL);
}


int Android_rt::dev_epoll_ctl(int epfd, int op, int fd, uint32_t events, uint64_t data)
{
	enum { ADD = 1, DEL = 2, MOD = 3 };
	Genode::Mutex::Guard guard(mutex);
	Dev_fd *e = lookup(epfd);
	if (!e || e->kind != Dev_fd::EPOLL) { set_errno(9); return -1; }

	for (unsigned i = 0; i < e->watch_count; i++)
		if (e->watch[i].fd == fd) {
			if (op == ADD) { set_errno(17); return -1; }          /* EEXIST */
			if (op == DEL) { e->watch[i] = e->watch[--e->watch_count]; return 0; }
			e->watch[i].events = events; e->watch[i].data = data;
			io_notify();   /* the new mask (or a freshly watched VFS fd) may already be ready */
			return 0;
		}
	if (op != ADD) { set_errno(2); return -1; }                  /* ENOENT */
	if (e->watch_count == MAX_WATCH) { set_errno(28); return -1; }
	e->watch[e->watch_count++] = { fd, events, data };
	io_notify();           /* wake a concurrent epoll_wait so it re-checks (and re-arms the
	                          10 ms VFS poll if the added fd has no wake-up of its own) */
	return 0;
}


static unsigned ready_locked(int fd, bool probe, bool &chardev);


int Android_rt::dev_epoll_wait(int epfd, uint32_t *events, uint64_t *datas,
                               int max, int timeout_ms)
{
	/*
	 * 'io_now_ms()' opens the process' Genode Timer connection on first use
	 * (Libc::Kernel::current_time()), so it must stay untouched on the
	 * common path where readiness resolves without ever waiting -- callers
	 * that never pass a positive timeout must not gain a Timer dependency.
	 */
	long start = 0;
	bool have_start = false;
	Chardev_slice slice { };

	for (;;) {
		unsigned const gen = io_generation();
		int  n = 0;
		bool vfs      = false;     /* VFS descriptors have no wake-up: re-check every 10 ms */
		bool chardevs = false;     /* chardevs: probe for a vanished server per slice */
		{
			Genode::Mutex::Guard guard(mutex);
			Dev_fd *e = lookup(epfd);
			if (!e || e->kind != Dev_fd::EPOLL) { set_errno(9); return -1; }
			for (unsigned i = 0; i < e->watch_count && n < max; i++) {
				if (!is_dev_fd(e->watch[i].fd)) vfs = true;
				bool c = false;
				unsigned const r = ready_locked(e->watch[i].fd, slice.probe, c);
				chardevs |= c;
				uint32_t ev = 0;
				if ((e->watch[i].events & 1) && (r & 1)) ev |= 1;      /* EPOLLIN */
				if ((e->watch[i].events & 4) && (r & 2)) ev |= 4;      /* EPOLLOUT */
				if (r & 4) ev |= 0x10;                                  /* EPOLLHUP */
				if (ev) { events[n] = ev; datas[n] = e->watch[i].data; n++; }
			}
		}
		slice.probe = false;
		if (n || timeout_ms == 0) return n;

		int wait = -1;
		if (timeout_ms > 0) {
			if (!have_start) { start = io_now_ms(); have_start = true; }
			long const left = timeout_ms - (io_now_ms() - start);
			if (left <= 0) return 0;
			wait = int(left);
		}
		if (vfs && (wait < 0 || wait > 10)) wait = 10;
		wait = slice.cap(chardevs, wait);
		slice.waited(chardevs, io_wait(gen, wait), wait);
	}
}


/*
 * Take a "use" of an open CHARDEV descriptor's Chardev_file, protecting it
 * from a concurrent dev_close() while the caller's RPC/memcpy is in flight
 * (close() on a still-used descriptor only marks it 'closing' -- see
 * chardev_release() and dev_close()). Returns nullptr (errno set to EBADF)
 * if 'fd' isn't an open, non-closing CHARDEV descriptor.
 */
static Chardev_file *chardev_take(int fd, int &err)
{
	Genode::Mutex::Guard guard(mutex);
	Dev_fd *d = lookup(fd);
	if (!d || d->kind != Dev_fd::CHARDEV || d->closing) { err = 9; return nullptr; }   /* EBADF */
	d->users++;
	return d->chardev;
}


/*
 * Drop a use taken by chardev_take(). If this was the last use of a
 * descriptor already marked 'closing', frees the slot -- the Chardev_file
 * destructor (session close + io_dissolve) always runs with the dev mutex
 * released, never under it.
 */
static void chardev_release(int fd)
{
	Chardev_file *doomed = nullptr;
	{
		Genode::Mutex::Guard guard(mutex);
		Dev_fd *d = lookup(fd);
		if (!d || d->kind != Dev_fd::CHARDEV) return;   /* closed and reused: nothing to do */
		if (--d->users == 0 && d->closing) {
			doomed = d->chardev;
			d->chardev = nullptr;
			d->kind = Dev_fd::FREE;
		}
	}
	if (doomed) { doomed->~Chardev_file(); ::free(doomed); io_notify(); }
}


/*
 * Run one Chardev_file operation ('attempt' calls exactly one of
 * Chardev_file::read()/write()/ioctl() and returns its Status) to
 * completion. Holds a use of the descriptor (chardev_take()/
 * chardev_release()) for the whole call, so a concurrent dev_close() cannot
 * free the Chardev_file while 'attempt' still has it.
 *
 * After WOULD_BLOCK the operation is NOT retried on every wake-up of the io
 * condition (other descriptors wake it too, and each retry is an RPC --
 * final review 1: that loop busy-spun rild and cbd). Instead the caller
 * waits until the descriptor's readiness ('need': READABLE for read,
 * WRITABLE for write) or HANGUP is reported; 'ready()' only issues an RPC
 * when a readiness signal, an own operation or a probe marked the cached
 * state stale. Each iteration snapshots io_generation() before the checks,
 * re-checks 'closing'/'nonblock' under the dev mutex and waits with the dev
 * mutex released. The wait is cut into 'Chardev_slice's so a vanished server
 * (which sends no signal) is noticed as HANGUP. A descriptor closed from
 * under the caller surfaces as EBADF, matching what a second thread using
 * the same (already invalid) fd number would see on Linux.
 */
static Chardev_file::Status chardev_io(int fd, unsigned need, int &err, auto const &attempt)
{
	using Status  = Chardev_file::Status;
	using Session = Chardev_file::Session;

	Chardev_file *f = chardev_take(fd, err);
	if (!f) return Status::ERROR;

	Status s;
	for (;;) {
		s = attempt(*f);
		if (s != Status::WOULD_BLOCK) break;

		Chardev_slice slice { };
		for (;;) {
			unsigned const gen = io_generation();

			bool closing = true, nonblock = true;
			{
				Genode::Mutex::Guard g(mutex);
				Dev_fd *d = lookup(fd);
				if (d && d->kind == Dev_fd::CHARDEV && !d->closing) {
					closing  = false;
					nonblock = d->nonblock;
				}
			}
			if (closing)  { err = 9;  s = Status::ERROR; break; }   /* EBADF */
			if (nonblock) { err = 11; s = Status::ERROR; break; }   /* EAGAIN */

			if (slice.probe) { f->probe(); slice.probe = false; }
			unsigned const r = f->ready();
			if (r & Session::HANGUP) { s = Status::HANGUP; break; }   /* read 0, write EPIPE */
			if (r & need) break;                                        /* retry the operation */

			int const wait = slice.cap(true, -1);
			slice.waited(true, io_wait(gen, wait), wait);
		}
		if (s != Status::WOULD_BLOCK) break;
	}
	chardev_release(fd);
	return s;
}


int Android_rt::dev_open(char const *path, int linux_flags)
{
	if (is_chardev_path(path)) {
		void *m = ::malloc(sizeof(Chardev_file));
		if (!m) { set_errno(12); return -1; }                    /* ENOMEM */
		Chardev_file *f = Genode::construct_at<Chardev_file>(m);
		char const *slash = strrchr(path, '/');                  /* "/dev/umts_ipc0" -> "umts_ipc0" */
		int const err = f->open(slash ? slash + 1 : path, linux_flags);
		if (err) { f->~Chardev_file(); ::free(f); set_errno(err); return -1; }

		int fd;
		{
			Genode::Mutex::Guard guard(mutex);
			fd = alloc_fd_locked(Dev_fd::CHARDEV);
			if (fd >= 0) {
				fds[fd - DEV_FD_BASE].chardev  = f;
				fds[fd - DEV_FD_BASE].nonblock = linux_flags & 04000;   /* O_NONBLOCK */
			}
		}
		/* destroy outside the mutex on failure: ~Chardev_file() closes the session */
		if (fd < 0) { f->~Chardev_file(); ::free(f); return -1; }
		return fd;
	}

	Dev_fd::Kind kind;

	if (!strcmp(path, "/dev/kmsg") || !strcmp(path, "/dev/pmsg0")) kind = Dev_fd::LOG;
	else return sock_open(path, linux_flags);    /* an interface's /proc file, or -2 */

	Genode::Mutex::Guard guard(mutex);

	for (int i = 0; i < MAX_DEV_FDS; i++)
		if (fds[i].kind == Dev_fd::FREE) {
			memset(&fds[i], 0, sizeof(fds[i]));
			fds[i].kind = kind;
			return DEV_FD_BASE + i;
		}
	set_errno(24);                               /* EMFILE */
	return -1;
}


ssize_t Android_rt::dev_read(int fd, void *buf, size_t n)
{
	if (is_sock_fd(fd)) return sock_read(fd, buf, n);

	mutex.acquire();
	Dev_fd *d = lookup(fd);
	if (!d) { mutex.release(); set_errno(9); return -1; }
	if (d->kind == Dev_fd::CHARDEV) {
		mutex.release();
		int err = 0; size_t count = 0;
		Chardev_file::Status const s = chardev_io(fd, Chardev_file::Session::READABLE, err,
			[&] (Chardev_file &f) { return f.read(buf, n, count, err); });
		if (s == Chardev_file::Status::OK)     return ssize_t(count);
		if (s == Chardev_file::Status::HANGUP) return 0;
		set_errno(err);
		return -1;
	}
	if (d->kind == Dev_fd::LOG) { mutex.release(); return 0; }

	if (d->kind == Dev_fd::EVENTFD) {
		if (n < 8) { mutex.release(); set_errno(22); return -1; }
		for (;;) {
			unsigned const gen = io_generation();
			if (d->counter) break;
			if (d->nonblock) { mutex.release(); set_errno(11); return -1; }   /* EAGAIN */
			mutex.release(); io_wait(gen, -1); mutex.acquire();
			d = lookup(fd);   /* closed and reused meanwhile? */
			if (!d || d->kind != Dev_fd::EVENTFD) { mutex.release(); set_errno(9); return -1; }
		}
		memcpy(buf, &d->counter, 8);
		d->counter = 0;
		mutex.release();
		io_notify();                               /* writable/readable changed */
		return 8;
	}
	if (d->kind == Dev_fd::PIPE_R) {
		for (;;) {
			unsigned const gen = io_generation();
			Pipe &p = pipes[d->pipe];
			if (p.count) {
				size_t const len = n < p.count ? n : p.count;
				for (size_t i = 0; i < len; i++)
					((uint8_t *)buf)[i] = p.buf[(p.head + i) % PIPE_SIZE];
				p.head = (p.head + len) % PIPE_SIZE;
				p.count -= len;
				mutex.release();
				io_notify();                       /* the writer may continue */
				return ssize_t(len);
			}
			if (!p.writers) { mutex.release(); return 0; }                   /* EOF */
			if (d->nonblock) { mutex.release(); set_errno(11); return -1; }   /* EAGAIN */
			mutex.release(); io_wait(gen, -1); mutex.acquire();
			d = lookup(fd);   /* closed and reused meanwhile? */
			if (!d || d->kind != Dev_fd::PIPE_R) { mutex.release(); set_errno(9); return -1; }
		}
	}
	mutex.release();
	set_errno(22);                               /* EINVAL: fd of a kind read() doesn't serve */
	return -1;
}


static ssize_t pipe_write(int fd, void const *buf, size_t n)
{
	size_t done = 0;
	mutex.acquire();
	for (;;) {
		unsigned const gen = io_generation();
		Dev_fd *d = lookup(fd);
		if (!d || d->kind != Dev_fd::PIPE_W) { mutex.release(); set_errno(9); return -1; }
		Pipe &p = pipes[d->pipe];
		if (!p.readers) { mutex.release(); set_errno(32); return -1; }       /* EPIPE */

		size_t const space = PIPE_SIZE - p.count;
		size_t const len   = (n - done) < space ? (n - done) : space;
		for (size_t i = 0; i < len; i++)
			p.buf[(p.head + p.count + i) % PIPE_SIZE] = ((uint8_t const *)buf)[done + i];
		p.count += len;
		done    += len;

		if (done == n) { mutex.release(); io_notify(); return ssize_t(n); }
		if (d->nonblock) {
			mutex.release();
			if (done) { io_notify(); return ssize_t(done); }
			set_errno(11); return -1;                                        /* EAGAIN */
		}
		/*
		 * 'len' bytes were just queued (the pipe is now full, more to write):
		 * wake the reader and re-check -- do NOT wait, or this thread's own
		 * notify would immediately satisfy its stale 'gen' and busy-spin.
		 * Only an iteration that copies nothing (pipe already full on entry)
		 * actually blocks, without notifying (nothing changed to notify about).
		 */
		if (len) { mutex.release(); io_notify(); mutex.acquire(); continue; }
		mutex.release(); io_wait(gen, -1); mutex.acquire();
	}
}


ssize_t Android_rt::dev_write(int fd, void const *buf, size_t n)
{
	if (is_sock_fd(fd)) return sock_write(fd, buf, n);

	Dev_fd::Kind kind = Dev_fd::FREE;
	{
		Genode::Mutex::Guard guard(mutex);
		if (Dev_fd *d = lookup(fd)) kind = d->kind;
	}
	if (kind == Dev_fd::PIPE_W) return pipe_write(fd, buf, n);   /* may block: own locking */
	if (kind == Dev_fd::PIPE_R) { set_errno(9); return -1; }
	if (kind == Dev_fd::CHARDEV) {
		int err = 0; size_t count = 0;
		Chardev_file::Status const s = chardev_io(fd, Chardev_file::Session::WRITABLE, err,
			[&] (Chardev_file &f) { return f.write(buf, n, count, err); });
		if (s == Chardev_file::Status::OK) return ssize_t(count);
		if (s == Chardev_file::Status::HANGUP) err = 32;   /* EPIPE */
		set_errno(err);
		return -1;
	}

	Genode::Mutex::Guard guard(mutex);
	Dev_fd *d = lookup(fd);
	if (!d) { set_errno(9); return -1; }

	if (d->kind == Dev_fd::EVENTFD) {
		if (n < 8) { set_errno(22); return -1; }
		uint64_t v; memcpy(&v, buf, 8);
		d->counter += v;
		io_notify();
		return 8;
	}
	if (d->kind == Dev_fd::EPOLL) { set_errno(22); return -1; }

	if (d->kind == Dev_fd::LOG) {
		char const *s = (char const *)buf;
		for (size_t i = 0; i < n; i++) {
			if (s[i] == '\n' || d->line_len == LINE_MAX - 1) {
				d->line[d->line_len] = 0;
				Genode::log("kmsg: ", Genode::Cstring(d->line));
				d->line_len = 0;
				if (s[i] == '\n') continue;
			}
			d->line[d->line_len++] = s[i];
		}
		return ssize_t(n);
	}

	set_errno(22);                               /* EINVAL: fd of a kind write() doesn't serve */
	return -1;
}


int Android_rt::dev_ioctl(int fd, unsigned long cmd, void *arg)
{
	if (is_sock_fd(fd)) return sock_ioctl(fd, cmd, arg);

	bool is_chardev = false;
	{
		Genode::Mutex::Guard guard(mutex);
		Dev_fd *d = lookup(fd);
		if (!d) { set_errno(9); return -1; }
		is_chardev = d->kind == Dev_fd::CHARDEV;
	}
	if (is_chardev) {
		int err = 0; long ret = 0;
		/* ioctl() never returns WOULD_BLOCK (it becomes EAGAIN): no wait */
		Chardev_file::Status const s = chardev_io(fd, 0, err,
			[&] (Chardev_file &f) { return f.ioctl(cmd, arg, ret, err); });
		if (s != Chardev_file::Status::OK) { set_errno(err); return -1; }
		return int(ret);
	}

	set_errno(25);                               /* ENOTTY: fd of a kind ioctl() doesn't serve */
	return -1;
}


/* Linux: the last close of a descriptor removes it from every epoll set */
static void forget_watches_locked(int fd)
{
	for (int i = 0; i < MAX_DEV_FDS; i++) {
		Dev_fd &e = fds[i];
		if (e.kind != Dev_fd::EPOLL) continue;
		for (unsigned w = 0; w < e.watch_count; )
			if (e.watch[w].fd == fd) e.watch[w] = e.watch[--e.watch_count];
			else w++;
	}
}


void Android_rt::dev_forget_fd(int fd)
{
	Genode::Mutex::Guard guard(mutex);
	forget_watches_locked(fd);
}


int Android_rt::dev_close(int fd)
{
	if (is_sock_fd(fd)) { dev_forget_fd(fd); return sock_close(fd); }

	Chardev_file *doomed = nullptr;
	{
		Genode::Mutex::Guard guard(mutex);
		Dev_fd *d = lookup(fd);
		if (!d || d->closing) { set_errno(9); return -1; }   /* EBADF, also for a second close */
		forget_watches_locked(fd);
		if (d->kind == Dev_fd::PIPE_R || d->kind == Dev_fd::PIPE_W) {
			Pipe &p = pipes[d->pipe];
			if (d->kind == Dev_fd::PIPE_R) p.readers--; else p.writers--;
			if (!p.readers && !p.writers) p.used = false;
		}
		if (d->kind == Dev_fd::CHARDEV && d->users) {
			/* an in-flight read/write/ioctl (chardev_io) still holds a use of
			 * 'd->chardev': leave the slot reserved and the pointer intact,
			 * wake it (via io_notify below) so it re-checks 'closing', and let
			 * chardev_release() free the slot when the last use drops */
			d->closing = true;
		} else {
			if (d->kind == Dev_fd::CHARDEV) doomed = d->chardev;
			d->chardev = nullptr;
			d->kind = Dev_fd::FREE;
		}
	}
	/* ~Chardev_file() (session close + io_dissolve) never runs under the dev mutex */
	if (doomed) { doomed->~Chardev_file(); ::free(doomed); }
	io_notify();
	return 0;
}


static unsigned ready_locked(int fd, bool probe, bool &chardev)
{
	chardev = false;
	if (!is_dev_fd(fd)) {                        /* VFS descriptor */
		pollfd p { fd, POLLIN | POLLOUT, 0 };
		if (::poll(&p, 1, 0) <= 0) return 0;
		return ((p.revents & POLLIN) ? 1 : 0) | ((p.revents & POLLOUT) ? 2 : 0);
	}
	if (is_sock_fd(fd)) return sock_ready(fd);
	Dev_fd *d = lookup(fd);
	if (!d) return 8;
	switch (d->kind) {
	case Dev_fd::LOG:     return 2;
	case Dev_fd::EVENTFD: return (d->counter ? 1 : 0) | 2;
	case Dev_fd::CHARDEV:
		chardev = true;
		if (probe) d->chardev->probe();
		return d->chardev->ready();
	case Dev_fd::PIPE_R: {
		Pipe const &p = pipes[d->pipe];
		return (p.count || !p.writers) ? 1 : 0; }
	case Dev_fd::PIPE_W: {
		Pipe const &p = pipes[d->pipe];
		return (p.count < PIPE_SIZE || !p.readers) ? 2 : 0; }
	default:              return 0;
	}
}


unsigned Android_rt::dev_ready(int fd, bool probe, bool &chardev)
{
	Genode::Mutex::Guard guard(mutex);
	return ready_locked(fd, probe, chardev);
}
