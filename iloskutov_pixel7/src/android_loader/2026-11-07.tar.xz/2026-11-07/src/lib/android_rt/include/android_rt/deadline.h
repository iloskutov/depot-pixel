/*
 * \brief  Absolute deadline of one clock expressed on another clock
 * \author Ivan Loskutov
 * \date   2026-09-29
 *
 * bionic's pthread_cond_clockwait takes a CLOCK_MONOTONIC or CLOCK_REALTIME
 * deadline, the Genode condition variable of the runtime measures
 * CLOCK_MONOTONIC. The deadline is moved to the target clock at the
 * same distance from "now". Validation follows bionic's check_timespec:
 * tv_nsec outside [0, 1e9) is EINVAL (checked first), tv_sec < 0 has
 * expired. A distance of MAX_REL_SEC or more -- e.g. libc++'s
 * time_point::max() for wait_for(hours::max()) -- is an untimed wait: the
 * arithmetic saturates instead of overflowing into a past deadline (which
 * made such a wait return ETIMEDOUT at once and its caller spin).
 */

/*
 * SPDX-License-Identifier: MIT
 */

#ifndef _ANDROID_RT__DEADLINE_H_
#define _ANDROID_RT__DEADLINE_H_

namespace Android_rt {

	struct Timespec64 { long long sec; long nsec; };

	struct Deadline
	{
		enum Kind { INVALID, EXPIRED, UNTIMED, AT };

		Kind       kind;
		Timespec64 at;   /* valid for AT, on the target clock */
	};

	enum : long long { NS_PER_S = 1000000000LL,
	                   MAX_REL_SEC = 1LL << 31 };   /* ~68 years: "forever" */

	/**
	 * Convert 'abs' (source clock) to the target clock
	 *
	 * \param src_now  current time of the source clock (valid, tv_sec >= 0)
	 * \param dst_now  current time of the target clock (valid, tv_sec >= 0)
	 */
	inline Deadline convert_deadline(Timespec64 abs, Timespec64 src_now, Timespec64 dst_now)
	{
		if (abs.nsec < 0 || abs.nsec >= NS_PER_S) return { Deadline::INVALID, { 0, 0 } };
		if (abs.sec < 0)                          return { Deadline::EXPIRED, { 0, 0 } };

		if (abs.sec < src_now.sec || (abs.sec == src_now.sec && abs.nsec <= src_now.nsec))
			return { Deadline::EXPIRED, { 0, 0 } };

		/* both non-negative, abs >= src_now: no overflow */
		long long rel_sec  = abs.sec - src_now.sec;
		long      rel_nsec = abs.nsec - src_now.nsec;
		if (rel_nsec < 0) { rel_nsec += long(NS_PER_S); rel_sec--; }

		if (rel_sec >= MAX_REL_SEC || dst_now.sec > __LONG_LONG_MAX__ - MAX_REL_SEC - 1)
			return { Deadline::UNTIMED, { 0, 0 } };

		Timespec64 at { dst_now.sec + rel_sec, dst_now.nsec + rel_nsec };
		if (at.nsec >= NS_PER_S) { at.nsec -= long(NS_PER_S); at.sec++; }
		return { Deadline::AT, at };
	}
}

#endif /* _ANDROID_RT__DEADLINE_H_ */
