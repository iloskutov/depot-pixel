/*
 * \brief  bionic system properties
 * \author Ivan Loskutov
 * \date   2026-09-25
 *
 * The properties live in an 'Android_prop::Table'. Local back end: a table
 * in process memory, initial values from the loader config, sets stay in
 * the process. Session back end (prop_service.cc, config
 * <property_service/>): the android_prop server's table, mapped read-only;
 * sets and waits go to the server. The 'prop_info *' handed to Android code
 * points at a table slot (stable for the process lifetime).
 */

/*
 * SPDX-License-Identifier: MIT
 */

#include <android_rt/runtime.h>
#include <android_rt/prop_service.h>
#include <android_prop/table.h>
#include <android_prop/text.h>
#include <base/log.h>
#include <base/mutex.h>
#include <util/construct_at.h>
#include <util/string.h>

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

using namespace Android_rt;
using Android_prop::Slot;
using Android_prop::Table;

namespace {

	Genode::Mutex local_mutex;   /* the local table's single writer */
	Table        *local;

	Table &local_table()
	{
		Genode::Mutex::Guard guard(local_mutex);
		if (!local) {
			void *mem = ::malloc(Table::SIZE);
			void *obj = ::malloc(sizeof(Table));
			if (!mem || !obj) { Genode::error("android_rt: no memory for the property table"); ::_exit(1); }
			local = Genode::construct_at<Table>(obj, mem);
			local->format();
		}
		return *local;
	}

	/* the table readers use: the service's mapping or the local table */
	Table const &view()
	{
		if (Table const *t = prop_service_table()) return *t;
		return local_table();
	}

	void log_result(char const *what, char const *name, Android_prop::Set_result r)
	{
		switch (r) {
		case Android_prop::Set_result::OK:        return;
		case Android_prop::Set_result::INVALID:   Genode::warning("android_rt: ", what, " ", Genode::Cstring(name), ": invalid name or value"); return;
		case Android_prop::Set_result::FULL:      Genode::warning("android_rt: ", what, " ", Genode::Cstring(name), ": property table full"); return;
		case Android_prop::Set_result::READ_ONLY: Genode::warning("android_rt: ", what, " ", Genode::Cstring(name), ": read-only property"); return;
		}
	}

	int local_set(char const *name, char const *value)
	{
		Table &t = local_table();
		Genode::Mutex::Guard guard(local_mutex);
		Android_prop::Set_result const r = t.set(name, value);
		log_result("setprop", name, r);
		return r == Android_prop::Set_result::OK ? 0 : -1;
	}

	/* a local set comes from this process: poll */
	bool local_wait(Slot const *pi, uint32_t old, uint32_t *new_serial, long timeout_ms)
	{
		Table const &t = view();
		for (long waited = 0;; waited += 10) {
			uint32_t const cur = pi ? t.serial(*pi) : t.area_serial();
			if (cur != old) { if (new_serial) *new_serial = cur; return true; }
			if (timeout_ms >= 0 && waited >= timeout_ms) return false;
			usleep(10000);
		}
	}
}


void Android_rt::set_property(char const *name, char const *value)
{
	Table &t = local_table();
	Genode::Mutex::Guard guard(local_mutex);
	log_result("<property>", name, t.load(name, value));
}


void Android_rt::load_properties_file(char const *path)
{
	FILE *f = fopen(path, "r");
	if (!f) { Genode::error("android_rt: cannot open properties file ", Genode::Cstring(path)); return; }

	size_t size = 0, cap = 64*1024;
	char *text = (char *)::malloc(cap);
	size_t n;
	while (text && (n = fread(text + size, 1, cap - size, f)) > 0) {
		size += n;
		if (size == cap) { cap *= 2; text = (char *)::realloc(text, cap); }
	}
	fclose(f);
	if (!text) { Genode::error("android_rt: no memory for ", Genode::Cstring(path)); return; }

	Table &t = local_table();
	unsigned loaded;
	{
		Genode::Mutex::Guard guard(local_mutex);
		loaded = Android_prop::parse_getprop(text, size, [&] (char const *name, char const *value) {
			return t.load(name, value) == Android_prop::Set_result::OK; });
	}
	::free(text);
	Genode::log("android_rt: ", loaded, " properties from ", Genode::Cstring(path));
}


extern "C" {

	int art___system_property_get(char const *name, char *value)
	{
		Table const &t = view();
		Slot const *s = t.find(name);
		if (!s) { value[0] = 0; return 0; }
		return int(t.read(*s, value));
	}

	int art___system_property_set(char const *name, char const *value)
	{
		Genode::log("android_rt: setprop ", Genode::Cstring(name), " ", Genode::Cstring(value));
		return prop_service_table() ? prop_service_set(name, value) : local_set(name, value);
	}

	void const *art___system_property_find(char const *name) { return view().find(name); }

	int art___system_property_read(void const *pi, char *name, char *value)
	{
		/*
		 * Legacy bionic API: 'name' is a caller buffer of 'PROP_NAME_MAX'
		 * (32, including the NUL) bytes, unlike 'Slot::name' (128 bytes).
		 * LOS property names reach 70 characters, so copying the whole
		 * slot name (as 'strcpy' did) overflows a legacy caller's buffer;
		 * bionic itself truncates to 'PROP_NAME_MAX - 1' characters here.
		 */
		enum { PROP_NAME_MAX = 32 };
		Slot const &s = *(Slot const *)pi;
		if (name) {
			size_t i = 0;
			for (; i < PROP_NAME_MAX - 1 && s.name[i]; i++) name[i] = s.name[i];
			name[i] = 0;
		}
		return int(view().read(s, value));
	}

	void art___system_property_read_callback(void const *pi,
	                                         void (*cb)(void *, char const *, char const *, uint32_t),
	                                         void *cookie)
	{
		Slot const &s = *(Slot const *)pi;
		char value[Android_prop::LONG_VALUE_MAX];
		uint32_t serial = 0;
		view().read_full(s, value, &serial);
		cb(cookie, s.name, value, serial);
	}

	int art___system_property_foreach(void (*cb)(void const *, void *), void *cookie)
	{
		Table const &t = view();
		unsigned const n = t.count();
		for (unsigned i = 0; i < n; i++) cb(t.slot(i), cookie);
		return 0;
	}

	/* wait for 'pi' (or any property if null) to change from 'old' */
	bool art___system_property_wait(void const *pi, uint32_t old, uint32_t *new_serial,
	                                timespec const *timeout)
	{
		long const timeout_ms = timeout ? long(timeout->tv_sec * 1000 + timeout->tv_nsec / 1000000) : -1;
		if (prop_service_table())
			return prop_service_wait((Slot const *)pi, old, new_serial, timeout_ms);
		return local_wait((Slot const *)pi, old, new_serial, timeout_ms);
	}

	uint32_t art___system_property_serial(void const *pi) { return view().serial(*(Slot const *)pi); }
	uint32_t art___system_property_area_serial()           { return view().area_serial(); }
}


static Export const exports[] = {
	{ "__system_property_get",           (void *)art___system_property_get },
	{ "__system_property_set",           (void *)art___system_property_set },
	{ "__system_property_find",          (void *)art___system_property_find },
	{ "__system_property_read",          (void *)art___system_property_read },
	{ "__system_property_read_callback", (void *)art___system_property_read_callback },
	{ "__system_property_foreach",       (void *)art___system_property_foreach },
	{ "__system_property_serial",        (void *)art___system_property_serial },
	{ "__system_property_wait",          (void *)art___system_property_wait },
	{ "__system_property_area_serial",   (void *)art___system_property_area_serial },
};

Export_group Android_rt::prop_exports() { return { exports, sizeof(exports) / sizeof(exports[0]) }; }
