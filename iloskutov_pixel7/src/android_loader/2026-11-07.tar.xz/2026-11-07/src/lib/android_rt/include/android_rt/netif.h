/*
 * \brief  Network-interface control as rild's NetIfController uses it
 * \author Ivan Loskutov
 * \date   2026-10-04
 *
 * Linux lets a process configure an interface through ioctls on any
 * AF_INET / AF_INET6 datagram socket and list links and addresses through
 * an rtnetlink dump. rild does this to rmnetN when a data call comes up.
 * Here the interfaces are
 * names only (the loader's <net_interfaces>); no packet passes through this
 * code. 'Table' keeps what was set per interface so that a GET returns the
 * last SET, 'Netlink' answers every dump request with an empty dump.
 *
 * Free of Genode headers. Structures
 * are those of Linux on arm64, errors are Linux errno values.
 */

/*
 * SPDX-License-Identifier: MIT
 */

#ifndef _ANDROID_RT__NETIF_H_
#define _ANDROID_RT__NETIF_H_

#include <stdint.h>
#include <stdio.h>
#include <string.h>

namespace Android_rt { namespace Netif {

	enum {
		AF_UNIX_ = 1, AF_INET_ = 2, AF_INET6_ = 10, AF_NETLINK_ = 16,
		SOCK_DGRAM_ = 2, SOCK_RAW_ = 3, SOCK_TYPE_MASK = 0xf,
		NETLINK_ROUTE_ = 0,
	};

	enum {
		SIOCGIFFLAGS   = 0x8913, SIOCSIFFLAGS   = 0x8914,
		SIOCGIFADDR    = 0x8915, SIOCSIFADDR    = 0x8916,
		SIOCGIFNETMASK = 0x891b, SIOCSIFNETMASK = 0x891c,
		SIOCGIFMTU     = 0x8921, SIOCSIFMTU     = 0x8922,
		SIOCGIFINDEX   = 0x8933, SIOCDIFADDR    = 0x8936,
	};

	enum {
		IFF_UP = 0x1, IFF_LOOPBACK = 0x8, IFF_POINTOPOINT = 0x10,
		IFF_RUNNING = 0x40, IFF_NOARP = 0x80, IFF_MULTICAST = 0x1000,
	};

	enum {
		E_NOENT = 2, E_AGAIN = 11, E_FAULT = 14, E_NODEV = 19, E_INVAL = 22,
		E_NOTTY = 25, E_OPNOTSUPP = 95,
	};

	enum { NAME_LEN = 16, MSG_LEN = 96 };

	/* struct sockaddr_in as far as used */
	struct Sockaddr
	{
		uint16_t family;
		uint16_t port;
		uint8_t  addr[4];
		uint8_t  zero[8];
	};

	/* struct ifreq */
	struct Ifreq
	{
		char name[NAME_LEN];
		union {
			Sockaddr addr;
			int16_t  flags;
			int32_t  value;      /* ifr_ifindex, ifr_mtu */
			uint8_t  raw[24];
		};
	};

	/* struct in6_ifreq: the argument of SIOCSIFADDR / SIOCDIFADDR on AF_INET6 */
	struct In6_ifreq
	{
		uint8_t  addr[16];
		uint32_t prefixlen;
		int32_t  ifindex;
	};

	static_assert(sizeof(Ifreq) == 40, "struct ifreq of Linux arm64");
	static_assert(sizeof(In6_ifreq) == 24, "struct in6_ifreq");

	/**
	 * Copy the interface name of an ifreq (not necessarily terminated)
	 */
	inline void ifreq_name(Ifreq const &req, char out[NAME_LEN + 1])
	{
		memcpy(out, req.name, NAME_LEN);
		out[NAME_LEN] = 0;
	}

	/**
	 * State of the interfaces 1..count (index 1 is lo), as the last SETs
	 * left it. Initial values are those of an idle rmnetN on the Pixel 7:
	 * flags POINTOPOINT|NOARP|MULTICAST (0x1090), MTU 1500, no address.
	 */
	class Table
	{
		public:

			enum { MAX = 65 };

			struct State
			{
				uint8_t  addr[4];
				uint8_t  netmask[4];
				unsigned flags;
				int      mtu;
				bool     disable_ipv6;
			};

		private:

			State    _state[MAX] { };
			unsigned _count = 0;

			static void _init(State &s, bool lo)
			{
				s = State { };
				s.flags = lo ? unsigned(IFF_UP | IFF_LOOPBACK | IFF_RUNNING)
				             : unsigned(IFF_POINTOPOINT | IFF_NOARP | IFF_MULTICAST);
				s.mtu   = lo ? 65536 : 1500;
				if (lo) { s.addr[0] = 127; s.addr[3] = 1; s.netmask[0] = 255; }
			}

			static void _ipv4(char *out, unsigned cap, char const *what, uint8_t const a[4])
			{
				snprintf(out, cap, "%s %u.%u.%u.%u", what, a[0], a[1], a[2], a[3]);
			}

		public:

			/**
			 * (Re)create 'count' interfaces (including lo) in their initial state
			 */
			void reset(unsigned count)
			{
				_count = count < unsigned(MAX) ? count : unsigned(MAX);
				for (unsigned i = 0; i < _count; i++) _init(_state[i], i == 0);
			}

			unsigned count() const { return _count; }

			/**
			 * State of interface 'index' (1-based), nullptr if there is none
			 */
			State const *state(unsigned index) const
			{
				return (index >= 1 && index <= _count) ? &_state[index - 1] : nullptr;
			}

			/**
			 * ioctl on a control socket
			 *
			 * \param inet6  the socket is AF_INET6 (address requests take a
			 *               'struct in6_ifreq', which names the interface by
			 *               its index)
			 * \param index  index of the interface 'arg' names as 'struct
			 *               ifreq' (0: no such interface); the caller resolves
			 *               the name, also for requests that carry none
			 * \param msg    for a SET that succeeded: what was set, to be
			 *               logged by the caller ("" otherwise)
			 * \return 0 or a Linux errno
			 */
			int ioctl(bool inet6, unsigned long cmd, void *arg, unsigned index,
			          char msg[MSG_LEN])
			{
				msg[0] = 0;
				if (!arg) return E_FAULT;

				/* IPv6 addresses are accepted and not kept (IPv4 only so far) */
				if (inet6 && (cmd == SIOCSIFADDR || cmd == SIOCDIFADDR)) {
					In6_ifreq const &req6 = *(In6_ifreq const *)arg;
					if (req6.ifindex < 1 || unsigned(req6.ifindex) > _count) return E_NODEV;
					char hex[33];
					for (unsigned i = 0; i < 16; i++)
						snprintf(hex + 2*i, 3, "%02x", req6.addr[i]);
					snprintf(msg, MSG_LEN, "ipv6 addr %s %s/%u (not kept)",
					         cmd == SIOCSIFADDR ? "set" : "deleted", hex, req6.prefixlen);
					return 0;
				}

				switch (cmd) {
				case SIOCGIFFLAGS: case SIOCSIFFLAGS: case SIOCGIFADDR: case SIOCSIFADDR:
				case SIOCGIFNETMASK: case SIOCSIFNETMASK: case SIOCGIFMTU: case SIOCSIFMTU:
				case SIOCGIFINDEX:
					break;
				default:
					return E_NOTTY;   /* a request this table does not know */
				}

				if (index < 1 || index > _count) return E_NODEV;

				Ifreq &req = *(Ifreq *)arg;
				State &s   = _state[index - 1];

				auto get_addr = [&] (uint8_t const a[4]) {
					memset(&req.addr, 0, sizeof(req.addr));
					req.addr.family = AF_INET_;
					memcpy(req.addr.addr, a, 4);
				};

				switch (cmd) {

				case SIOCGIFINDEX: req.value = int32_t(index); return 0;

				case SIOCGIFFLAGS: req.flags = int16_t(s.flags); return 0;

				case SIOCSIFFLAGS: {
					/* RUNNING follows UP, as on a link that is always there */
					unsigned f = unsigned(uint16_t(req.flags)) & ~unsigned(IFF_RUNNING);
					if (f & IFF_UP) f |= IFF_RUNNING;
					s.flags = f;
					snprintf(msg, MSG_LEN, "%s (flags 0x%x)", (f & IFF_UP) ? "up" : "down", f);
					return 0;
				}

				case SIOCGIFADDR:    get_addr(s.addr);    return 0;
				case SIOCGIFNETMASK: get_addr(s.netmask); return 0;

				case SIOCSIFADDR:
					if (req.addr.family != AF_INET_) return E_INVAL;
					memcpy(s.addr, req.addr.addr, 4);
					_ipv4(msg, MSG_LEN, "addr", s.addr);
					return 0;

				case SIOCSIFNETMASK:
					if (req.addr.family != AF_INET_) return E_INVAL;
					memcpy(s.netmask, req.addr.addr, 4);
					_ipv4(msg, MSG_LEN, "netmask", s.netmask);
					return 0;

				case SIOCGIFMTU: req.value = s.mtu; return 0;

				case SIOCSIFMTU:
					if (req.value < 68 || req.value > 65535) return E_INVAL;
					s.mtu = req.value;
					snprintf(msg, MSG_LEN, "mtu %d", s.mtu);
					return 0;
				}
				return E_NOTTY;
			}

			/**
			 * Write to /proc/sys/net/ipv6/conf/<interface>/disable_ipv6
			 */
			int disable_ipv6(unsigned index, char const *text, unsigned long len,
			                 char msg[MSG_LEN])
			{
				msg[0] = 0;
				if (index < 1 || index > _count) return E_NODEV;
				if (!len || (text[0] != '0' && text[0] != '1')) return E_INVAL;
				_state[index - 1].disable_ipv6 = text[0] == '1';
				snprintf(msg, MSG_LEN, "disable_ipv6 %c", text[0]);
				return 0;
			}
	};


	/**
	 * Match "/proc/sys/net/ipv6/conf/<interface>/disable_ipv6"
	 *
	 * \return true with the interface name in 'name'
	 */
	inline bool proc_disable_ipv6(char const *path, char name[NAME_LEN + 1])
	{
		static char const prefix[] = "/proc/sys/net/ipv6/conf/";
		static char const suffix[] = "/disable_ipv6";

		unsigned long const plen = sizeof(prefix) - 1;
		if (!path || strncmp(path, prefix, plen)) return false;

		char const * const start = path + plen;
		char const * const slash = strchr(start, '/');
		if (!slash || slash == start || slash - start > NAME_LEN) return false;
		if (strcmp(slash, suffix)) return false;

		memcpy(name, start, (unsigned long)(slash - start));
		name[slash - start] = 0;
		return true;
	}


	/* struct nlmsghdr */
	struct Nlmsghdr
	{
		uint32_t len;
		uint16_t type;
		uint16_t flags;
		uint32_t seq;
		uint32_t pid;
	};

	enum {
		NLMSG_DONE_   = 3,
		NLM_F_REQUEST = 0x1, NLM_F_MULTI = 0x2, NLM_F_DUMP = 0x300,
		RTM_GETLINK   = 18, RTM_GETADDR = 22,
	};

	/**
	 * A NETLINK_ROUTE socket that knows no links and no addresses
	 *
	 * A dump request (RTM_GETLINK, RTM_GETADDR with NLM_F_DUMP) is answered
	 * by one NLMSG_DONE carrying the request's sequence number: an empty
	 * dump. rild reads a dump message by message until NLMSG_DONE, then
	 * sends the next request on the same socket. Other requests are refused.
	 */
	class Netlink
	{
		public:

			enum { QUEUE = 8, DONE_LEN = sizeof(Nlmsghdr) + 4 };

		private:

			uint32_t _seq[QUEUE] { };
			unsigned _count = 0;

		public:

			bool readable() const { return _count > 0; }

			/**
			 * \return 0 or a Linux errno
			 */
			int send(void const *buf, unsigned long len)
			{
				if (!buf || len < sizeof(Nlmsghdr)) return E_INVAL;

				Nlmsghdr hdr;
				memcpy(&hdr, buf, sizeof(hdr));
				if (hdr.len < sizeof(Nlmsghdr) || hdr.len > len) return E_INVAL;

				bool const dump = (hdr.flags & NLM_F_REQUEST)
				               && (hdr.flags & NLM_F_DUMP) == NLM_F_DUMP
				               && (hdr.type == RTM_GETLINK || hdr.type == RTM_GETADDR);
				if (!dump) return E_OPNOTSUPP;

				if (_count == QUEUE) return E_AGAIN;   /* answers not read */
				_seq[_count++] = hdr.seq;
				return 0;
			}

			/**
			 * Next message, cut to 'cap' bytes like a datagram
			 *
			 * \param peek  leave the message queued (MSG_PEEK)
			 * \param pid   port id of the socket (nlmsg_pid of the answer)
			 * \return number of bytes, or the negative Linux errno (-EAGAIN
			 *         if nothing is queued: a dump was not requested)
			 */
			long recv(void *buf, unsigned long cap, bool peek, uint32_t pid)
			{
				if (!_count) return -long(E_AGAIN);

				uint8_t msg[DONE_LEN] { };
				Nlmsghdr const hdr { DONE_LEN, NLMSG_DONE_, NLM_F_MULTI, _seq[0], pid };
				memcpy(msg, &hdr, sizeof(hdr));   /* payload: int 0 */

				unsigned long const n = cap < DONE_LEN ? cap : (unsigned long)DONE_LEN;
				if (n) memcpy(buf, msg, n);

				if (!peek) {
					for (unsigned i = 1; i < _count; i++) _seq[i - 1] = _seq[i];
					_count--;
				}
				return long(n);
			}
	};

} }

#endif /* _ANDROID_RT__NETIF_H_ */
