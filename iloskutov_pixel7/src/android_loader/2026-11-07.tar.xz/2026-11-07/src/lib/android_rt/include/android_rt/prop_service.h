/*
 * \brief  Session back end of the bionic property API
 * \author Ivan Loskutov
 * \date   2026-09-26
 */

/*
 * SPDX-License-Identifier: MIT
 */

#ifndef _ANDROID_RT__PROP_SERVICE_H_
#define _ANDROID_RT__PROP_SERVICE_H_

#include <android_prop/table.h>

namespace Android_rt {

	/**
	 * The service's table, or nullptr if the local back end is used
	 */
	Android_prop::Table const *prop_service_table();

	/**
	 * \return 0 or -1 (logged)
	 */
	int prop_service_set(char const *name, char const *value);

	/**
	 * Wait until the serial of 'pi' (or the area serial if null) differs
	 * from 'old'
	 *
	 * \param timeout_ms  -1: forever
	 * \return false on timeout
	 */
	bool prop_service_wait(Android_prop::Slot const *pi, uint32_t old,
	                       uint32_t *new_serial, long timeout_ms);
}

#endif /* _ANDROID_RT__PROP_SERVICE_H_ */
