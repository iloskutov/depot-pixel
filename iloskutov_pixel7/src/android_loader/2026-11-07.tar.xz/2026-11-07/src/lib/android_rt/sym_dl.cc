/*
 * \brief  bionic libdl on the loader's linker
 * \author Ivan Loskutov
 * \date   2026-09-25
 */

/*
 * SPDX-License-Identifier: MIT
 */

#include <android_rt/runtime.h>
#include <base/log.h>
#include <cpu/cache.h>
#include <util/string.h>

#include <pthread.h>
#include <stdio.h>
#include <string.h>

using namespace Android_rt;
using namespace Android_elf;

namespace {

	/*
	 * Recursive like bionic's g_dl_mutex: the constructors 'dlopen' runs may
	 * call dlopen/dlsym themselves
	 */
	struct Dl_mutex
	{
		pthread_mutex_t m { };

		Dl_mutex()
		{
			pthread_mutexattr_t a;
			pthread_mutexattr_init(&a);
			pthread_mutexattr_settype(&a, PTHREAD_MUTEX_RECURSIVE);
			pthread_mutex_init(&m, &a);
			pthread_mutexattr_destroy(&a);
		}
	};

	Dl_mutex &mutex() { static Dl_mutex m; return m; }

	/* handle of the libraries the runtime serves itself */
	char          runtime_handle;

	char          error_buf[512];
	bool          error_pending;

	void set_error(char const *prefix, char const *detail)
	{
		snprintf(error_buf, sizeof(error_buf), "%s%s", prefix, detail);
		error_pending = true;
	}

	int index_of(void *handle)
	{
		Linker &l = linker();
		for (unsigned i = 0; i < l.object_count(); i++)
			if (l.object(i) == handle) return int(i);
		return -1;
	}

	/* bionic's struct dl_phdr_info (LP64) */
	struct Phdr_info
	{
		uint64_t          addr;
		char const       *name;
		Elf64_Phdr const *phdr;
		uint16_t          phnum;
		unsigned long long adds, subs;
		size_t            tls_modid;
		void             *tls_data;
	};

	/* bionic's Dl_info */
	struct Dl_info { char const *fname; void *fbase; char const *sname; void *saddr; };
}


Android_rt::Dl_guard::Dl_guard()  { pthread_mutex_lock(&mutex().m); }
Android_rt::Dl_guard::~Dl_guard() { pthread_mutex_unlock(&mutex().m); }


extern "C" {

	void *art_dlopen(char const *name, int)
	{
		if (!name) return linker().program();

		Dl_guard guard { };
		Linker &l = linker();

		/* e.g. libc.so: never mapped, its symbols are the runtime's */
		char const *slash = strrchr(name, '/');
		if (l.replaced(slash ? slash + 1 : name)) return &runtime_handle;

		unsigned const first = l.object_count();

		Linker::Result r;
		Object *o = l.dlopen(name, r);
		if (!o) {
			/*
			 * Logged: a failing dlopen is a clean nullptr for the caller
			 * (e.g. rfsd's optional liboemnv.so, ENOENT on the device
			 * too), and the line lets a run script check that it was one.
			 */
			set_error("dlopen failed: ", l.error());
			Genode::log("android_rt: dlopen(\"", Genode::Cstring(name), "\") failed: ",
			            Genode::Cstring(l.error()));
			return nullptr;
		}
		if (l.object_count() == first) return o;          /* already loaded */

		/* new code must become visible to instruction fetch */
		for (unsigned i = first; i < l.object_count(); i++)
			Genode::cache_coherent(Genode::addr_t(l.object(i)->base()), l.object(i)->span());

		init_tls_of_new_objects(first);

		/* constructors of the new objects, dependencies first */
		l.for_each_init_order([&] (unsigned i) {
			if (i < first) return;
			void (**arr)(); size_t count;
			l.object(i)->init_array(arr, count);
			for (size_t k = 0; k < count; k++)
				if (arr[k] && arr[k] != (void (*)())-1) arr[k]();
		});
		return o;
	}

	void *art_dlsym(void *handle, char const *name)
	{
		Dl_guard guard { };
		Linker &l = linker();

		/* as for imports, the runtime's implementation comes first */
		void *addr = overrides().find(name);
		if (!addr && (!handle || handle == (void *)-1L)) {   /* RTLD_DEFAULT / RTLD_NEXT */
			addr = l.symbol_address(name, 0);
		} else if (!addr && handle != &runtime_handle) {
			/* the object and its dependencies only */
			int const i = index_of(handle);
			if (i >= 0) addr = l.tree_symbol_address(name, unsigned(i));
		}
		if (!addr) {
			set_error("undefined symbol: ", name);
		}
		return addr;
	}

	char *art_dlerror()
	{
		if (!error_pending) return nullptr;
		error_pending = false;
		return error_buf;
	}

	int art_dlclose(void *) { return 0; }

	int art_dladdr(void const *addr, Dl_info *info)
	{
		Linker &l = linker();
		int const i = l.object_at(addr);
		if (i < 0) return 0;
		info->fname = l.path(unsigned(i));
		info->fbase = l.object(unsigned(i))->base();
		info->sname = nullptr;
		info->saddr = nullptr;
		return 1;
	}

	int art_dl_iterate_phdr(int (*cb)(Phdr_info *, size_t, void *), void *data)
	{
		Linker &l = linker();
		for (unsigned i = 0; i < l.object_count(); i++) {
			Object const &o = *l.object(i);
			Phdr_info info { uint64_t(o.base()), l.path(i), o.phdrs(), uint16_t(o.phnum()),
			                 l.object_count(), 0, 0, nullptr };
			int const r = cb(&info, sizeof(info), data);
			if (r) return r;
		}
		return 0;
	}

	void *art_android_dlopen_ext(char const *name, int flags, void const *)
	{
		return art_dlopen(name, flags);
	}
}


static Export const exports[] = {
	{ "dlopen",             (void *)art_dlopen },
	{ "dlsym",              (void *)art_dlsym },
	{ "dlerror",            (void *)art_dlerror },
	{ "dlclose",            (void *)art_dlclose },
	{ "dladdr",             (void *)art_dladdr },
	{ "dl_iterate_phdr",    (void *)art_dl_iterate_phdr },
	{ "android_dlopen_ext", (void *)art_android_dlopen_ext },
};

Export_group Android_rt::dl_exports() { return { exports, sizeof(exports) / sizeof(exports[0]) }; }
