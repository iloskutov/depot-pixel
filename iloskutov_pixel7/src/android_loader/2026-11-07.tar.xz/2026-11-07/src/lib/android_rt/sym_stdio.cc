/*
 * \brief  bionic stdio on Genode: FILE objects and the standard streams
 * \author Ivan Loskutov
 * \date   2026-09-25
 *
 * bionic code sees FILE as opaque except for the stride of the legacy
 * '__sF' array (stdin/stdout/stderr = &__sF[0..2], sizeof(FILE) == 152).
 * The standard streams go to the Genode log line by line; other FILEs wrap
 * Genode libc FILEs.
 */

/*
 * SPDX-License-Identifier: MIT
 */

#include <android_rt/runtime.h>
#include <base/log.h>
#include <base/mutex.h>
#include <util/string.h>

#include <errno.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

using namespace Android_rt;

namespace {

	enum { BIONIC_FILE_SIZE = 152 };

	struct Bionic_file { char opaque[BIONIC_FILE_SIZE]; };

	/* a FILE handed to Android code: bionic-sized, Genode FILE behind it */
	struct Art_file { char opaque[BIONIC_FILE_SIZE]; FILE *genode; };

	struct Line_buffer
	{
		Genode::Mutex mutex { };
		char     buf[1024];
		unsigned len = 0;

		void _flush_locked()
		{
			if (!len) return;
			buf[len] = 0;
			Genode::log(Genode::Cstring(buf));   /* stderr too: one log keeps the order */
			len = 0;
		}

		void write(char const *s, size_t n)
		{
			Genode::Mutex::Guard guard(mutex);
			for (size_t i = 0; i < n; i++) {
				if (s[i] == '\n') { _flush_locked(); continue; }
				if (len == sizeof(buf) - 1) _flush_locked();
				buf[len++] = s[i];
			}
		}

		void flush() { Genode::Mutex::Guard guard(mutex); _flush_locked(); }
	};

	Line_buffer &out() { static Line_buffer b; return b; }
	Line_buffer &err() { static Line_buffer b; return b; }
}


extern "C" {

	Bionic_file art___sF[3];
	void *art_stdin  = &art___sF[0];
	void *art_stdout = &art___sF[1];
	void *art_stderr = &art___sF[2];
}


void Android_rt::flush_stdio() { out().flush(); err().flush(); }


/* index of a standard stream, -1 for other FILEs */
static int std_index(void const *f)
{
	for (int i = 0; i < 3; i++) if (f == &art___sF[i]) return i;
	return -1;
}

static FILE *genode_file(void *f) { return ((Art_file *)f)->genode; }

static Line_buffer *std_buffer(void *f)
{
	switch (std_index(f)) {
	case 1: return &out();
	case 2: return &err();
	default: return nullptr;
	}
}


extern "C" {

	int art_vfprintf(void *f, char const *fmt, va_list ap)
	{
		if (Line_buffer *lb = std_buffer(f)) {
			char buf[1024];
			int const n = vsnprintf(buf, sizeof(buf), fmt, ap);
			if (n > 0) lb->write(buf, (size_t)n < sizeof(buf) ? (size_t)n : sizeof(buf) - 1);
			return n;
		}
		if (std_index(f) == 0) return -1;
		return vfprintf(genode_file(f), fmt, ap);
	}

	int art_fprintf(void *f, char const *fmt, ...)
	{
		va_list ap; va_start(ap, fmt);
		int const n = art_vfprintf(f, fmt, ap);
		va_end(ap);
		return n;
	}

	int art_vprintf(char const *fmt, va_list ap) { return art_vfprintf(&art___sF[1], fmt, ap); }

	int art_printf(char const *fmt, ...)
	{
		va_list ap; va_start(ap, fmt);
		int const n = art_vfprintf(&art___sF[1], fmt, ap);
		va_end(ap);
		return n;
	}

	size_t art_fwrite(void const *p, size_t size, size_t n, void *f)
	{
		if (Line_buffer *lb = std_buffer(f)) { lb->write((char const *)p, size * n); return n; }
		if (std_index(f) == 0) return 0;
		return fwrite(p, size, n, genode_file(f));
	}

	int art_fputs(char const *s, void *f)
	{
		size_t const n = strlen(s);
		return art_fwrite(s, 1, n, f) == n ? 0 : -1;
	}

	int art_fputc(int c, void *f) { char ch = char(c); return art_fwrite(&ch, 1, 1, f) ? c : -1; }

	int art_putchar(int c) { return art_fputc(c, &art___sF[1]); }

	int art_puts(char const *s)
	{
		out().write(s, strlen(s));
		out().write("\n", 1);
		return 1;
	}

	int art_fflush(void *f)
	{
		if (!f) { flush_stdio(); return fflush(nullptr); }   /* all streams */
		if (std_index(f) > 0) { flush_stdio(); return 0; }
		if (std_index(f) == 0) return 0;
		return fflush(genode_file(f));
	}

	void *art_fopen(char const *path, char const *mode)
	{
		FILE *g = fopen(path, mode);
		if (!g) { set_errno_from_libc(); return nullptr; }
		Art_file *f = (Art_file *)calloc(1, sizeof(Art_file));
		f->genode = g;
		return f;
	}

	void *art_fdopen(int fd, char const *mode)
	{
		FILE *g = fdopen(fd, mode);
		if (!g) { set_errno_from_libc(); return nullptr; }
		Art_file *f = (Art_file *)calloc(1, sizeof(Art_file));
		f->genode = g;
		return f;
	}

	int art_fclose(void *f)
	{
		if (std_index(f) >= 0) return 0;
		int const r = fclose(genode_file(f));
		free(f);
		return r;
	}

	char *art_fgets(char *s, int n, void *f)
	{
		if (std_index(f) >= 0) return nullptr;
		return fgets(s, n, genode_file(f));
	}

	size_t art_fread(void *p, size_t size, size_t n, void *f)
	{
		if (std_index(f) >= 0) return 0;
		return fread(p, size, n, genode_file(f));
	}

	int  art_fgetc(void *f)                  { return std_index(f) >= 0 ? -1 : fgetc(genode_file(f)); }
	int  art_feof(void *f)                   { return std_index(f) >= 0 ? 0 : feof(genode_file(f)); }
	int  art_ferror(void *f)                 { return std_index(f) >= 0 ? 0 : ferror(genode_file(f)); }
	void art_clearerr(void *f)               { if (std_index(f) < 0) clearerr(genode_file(f)); }
	int  art_fseek(void *f, long o, int w)   { return std_index(f) >= 0 ? -1 : fseek(genode_file(f), o, w); }
	long art_ftell(void *f)                  { return std_index(f) >= 0 ? -1 : ftell(genode_file(f)); }
	void art_rewind(void *f)                 { if (std_index(f) < 0) rewind(genode_file(f)); }
	int  art_fileno(void *f)                 { int i = std_index(f); return i >= 0 ? i : fileno(genode_file(f)); }
	int  art_setvbuf(void *, char *, int, size_t) { return 0; }
	void art_setbuf(void *, char *) { }
	int  art_fseeko(void *f, off_t o, int w) { return std_index(f) >= 0 ? -1 : fseeko(genode_file(f), o, w); }
	off_t art_ftello(void *f)                { return std_index(f) >= 0 ? -1 : ftello(genode_file(f)); }
	int  art_ungetc(int c, void *f)          { return std_index(f) >= 0 ? -1 : ungetc(c, genode_file(f)); }

	int art_vfscanf(void *f, char const *fmt, va_list ap)
	{
		if (std_index(f) >= 0) return -1;
		return vfscanf(genode_file(f), fmt, ap);
	}

	int art_fscanf(void *f, char const *fmt, ...)
	{
		va_list ap; va_start(ap, fmt);
		int const n = art_vfscanf(f, fmt, ap);
		va_end(ap);
		return n;
	}
}


#define EXPORT(name) { #name, (void *)name }

static Export const exports[] = {
	{ "__sF",     (void *)art___sF },
	{ "stdin",    (void *)&art_stdin },
	{ "stdout",   (void *)&art_stdout },
	{ "stderr",   (void *)&art_stderr },
	{ "printf",   (void *)art_printf },
	{ "vprintf",  (void *)art_vprintf },
	{ "fprintf",  (void *)art_fprintf },
	{ "vfprintf", (void *)art_vfprintf },
	{ "fwrite",   (void *)art_fwrite },
	{ "fputs",    (void *)art_fputs },
	{ "fputc",    (void *)art_fputc },
	{ "putc",     (void *)art_fputc },
	{ "putchar",  (void *)art_putchar },
	{ "puts",     (void *)art_puts },
	{ "fflush",   (void *)art_fflush },
	{ "fopen",    (void *)art_fopen },
	{ "fdopen",   (void *)art_fdopen },
	{ "fclose",   (void *)art_fclose },
	{ "fgets",    (void *)art_fgets },
	{ "fread",    (void *)art_fread },
	{ "fgetc",    (void *)art_fgetc },
	{ "getc",     (void *)art_fgetc },
	{ "feof",     (void *)art_feof },
	{ "ferror",   (void *)art_ferror },
	{ "clearerr", (void *)art_clearerr },
	{ "fseek",    (void *)art_fseek },
	{ "ftell",    (void *)art_ftell },
	{ "rewind",   (void *)art_rewind },
	{ "fileno",   (void *)art_fileno },
	{ "setvbuf",  (void *)art_setvbuf },
	{ "setbuf",   (void *)art_setbuf },
	{ "fseeko",   (void *)art_fseeko },
	{ "ftello",   (void *)art_ftello },
	{ "ungetc",   (void *)art_ungetc },
	{ "fscanf",   (void *)art_fscanf },
	{ "vfscanf",  (void *)art_vfscanf },
	EXPORT(snprintf), EXPORT(vsnprintf), EXPORT(sprintf), EXPORT(vsprintf),
	EXPORT(asprintf), EXPORT(vasprintf), EXPORT(sscanf), EXPORT(vsscanf),
};

#undef EXPORT

Export_group Android_rt::stdio_exports() { return { exports, sizeof(exports) / sizeof(exports[0]) }; }
