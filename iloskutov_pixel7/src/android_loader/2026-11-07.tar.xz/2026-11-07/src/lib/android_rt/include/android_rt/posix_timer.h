/*
 * \brief  POSIX per-process timers (timer_create and friends): the table
 * \author Ivan Loskutov
 * \date   2026-10-04
 *
 * Which timers exist, when each one expires next, and which have expired
 * at a given time. The waiting and the notification are the runtime's
 * (sym_signal.cc). Times are milliseconds of one monotonic clock. Free of
 * Genode headers.
 */

/*
 * SPDX-License-Identifier: MIT
 */

#ifndef _ANDROID_RT__POSIX_TIMER_H_
#define _ANDROID_RT__POSIX_TIMER_H_

#include <stdint.h>

namespace Android_rt {

	class Posix_timers
	{
		public:

			enum { MAX = 32 };

			/* what to do at expiry: a signal with a value, or a function */
			struct Notify
			{
				int      signo;           /* 0: none */
				uint64_t value;           /* sigev_value */
				void   (*function)(uint64_t);   /* SIGEV_THREAD, else nullptr */
			};

		private:

			struct Timer
			{
				bool     used;
				bool     armed;
				int64_t  deadline_ms;
				int64_t  interval_ms;     /* 0: one shot */
				Notify   notify;
			};

			Timer _timers[MAX] { };

			Timer *_lookup(int id)
			{
				return (id >= 1 && id <= MAX && _timers[id - 1].used) ? &_timers[id - 1] : nullptr;
			}

		public:

			/**
			 * \return id >= 1, or 0 if the table is full
			 */
			int create(Notify const &notify)
			{
				for (int i = 0; i < MAX; i++) {
					if (_timers[i].used) continue;
					_timers[i] = Timer { true, false, 0, 0, notify };
					return i + 1;
				}
				return 0;
			}

			bool destroy(int id)
			{
				Timer *t = _lookup(id);
				if (!t) return false;
				t->used = false;
				return true;
			}

			/**
			 * Arm (value_ms > 0, relative to 'now_ms') or disarm (0)
			 *
			 * \param old_left_ms  time that was left before, 0 if disarmed
			 */
			bool set(int id, int64_t now_ms, int64_t value_ms, int64_t interval_ms,
			         int64_t *old_left_ms = nullptr)
			{
				Timer *t = _lookup(id);
				if (!t) return false;
				if (old_left_ms)
					*old_left_ms = !t->armed ? 0
					             : t->deadline_ms > now_ms ? t->deadline_ms - now_ms : 1;
				t->armed       = value_ms > 0;
				t->deadline_ms = now_ms + value_ms;
				t->interval_ms = interval_ms > 0 ? interval_ms : 0;
				return true;
			}

			/**
			 * Take one timer that has expired at 'now_ms': a one-shot timer
			 * is disarmed, a periodic one moves to its next expiry after now
			 *
			 * \param id  set to the id of the timer, if not null
			 * \return false if none has expired
			 */
			bool expired(int64_t now_ms, Notify &out, int *id = nullptr)
			{
				for (Timer &t : _timers) {
					if (!t.used || !t.armed || t.deadline_ms > now_ms) continue;
					out = t.notify;
					if (id) *id = int(&t - _timers) + 1;
					if (t.interval_ms) {
						int64_t const missed = (now_ms - t.deadline_ms) / t.interval_ms;
						t.deadline_ms += (missed + 1) * t.interval_ms;
					} else {
						t.armed = false;
					}
					return true;
				}
				return false;
			}

			/**
			 * Milliseconds from 'now_ms' to the next expiry (0: due), -1 if
			 * no timer is armed
			 */
			int64_t next_in(int64_t now_ms) const
			{
				int64_t best = -1;
				for (Timer const &t : _timers) {
					if (!t.used || !t.armed) continue;
					int64_t const left = t.deadline_ms > now_ms ? t.deadline_ms - now_ms : 0;
					if (best < 0 || left < best) best = left;
				}
				return best;
			}
	};
}

#endif /* _ANDROID_RT__POSIX_TIMER_H_ */
