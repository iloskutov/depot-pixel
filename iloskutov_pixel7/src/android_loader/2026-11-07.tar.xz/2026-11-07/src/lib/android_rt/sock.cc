/*
 * \brief  Sockets the Android runtime serves itself (interface control, rtnetlink)
 * \author Ivan Loskutov
 * \date   2026-10-04
 *
 * See android_rt/sock.h and android_rt/netif.h. Every SET is logged as
 * "android_rt: netif <interface>: <what>".
 */

/*
 * SPDX-License-Identifier: MIT
 */

#include <android_rt/runtime.h>
#include <android_rt/sock.h>
#include <android_rt/netif.h>
#include <android_rt/io.h>
#include <base/log.h>
#include <base/mutex.h>

#include <string.h>

using namespace Android_rt;

namespace {

	struct Sock_fd
	{
		enum Kind { FREE, CTL, CTL6, NETLINK, PROC_DISABLE_IPV6 };

		Kind           kind    = FREE;
		Netif::Netlink netlink { };   /* NETLINK */
		unsigned       index   = 0;   /* PROC_DISABLE_IPV6: interface */
	};

	Genode::Mutex mutex;
	Sock_fd       fds[SOCK_FD_COUNT];
	Netif::Table  table;

	Sock_fd *lookup(int fd)
	{
		if (!is_sock_fd(fd)) return nullptr;
		Sock_fd &s = fds[fd - SOCK_FD_BASE];
		return s.kind != Sock_fd::FREE ? &s : nullptr;
	}

	int alloc_locked(Sock_fd::Kind kind)
	{
		for (int i = 0; i < SOCK_FD_COUNT; i++)
			if (fds[i].kind == Sock_fd::FREE) {
				fds[i] = Sock_fd { };
				fds[i].kind = kind;
				return SOCK_FD_BASE + i;
			}
		set_errno(24);                               /* EMFILE */
		return -1;
	}

	/* the interface list is configured once, before the program starts */
	Netif::Table &table_locked()
	{
		if (table.count() != net_interface_count()) table.reset(net_interface_count());
		return table;
	}

	void log_set(unsigned index, char const *msg)
	{
		if (!msg[0]) return;
		char const * const name = net_interface_name(index);
		Genode::log("android_rt: netif ", Genode::Cstring(name ? name : "?"), ": ",
		            Genode::Cstring(msg));
	}
}


int Android_rt::sock_socket(int domain, int type, int protocol)
{
	using namespace Netif;

	int const kind_of_type = type & SOCK_TYPE_MASK;

	Sock_fd::Kind kind;
	if      (domain == AF_INET_    && kind_of_type == SOCK_DGRAM_) kind = Sock_fd::CTL;
	else if (domain == AF_INET6_   && kind_of_type == SOCK_DGRAM_) kind = Sock_fd::CTL6;
	else if (domain == AF_NETLINK_ && kind_of_type == SOCK_RAW_
	      && protocol == NETLINK_ROUTE_)                           kind = Sock_fd::NETLINK;
	else return -2;

	Genode::Mutex::Guard guard(mutex);
	return alloc_locked(kind);
}


int Android_rt::sock_open(char const *path, int)
{
	char name[Netif::NAME_LEN + 1];
	if (!Netif::proc_disable_ipv6(path, name)) return -2;

	unsigned const index = net_interface_index(name);
	if (!index) { set_errno(Netif::E_NOENT); return -1; }

	Genode::Mutex::Guard guard(mutex);
	int const fd = alloc_locked(Sock_fd::PROC_DISABLE_IPV6);
	if (fd >= 0) fds[fd - SOCK_FD_BASE].index = index;
	return fd;
}


int Android_rt::sock_ioctl(int fd, unsigned long cmd, void *arg)
{
	char     msg[Netif::MSG_LEN] { };
	unsigned index = 0;
	int      err   = 0;
	{
		Genode::Mutex::Guard guard(mutex);
		Sock_fd *s = lookup(fd);
		if (!s) { set_errno(9); return -1; }                    /* EBADF */

		if (s->kind != Sock_fd::CTL && s->kind != Sock_fd::CTL6) {
			err = Netif::E_NOTTY;
		} else if (!arg) {
			err = Netif::E_FAULT;
		} else {
			bool const inet6 = s->kind == Sock_fd::CTL6;
			if (inet6 && (cmd == Netif::SIOCSIFADDR || cmd == Netif::SIOCDIFADDR)) {
				index = unsigned(((Netif::In6_ifreq const *)arg)->ifindex);
			} else {
				char name[Netif::NAME_LEN + 1];
				Netif::ifreq_name(*(Netif::Ifreq const *)arg, name);
				index = net_interface_index(name);
			}
			err = table_locked().ioctl(inet6, cmd, arg, index, msg);
		}
	}

	if (err == Netif::E_NOTTY)
		Genode::warning("android_rt: ioctl(", fd, ", ", Genode::Hex(cmd),
		                ") on a socket not supported");
	if (err) { set_errno(err); return -1; }

	log_set(index, msg);
	return 0;
}


ssize_t Android_rt::sock_send(int fd, void const *buf, size_t n)
{
	int err = 0;
	{
		Genode::Mutex::Guard guard(mutex);
		Sock_fd *s = lookup(fd);
		if (!s) { set_errno(9); return -1; }
		if (s->kind != Sock_fd::NETLINK) err = 13;              /* EACCES, as before */
		else                             err = s->netlink.send(buf, n);
	}
	if (err == Netif::E_OPNOTSUPP)
		Genode::warning("android_rt: netlink request on fd ", fd, " is no link or address dump, refused");
	if (err == 13)
		Genode::warning("android_rt: send on socket fd ", fd, " denied");
	if (err) { set_errno(err); return -1; }

	io_notify();
	return ssize_t(n);
}


ssize_t Android_rt::sock_recv(int fd, void *buf, size_t n, int flags)
{
	enum { MSG_PEEK_ = 2, MSG_TRUNC_ = 0x20 };

	long r = 0;
	{
		Genode::Mutex::Guard guard(mutex);
		Sock_fd *s = lookup(fd);
		if (!s) { set_errno(9); return -1; }
		if (s->kind != Sock_fd::NETLINK) r = -13;
		else r = s->netlink.recv(buf, n, flags & MSG_PEEK_, 1000 /* getpid() */);
	}
	if (r == -13)
		Genode::warning("android_rt: receive on socket fd ", fd, " denied");
	if (r == -long(Netif::E_AGAIN))
		Genode::warning("android_rt: receive on netlink fd ", fd, " without a pending dump");
	if (r < 0) { set_errno(int(-r)); return -1; }

	/* MSG_TRUNC asks for the real length of the datagram */
	if ((flags & MSG_TRUNC_) && r < long(Netif::Netlink::DONE_LEN))
		r = Netif::Netlink::DONE_LEN;
	return ssize_t(r);
}


ssize_t Android_rt::sock_read(int fd, void *buf, size_t n)
{
	Sock_fd::Kind kind = Sock_fd::FREE;
	{
		Genode::Mutex::Guard guard(mutex);
		if (Sock_fd *s = lookup(fd)) kind = s->kind;
	}
	if (kind == Sock_fd::NETLINK) return sock_recv(fd, buf, n, 0);
	set_errno(kind == Sock_fd::FREE ? 9 : 22);                  /* EBADF, EINVAL */
	return -1;
}


ssize_t Android_rt::sock_write(int fd, void const *buf, size_t n)
{
	char     msg[Netif::MSG_LEN] { };
	unsigned index = 0;
	{
		Genode::Mutex::Guard guard(mutex);
		Sock_fd *s = lookup(fd);
		if (!s) { set_errno(9); return -1; }
		if (s->kind == Sock_fd::PROC_DISABLE_IPV6) {
			index = s->index;
			int const err = table_locked().disable_ipv6(index, (char const *)buf, n, msg);
			if (err) { set_errno(err); return -1; }
		}
	}
	if (index) { log_set(index, msg); return ssize_t(n); }
	return sock_send(fd, buf, n);
}


int Android_rt::sock_close(int fd)
{
	Genode::Mutex::Guard guard(mutex);
	Sock_fd *s = lookup(fd);
	if (!s) { set_errno(9); return -1; }
	s->kind = Sock_fd::FREE;
	return 0;
}


unsigned Android_rt::sock_ready(int fd)
{
	Genode::Mutex::Guard guard(mutex);
	Sock_fd *s = lookup(fd);
	if (!s) return 8;
	return (s->kind == Sock_fd::NETLINK && s->netlink.readable() ? 1u : 0u) | 2u;
}
