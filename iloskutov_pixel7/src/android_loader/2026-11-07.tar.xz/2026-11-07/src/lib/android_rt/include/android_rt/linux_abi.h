/*
 * \brief  Linux/bionic ABI values that differ from Genode's libc (FreeBSD)
 * \author Ivan Loskutov
 * \date   2026-09-25
 */

/*
 * SPDX-License-Identifier: MIT
 */

#ifndef _ANDROID_RT__LINUX_ABI_H_
#define _ANDROID_RT__LINUX_ABI_H_

#include <stdint.h>

namespace Linux {

	/* struct stat of arm64 (asm-generic), 128 bytes */
	struct Stat
	{
		uint64_t st_dev, st_ino;
		uint32_t st_mode, st_nlink, st_uid, st_gid;
		uint64_t st_rdev, pad1;
		int64_t  st_size;
		int32_t  st_blksize, pad2;
		int64_t  st_blocks;
		int64_t  st_atime_sec, st_atime_nsec;
		int64_t  st_mtime_sec, st_mtime_nsec;
		int64_t  st_ctime_sec, st_ctime_nsec;
		uint32_t unused[2];
	};
	static_assert(sizeof(Stat) == 128, "Linux arm64 struct stat is 128 bytes");

	/* open() flags of arm64 */
	enum : int {
		OPEN_ACCMODE = 3, OPEN_CREAT = 0100, OPEN_EXCL = 0200, OPEN_NOCTTY = 0400,
		OPEN_TRUNC = 01000, OPEN_APPEND = 02000, OPEN_NONBLOCK = 04000,
		OPEN_DIRECTORY = 040000, OPEN_NOFOLLOW = 0100000, OPEN_CLOEXEC = 02000000 };

	/* FreeBSD errno -> Linux errno */
	inline int errno_from_freebsd(int e)
	{
		switch (e) {
		case 11: return 35;    /* EDEADLK */
		case 35: return 11;    /* EAGAIN */
		case 36: return 115;   /* EINPROGRESS */
		case 37: return 114;   /* EALREADY */
		case 38: return 88;    /* ENOTSOCK */
		case 39: return 89;    /* EDESTADDRREQ */
		case 40: return 90;    /* EMSGSIZE */
		case 41: return 91;    /* EPROTOTYPE */
		case 42: return 92;    /* ENOPROTOOPT */
		case 43: return 93;    /* EPROTONOSUPPORT */
		case 44: return 94;    /* ESOCKTNOSUPPORT */
		case 45: return 95;    /* EOPNOTSUPP */
		case 46: return 96;    /* EPFNOSUPPORT */
		case 47: return 97;    /* EAFNOSUPPORT */
		case 48: return 98;    /* EADDRINUSE */
		case 49: return 99;    /* EADDRNOTAVAIL */
		case 50: return 100;   /* ENETDOWN */
		case 51: return 101;   /* ENETUNREACH */
		case 52: return 102;   /* ENETRESET */
		case 53: return 103;   /* ECONNABORTED */
		case 54: return 104;   /* ECONNRESET */
		case 55: return 105;   /* ENOBUFS */
		case 56: return 106;   /* EISCONN */
		case 57: return 107;   /* ENOTCONN */
		case 58: return 108;   /* ESHUTDOWN */
		case 59: return 109;   /* ETOOMANYREFS */
		case 60: return 110;   /* ETIMEDOUT */
		case 61: return 111;   /* ECONNREFUSED */
		case 62: return 40;    /* ELOOP */
		case 63: return 36;    /* ENAMETOOLONG */
		case 64: return 112;   /* EHOSTDOWN */
		case 65: return 113;   /* EHOSTUNREACH */
		case 66: return 39;    /* ENOTEMPTY */
		case 68: return 87;    /* EUSERS */
		case 69: return 122;   /* EDQUOT */
		case 70: return 116;   /* ESTALE */
		case 71: return 66;    /* EREMOTE */
		case 77: return 37;    /* ENOLCK */
		case 78: return 38;    /* ENOSYS */
		case 82: return 43;    /* EIDRM */
		case 83: return 42;    /* ENOMSG */
		case 84: return 75;    /* EOVERFLOW */
		case 85: return 125;   /* ECANCELED */
		case 86: return 84;    /* EILSEQ */
		case 89: return 74;    /* EBADMSG */
		case 90: return 72;    /* EMULTIHOP */
		case 91: return 67;    /* ENOLINK */
		case 92: return 71;    /* EPROTO */
		case 95: return 131;   /* ENOTRECOVERABLE */
		case 96: return 130;   /* EOWNERDEAD */
		default: return e <= 34 ? e : 5;   /* 1..34 are identical, the rest has no Linux value: EIO */
		}
	}
}

#endif /* _ANDROID_RT__LINUX_ABI_H_ */
