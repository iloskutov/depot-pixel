/*
 * \brief  bionic string, memory, ctype and number-conversion functions
 * \author Ivan Loskutov
 * \date   2026-09-25
 *
 * Pure functions whose ABI is the same on bionic and Genode's libc are
 * exported directly. Only errno-reporting conversions get a wrapper.
 */

/*
 * SPDX-License-Identifier: MIT
 */

#include <android_rt/runtime.h>

#include <ctype.h>
#include <errno.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <wchar.h>

using namespace Android_rt;

extern "C" {

	long art_strtol(char const *s, char **e, int b)
	{ errno = 0; long r = strtol(s, e, b); if (errno) set_errno_from_libc(); return r; }

	unsigned long art_strtoul(char const *s, char **e, int b)
	{ errno = 0; unsigned long r = strtoul(s, e, b); if (errno) set_errno_from_libc(); return r; }

	long long art_strtoll(char const *s, char **e, int b)
	{ errno = 0; long long r = strtoll(s, e, b); if (errno) set_errno_from_libc(); return r; }

	unsigned long long art_strtoull(char const *s, char **e, int b)
	{ errno = 0; unsigned long long r = strtoull(s, e, b); if (errno) set_errno_from_libc(); return r; }

	double art_strtod(char const *s, char **e)
	{ errno = 0; double r = strtod(s, e); if (errno) set_errno_from_libc(); return r; }

	int art_posix_memalign(void **p, size_t align, size_t size)
	{
		int const err = posix_memalign(p, align, size);
		return err ? (err == ENOMEM ? 12 : 22) : 0;
	}

	void *art_memalign(size_t align, size_t size)
	{
		void *p = nullptr;
		return posix_memalign(&p, align < sizeof(void *) ? sizeof(void *) : align, size) ? nullptr : p;
	}
}


#define EXPORT(name) { #name, (void *)name }

static Export const exports[] = {
	EXPORT(memcpy), EXPORT(memmove), EXPORT(memset), EXPORT(memcmp), EXPORT(memchr),
	EXPORT(strlen), EXPORT(strnlen), EXPORT(strcmp), EXPORT(strncmp), EXPORT(strcpy),
	EXPORT(strncpy), EXPORT(strcat), EXPORT(strncat), EXPORT(strchr), EXPORT(strrchr),
	EXPORT(strstr), EXPORT(strcspn), EXPORT(strspn), EXPORT(strpbrk), EXPORT(strdup),
	EXPORT(strndup), EXPORT(strtok), EXPORT(strtok_r), EXPORT(strcasecmp), EXPORT(strncasecmp),
	EXPORT(strlcpy), EXPORT(strlcat), EXPORT(strsep), EXPORT(strcoll),
	EXPORT(malloc), EXPORT(free), EXPORT(calloc), EXPORT(realloc),
	EXPORT(atoi), EXPORT(atol), EXPORT(atoll), EXPORT(abs), EXPORT(labs),
	EXPORT(qsort), EXPORT(bsearch),
	EXPORT(isalpha), EXPORT(isdigit), EXPORT(isspace), EXPORT(isalnum), EXPORT(isupper),
	EXPORT(islower), EXPORT(isxdigit), EXPORT(isprint), EXPORT(ispunct), EXPORT(iscntrl),
	EXPORT(toupper), EXPORT(tolower),
	EXPORT(strtof), EXPORT(strtold),
	EXPORT(wcslen), EXPORT(wmemchr), EXPORT(wmemcmp), EXPORT(wmemcpy), EXPORT(wmemmove),
	EXPORT(wmemset), EXPORT(wcscmp), EXPORT(wcsncmp),
	{ "strtol",         (void *)art_strtol },
	{ "strtoul",        (void *)art_strtoul },
	{ "strtoll",        (void *)art_strtoll },
	{ "strtoull",       (void *)art_strtoull },
	{ "strtod",         (void *)art_strtod },
	{ "posix_memalign", (void *)art_posix_memalign },
	{ "memalign",       (void *)art_memalign },
	{ "aligned_alloc",  (void *)art_memalign },
};

#undef EXPORT

Export_group Android_rt::string_exports() { return { exports, sizeof(exports) / sizeof(exports[0]) }; }
