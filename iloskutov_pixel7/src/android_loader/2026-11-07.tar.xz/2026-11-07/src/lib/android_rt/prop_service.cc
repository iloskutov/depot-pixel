/*
 * \brief  Session back end of the bionic property API
 * \author Ivan Loskutov
 * \date   2026-09-26
 *
 * Reads go to the server's table, mapped read-only. A waiter arms the
 * session (one signal after the next set by anyone) and sleeps on the
 * runtime's io condition. The session is re-armed only after its signal
 * arrived (the io thread marks the Io_signal stale), so a waiter woken by
 * other io activity does not call the server -- no polling.
 * 'armed' and the stale flag are process-wide: whichever waiting thread
 * sees the signal first re-arms for all of them.
 */

/*
 * SPDX-License-Identifier: MIT
 */

#include <android_rt/runtime.h>
#include <android_rt/io.h>
#include <android_rt/prop_service.h>
#include <android_property_session/android_property_session.h>
#include <base/log.h>
#include <base/mutex.h>
#include <try_connection.h>
#include <util/construct_at.h>

#include <stdlib.h>
#include <string.h>

using namespace Android_rt;

namespace {

	using Session    = Android_property_session::Session;
	using Connection = Genode_pixel::Try_connection<Session, Android_property_session::Session_client>;

	struct Service : Genode::Noncopyable
	{
		Connection            conn { Android_rt::env() };
		Android_prop::Table  *table = nullptr;
		Io_signal             signal { };
		Genode::Mutex         arm_mutex { };
		bool                  armed = false;
	};

	Service *service;

	template <typename T>
	T *alloc_construct(auto &&... args)
	{
		void *p = ::malloc(sizeof(T));
		return p ? Genode::construct_at<T>(p, args...) : nullptr;
	}
}


bool Android_rt::use_property_service()
{
	Service *s = alloc_construct<Service>();
	if (!s) { Genode::error("android_rt: no memory for the property service"); return false; }

	switch (s->conn.open("properties")) {
	case Connection::Result::OK: break;
	case Connection::Result::DENIED:
		Genode::error("android_rt: <property_service/>: Android_property session denied "
		              "(no route, or no matching <policy> in android_prop)");
		return false;
	case Connection::Result::FAILED:
		Genode::error("android_rt: <property_service/>: Android_property session request failed");
		return false;
	}

	void *mem = Android_rt::env().rm().attach(s->conn.client().table(), {
		.size = { }, .offset = { }, .use_at = { }, .at = { },
		.executable = false, .writeable = false
	}).convert<void *>(
		[&] (Genode::Env::Local_rm::Attachment &a) { a.deallocate = false; return a.ptr; },
		[&] (Genode::Env::Local_rm::Error)          { return (void *)nullptr; });
	if (!mem) { Genode::error("android_rt: cannot attach the property table"); return false; }

	s->table = alloc_construct<Android_prop::Table>(mem);
	if (!s->table || !s->table->valid()) {
		Genode::error("android_rt: property table has a wrong magic number or version");
		return false;
	}

	s->conn.client().wait_sigh(io_manage(s->signal));
	service = s;
	Genode::log("android_rt: property service with ", s->table->count(), " properties");
	return true;
}


Android_prop::Table const *Android_rt::prop_service_table() { return service ? service->table : nullptr; }


int Android_rt::prop_service_set(char const *name, char const *value)
{
	if (::strlen(name) >= Android_prop::NAME_MAX_LEN ||
	    ::strlen(value) >= Session::SET_VALUE_MAX - 1) {
		Genode::warning("android_rt: setprop ", Genode::Cstring(name), ": name or value too long");
		return -1;
	}

	Session::Set_result r = Session::Set_result::DENIED;
	try {
		r = service->conn.client().set(Session::Name(Genode::Cstring(name)),
		                               Session::Value(Genode::Cstring(value)));
	} catch (...) {
		Genode::error("android_rt: setprop ", Genode::Cstring(name), ": property service unreachable");
		return -1;
	}

	switch (r) {
	case Session::Set_result::OK:      return 0;
	case Session::Set_result::DENIED:  Genode::warning("android_rt: setprop ", Genode::Cstring(name), ": denied by android_prop"); break;
	case Session::Set_result::INVALID: Genode::warning("android_rt: setprop ", Genode::Cstring(name), ": invalid name or value"); break;
	case Session::Set_result::FULL:    Genode::warning("android_rt: setprop ", Genode::Cstring(name), ": property table full"); break;
	}
	return -1;
}


bool Android_rt::prop_service_wait(Android_prop::Slot const *pi, uint32_t old,
                                   uint32_t *new_serial, long timeout_ms)
{
	Android_prop::Table const &t = *service->table;
	long const deadline = timeout_ms < 0 ? -1 : io_now_ms() + timeout_ms;

	for (;;) {
		unsigned const gen = io_generation();   /* before the check: no lost wake-up */
		{
			Genode::Mutex::Guard guard(service->arm_mutex);
			if (io_take_stale(service->signal)) service->armed = false;
			if (!service->armed) {
				try { service->conn.client().arm(); }
				catch (...) {
					Genode::error("android_rt: property wait: property service unreachable");
					return false;
				}
				service->armed = true;
			}
		}

		uint32_t const cur = pi ? t.serial(*pi) : t.area_serial();
		if (cur != old) { if (new_serial) *new_serial = cur; return true; }

		int wait_ms = -1;
		if (deadline >= 0) {
			long const left = deadline - io_now_ms();
			if (left <= 0) return false;
			wait_ms = int(left);
		}
		io_wait(gen, wait_ms);
	}
}
