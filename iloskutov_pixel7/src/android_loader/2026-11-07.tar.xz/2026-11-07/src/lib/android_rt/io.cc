/*
 * \brief  Runtime-wide io condition, io thread, Genode environment
 * \author Ivan Loskutov
 * \date   2026-09-26
 */

/*
 * SPDX-License-Identifier: MIT
 */

#include <android_rt/runtime.h>
#include <android_rt/io.h>
#include <util/reconstructible.h>

#include <pthread.h>
#include <time.h>
#include <unistd.h>

using namespace Android_rt;

namespace {

	Genode::Env    *genode_env;
	pthread_mutex_t io_mutex;
	pthread_cond_t  io_cond;
	unsigned        generation;

	Genode::Constructible<Genode::Signal_receiver> receiver;

	void *io_thread(void *)
	{
		for (;;) {
			Genode::Signal s = receiver->wait_for_signal();
			if (Io_signal *ctx = static_cast<Io_signal *>(s.context()))
				__atomic_store_n(&ctx->stale, 1u, __ATOMIC_RELEASE);
			io_notify();
		}
		return nullptr;
	}
}


void Android_rt::init_genode(Genode::Env &e)
{
	genode_env = &e;

	pthread_mutex_init(&io_mutex, nullptr);
	pthread_condattr_t attr;
	pthread_condattr_init(&attr);
	pthread_condattr_setclock(&attr, CLOCK_MONOTONIC);
	pthread_cond_init(&io_cond, &attr);
	pthread_condattr_destroy(&attr);

	receiver.construct();
	pthread_t t;
	if (pthread_create(&t, nullptr, io_thread, nullptr) == 0) {
		pthread_detach(t);
	} else {
		/*
		 * Without the io thread, chardev readiness signals never arrive and
		 * every future 'io_wait()' on them would block forever: fatal, not a
		 * degraded mode.
		 */
		Genode::error("android_rt: cannot start the io thread");
		::_exit(1);
	}
}


Genode::Env &Android_rt::env() { return *genode_env; }

unsigned Android_rt::io_generation() { return __atomic_load_n(&generation, __ATOMIC_ACQUIRE); }


void Android_rt::io_notify()
{
	pthread_mutex_lock(&io_mutex);
	__atomic_add_fetch(&generation, 1u, __ATOMIC_ACQ_REL);
	pthread_cond_broadcast(&io_cond);
	pthread_mutex_unlock(&io_mutex);
}


long Android_rt::io_now_ms()
{
	timespec ts { };
	clock_gettime(CLOCK_MONOTONIC, &ts);
	return long(ts.tv_sec) * 1000 + ts.tv_nsec / 1000000;
}


bool Android_rt::io_wait(unsigned seen, int timeout_ms)
{
	timespec deadline { };
	if (timeout_ms > 0) {
		clock_gettime(CLOCK_MONOTONIC, &deadline);
		deadline.tv_sec  += timeout_ms / 1000;
		deadline.tv_nsec += long(timeout_ms % 1000) * 1000000;
		if (deadline.tv_nsec >= 1000000000) { deadline.tv_sec++; deadline.tv_nsec -= 1000000000; }
	}

	pthread_mutex_lock(&io_mutex);
	int r = 0;
	while (io_generation() == seen && r == 0 && timeout_ms != 0)
		r = timeout_ms < 0 ? pthread_cond_wait(&io_cond, &io_mutex)
		                   : pthread_cond_timedwait(&io_cond, &io_mutex, &deadline);
	bool const changed = io_generation() != seen;
	pthread_mutex_unlock(&io_mutex);
	return changed;
}


Genode::Signal_context_capability Android_rt::io_manage(Io_signal &s) { return receiver->manage(s); }

void Android_rt::io_dissolve(Io_signal &s) { receiver->dissolve(s); }
