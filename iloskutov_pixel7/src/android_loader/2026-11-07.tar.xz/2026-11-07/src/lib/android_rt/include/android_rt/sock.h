/*
 * \brief  Sockets the Android runtime serves itself (interface control, rtnetlink)
 * \author Ivan Loskutov
 * \date   2026-10-04
 *
 * Only what rild's NetIfController needs to configure rmnetN for a data
 * call (android_rt/netif.h): AF_INET / AF_INET6 datagram sockets as handles
 * for the SIOC*IF* ioctls, a NETLINK_ROUTE socket that answers dumps with
 * an empty list, and /proc/sys/net/ipv6/conf/<if>/disable_ipv6. No socket
 * carries data; every other socket() is refused as before.
 *
 * The descriptors live in their own range above the device descriptors
 * (dev.h), so the 60 control sockets rild opens take no slot there.
 */

/*
 * SPDX-License-Identifier: MIT
 */

#ifndef _ANDROID_RT__SOCK_H_
#define _ANDROID_RT__SOCK_H_

#include <android_rt/dev.h>

namespace Android_rt {

	enum { SOCK_FD_BASE = int(DEV_FD_BASE) + int(DEV_FD_COUNT), SOCK_FD_COUNT = 128 };

	/* below FD_SETSIZE (1024), like the device descriptors */
	static_assert(SOCK_FD_BASE + SOCK_FD_COUNT <= 1024, "select() must see socket descriptors");

	inline bool is_sock_fd(int fd) { return fd >= SOCK_FD_BASE && fd < SOCK_FD_BASE + SOCK_FD_COUNT; }

	/**
	 * socket()
	 *
	 * \return fd, -1 with errno set, or -2 if this kind of socket is not
	 *         served (the caller refuses it)
	 */
	int sock_socket(int domain, int type, int protocol);

	/**
	 * open() of a /proc file of an interface
	 *
	 * \return fd, -1 with errno set, or -2 if 'path' is none of them
	 */
	int sock_open(char const *path, int linux_flags);

	int      sock_ioctl(int fd, unsigned long cmd, void *arg);
	ssize_t  sock_send(int fd, void const *buf, size_t n);
	ssize_t  sock_recv(int fd, void *buf, size_t n, int flags);
	ssize_t  sock_read(int fd, void *buf, size_t n);
	ssize_t  sock_write(int fd, void const *buf, size_t n);
	int      sock_close(int fd);

	/**
	 * poll() readiness: bit 0 readable, bit 1 writeable, bit 3 not open
	 */
	unsigned sock_ready(int fd);
}

#endif /* _ANDROID_RT__SOCK_H_ */
