/*
 * \brief  bionic-ABI runtime of the Android loader
 * \author Ivan Loskutov
 * \date   2026-09-25
 */

/*
 * SPDX-License-Identifier: MIT
 */

#ifndef _ANDROID_RT__RUNTIME_H_
#define _ANDROID_RT__RUNTIME_H_

#include <android_elf/linker.h>
#include <android_rt/chardev_ioctl.h>
#include <util/interface.h>

namespace Genode { struct Env; class Allocator; }

namespace Android_rt {

	class Overrides;

	/**
	 * One symbol the runtime exports under its bionic name
	 */
	struct Export { char const *name; void *addr; };

	struct Export_group { Export const *exports; unsigned count; };

	/* groups, one per sym_*.cc */
	Export_group stdio_exports();
	Export_group log_exports();
	Export_group string_exports();
	Export_group thread_exports();
	Export_group file_exports();
	Export_group prop_exports();
	Export_group dl_exports();
	Export_group locale_exports();
	Export_group system_exports();
	Export_group fortify_exports();
	Export_group parcel_exports();
	Export_group binder_exports();
	Export_group signal_exports();
	Export_group platform_exports();
	Export_group unwind_exports();

	/**
	 * Initial system properties from a 'getprop' dump ("[name]: [value]")
	 */
	void load_properties_file(char const *path);

	/**
	 * Network interfaces reported besides lo: <prefix>0..<prefix><count-1>
	 */
	void set_net_interfaces(char const *prefix, unsigned count);

	/**
	 * The reported interfaces: their number (with lo), the 1-based index of
	 * a name as if_nametoindex gives it (0: none), the name of an index
	 * (nullptr: none)
	 */
	unsigned    net_interface_count();
	unsigned    net_interface_index(char const *name);
	char const *net_interface_name(unsigned index);

	/**
	 * Linker and memory of the running program (valid after start_program)
	 */
	Android_elf::Linker &linker();
	Android_elf::Memory &memory();
	Overrides           &overrides();

	/**
	 * Holds the lock of dlopen and dlsym, which guards the linker's objects
	 *
	 * The lock is recursive. It is taken before the one of the thread
	 * blocks, never the other way round.
	 */
	struct Dl_guard
	{
		Dl_guard();
		~Dl_guard();

		Dl_guard(Dl_guard const &) = delete;
		Dl_guard &operator = (Dl_guard const &) = delete;
	};

	/**
	 * bionic thread block of a new thread: TLS images copied, canary set
	 *
	 * \return thread pointer to load into tpidr_el0
	 */
	uint8_t *create_thread_block();

	/**
	 * Copy the TLS images of objects [first, count) into every thread block
	 */
	void init_tls_of_new_objects(unsigned first);

	void set_tp(void *tp);

	/**
	 * Thread of the runtime itself that may run Android code (own bionic
	 * thread block), e.g. the binder dispatcher
	 */
	void start_thread(void *(*fn)(void *), void *arg);

	/**
	 * The calling thread's bionic errno
	 */
	int *errno_location();

	/**
	 * Store Genode libc's errno (FreeBSD numbering) as Linux errno
	 */
	void set_errno_from_libc();
	void set_errno(int linux_errno);

	/**
	 * Genode environment for sessions opened by the runtime (binder)
	 */
	void init_genode(Genode::Env &);

	/**
	 * Announce the Android_binder service (instances added by the program)
	 */
	void export_binder_service();

	/**
	 * Log every binder transaction and callback-ring push as
	 * 'binder-trace' lines (loader config <binder trace="yes"/>)
	 */
	void binder_trace(bool);

	/**
	 * Use the Android_property service instead of a process-local table
	 * (loader config <property_service/>); call after init_genode
	 *
	 * \return false if the session cannot be opened or its table does not
	 *         match (an error is logged)
	 */
	bool use_property_service();

	/**
	 * Initial system property (from the loader config)
	 */
	void set_property(char const *name, char const *value);

	/**
	 * Log constructor progress and program entry (config verbose="yes")
	 */
	void verbose(bool);

	/**
	 * Lowest Android log priority written to the Genode log (config
	 * log_level="verbose|debug|info|warn|error", default: all)
	 *
	 * On the device every log line goes out synchronously over the
	 * 115200-baud UART; a chatty vendor daemon (rild: ~2.7 MB per run)
	 * spends seconds blocked in its own logging.
	 */
	void log_level(int min_priority);

	/**
	 * argv[0] of the program
	 */
	char const *program_name();

	/**
	 * Initial environment (argv/envp of the program)
	 */
	void set_environment(char const * const *envp);


	/**
	 * Run the loaded program on the calling thread (never returns)
	 *
	 * Sets up the bionic TLS block, runs all constructors in dependency
	 * order and enters the program's _start with a Linux-style argument
	 * block on this thread's stack.
	 */
	[[noreturn]] void start_program(Android_elf::Linker &, Android_elf::Memory &,
	                                Overrides &, int argc, char const * const *argv,
	                                char const * const *envp);

	/**
	 * Write out buffered stdout/stderr lines
	 */
	void flush_stdio();

	/**
	 * Terminate the program: atexit handlers, fini arrays, then exit
	 */
	[[noreturn]] void exit_program(int status);

	/**
	 * Attributes of the loader's <profile> node, for the profile's config_attr
	 */
	struct Profile_config : Genode::Interface
	{
		virtual int attr(char const *name, char *buf, unsigned len) = 0;
	};

	/**
	 * Load the profile library and run its android_profile_init
	 *
	 * \return false if it cannot be loaded or rejects the API
	 */
	bool load_profile(Genode::Env &, Genode::Allocator &, char const *lib, Profile_config &);

	/**
	 * Symbol registered by the profile, or nullptr
	 */
	void *profile_override(char const *name);

	/**
	 * ioctl-payload function the profile registered for 'cmd', or nullptr
	 */
	Ioctl_payload_fn ioctl_payload_hook(unsigned long cmd);
}


class Android_rt::Overrides : public Android_elf::Overrides
{
	private:

		Android_elf::Memory &_code;   /* executable memory for stubs */

	public:

		Overrides(Android_elf::Memory &code) : _code(code) { }

		Android_elf::Memory &code_memory() { return _code; }

		void *find(char const *name) override;
		void *stub(char const *name) override;
};


/* assembly helpers (entry.S) */
extern "C" void art_tlsdesc_static();
extern "C" [[noreturn]] void art_enter(void *entry, void *raw_args);

#endif /* _ANDROID_RT__RUNTIME_H_ */
