/*
 * \brief  Linker core of the Android loader
 * \author Ivan Loskutov
 * \date   2026-09-25
 *
 * Loads a program and its DT_NEEDED closure, binds imports (runtime
 * overrides first), applies relocations and assigns bionic's static TLS
 * layout. Files, memory and the runtime's exports are reached through small
 * interfaces.
 */

/*
 * SPDX-License-Identifier: MIT
 */

#ifndef _ANDROID_ELF__LINKER_H_
#define _ANDROID_ELF__LINKER_H_

#include <android_elf/object.h>

namespace Android_elf {

	struct File_source
	{
		/**
		 * 'path' (e.g. "/vendor/lib64/libz.so") names a file
		 */
		virtual bool exists(char const *path) = 0;

		/**
		 * Content of 'path', nullptr if absent; valid until 'release'
		 */
		virtual uint8_t const *read(char const *path, size_t &size) = 0;

		/**
		 * The content is copied into the image: give its buffer back
		 */
		virtual void release(uint8_t const *content) = 0;

		virtual ~File_source() { }
	};

	struct Overrides
	{
		/**
		 * Runtime implementation of 'name', nullptr if there is none
		 */
		virtual void *find(char const *name) = 0;

		/**
		 * Code address that reports 'name' as unimplemented when called
		 */
		virtual void *stub(char const *name) = 0;

		virtual ~Overrides() { }
	};

	class Linker;
}


class Android_elf::Linker
{
	public:

		enum { MAX_OBJECTS = 128, MAX_DEPS = 64, MAX_PATHS = 8, MAX_REPLACED = 8,
		       MAX_STUBS = 1024, PATH_MAX_LEN = 160,
		       TLS_SLOTS_SIZE = 64,       /* bionic's 8 TLS slots at tp[0..7] */
		       TLS_SURPLUS    = 16*1024 };

		enum class Result { OK, NOT_FOUND, LOAD_FAILED, BAD_RELOC,
		                    TLS_UNDERALIGNED, TOO_MANY };

	private:

		struct Entry
		{
			Object  *obj;
			char     path[PATH_MAX_LEN];
			bool     vendor;              /* uses the vendor search list */
			unsigned root;                /* object its 'dlopen' named, 0: loaded with the program */
			unsigned deps[MAX_DEPS];
			unsigned dep_count;
			size_t   tls_offset;          /* tp-relative, valid if obj->has_tls() */
		};

		Memory      &_mem;
		File_source &_files;
		Overrides   &_overrides;
		void * const _tlsdesc_resolver;

		char const *_vendor_paths[MAX_PATHS] { };
		char const *_system_paths[MAX_PATHS] { };
		char const *_replaced[MAX_REPLACED]  { };
		unsigned    _vendor_path_count = 0, _system_path_count = 0, _replaced_count = 0;

		Entry    _entries[MAX_OBJECTS] { };
		unsigned _count = 0;

		char const *_stubs[MAX_STUBS] { };
		unsigned    _stub_count = 0;

		size_t _tls_end = TLS_SLOTS_SIZE;   /* first free static TLS offset */
		size_t _tls_static = 0;             /* size of the static area at startup */

		char _error[256] { };

		bool     _is_replaced(char const *name) const;
		int      _find_loaded(char const *path) const;
		Result   _load(char const *path, bool vendor, unsigned &index);
		Result   _load_closure(unsigned first);
		Result   _assign_tls(unsigned index, bool program);
		Result   _relocate(unsigned index);
		bool     _lookup_tree(char const *name, unsigned root, bool seen[MAX_OBJECTS],
		                      unsigned &def, Elf64_Sym const *&sym) const;
		bool     _lookup(char const *name, unsigned requester,
		                 unsigned &def, Elf64_Sym const *&sym) const;
		void    *_record_stub(char const *name);
		void     _set_error(char const *a, char const *b = "", char const *c = "",
		                    char const *d = "");

	public:

		Linker(Memory &mem, File_source &files, Overrides &overrides,
		       void *tlsdesc_resolver)
		: _mem(mem), _files(files), _overrides(overrides),
		  _tlsdesc_resolver(tlsdesc_resolver) { }

		/**
		 * Directories searched for DT_NEEDED of vendor/system objects, in order
		 *
		 * An object below "/vendor/" searches the vendor list, then the
		 * system list; any other object searches the system list only.
		 */
		void add_vendor_path(char const *dir) { if (_vendor_path_count < MAX_PATHS) _vendor_paths[_vendor_path_count++] = dir; }
		void add_system_path(char const *dir) { if (_system_path_count < MAX_PATHS) _system_paths[_system_path_count++] = dir; }

		/**
		 * Library served entirely by the runtime, never mapped
		 */
		void replace(char const *soname) { if (_replaced_count < MAX_REPLACED) _replaced[_replaced_count++] = soname; }

		/**
		 * Load the program and its closure, assign TLS, relocate everything
		 */
		Result load_program(char const *path);

		/**
		 * Load a library at runtime (TLS from the surplus area)
		 */
		Object *dlopen(char const *name, Result &result);

		Object  *program()           const { return _count ? _entries[0].obj : nullptr; }
		unsigned object_count()      const { return _count; }
		Object  *object(unsigned i)  const { return _entries[i].obj; }
		char const *path(unsigned i) const { return _entries[i].path; }

		/**
		 * tp-relative offset of the object's TLS block
		 */
		size_t tls_offset(unsigned i) const { return _entries[i].tls_offset; }

		/**
		 * Bytes above tp needed per thread: slots + static TLS + surplus
		 */
		size_t tls_area_size() const { return _tls_static + TLS_SURPLUS; }

		unsigned    stub_count()          const { return _stub_count; }
		char const *stub_name(unsigned i) const { return _stubs[i]; }
		char const *error()               const { return _error; }

		/**
		 * Call 'fn(unsigned index)' in the order of bionic's constructors:
		 * depth first from the program, the dependencies of an object in the
		 * order of its DT_NEEDED entries before the object itself, then
		 * likewise from each object loaded by 'dlopen'
		 */
		template <typename FN>
		void for_each_init_order(FN const &fn) const
		{
			bool done[MAX_OBJECTS] { };
			auto visit = [&] (auto &self, unsigned i) -> void {
				if (done[i]) return;
				done[i] = true;
				for (unsigned d = 0; d < _entries[i].dep_count; d++)
					self(self, _entries[i].deps[d]);
				fn(i);
			};
			unsigned const count = _count;   /* 'fn' may load further objects */
			for (unsigned i = 0; i < count; i++)
				visit(visit, i);
		}

		/**
		 * Index of the object containing 'addr', -1 if none
		 */
		int object_at(void const *addr) const;

		/**
		 * 'soname' is served by the runtime (see 'replace')
		 */
		bool replaced(char const *soname) const { return _is_replaced(soname); }

		/**
		 * Look up 'name' in the scope of object 'requester'
		 */
		void *symbol_address(char const *name, unsigned requester) const;

		/**
		 * Look up 'name' in object 'root' and its dependencies only
		 */
		void *tree_symbol_address(char const *name, unsigned root) const;
};

#endif /* _ANDROID_ELF__LINKER_H_ */
