/*
 * \brief  Linker core of the Android loader
 * \author Ivan Loskutov
 * \date   2026-09-25
 */

/*
 * SPDX-License-Identifier: MIT
 */

#include <android_elf/linker.h>
#include <stdio.h>
#include <string.h>

using namespace Android_elf;

static size_t align_up(size_t v, size_t a) { return (v + a - 1) & ~(a - 1); }

static char const *base_name(char const *path)
{
	char const *s = strrchr(path, '/');
	return s ? s + 1 : path;
}


void Linker::_set_error(char const *a, char const *b, char const *c, char const *d)
{
	snprintf(_error, sizeof(_error), "%s%s%s%s", a, b, c, d);
}


bool Linker::_is_replaced(char const *name) const
{
	for (unsigned i = 0; i < _replaced_count; i++)
		if (!strcmp(_replaced[i], name)) return true;
	return false;
}


int Linker::_find_loaded(char const *path) const
{
	for (unsigned i = 0; i < _count; i++)
		if (!strcmp(_entries[i].path, path)) return int(i);
	return -1;
}


Linker::Result Linker::_load(char const *path, bool vendor, unsigned &index)
{
	int const loaded = _find_loaded(path);
	if (loaded >= 0) { index = unsigned(loaded); return Result::OK; }

	if (_count == MAX_OBJECTS) { _set_error("too many objects at ", path); return Result::TOO_MANY; }

	size_t size = 0;
	uint8_t const *file = _files.read(path, size);
	if (!file) { _set_error("not found: ", path); return Result::NOT_FOUND; }

	Object::Load_error err;
	Object *o = Object::load(base_name(path), file, size, _mem, err);
	_files.release(file);   /* the segments are copied into the image */
	if (!o) { _set_error("cannot load ", path); return Result::LOAD_FAILED; }

	Entry &e = _entries[_count];
	e        = Entry { };   /* the slot may hold the rest of a failed dlopen */
	e.obj    = o;
	e.vendor = vendor;
	strncpy(e.path, path, PATH_MAX_LEN - 1);
	index = _count++;
	return Result::OK;
}


/*
 * Breadth-first over DT_NEEDED starting at entry 'first'
 */
Linker::Result Linker::_load_closure(unsigned first)
{
	for (unsigned i = first; i < _count; i++) {
		Entry &e = _entries[i];
		for (unsigned n = 0; n < e.obj->needed_count(); n++) {
			char const *name = e.obj->needed(n);
			if (_is_replaced(name)) continue;

			char path[PATH_MAX_LEN];
			bool found = false, dep_vendor = false;

			auto try_dirs = [&] (char const * const *dirs, unsigned count, bool vendor) {
				for (unsigned d = 0; d < count && !found; d++) {
					path[0] = 0;
					strncat(path, dirs[d], sizeof(path) - 1);
					strncat(path, "/", sizeof(path) - strlen(path) - 1);
					strncat(path, name, sizeof(path) - strlen(path) - 1);
					if (_find_loaded(path) >= 0) { found = true; dep_vendor = vendor; break; }
					if (_files.exists(path)) { found = true; dep_vendor = vendor; }
				}
			};
			if (e.vendor) try_dirs(_vendor_paths, _vendor_path_count, true);
			try_dirs(_system_paths, _system_path_count, false);

			if (!found) { _set_error("library ", name, " not found"); return Result::NOT_FOUND; }

			unsigned dep;
			Result r = _load(path, dep_vendor, dep);
			if (r != Result::OK) return r;

			Entry &self = _entries[i];   /* _load does not move entries */
			if (self.dep_count < MAX_DEPS) self.deps[self.dep_count++] = dep;
		}
	}
	return Result::OK;
}


/*
 * bionic arm64 static TLS: tp[0..7] are the TLS slots; the executable's
 * segment starts at tp + align_up(16, p_align) and must be aligned to at
 * least 64 so it lands behind the slots; libraries follow.
 */
Linker::Result Linker::_assign_tls(unsigned index, bool program)
{
	Entry &e = _entries[index];
	if (!e.obj->has_tls()) return Result::OK;

	Tls_image const t = e.obj->tls();
	if (program) {
		if (t.align < TLS_SLOTS_SIZE) {
			_set_error("TLS segment of ", e.path, " is aligned below 64 bytes");
			return Result::TLS_UNDERALIGNED;
		}
		e.tls_offset = align_up(16, t.align);
	} else {
		e.tls_offset = align_up(_tls_end, t.align);
	}
	size_t const end = e.tls_offset + t.memsz;
	if (end < e.tls_offset) {
		_set_error("TLS segment of ", e.path, " is too large");
		return Result::LOAD_FAILED;
	}
	if (end > _tls_end) _tls_end = end;
	return Result::OK;
}


/*
 * Object 'root' and its dependency tree, breadth first; 'seen' marks the
 * objects searched
 */
bool Linker::_lookup_tree(char const *name, unsigned root, bool seen[MAX_OBJECTS],
                          unsigned &def, Elf64_Sym const *&sym) const
{
	unsigned queue[MAX_OBJECTS];
	unsigned head = 0, tail = 0;
	queue[tail++] = root; seen[root] = true;

	while (head < tail) {
		unsigned const i = queue[head++];
		Elf64_Sym const *s = _entries[i].obj->lookup(name);
		if (s) { def = i; sym = s; return true; }
		for (unsigned d = 0; d < _entries[i].dep_count; d++) {
			unsigned const n = _entries[i].deps[d];
			if (!seen[n]) { seen[n] = true; queue[tail++] = n; }
		}
	}
	return false;
}


/*
 * The order of bionic's linker: the global group, which is the program,
 * then the local group of the requester, which is the tree of the program
 * or of the object its 'dlopen' named. The tree of the program is searched
 * breadth first, which is its load order.
 */
bool Linker::_lookup(char const *name, unsigned requester,
                     unsigned &def, Elf64_Sym const *&sym) const
{
	bool seen[MAX_OBJECTS] { };

	unsigned const root = _entries[requester].root;
	if (root != 0) {
		Elf64_Sym const *s = _entries[0].obj->lookup(name);
		if (s) { def = 0; sym = s; return true; }
		seen[0] = true;
	}
	if (_lookup_tree(name, root, seen, def, sym)) return true;

	/* beyond bionic: any other object, in load order */
	for (unsigned i = 0; i < _count; i++) {
		if (seen[i]) continue;
		Elf64_Sym const *s = _entries[i].obj->lookup(name);
		if (s) { def = i; sym = s; return true; }
	}
	return false;
}


void *Linker::_record_stub(char const *name)
{
	bool known = false;
	for (unsigned i = 0; i < _stub_count && !known; i++)
		known = !strcmp(_stubs[i], name);
	if (!known && _stub_count < MAX_STUBS) _stubs[_stub_count++] = name;
	return _overrides.stub(name);
}


Linker::Result Linker::_relocate(unsigned index)
{
	Entry  &e    = _entries[index];
	Object &o    = *e.obj;
	uint8_t *bias = o.base();
	Result  result = Result::OK;

	/* a relocation outside the image is a corrupt file, not a place to write */
	auto bad_target = [&] {
		_set_error("relocation outside ", e.path);
		result = Result::BAD_RELOC;
	};

	o.for_each_relr([&] (uint64_t off) {
		if (result != Result::OK) return;
		if (!o.in_image(off, 8)) { bad_target(); return; }
		*(uint64_t *)(bias + off) += uint64_t(bias); });

	/* stops at the first error */
	o.for_each_rela([&] (Elf64_Rela const &rel) {

		uint32_t const type = rela_type(rel.r_info);
		uint32_t const si   = rela_sym(rel.r_info);

		if (type == R_AARCH64_NONE) return true;

		/* a TLS descriptor is two words */
		if (!o.in_image(rel.r_offset, type == R_AARCH64_TLSDESC ? 16 : 8)) {
			bad_target(); return false; }

		uint64_t *where = (uint64_t *)(bias + rel.r_offset);
		if (type == R_AARCH64_RELATIVE) { *where = uint64_t(bias) + rel.r_addend; return true; }

		/* symbol value S and, for TLS, the defining object */
		uint64_t         value   = 0;
		unsigned         def     = index;
		Elf64_Sym const *def_sym = si ? o.sym(si) : nullptr;

		if (si && !def_sym) {
			_set_error("symbol index outside the symbol table of ", e.path);
			result = Result::BAD_RELOC;
			return false;
		}

		if (si) {
			Elf64_Sym const &s    = *def_sym;
			char const      *name = o.sym_name(si);
			bool const       tls  = sym_type(s.st_info) == STT_TLS;

			if (sym_bind(s.st_info) == STB_LOCAL) {
				value = uint64_t(bias) + s.st_value;
			} else if (void *ov = tls ? nullptr : _overrides.find(name)) {
				value = uint64_t(ov);
			} else if (_lookup(name, index, def, def_sym)) {
				value = uint64_t(_entries[def].obj->base()) + def_sym->st_value;
			} else if (sym_bind(s.st_info) == STB_WEAK) {
				value = 0;
			} else if (tls) {
				_set_error("unresolved TLS symbol ", name, "");
				result = Result::BAD_RELOC;
				return false;
			} else {
				value = uint64_t(_record_stub(name));
			}
		}

		switch (type) {
		case R_AARCH64_ABS64:
		case R_AARCH64_GLOB_DAT:
		case R_AARCH64_JUMP_SLOT:
			*where = value + rel.r_addend;
			break;
		case R_AARCH64_TLS_TPREL64:
			*where = _entries[def].tls_offset + (def_sym ? def_sym->st_value : 0) + rel.r_addend;
			break;
		case R_AARCH64_TLSDESC:
			where[0] = uint64_t(_tlsdesc_resolver);
			where[1] = _entries[def].tls_offset + (def_sym ? def_sym->st_value : 0) + rel.r_addend;
			break;
		default:
			{
				char num[16];
				snprintf(num, sizeof(num), "%u", type);
				_set_error("unsupported relocation type ", num, " in ", e.path);
				result = Result::BAD_RELOC;
			}
		}
		return result == Result::OK;
	});

	if (result == Result::OK && o.aps2_error()) {
		_set_error("malformed packed relocations in ", e.path);
		result = Result::BAD_RELOC;
	}
	return result;
}


Linker::Result Linker::load_program(char const *path)
{
	unsigned index;
	Result r = _load(path, !strncmp(path, "/vendor/", 8), index);
	if (r != Result::OK) return r;

	r = _load_closure(0);
	if (r != Result::OK) return r;

	for (unsigned i = 0; i < _count; i++) {
		r = _assign_tls(i, i == 0);
		if (r != Result::OK) return r;
	}
	_tls_static = align_up(_tls_end, 16);

	for (unsigned i = 0; i < _count; i++) {
		r = _relocate(i);
		if (r != Result::OK) return r;
	}
	return Result::OK;
}


Object *Linker::dlopen(char const *name, Result &result)
{
	/* already loaded (by soname or path)? */
	for (unsigned i = 0; i < _count; i++)
		if (!strcmp(_entries[i].obj->soname(), name) || !strcmp(_entries[i].path, name)) {
			result = Result::OK;
			return _entries[i].obj;
		}

	char path[PATH_MAX_LEN];
	bool found = false, vendor = false;
	if (name[0] == '/') {
		strncpy(path, name, sizeof(path) - 1); path[sizeof(path) - 1] = 0;
		found = _files.exists(path);
		vendor = !strncmp(path, "/vendor/", 8);
	} else {
		auto try_dirs = [&] (char const * const *dirs, unsigned count, bool v) {
			for (unsigned d = 0; d < count && !found; d++) {
				path[0] = 0;
				strncat(path, dirs[d], sizeof(path) - 1);
				strncat(path, "/", sizeof(path) - strlen(path) - 1);
				strncat(path, name, sizeof(path) - strlen(path) - 1);
				if (_files.exists(path)) { found = true; vendor = v; }
			}
		};
		try_dirs(_vendor_paths, _vendor_path_count, true);
		try_dirs(_system_paths, _system_path_count, false);
	}
	if (!found) { _set_error("library ", name, " not found"); result = Result::NOT_FOUND; return nullptr; }

	/*
	 * A failure anywhere below leaves no half-loaded object behind: the
	 * entries and the TLS area return to what they were (the image memory
	 * stays allocated, 'Memory' has no free).
	 */
	unsigned const first   = _count;
	size_t   const tls_end = _tls_end;
	auto rollback = [&] { _count = first; _tls_end = tls_end; return nullptr; };

	unsigned index;
	result = _load(path, vendor, index);
	if (result != Result::OK) return rollback();
	result = _load_closure(first);
	if (result != Result::OK) return rollback();

	for (unsigned i = first; i < _count; i++) _entries[i].root = first;

	for (unsigned i = first; i < _count; i++) {
		result = _assign_tls(i, false);
		if (result != Result::OK) return rollback();
		if (_tls_end > _tls_static + TLS_SURPLUS) {
			_set_error("TLS surplus exhausted by ", _entries[i].path);
			result = Result::TOO_MANY;
			return rollback();
		}
	}
	for (unsigned i = first; i < _count; i++) {
		result = _relocate(i);
		if (result != Result::OK) return rollback();
	}
	return _entries[index].obj;
}


int Linker::object_at(void const *addr) const
{
	for (unsigned i = 0; i < _count; i++) {
		Object const &o = *_entries[i].obj;
		for (unsigned p = 0; p < o.phnum(); p++) {
			Elf64_Phdr const &ph = o.phdrs()[p];
			if (ph.p_type != PT_LOAD) continue;
			uint8_t const *lo = o.base() + ph.p_vaddr;
			if ((uint8_t const *)addr >= lo && (uint8_t const *)addr < lo + ph.p_memsz)
				return int(i);
		}
	}
	return -1;
}


void *Linker::symbol_address(char const *name, unsigned requester) const
{
	unsigned def; Elf64_Sym const *sym;
	if (!_lookup(name, requester, def, sym)) return nullptr;
	return _entries[def].obj->base() + sym->st_value;
}


void *Linker::tree_symbol_address(char const *name, unsigned root) const
{
	bool seen[MAX_OBJECTS] { };
	unsigned def; Elf64_Sym const *sym;
	if (!_lookup_tree(name, root, seen, def, sym)) return nullptr;
	return _entries[def].obj->base() + sym->st_value;
}
