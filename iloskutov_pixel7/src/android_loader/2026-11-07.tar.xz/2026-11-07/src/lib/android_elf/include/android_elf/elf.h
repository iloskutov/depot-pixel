/*
 * \brief  Minimal ELF64 definitions for the Android loader
 * \author Ivan Loskutov
 * \date   2026-09-25
 *
 * Own definitions instead of <elf.h>, which lacks Android's DT_ANDROID_*
 * tags.
 */

/*
 * SPDX-License-Identifier: MIT
 */

#ifndef _ANDROID_ELF__ELF_H_
#define _ANDROID_ELF__ELF_H_

#include <stdint.h>
#include <stddef.h>

namespace Android_elf {

	struct Elf64_Ehdr
	{
		uint8_t  e_ident[16];
		uint16_t e_type, e_machine;
		uint32_t e_version;
		uint64_t e_entry, e_phoff, e_shoff;
		uint32_t e_flags;
		uint16_t e_ehsize, e_phentsize, e_phnum, e_shentsize, e_shnum, e_shstrndx;
	};

	struct Elf64_Phdr
	{
		uint32_t p_type, p_flags;
		uint64_t p_offset, p_vaddr, p_paddr, p_filesz, p_memsz, p_align;
	};

	struct Elf64_Dyn  { int64_t d_tag; uint64_t d_val; };

	struct Elf64_Sym
	{
		uint32_t st_name;
		uint8_t  st_info, st_other;
		uint16_t st_shndx;
		uint64_t st_value, st_size;
	};

	struct Elf64_Rela { uint64_t r_offset, r_info; int64_t r_addend; };

	enum : uint16_t { ET_DYN = 3, EM_AARCH64 = 183 };

	enum : uint32_t { PT_LOAD = 1, PT_DYNAMIC = 2, PT_INTERP = 3, PT_TLS = 7,
	                  PT_GNU_RELRO = 0x6474e552 };

	enum : int64_t {
		DT_NULL = 0, DT_NEEDED = 1, DT_PLTRELSZ = 2, DT_STRTAB = 5, DT_SYMTAB = 6,
		DT_RELA = 7, DT_RELASZ = 8, DT_STRSZ = 10, DT_SONAME = 14, DT_JMPREL = 23,
		DT_INIT_ARRAY = 25, DT_FINI_ARRAY = 26, DT_INIT_ARRAYSZ = 27,
		DT_FINI_ARRAYSZ = 28,
		DT_RELRSZ = 35, DT_RELR = 36,
		DT_ANDROID_RELA = 0x60000011, DT_ANDROID_RELASZ = 0x60000012,
		DT_GNU_HASH = 0x6ffffef5, DT_VERSYM = 0x6ffffff0,
		DT_ANDROID_RELR = 0x6fffe000, DT_ANDROID_RELRSZ = 0x6fffe001,
		DT_ANDROID_RELRENT = 0x6fffe003 };

	enum : uint32_t {
		R_AARCH64_NONE = 0, R_AARCH64_ABS64 = 257, R_AARCH64_GLOB_DAT = 1025,
		R_AARCH64_JUMP_SLOT = 1026, R_AARCH64_RELATIVE = 1027,
		R_AARCH64_TLS_TPREL64 = 1030, R_AARCH64_TLSDESC = 1031 };

	enum : uint8_t  { STB_LOCAL = 0, STB_GLOBAL = 1, STB_WEAK = 2, STT_TLS = 6 };

	enum : uint16_t { SHN_UNDEF = 0, VERSYM_HIDDEN = 0x8000 };

	inline uint32_t rela_type(uint64_t info) { return uint32_t(info & 0xffffffff); }
	inline uint32_t rela_sym (uint64_t info) { return uint32_t(info >> 32); }
	inline uint8_t  sym_bind (uint8_t info)  { return info >> 4; }
	inline uint8_t  sym_type (uint8_t info)  { return info & 0xf; }
}

#endif /* _ANDROID_ELF__ELF_H_ */
