/*
 * \brief  One ELF object mapped by the Android loader
 * \author Ivan Loskutov
 * \date   2026-09-25
 */

/*
 * SPDX-License-Identifier: MIT
 */

#include <android_elf/object.h>
#include <string.h>

using namespace Android_elf;

enum { PAGE = 4096, MAX_ALIGN = 2*1024*1024,     /* a segment aligned beyond 2 MiB is not a library */
       MAX_IMAGE = 1024*1024*1024,               /* nor is an image beyond 1 GiB */
       MAX_TLS   = 16*1024*1024 };

static uint64_t align_down(uint64_t v, uint64_t a) { return v & ~(a - 1); }
static uint64_t align_up  (uint64_t v, uint64_t a) { return (v + a - 1) & ~(a - 1); }


static uint32_t gnu_hash(char const *s)
{
	uint32_t h = 5381;
	for (; *s; s++) h = h * 33 + uint8_t(*s);
	return h;
}


Object *Object::load(char const *name, uint8_t const *file, size_t size,
                     Memory &mem, Load_error &err)
{
	err = Load_error::NONE;

	if (size < sizeof(Elf64_Ehdr) || memcmp(file, "\177ELF", 4) || file[4] != 2) {
		err = Load_error::NOT_ELF; return nullptr; }

	Elf64_Ehdr const &eh = *(Elf64_Ehdr const *)file;
	if (eh.e_machine != EM_AARCH64) { err = Load_error::NOT_AARCH64; return nullptr; }
	if (eh.e_type    != ET_DYN)     { err = Load_error::NOT_DYN;     return nullptr; }

	/* every sum below is checked without overflowing */
	if (eh.e_phentsize != sizeof(Elf64_Phdr) || eh.e_phoff > size
	 || uint64_t(eh.e_phnum) * sizeof(Elf64_Phdr) > size - eh.e_phoff) {
		err = Load_error::BAD_PHDR; return nullptr; }

	Elf64_Phdr const *ph = (Elf64_Phdr const *)(file + eh.e_phoff);

	uint64_t lo = ~0ull, hi = 0, align = PAGE;
	for (unsigned i = 0; i < eh.e_phnum; i++) {
		if (ph[i].p_type != PT_LOAD) continue;
		if (ph[i].p_offset > size || ph[i].p_filesz > size - ph[i].p_offset
		 || ph[i].p_filesz > ph[i].p_memsz || ph[i].p_vaddr > ~0ull - PAGE
		 || ph[i].p_memsz > ~0ull - PAGE - ph[i].p_vaddr
		 || (ph[i].p_align & (ph[i].p_align - 1)) || ph[i].p_align > MAX_ALIGN) {
			err = Load_error::BAD_PHDR; return nullptr; }
		lo = (ph[i].p_vaddr < lo) ? ph[i].p_vaddr : lo;
		uint64_t const end = ph[i].p_vaddr + ph[i].p_memsz;
		hi = (end > hi) ? end : hi;
		if (ph[i].p_align > align) align = ph[i].p_align;
	}
	if (lo == ~0ull) { err = Load_error::BAD_PHDR; return nullptr; }
	lo = align_down(lo, PAGE);
	hi = align_up(hi, PAGE);
	if (hi - lo > MAX_IMAGE) { err = Load_error::BAD_PHDR; return nullptr; }

	Object *o = (Object *)mem.alloc(sizeof(Object), 16);
	uint8_t *image = mem.alloc(hi - lo, align);
	if (!o || !image) { err = Load_error::OUT_OF_MEMORY; return nullptr; }

	strncpy(o->_name, name, NAME_MAX - 1);
	o->_bias  = image - lo;
	o->_lo    = lo;
	o->_span  = hi - lo;
	o->_entry = eh.e_entry;

	Elf64_Dyn const *dyn = nullptr;
	size_t dyn_max = 0;
	for (unsigned i = 0; i < eh.e_phnum; i++) {
		switch (ph[i].p_type) {
		case PT_LOAD:
			memcpy(o->_bias + ph[i].p_vaddr, file + ph[i].p_offset, ph[i].p_filesz);
			break;
		case PT_DYNAMIC:
			if (!o->in_image(ph[i].p_vaddr, ph[i].p_memsz)) {
				err = Load_error::BAD_PHDR; return nullptr; }
			dyn = (Elf64_Dyn const *)(o->_bias + ph[i].p_vaddr);
			dyn_max = ph[i].p_memsz / sizeof(Elf64_Dyn);
			break;
		case PT_TLS:
			if (ph[i].p_filesz > ph[i].p_memsz || !o->in_image(ph[i].p_vaddr, ph[i].p_filesz)
			 || ph[i].p_memsz > MAX_TLS
			 || (ph[i].p_align & (ph[i].p_align - 1)) || ph[i].p_align > PAGE) {
				err = Load_error::BAD_PHDR; return nullptr; }
			o->_has_tls = true;
			o->_tls = { o->_bias + ph[i].p_vaddr, ph[i].p_filesz, ph[i].p_memsz,
			            ph[i].p_align ? ph[i].p_align : 1 };
			break;
		}
	}

	/* program headers: inside the mapped image if a PT_LOAD covers them */
	Elf64_Phdr *copy = (Elf64_Phdr *)mem.alloc(eh.e_phnum * sizeof(Elf64_Phdr), 16);
	if (!copy) { err = Load_error::OUT_OF_MEMORY; return nullptr; }
	memcpy(copy, ph, eh.e_phnum * sizeof(Elf64_Phdr));
	o->_phdrs = copy;
	o->_phnum = eh.e_phnum;

	if (!dyn) { err = Load_error::NO_DYNAMIC; return nullptr; }
	if (!o->_parse_dynamic(dyn, dyn_max) || !o->_count_symbols()) {
		err = Load_error::BAD_DYNAMIC; return nullptr; }
	return o;
}


bool Object::_parse_dynamic(Elf64_Dyn const *dyn, size_t max_entries)
{
	uint64_t strtab = 0, strsz = 0, symtab = 0, gnu_hash = 0, versym = 0,
	         rela = 0, relasz = 0, jmprel = 0, pltrelsz = 0, aps2 = 0, aps2sz = 0,
	         relr = 0, relrsz = 0, init = 0, initsz = 0, fini = 0, finisz = 0;

	for (size_t n = 0; n < max_entries && dyn->d_tag != DT_NULL; n++, dyn++) {
		uint64_t const v = dyn->d_val;
		switch (dyn->d_tag) {
		case DT_STRTAB:      strtab   = v; break;
		case DT_STRSZ:       strsz    = v; break;
		case DT_SYMTAB:      symtab   = v; break;
		case DT_GNU_HASH:    gnu_hash = v; break;
		case DT_VERSYM:      versym   = v; break;
		case DT_RELA:        rela = v;     break;
		case DT_RELASZ:      relasz = v;   break;
		case DT_JMPREL:      jmprel = v;   break;
		case DT_PLTRELSZ:    pltrelsz = v; break;
		case DT_ANDROID_RELA:   aps2 = v;   break;
		case DT_ANDROID_RELASZ: aps2sz = v; break;
		case DT_ANDROID_RELR:
		case DT_RELR:           relr = v;   break;
		case DT_ANDROID_RELRSZ:
		case DT_RELRSZ:         relrsz = v; break;
		case DT_INIT_ARRAY:     init = v;   break;
		case DT_INIT_ARRAYSZ:   initsz = v; break;
		case DT_FINI_ARRAY:     fini = v;   break;
		case DT_FINI_ARRAYSZ:   finisz = v; break;
		case DT_SONAME:         _soname = uint32_t(v); break;
		case DT_NEEDED:
			if (_needed_count < NEEDED_MAX) _needed[_needed_count++] = uint32_t(v);
			break;
		}
	}

	if (!strtab || !symtab || !gnu_hash) return false;

	/* the tables lie inside the image, the string table ends with a NUL */
	if (!strsz || strsz > uint32_t(~0u) || !in_image(strtab, strsz)
	 || _bias[strtab + strsz - 1] != 0) return false;
	if (!in_image(symtab, sizeof(Elf64_Sym)) || !in_image(gnu_hash, 4 * sizeof(uint32_t)))
		return false;
	if ((versym  && !in_image(versym, 0))
	 || (rela    && !in_image(rela, relasz)) || (jmprel && !in_image(jmprel, pltrelsz))
	 || (aps2    && !in_image(aps2, aps2sz)) || (relr   && !in_image(relr, relrsz))
	 || (init    && !in_image(init, initsz)) || (fini   && !in_image(fini, finisz)))
		return false;

	_strtab   = (char const *)(_bias + strtab);
	_strsz    = uint32_t(strsz);
	_symtab   = (Elf64_Sym const *)(_bias + symtab);
	_gnu_hash = (uint32_t const *)(_bias + gnu_hash);
	if (versym)  _versym  = (uint16_t const *)(_bias + versym);

	if (rela)   { _rela   = (Elf64_Rela const *)(_bias + rela);   _rela_count   = relasz   / sizeof(Elf64_Rela); }
	if (jmprel) { _jmprel = (Elf64_Rela const *)(_bias + jmprel); _jmprel_count = pltrelsz / sizeof(Elf64_Rela); }
	if (aps2)   { _aps2   = _bias + aps2; _aps2_size = aps2sz; }
	if (relr)   { _relr   = (uint64_t const *)(_bias + relr); _relr_count = relrsz / 8; }
	if (init)   { _init_array = (void (**)())(_bias + init); _init_count = initsz / 8; }
	if (fini)   { _fini_array = (void (**)())(_bias + fini); _fini_count = finisz / 8; }
	return true;
}


/*
 * GNU hash carries no symbol count: it is one past the last chain entry of
 * the highest non-empty bucket
 *
 * \return false if the hash table or the symbol table reaches beyond the image
 */
bool Object::_count_symbols()
{
	uint32_t const nbuckets = _gnu_hash[0], symoffset = _gnu_hash[1], bloom_size = _gnu_hash[2];
	if (!nbuckets || !bloom_size) return false;

	uint64_t const *bloom   = (uint64_t const *)(_gnu_hash + 4);
	uint32_t const *buckets = (uint32_t const *)(bloom + bloom_size);
	uint32_t const *chain   = buckets + nbuckets;
	if (!_inside(bloom, uint64_t(bloom_size) * 8) || !_inside(buckets, uint64_t(nbuckets) * 4)
	 || !_inside(chain, 0)) return false;

	/* the chain may extend to the end of the image at most */
	uint64_t const chain_max = (uint64_t(_span) - uint64_t((uint8_t const *)chain - _bias - _lo)) / 4;

	uint32_t last = 0;
	for (uint32_t b = 0; b < nbuckets; b++)
		if (buckets[b] > last) last = buckets[b];

	if (last < symoffset) {
		_sym_count = symoffset;
	} else {
		while (last - symoffset < chain_max && !(chain[last - symoffset] & 1)) last++;
		if (last - symoffset >= chain_max) return false;
		_sym_count = last + 1;
	}
	if (!_inside(_symtab, uint64_t(_sym_count) * sizeof(Elf64_Sym))) return false;
	if (_versym && !_inside(_versym, uint64_t(_sym_count) * sizeof(uint16_t))) return false;
	return true;
}


Elf64_Sym const *Object::lookup(char const *name) const
{
	uint32_t const *t = _gnu_hash;
	uint32_t const nbuckets = t[0], symoffset = t[1], bloom_size = t[2], bloom_shift = t[3];
	uint64_t const *bloom   = (uint64_t const *)(t + 4);
	uint32_t const *buckets = (uint32_t const *)(bloom + bloom_size);
	uint32_t const *chain   = buckets + nbuckets;

	uint32_t const h    = gnu_hash(name);
	uint64_t const word = bloom[(h / 64) % bloom_size];
	uint64_t const mask = (1ull << (h % 64)) | (1ull << ((h >> bloom_shift) % 64));
	if ((word & mask) != mask) return nullptr;

	uint32_t i = buckets[h % nbuckets];
	if (i < symoffset) return nullptr;

	for (; i < _sym_count; i++) {       /* '_count_symbols' bounded the chain */
		uint32_t const   h2 = chain[i - symoffset];
		Elf64_Sym const &s  = _symtab[i];
		if ((h | 1) == (h2 | 1) && !strcmp(name, _str(s.st_name))
		 && s.st_shndx != SHN_UNDEF && sym_bind(s.st_info) != STB_LOCAL
		 && (!_versym || !(_versym[i] & VERSYM_HIDDEN)))
			return &s;
		if (h2 & 1) break;
	}
	return nullptr;
}
