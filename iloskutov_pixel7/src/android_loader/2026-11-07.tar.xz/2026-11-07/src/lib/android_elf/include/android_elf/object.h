/*
 * \brief  One ELF object mapped by the Android loader
 * \author Ivan Loskutov
 * \date   2026-09-25
 *
 * Platform independent: memory comes from a 'Memory' implementation (Genode
 * RAM dataspaces in the loader). An Object lives in that memory,
 * zero-initialised, and needs no C++ runtime.
 */

/*
 * SPDX-License-Identifier: MIT
 */

#ifndef _ANDROID_ELF__OBJECT_H_
#define _ANDROID_ELF__OBJECT_H_

#include <android_elf/decode.h>

namespace Android_elf {

	struct Memory
	{
		/**
		 * Zeroed, readable, writeable and executable memory
		 *
		 * \return nullptr if exhausted
		 */
		virtual uint8_t *alloc(size_t size, size_t align) = 0;

		virtual ~Memory() { }
	};

	struct Tls_image
	{
		uint8_t const *init;
		size_t filesz, memsz, align;
	};

	class Object;
}


class Android_elf::Object
{
	public:

		enum class Load_error { NONE, NOT_ELF, NOT_AARCH64, NOT_DYN, BAD_PHDR,
		                        NO_DYNAMIC, BAD_DYNAMIC, OUT_OF_MEMORY };

		enum { NAME_MAX = 128, NEEDED_MAX = 64 };

	private:

		char      _name[NAME_MAX];
		uint8_t  *_bias;             /* load address of vaddr 0 */
		uint64_t  _lo;               /* first vaddr of the image */
		size_t    _span;
		uint64_t  _entry;

		Elf64_Phdr const *_phdrs;
		unsigned          _phnum;

		char const      *_strtab;
		uint32_t         _strsz;
		Elf64_Sym const *_symtab;
		uint32_t         _sym_count;
		uint32_t const  *_gnu_hash;
		uint16_t const  *_versym;

		Elf64_Rela const *_rela;     size_t _rela_count;
		Elf64_Rela const *_jmprel;   size_t _jmprel_count;
		uint8_t const    *_aps2;     size_t _aps2_size;
		uint64_t const   *_relr;     size_t _relr_count;
		mutable bool      _aps2_error;

		void (**_init_array)();      size_t _init_count;
		void (**_fini_array)();      size_t _fini_count;

		uint32_t _soname;            /* strtab offset, 0 if none */
		uint32_t _needed[NEEDED_MAX];
		unsigned _needed_count;

		bool      _has_tls;
		Tls_image _tls;

		bool _parse_dynamic(Elf64_Dyn const *dyn, size_t max_entries);
		bool _count_symbols();

		/* 'len' bytes at 'p' lie inside the image */
		bool _inside(void const *p, uint64_t len) const {
			return in_image(uint64_t((uint8_t const *)p - _bias), len); }

		/* string table entry, "" if the offset is outside the table */
		char const *_str(uint64_t off) const { return off < _strsz ? _strtab + off : ""; }

	public:

		/**
		 * 'len' bytes at virtual address 'vaddr' lie inside the image
		 *
		 * Everything the file says about itself -- addresses in the dynamic
		 * section, relocation targets, hash and version tables -- is checked
		 * against the image before it is used, so a corrupt file fails to
		 * load instead of faulting.
		 */
		bool in_image(uint64_t vaddr, uint64_t len) const {
			return vaddr >= _lo && vaddr - _lo <= _span && len <= _span - (vaddr - _lo); }

		/**
		 * Map 'file' and parse its dynamic section
		 *
		 * \return nullptr and 'err' on failure
		 */
		static Object *load(char const *name, uint8_t const *file, size_t size,
		                    Memory &, Load_error &err);

		char const *name()   const { return _name; }
		char const *soname() const { return _soname ? _str(_soname) : _name; }
		uint8_t    *base()   const { return _bias; }
		uint64_t    entry()  const { return _entry; }
		size_t      span()   const { return _span; }

		Elf64_Phdr const *phdrs() const { return _phdrs; }
		unsigned          phnum() const { return _phnum; }

		unsigned    needed_count()     const { return _needed_count; }
		char const *needed(unsigned i) const { return _str(_needed[i]); }

		/**
		 * Defined, non-local symbol 'name' (its default version)
		 */
		Elf64_Sym const *lookup(char const *name) const;

		Elf64_Sym const *sym(uint32_t i) const {
			return (i < _sym_count) ? &_symtab[i] : nullptr; }

		char const *sym_name(uint32_t i) const { return _str(_symtab[i].st_name); }

		/**
		 * Call 'fn(Elf64_Rela const &)' for each relocation until it returns
		 * false
		 */
		template <typename FN>
		void for_each_rela(FN const &fn) const
		{
			for (size_t i = 0; i < _rela_count; i++)   if (!fn(_rela[i]))   return;
			for (size_t i = 0; i < _jmprel_count; i++) if (!fn(_jmprel[i])) return;

			/* each packed relocation has its own word of the image */
			if (_aps2 && !decode_aps2(_aps2, _aps2_size, _span / 8, fn))
				_aps2_error = true;
		}

		template <typename FN>
		void for_each_relr(FN const &fn) const {
			if (_relr) decode_relr(_relr, _relr_count, fn); }

		bool aps2_error() const { return _aps2_error; }

		void init_array(void (**&arr)(), size_t &count) const {
			arr = _init_array; count = _init_count; }

		void fini_array(void (**&arr)(), size_t &count) const {
			arr = _fini_array; count = _fini_count; }

		bool      has_tls() const { return _has_tls; }
		Tls_image tls()     const { return _tls; }
};

#endif /* _ANDROID_ELF__OBJECT_H_ */
