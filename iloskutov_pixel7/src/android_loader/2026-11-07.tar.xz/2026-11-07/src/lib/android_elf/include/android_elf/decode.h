/*
 * \brief  Decoders for Android's packed relocations (APS2) and RELR
 * \author Ivan Loskutov
 * \date   2026-09-25
 *
 * APS2 as produced by lld --pack-dyn-relocs=android and consumed by bionic's
 * linker (linker_reloc_iterators.h): magic "APS2", SLEB128 count and start
 * offset, then groups of (size, flags[, offset delta][, info][, addend
 * delta]). Offset and addend are delta-encoded across the whole stream.
 */

/*
 * SPDX-License-Identifier: MIT
 */

#ifndef _ANDROID_ELF__DECODE_H_
#define _ANDROID_ELF__DECODE_H_

#include <android_elf/elf.h>

namespace Android_elf {

	struct Sleb_reader
	{
		uint8_t const *p;
		uint8_t const *end;
		bool ok = true;

		int64_t next()
		{
			uint64_t v = 0;
			unsigned shift = 0;
			uint8_t  b;
			do {
				if (p >= end || shift >= 64) { ok = false; return 0; }
				b = *p++;
				v |= uint64_t(b & 0x7f) << shift;
				shift += 7;
			} while (b & 0x80);
			if (shift < 64 && (b & 0x40))
				v |= ~uint64_t(0) << shift;
			return int64_t(v);
		}
	};

	/**
	 * Call 'fn(Elf64_Rela const &)' for each packed relocation until it
	 * returns false
	 *
	 * \param max_count  most relocations the stream may hold (a group needs
	 *                   no bytes per relocation, so 'len' does not bound them)
	 *
	 * \return false on malformed input or if 'fn' returned false (then 'fn'
	 *         saw a prefix only)
	 */
	template <typename FN>
	bool decode_aps2(uint8_t const *data, size_t len, uint64_t max_count, FN const &fn)
	{
		enum { BY_INFO = 1, BY_OFFSET_DELTA = 2, BY_ADDEND = 4, HAS_ADDEND = 8 };

		if (len < 4 || data[0] != 'A' || data[1] != 'P' || data[2] != 'S' || data[3] != '2')
			return false;

		Sleb_reader r { data + 4, data + len };
		int64_t    remaining = r.next();
		Elf64_Rela rel { uint64_t(r.next()), 0, 0 };

		if (remaining < 0 || uint64_t(remaining) > max_count) return false;

		while (r.ok && remaining > 0) {
			int64_t const size  = r.next();
			int64_t const flags = r.next();
			if (!r.ok || size <= 0 || size > remaining) return false;

			int64_t offset_delta = 0;
			if (flags & BY_OFFSET_DELTA) offset_delta = r.next();
			if (flags & BY_INFO)         rel.r_info   = uint64_t(r.next());
			if ((flags & HAS_ADDEND) && (flags & BY_ADDEND)) rel.r_addend += r.next();
			else if (!(flags & HAS_ADDEND))                  rel.r_addend  = 0;

			for (int64_t i = 0; i < size; i++) {
				rel.r_offset += uint64_t((flags & BY_OFFSET_DELTA) ? offset_delta : r.next());
				if (!(flags & BY_INFO)) rel.r_info = uint64_t(r.next());
				if ((flags & HAS_ADDEND) && !(flags & BY_ADDEND)) rel.r_addend += r.next();
				if (!r.ok || !fn(rel)) return false;
			}
			remaining -= size;
		}
		return r.ok && remaining == 0;
	}

	/**
	 * Call 'fn(uint64_t offset)' for every word RELR marks for relocation
	 */
	template <typename FN>
	void decode_relr(uint64_t const *relr, size_t count, FN const &fn)
	{
		uint64_t where = 0;
		for (size_t i = 0; i < count; i++) {
			uint64_t const e = relr[i];
			if (!(e & 1)) { fn(e); where = e + 8; continue; }
			for (unsigned bit = 1; bit < 64; bit++)
				if ((e >> bit) & 1) fn(where + (bit - 1) * 8);
			where += 63 * 8;
		}
	}
}

#endif /* _ANDROID_ELF__DECODE_H_ */
