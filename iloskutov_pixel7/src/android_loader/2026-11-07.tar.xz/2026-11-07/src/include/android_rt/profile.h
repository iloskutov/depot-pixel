/*
 * \brief  Android loader profile API (ANDROID_PROFILE_API 1.1)
 * \author Ivan Loskutov
 * \date   2026-09-26
 *
 * A profile is a shared library with the executable-specific code that must
 * run inside the vendor process (symbol overrides). The loader loads it
 * from <profile lib="..."/> and calls android_profile_init() before the
 * program is linked, so its overrides win over the runtime's exports and the
 * vendor libraries. The profile depends on this header only.
 *
 * Compatibility: a minor version adds members at the end; 'size' tells how
 * many the runtime provides. A profile rejects a different major.
 * Strings are copied into the caller's buffer: config_attr and property_get
 * return the length, or -1 if absent.
 *
 * Threads: 'override' is valid only during android_profile_init() (the
 * runtime reads the table without locking while it links the program and
 * later dlopen()s; afterwards 'override' fails with -1). The overriding
 * functions themselves run on whatever vendor thread calls the symbol --
 * any thread, concurrently -- and must be thread-safe. 'log', 'config_attr',
 * 'set_errno' and 'property_get' may be called from any thread at any time.
 * An overriding function reports errors the bionic way: return the error
 * value and set errno through 'set_errno' (Linux numbering) -- never through
 * the profile's own libc 'errno', which the vendor code does not see.
 */

/*
 * SPDX-License-Identifier: MIT
 */

#ifndef _INCLUDE__ANDROID_RT__PROFILE_H_
#define _INCLUDE__ANDROID_RT__PROFILE_H_

#ifdef __cplusplus
extern "C" {
#endif

enum { ANDROID_PROFILE_API_MAJOR = 1, ANDROID_PROFILE_API_MINOR = 1 };

struct Android_profile_api
{
	unsigned major, minor, size;   /* size = sizeof(struct Android_profile_api) */

	void (*log)(char const *msg);

	/* attribute of the profile's own <profile> config node */
	int  (*config_attr)(char const *name, char *buf, unsigned len);

	/* the calling thread's bionic errno (Linux numbering) */
	void (*set_errno)(int linux_errno);

	/*
	 * export 'fn' under 'symbol' (bionic ABI), 0 on success; only inside
	 * android_profile_init(), -1 afterwards
	 */
	int  (*override)(char const *symbol, void *fn);

	/* system property from the runtime's store */
	int  (*property_get)(char const *name, char *buf, unsigned len);

	/*
	 * Extra input bytes for a chardev ioctl: for 'cmd', 'fn(arg, out, cap)'
	 * returns how many bytes it wrote to 'out' (at most 'cap'); they are sent
	 * after the command's own input. Only inside android_profile_init().
	 * Returns 0 on success. (minor 1)
	 */
	int (*ioctl_payload)(unsigned long cmd,
	                     unsigned long (*fn)(void const *arg, void *out, unsigned long cap));
};

/* 0 on success; any other value stops the loader */
int android_profile_init(struct Android_profile_api const *api);

#ifdef __cplusplus
}
#endif

#endif /* _INCLUDE__ANDROID_RT__PROFILE_H_ */
