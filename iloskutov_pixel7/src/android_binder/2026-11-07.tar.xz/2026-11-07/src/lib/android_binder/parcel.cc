/*
 * \brief  Parcel format and the AParcel_* / AStatus_* API
 * \author Ivan Loskutov
 * \date   2026-09-25
 *
 * Format: little endian, every item padded to 4 bytes.
 *   string  int32 byte length (-1 = null), UTF-8 bytes, NUL
 *   array   int32 element count (-1 = null), elements
 *   status  int32 exception [, int32 service-specific error or status]
 *           [, string message] (exception 0 = OK, nothing follows)
 */

/*
 * SPDX-License-Identifier: MIT
 */

#include <android_binder/parcel.h>

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct AParcel
{
	uint8_t *data;
	size_t   size;           /* bytes written */
	size_t   cap;
	mutable size_t pos;      /* read/write position */
	Android_binder::Binder_codec *codec;
};

struct AStatus
{
	binder_exception_t exception;
	binder_status_t    status;          /* EX_TRANSACTION_FAILED */
	int32_t            service_error;   /* EX_SERVICE_SPECIFIC */
	char              *message;
};


static size_t pad4(size_t n) { return (n + 3) & ~size_t(3); }

/* no parcel grows beyond this, so size math on it cannot overflow */
enum : size_t { MAX_SIZE = size_t(1) << 30 };

/* every element of an array takes at least 4 bytes (a length or a marker) */
static bool array_fits(AParcel const *p, int32_t len)
{
	return len <= 0 || size_t(len) * 4 <= p->size - p->pos;
}


/* reserve 'n' bytes at the position, return where to write */
static uint8_t *space(AParcel *p, size_t n)
{
	if (n > MAX_SIZE || p->pos > MAX_SIZE) return nullptr;
	size_t const need = p->pos + pad4(n);
	if (need > p->cap) {
		size_t cap = p->cap ? p->cap : 256;
		while (cap < need) cap *= 2;
		uint8_t *d = (uint8_t *)realloc(p->data, cap);
		if (!d) return nullptr;
		memset(d + p->cap, 0, cap - p->cap);
		p->data = d; p->cap = cap;
	}
	uint8_t *at = p->data + p->pos;
	memset(at, 0, pad4(n));
	p->pos += pad4(n);
	if (p->pos > p->size) p->size = p->pos;
	return at;
}


static binder_status_t put(AParcel *p, void const *v, size_t n)
{
	uint8_t *at = space(p, n);
	if (!at) return STATUS_NO_MEMORY;
	if (n) memcpy(at, v, n);
	return STATUS_OK;
}


static binder_status_t get(AParcel const *p, void *v, size_t n)
{
	if (p->pos + pad4(n) > p->size) return STATUS_NOT_ENOUGH_DATA;
	if (n) memcpy(v, p->data + p->pos, n);
	p->pos += pad4(n);
	return STATUS_OK;
}


AParcel *Android_binder::parcel_create() { return (AParcel *)calloc(1, sizeof(AParcel)); }

AParcel *Android_binder::parcel_from(void const *data, size_t size)
{
	AParcel *p = parcel_create();
	if (!p) return nullptr;
	p->data = (uint8_t *)malloc(size ? size : 1);
	if (!p->data) { free(p); return nullptr; }
	memcpy(p->data, data, size);
	p->size = p->cap = size;
	return p;
}

uint8_t const *Android_binder::parcel_data(AParcel const *p) { return p->data; }
size_t         Android_binder::parcel_size(AParcel const *p) { return p->size; }

bool Android_binder::parcel_set(AParcel *p, void const *data, size_t size)
{
	p->size = p->pos = 0;
	if (!size) return true;
	uint8_t *at = space(p, size);
	if (!at) return false;
	memcpy(at, data, size);
	p->size = size;   /* not padded: the copy is exactly what the sender wrote */
	p->pos  = 0;
	return true;
}

void Android_binder::set_binder_codec(AParcel *p, Binder_codec *c) { p->codec = c; }
Android_binder::Binder_codec *Android_binder::binder_codec(AParcel const *p) { return p->codec; }


extern "C" {

	/* AStatus */

	static AStatus *status_new(binder_exception_t ex, binder_status_t st, int32_t err, char const *msg)
	{
		AStatus *s = (AStatus *)calloc(1, sizeof(AStatus));
		if (!s) return nullptr;
		s->exception = ex; s->status = st; s->service_error = err;
		s->message = msg ? strdup(msg) : nullptr;
		return s;
	}

	AStatus *AStatus_newOk() { return status_new(EX_NONE, STATUS_OK, 0, nullptr); }
	AStatus *AStatus_fromExceptionCode(binder_exception_t e) { return status_new(e, STATUS_OK, 0, nullptr); }
	AStatus *AStatus_fromExceptionCodeWithMessage(binder_exception_t e, char const *m) { return status_new(e, STATUS_OK, 0, m); }
	AStatus *AStatus_fromServiceSpecificError(int32_t e) { return status_new(EX_SERVICE_SPECIFIC, STATUS_OK, e, nullptr); }
	AStatus *AStatus_fromServiceSpecificErrorWithMessage(int32_t e, char const *m) { return status_new(EX_SERVICE_SPECIFIC, STATUS_OK, e, m); }

	AStatus *AStatus_fromStatus(binder_status_t st)
	{
		return st == STATUS_OK ? AStatus_newOk() : status_new(EX_TRANSACTION_FAILED, st, 0, nullptr);
	}

	bool AStatus_isOk(AStatus const *s) { return s->exception == EX_NONE; }
	binder_exception_t AStatus_getExceptionCode(AStatus const *s) { return s->exception; }
	int32_t AStatus_getServiceSpecificError(AStatus const *s) { return s->exception == EX_SERVICE_SPECIFIC ? s->service_error : 0; }
	binder_status_t AStatus_getStatus(AStatus const *s) { return s->exception == EX_TRANSACTION_FAILED ? s->status : STATUS_OK; }
	char const *AStatus_getMessage(AStatus const *s) { return s->message ? s->message : ""; }

	char const *AStatus_getDescription(AStatus const *s)
	{
		char buf[256];
		snprintf(buf, sizeof(buf), "Status(%d, %s): %d, %d: '%s'", s->exception,
		         s->exception == EX_NONE ? "EX_NONE" : "EX_ERROR", s->service_error, s->status,
		         s->message ? s->message : "");
		return strdup(buf);
	}

	void AStatus_deleteDescription(char const *d) { free((void *)d); }

	void AStatus_delete(AStatus *s)
	{
		if (!s) return;
		free(s->message);
		free(s);
	}

	/* AParcel */

	void AParcel_delete(AParcel *p)
	{
		if (!p) return;
		free(p->data);
		free(p);
	}

	int32_t AParcel_getDataPosition(AParcel const *p) { return int32_t(p->pos); }

	binder_status_t AParcel_setDataPosition(AParcel const *p, int32_t pos)
	{
		if (pos < 0 || size_t(pos) > p->size) return STATUS_BAD_VALUE;
		p->pos = size_t(pos);
		return STATUS_OK;
	}

	binder_status_t AParcel_writeInt32(AParcel *p, int32_t v) { return put(p, &v, 4); }
	binder_status_t AParcel_writeInt64(AParcel *p, int64_t v) { return put(p, &v, 8); }
	binder_status_t AParcel_writeBool (AParcel *p, bool v)    { return AParcel_writeInt32(p, v ? 1 : 0); }
	binder_status_t AParcel_writeByte (AParcel *p, int8_t v)  { return AParcel_writeInt32(p, v); }
	binder_status_t AParcel_writeChar (AParcel *p, char16_t v){ return AParcel_writeInt32(p, int32_t(v)); }

	binder_status_t AParcel_readInt32(AParcel const *p, int32_t *v) { return get(p, v, 4); }
	binder_status_t AParcel_readInt64(AParcel const *p, int64_t *v) { return get(p, v, 8); }

	binder_status_t AParcel_readBool(AParcel const *p, bool *v)
	{
		int32_t i; binder_status_t const r = get(p, &i, 4);
		if (r == STATUS_OK) *v = i != 0;
		return r;
	}

	binder_status_t AParcel_readByte(AParcel const *p, int8_t *v)
	{
		int32_t i; binder_status_t const r = get(p, &i, 4);
		if (r == STATUS_OK) *v = int8_t(i);
		return r;
	}

	binder_status_t AParcel_readChar(AParcel const *p, char16_t *v)
	{
		int32_t i; binder_status_t const r = get(p, &i, 4);
		if (r == STATUS_OK) *v = char16_t(i);
		return r;
	}

	binder_status_t AParcel_writeString(AParcel *p, char const *s, int32_t len)
	{
		if (!s || len < 0) return AParcel_writeInt32(p, -1);
		binder_status_t r = AParcel_writeInt32(p, len);
		if (r != STATUS_OK) return r;
		uint8_t *at = space(p, size_t(len) + 1);
		if (!at) return STATUS_NO_MEMORY;
		memcpy(at, s, size_t(len));
		at[len] = 0;
		return STATUS_OK;
	}

	/* allocator gets the length incl. NUL, or -1 for null */
	binder_status_t AParcel_readString(AParcel const *p, void *data, AParcel_stringAllocator alloc)
	{
		int32_t len;
		binder_status_t r = AParcel_readInt32(p, &len);
		if (r != STATUS_OK) return r;
		char *buf = nullptr;
		if (len < 0) return alloc(data, -1, &buf) ? STATUS_OK : STATUS_UNEXPECTED_NULL;
		if (p->pos + pad4(size_t(len) + 1) > p->size) return STATUS_NOT_ENOUGH_DATA;
		if (!alloc(data, len + 1, &buf) || !buf) return STATUS_NO_MEMORY;
		memcpy(buf, p->data + p->pos, size_t(len));
		buf[len] = 0;
		p->pos += pad4(size_t(len) + 1);
		return STATUS_OK;
	}

	binder_status_t AParcel_writeInt32Array(AParcel *p, int32_t const *a, int32_t len)
	{
		if (!a && len != 0) return AParcel_writeInt32(p, -1);
		binder_status_t r = AParcel_writeInt32(p, len);
		return r == STATUS_OK ? put(p, a, size_t(len) * 4) : r;
	}

	binder_status_t AParcel_readInt32Array(AParcel const *p, void *data, AParcel_int32ArrayAllocator alloc)
	{
		int32_t len;
		binder_status_t r = AParcel_readInt32(p, &len);
		if (r != STATUS_OK) return r;
		int32_t *buf = nullptr;
		if (len < 0) return alloc(data, -1, &buf) ? STATUS_OK : STATUS_UNEXPECTED_NULL;
		if (p->pos + size_t(len) * 4 > p->size) return STATUS_NOT_ENOUGH_DATA;
		if (!alloc(data, len, &buf)) return STATUS_NO_MEMORY;
		return get(p, buf, size_t(len) * 4);
	}

	binder_status_t AParcel_writeByteArray(AParcel *p, int8_t const *a, int32_t len)
	{
		if (!a && len != 0) return AParcel_writeInt32(p, -1);
		binder_status_t r = AParcel_writeInt32(p, len);
		return r == STATUS_OK ? put(p, a, size_t(len)) : r;
	}

	binder_status_t AParcel_readByteArray(AParcel const *p, void *data, AParcel_byteArrayAllocator alloc)
	{
		int32_t len;
		binder_status_t r = AParcel_readInt32(p, &len);
		if (r != STATUS_OK) return r;
		int8_t *buf = nullptr;
		if (len < 0) return alloc(data, -1, &buf) ? STATUS_OK : STATUS_UNEXPECTED_NULL;
		if (p->pos + pad4(size_t(len)) > p->size) return STATUS_NOT_ENOUGH_DATA;
		if (!alloc(data, len, &buf)) return STATUS_NO_MEMORY;
		return get(p, buf, size_t(len));
	}

	binder_status_t AParcel_writeStringArray(AParcel *p, void const *data, int32_t len,
	                                         AParcel_stringArrayElementGetter getter)
	{
		if (!data && len != 0) return AParcel_writeInt32(p, -1);
		binder_status_t r = AParcel_writeInt32(p, len);
		for (int32_t i = 0; r == STATUS_OK && i < len; i++) {
			int32_t slen = 0;
			char const *s = getter(data, size_t(i), &slen);
			r = AParcel_writeString(p, s, s ? slen : -1);
		}
		return r;
	}

	namespace { struct Elem_ctx { void *data; size_t index; AParcel_stringArrayElementAllocator alloc; }; }

	static bool elem_string_alloc(void *ctx, int32_t len, char **buf)
	{
		Elem_ctx *c = (Elem_ctx *)ctx;
		return c->alloc(c->data, c->index, len, buf);
	}

	binder_status_t AParcel_readStringArray(AParcel const *p, void *data,
	                                        AParcel_stringArrayAllocator alloc,
	                                        AParcel_stringArrayElementAllocator elem_alloc)
	{
		int32_t len;
		binder_status_t r = AParcel_readInt32(p, &len);
		if (r != STATUS_OK) return r;
		if (!array_fits(p, len)) return STATUS_NOT_ENOUGH_DATA;
		if (!alloc(data, len)) return len < 0 ? STATUS_UNEXPECTED_NULL : STATUS_NO_MEMORY;
		for (int32_t i = 0; r == STATUS_OK && i < len; i++) {
			Elem_ctx ctx { data, size_t(i), elem_alloc };
			r = AParcel_readString(p, &ctx, elem_string_alloc);
		}
		return r;
	}

	binder_status_t AParcel_writeParcelableArray(AParcel *p, void const *data, int32_t len,
	                                             AParcel_writeParcelableElement write)
	{
		if (!data && len != 0) return AParcel_writeInt32(p, -1);
		binder_status_t r = AParcel_writeInt32(p, len);
		for (int32_t i = 0; r == STATUS_OK && i < len; i++)
			r = write(p, data, size_t(i));
		return r;
	}

	binder_status_t AParcel_readParcelableArray(AParcel const *p, void *data,
	                                            AParcel_parcelableArrayAllocator alloc,
	                                            AParcel_readParcelableElement read)
	{
		int32_t len;
		binder_status_t r = AParcel_readInt32(p, &len);
		if (r != STATUS_OK) return r;
		if (!array_fits(p, len)) return STATUS_NOT_ENOUGH_DATA;
		if (!alloc(data, len)) return len < 0 ? STATUS_UNEXPECTED_NULL : STATUS_NO_MEMORY;
		for (int32_t i = 0; r == STATUS_OK && i < len; i++)
			r = read(p, data, size_t(i));
		return r;
	}

	binder_status_t AParcel_writeStatusHeader(AParcel *p, AStatus const *s)
	{
		binder_status_t r = AParcel_writeInt32(p, s->exception);
		if (r != STATUS_OK || s->exception == EX_NONE) return r;
		if (s->exception == EX_SERVICE_SPECIFIC)        r = AParcel_writeInt32(p, s->service_error);
		else if (s->exception == EX_TRANSACTION_FAILED) r = AParcel_writeInt32(p, s->status);
		if (r != STATUS_OK) return r;
		return AParcel_writeString(p, s->message, s->message ? int32_t(strlen(s->message)) : -1);
	}

	static bool status_msg_alloc(void *ctx, int32_t len, char **buf)
	{
		char **msg = (char **)ctx;
		if (len < 0) { *msg = nullptr; *buf = nullptr; return true; }
		*msg = (char *)malloc(size_t(len));
		*buf = *msg;
		return *msg != nullptr;
	}

	binder_status_t AParcel_readStatusHeader(AParcel const *p, AStatus **out)
	{
		int32_t ex;
		binder_status_t r = AParcel_readInt32(p, &ex);
		if (r != STATUS_OK) return r;
		int32_t extra = 0;
		char *msg = nullptr;
		if (ex != EX_NONE) {
			if (ex == EX_SERVICE_SPECIFIC || ex == EX_TRANSACTION_FAILED)
				if ((r = AParcel_readInt32(p, &extra)) != STATUS_OK) return r;
			if ((r = AParcel_readString(p, &msg, status_msg_alloc)) != STATUS_OK) return r;
		}
		*out = status_new(ex, ex == EX_TRANSACTION_FAILED ? extra : STATUS_OK,
		                  ex == EX_SERVICE_SPECIFIC ? extra : 0, msg);
		free(msg);
		return *out ? STATUS_OK : STATUS_NO_MEMORY;
	}

	binder_status_t AParcel_writeStrongBinder(AParcel *p, AIBinder *b)
	{
		if (!p->codec) {
			if (b) return STATUS_INVALID_OPERATION;
			AParcel_writeInt32(p, 0);
			return AParcel_writeInt32(p, 0);
		}
		return p->codec->write(p, b);
	}

	binder_status_t AParcel_readStrongBinder(AParcel const *p, AIBinder **b)
	{
		if (!p->codec) {
			int32_t kind, id;
			binder_status_t r = AParcel_readInt32(p, &kind);
			if (r == STATUS_OK) r = AParcel_readInt32(p, &id);
			*b = nullptr;
			return r == STATUS_OK && kind != 0 ? STATUS_INVALID_OPERATION : r;
		}
		return p->codec->read(p, b);
	}
}
