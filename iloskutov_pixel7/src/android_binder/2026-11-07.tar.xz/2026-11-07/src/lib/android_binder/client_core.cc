/*
 * \brief  Transport-independent core of an Android_binder client connection
 * \author Ivan Loskutov
 * \date   2026-09-27
 */

/*
 * SPDX-License-Identifier: MIT
 */

#include <android_binder/client_core.h>
#include <base/log.h>

#include <string.h>

using namespace Android_binder;


int Client_core::register_callback(Callback &cb)
{
	unsigned const n = _count();
	for (unsigned i = 0; i < n; i++)
		if (_cb[i] == &cb) return int(i + 1);

	if (n >= MAX_CB) return -1;

	_cb[n] = &cb;
	__atomic_store_n(&_cb_n, n + 1, __ATOMIC_RELEASE);   /* publish the entry */
	return int(n + 1);
}


Callback *Client_core::callback(unsigned id) const
{
	return (id >= 1 && id <= _count()) ? _cb[id - 1] : nullptr;
}


binder_status_t Client_core::Codec::write(AParcel *p, AIBinder *b)
{
	int32_t id = 0;
	if (b) {
		Callback const *cb = reinterpret_cast<Callback const *>(b);
		unsigned const n = core._count();
		for (unsigned i = 0; i < n && !id; i++)
			if (core._cb[i] == cb) id = int32_t(i + 1);
		if (!id) return STATUS_BAD_VALUE;   /* not registered at this connection */
	}
	binder_status_t const r = AParcel_writeInt32(p, id ? 1 : 0);
	return r == STATUS_OK ? AParcel_writeInt32(p, id) : r;
}


binder_status_t Client_core::Codec::read(AParcel const *p, AIBinder **out)
{
	int32_t kind = 0, id = 0;
	binder_status_t r = AParcel_readInt32(p, &kind);
	if (r == STATUS_OK) r = AParcel_readInt32(p, &id);
	*out = nullptr;
	return r;
}


Client_core::Transact_result
Client_core::transact(Transport &transport, uint8_t *txn, size_t txn_size,
                      uint32_t code, AParcel const &in, bool oneway,
                      AParcel *reply, binder_status_t &status)
{
	size_t const len = parcel_size(&in);
	if (len > txn_size) {
		status = STATUS_FAILED_TRANSACTION;
		return Transact_result::TOO_LARGE;
	}
	if (len) ::memcpy(txn, parcel_data(&in), len);

	Transport::Result const r = transport.transact(code, oneway, uint32_t(len));
	if (!r.ok || (!oneway && r.reply_len > txn_size)) {
		status = STATUS_DEAD_OBJECT;
		return Transact_result::FAILED;
	}

	status = r.status;
	if (!oneway && reply && !parcel_set(reply, txn, r.reply_len)) {
		status = STATUS_NO_MEMORY;
		return Transact_result::NO_MEMORY;
	}
	return Transact_result::OK;
}


unsigned Client_core::drain(Ring &ring)
{
	unsigned n = 0;
	Ring::Entry e { };

	/* lost callbacks are not silent: a reply the logic waits for may be among them */
	if (uint32_t const d = ring.dropped(); d != _dropped_seen) {
		_dropped_seen = d;
		Genode::warning("android_binder: ", d, " callbacks dropped by the server (ring full)");
	}
	if (uint32_t const c = ring.corrupt(); c != _corrupt_seen) {
		_corrupt_seen = c;
		Genode::warning("android_binder: ", c, " malformed callback records, ring resynchronised");
	}
	while (n < MAX_DRAIN && ring.pop(e)) {
		n++;
		Callback *cb = callback(e.object);
		AParcel  *in = cb ? parcel_from(e.data, e.len) : nullptr;
		if (in) {
			cb->on_transact(e.code, *in);
			AParcel_delete(in);
		} else {
			__atomic_add_fetch(&_skipped, 1, __ATOMIC_RELAXED);
		}
		ring.release(e);
	}
	return n;
}
