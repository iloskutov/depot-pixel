/*
 * \brief  Client connection to one Android_binder service instance
 * \author Ivan Loskutov
 * \date   2026-09-27
 *
 * Session plumbing around 'Client_core'. A failing RPC is reported as
 * 'Genode::Ipc_error' where the kernel reflects it; the connection is then
 * marked disconnected. The dataspace stays attached until the next 'open'
 * so a 'drain' concurrent to a failing 'transact' never touches unmapped
 * memory.
 */

/*
 * SPDX-License-Identifier: MIT
 */

#include <android_binder/client.h>
#include <base/log.h>

using namespace Android_binder;


Client_conn::Client_conn(Genode::Env &env, char const *instance)
:
	_env(env), _instance(instance)
{ }


void Client_conn::_disconnect(char const *reason)
{
	if (!_connected) return;
	_connected = false;
	Genode::error("android_binder: '", _instance, "': ", reason, ", disconnected");
}


void Client_conn::_install_sigh()
{
	if (!_connected || !_sigh.valid()) return;
	try { _conn->client().callback_sigh(_sigh); }
	catch (Genode::Ipc_error) { _disconnect("callback_sigh RPC failed"); }
}


Client_conn::Open_result Client_conn::open()
{
	if (_connected) return Open_result::OK;

	/* drop a failed session before requesting a new one */
	if (_conn.constructed() && _ds.constructed()) {
		_ring.destruct();
		_ds.destruct();
		_conn.destruct();
	}
	if (!_conn.constructed())
		_conn.construct(_env);

	switch (_conn->open(_instance.string())) {
	case Try_connection::Result::OK:     break;
	case Try_connection::Result::DENIED: return Open_result::DENIED;
	case Try_connection::Result::FAILED: return Open_result::FAILED;
	}

	try {
		_ds.construct(_env.rm(), _conn->client().dataspace());
	} catch (Genode::Exception) {
		Genode::error("android_binder: '", _instance, "': cannot attach the session dataspace");
		_ds.destruct();
		_conn.destruct();
		return Open_result::FAILED;
	}
	if (_ds->size() < TXN_SIZE + RING_SIZE) {
		Genode::error("android_binder: '", _instance, "': session dataspace too small (",
		              _ds->size(), ")");
		_ds.destruct();
		_conn.destruct();
		return Open_result::FAILED;
	}
	_ring.construct(_ds->local_addr<uint8_t>() + TXN_SIZE, RING_SIZE);
	_connected = true;
	_install_sigh();
	return _connected ? Open_result::OK : Open_result::FAILED;
}


Transport::Result Client_conn::Session_transport::transact(uint32_t code, bool oneway,
                                                           uint32_t len)
{
	try {
		Session::Transact_result const r =
			conn._conn->client().transact(0, code, oneway ? uint32_t(FLAG_ONEWAY) : 0u, len);
		return { true, r.status, r.reply_len };
	}
	catch (Genode::Ipc_error) { return { false, STATUS_DEAD_OBJECT, 0 }; }
}


Client_conn::Transact_result Client_conn::transact(uint32_t code, AParcel const &in,
                                                   bool oneway, AParcel *reply,
                                                   binder_status_t *status)
{
	binder_status_t st = STATUS_DEAD_OBJECT;
	Transact_result result = Transact_result::FAILED;

	{
		Genode::Mutex::Guard guard(_txn_mutex);

		if (_connected) {
			using R = Client_core::Transact_result;

			switch (_core.transact(_transport, _ds->local_addr<uint8_t>(), TXN_SIZE,
			                       code, in, oneway, reply, st)) {
			case R::OK:
				result = Transact_result::OK;
				break;
			case R::TOO_LARGE:
				Genode::error("android_binder: '", _instance, "': request parcel too large (",
				              parcel_size(&in), ")");
				break;
			case R::NO_MEMORY:
				Genode::error("android_binder: '", _instance, "': no memory for the reply");
				break;
			case R::FAILED:
				_disconnect("transaction failed");
				break;
			}
		}
	}

	if (status) *status = st;
	return result;
}


int Client_conn::register_callback(Callback &cb)
{
	Genode::Mutex::Guard guard(_cb_mutex);
	return _core.register_callback(cb);
}


unsigned Client_conn::drain()
{
	if (!_connected) return 0;

	unsigned const n = _core.drain(*_ring);

	/* stopped at the bound: the rest is drained by the next signal */
	if (n == Client_core::MAX_DRAIN && _sigh.valid())
		Genode::Signal_transmitter(_sigh).submit();

	unsigned const skipped = _core.skipped();
	if (skipped != _skipped_logged) {
		Genode::warning("android_binder: '", _instance, "': ", skipped - _skipped_logged,
		                " callback entries skipped (unknown object id or out of memory)");
		_skipped_logged = skipped;
	}
	return n;
}


void Client_conn::callback_sigh(Genode::Signal_context_capability sigh)
{
	_sigh = sigh;
	_install_sigh();
}
