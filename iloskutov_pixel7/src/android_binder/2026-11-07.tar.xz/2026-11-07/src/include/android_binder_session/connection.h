/*
 * \brief  Connection to an Android_binder service instance
 * \author Ivan Loskutov
 * \date   2026-09-25
 */

/*
 * SPDX-License-Identifier: MIT
 */

#ifndef _INCLUDE__ANDROID_BINDER_SESSION__CONNECTION_H_
#define _INCLUDE__ANDROID_BINDER_SESSION__CONNECTION_H_

#include <android_binder_session/android_binder_session.h>
#include <base/connection.h>
#include <base/rpc_client.h>
#include <util/reconstructible.h>
#include <try_connection.h>

namespace Android_binder_session {
	struct Session_client;
	struct Connection;
}


struct Android_binder_session::Session_client : Genode::Rpc_client<Session>
{
	explicit Session_client(Genode::Capability<Session> cap)
	: Genode::Rpc_client<Session>(cap) { }

	Genode::Dataspace_capability dataspace() override {
		return call<Rpc_dataspace>(); }

	Transact_result transact(uint32_t handle, uint32_t code,
	                         uint32_t flags, uint32_t len) override {
		return call<Rpc_transact>(handle, code, flags, len); }

	void callback_sigh(Genode::Signal_context_capability sigh) override {
		call<Rpc_callback_sigh>(sigh); }
};


namespace Android_binder_session {

	/**
	 * Connection opened on request: a server denies an instance its program
	 * has not exported (yet), so waitForService retries until it appears
	 */
	using Try_connection = Genode_pixel::Try_connection<Session, Session_client>;
}


/**
 * Connection that blocks until the instance is served
 *
 * If the server denies the instance (not exported), Genode's session
 * request stops the component for good -- use Try_connection to retry.
 */
struct Android_binder_session::Connection : Genode::Connection<Session>, Session_client
{
	/**
	 * \param instance  e.g. "android.hardware.radio.network.IRadioNetwork/slot1"
	 */
	Connection(Genode::Env &env, char const *instance)
	:
		Genode::Connection<Session>(env, Genode::Session_label(instance),
		                            Genode::Ram_quota { RAM_QUOTA }, Args()),
		Session_client(cap())
	{ }
};


#endif /* _INCLUDE__ANDROID_BINDER_SESSION__CONNECTION_H_ */
