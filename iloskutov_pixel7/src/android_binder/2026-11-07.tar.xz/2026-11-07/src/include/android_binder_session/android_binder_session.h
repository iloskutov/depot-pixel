/*
 * \brief  Android_binder session: one service instance exported by a
 *         component running Android code (e.g. rild's IRadioNetwork/slot1)
 * \author Ivan Loskutov
 * \date   2026-09-25
 *
 * The session label's last element names the instance. Parcels travel in
 * the session's shared dataspace:
 *
 *   [0, TXN_SIZE)                 transaction area (request, then reply)
 *   [TXN_SIZE, TXN_SIZE+RING_SIZE) callback ring (server -> client oneway)
 *
 * Handle 0 is the instance's root object. Binder objects the client passes
 * to the server are addressed by the client's ids in callback entries.
 */

/*
 * SPDX-License-Identifier: MIT
 */

#ifndef _INCLUDE__ANDROID_BINDER_SESSION__ANDROID_BINDER_SESSION_H_
#define _INCLUDE__ANDROID_BINDER_SESSION__ANDROID_BINDER_SESSION_H_

#include <base/rpc.h>
#include <base/signal.h>
#include <dataspace/capability.h>
#include <session/session.h>

namespace Android_binder_session { struct Session; }


struct Android_binder_session::Session : Genode::Session
{
	static const char *service_name() { return "Android_binder"; }

	enum { CAP_QUOTA = 6,
	       TXN_SIZE  = 64*1024,
	       RING_SIZE = 256*1024,
	       RAM_QUOTA = TXN_SIZE + RING_SIZE + 16*1024 };

	struct Transact_result
	{
		int32_t  status;       /* binder_status_t */
		uint32_t reply_len;    /* bytes of the reply in the transaction area */
	};

	virtual Genode::Dataspace_capability dataspace() = 0;

	/**
	 * Run transaction 'code' on object 'handle' with 'len' request bytes
	 *
	 * \param flags  FLAG_ONEWAY (1): no reply, returns when queued
	 */
	virtual Transact_result transact(uint32_t handle, uint32_t code,
	                                 uint32_t flags, uint32_t len) = 0;

	/**
	 * Signal for new entries in the callback ring
	 */
	virtual void callback_sigh(Genode::Signal_context_capability) = 0;

	GENODE_RPC(Rpc_dataspace, Genode::Dataspace_capability, dataspace);
	GENODE_RPC(Rpc_transact, Transact_result, transact, uint32_t, uint32_t, uint32_t, uint32_t);
	GENODE_RPC(Rpc_callback_sigh, void, callback_sigh, Genode::Signal_context_capability);

	GENODE_RPC_INTERFACE(Rpc_dataspace, Rpc_transact, Rpc_callback_sigh);
};

#endif /* _INCLUDE__ANDROID_BINDER_SESSION__ANDROID_BINDER_SESSION_H_ */
