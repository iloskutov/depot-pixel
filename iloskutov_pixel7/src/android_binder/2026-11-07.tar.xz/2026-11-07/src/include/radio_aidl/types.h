/*
 * \brief  Value types and parcel codecs used by the generated radio AIDL headers
 * \author Ivan Loskutov
 * \date   2026-09-27
 *
 * The generated headers (tool/aidl_gen.py) describe AIDL types as
 * plain structs without heap: strings are fixed-capacity 'Str_n', arrays
 * fixed-capacity 'Vec', '@nullable' parcelables 'Opt'. 'Codec<T>' writes and
 * reads a value in the format the NDK-generated stubs produce through our
 * 'AParcel_*' implementation (lib/android_binder, parcel.cc):
 *
 *   int, boolean, byte, char   int32 slot     long   int64
 *   enum                       its backing type's slot
 *   String                     AParcel_writeString (int32 length, -1 = null)
 *   T[]                        int32 count (-1 = null), elements
 *   byte[], byte-enum[]        AParcel_writeByteArray (packed)
 *   parcelable, union          int32 1 (non-null marker), body
 *   @nullable parcelable       int32 0, or int32 1 and the body
 *   parcelable body            int32 size (counts itself), fields in order
 *   union body                 int32 tag (member index), the member
 *   interface                  AParcel_writeStrongBinder (via the codec)
 *
 * Reading is lenient where the NDK would fail with UNEXPECTED_NULL (a null
 * non-nullable string or array reads as 'null'). A string or array longer
 * than its capacity is truncated (and marked), the parcel is still consumed
 * completely.
 */

/*
 * SPDX-License-Identifier: MIT
 */

#ifndef _INCLUDE__RADIO_AIDL__TYPES_H_
#define _INCLUDE__RADIO_AIDL__TYPES_H_

#include <android_binder/parcel.h>
#include <android_binder/client_core.h>

namespace Radio_aidl {

	/* transaction codes (frameworks/native IBinder.h, NDK-generated stubs) */
	enum : uint32_t {
		FIRST_CALL_TRANSACTION = 1,
		GET_INTERFACE_VERSION  = FIRST_CALL_TRANSACTION + 16777214,   /* 0x00ffffff */
		GET_INTERFACE_HASH     = FIRST_CALL_TRANSACTION + 16777213,   /* 0x00fffffe */
	};

	template <unsigned CAP>              struct Str_n;
	template <typename T, unsigned N>    struct Vec;
	template <typename T>                struct Opt;
	template <typename T>                struct Codec;

	using Str = Str_n<256>;

	template <typename T> inline bool put(AParcel &p, T const &v) { return Codec<T>::put(p, v); }
	template <typename T> inline bool get(AParcel const &p, T &v) { return Codec<T>::get(p, v); }

	inline int32_t pos(AParcel const &p) { return AParcel_getDataPosition(&p); }
	inline bool    seek(AParcel const &p, int32_t at) { return AParcel_setDataPosition(&p, at) == STATUS_OK; }

	inline uint32_t pad4(uint32_t n) { return (n + 3u) & ~3u; }

	/* bytes left behind the read position */
	inline uint32_t remaining(AParcel const &p)
	{
		size_t const size = Android_binder::parcel_size(&p);
		size_t const at   = size_t(pos(p));
		return at < size ? uint32_t(size - at) : 0u;
	}

	inline void copy(char *dst, char const *src, uint32_t n) { for (uint32_t i = 0; i < n; i++) dst[i] = src[i]; }
}


/**
 * String of at most CAP-1 bytes (UTF-8, NUL-terminated)
 */
template <unsigned CAP>
struct Radio_aidl::Str_n
{
	static_assert(CAP > 1, "string capacity too small");

	char     buf[CAP] { };
	uint32_t len       = 0;
	bool     null      = false;   /* written as length -1 */
	bool     truncated = false;   /* read: the sender's string was longer */

	Str_n() { }

	Str_n(char const *s) { set(s); }

	/**
	 * Assign a C string, nullptr makes the string null
	 */
	void set(char const *s)
	{
		null = !s; len = 0; truncated = false;
		if (s) while (s[len] && len + 1 < CAP) { buf[len] = s[len]; len++; }
		if (s && s[len]) truncated = true;
		buf[len] = 0;
	}

	char const *string() const { return buf; }

	bool operator == (char const *s) const
	{
		if (null || !s) return null && !s;
		uint32_t i = 0;
		for (; i < len; i++) if (buf[i] != s[i]) return false;
		return s[i] == 0;
	}
};


/**
 * Array of at most N elements
 */
template <typename T, unsigned N>
struct Radio_aidl::Vec
{
	static_assert(N > 0, "array capacity must not be 0");

	T        items[N] { };
	uint32_t count     = 0;
	bool     null      = false;   /* written as count -1 */
	bool     truncated = false;   /* read: the sender had more elements */

	enum { CAPACITY = N };

	/**
	 * Append a copy, false if full
	 */
	bool add(T const &v)
	{
		if (count >= N) return false;
		items[count++] = v;
		return true;
	}

	T       &operator [] (unsigned i)       { return items[i]; }
	T const &operator [] (unsigned i) const { return items[i]; }
};


/**
 * '@nullable' parcelable or union
 */
template <typename T>
struct Radio_aidl::Opt
{
	T    value   { };
	bool present = false;
};


namespace Radio_aidl {

	/*
	 * Primary template: parcelables and unions (generated structs with
	 * 'write'/'read' of their body), preceded by the non-null marker
	 */
	template <typename T>
	struct Codec
	{
		static bool put(AParcel &p, T const &v) { return AParcel_writeInt32(&p, 1) == STATUS_OK && v.write(p); }

		static bool get(AParcel const &p, T &v)
		{
			int32_t marker = 0;
			return AParcel_readInt32(&p, &marker) == STATUS_OK && marker != 0 && v.read(p);
		}
	};

	template <> struct Codec<int32_t>
	{
		static bool put(AParcel &p, int32_t v)        { return AParcel_writeInt32(&p, v) == STATUS_OK; }
		static bool get(AParcel const &p, int32_t &v) { return AParcel_readInt32(&p, &v) == STATUS_OK; }
	};

	template <> struct Codec<int64_t>
	{
		static bool put(AParcel &p, int64_t v)        { return AParcel_writeInt64(&p, v) == STATUS_OK; }
		static bool get(AParcel const &p, int64_t &v) { return AParcel_readInt64(&p, &v) == STATUS_OK; }
	};

	template <> struct Codec<bool>
	{
		static bool put(AParcel &p, bool v)        { return AParcel_writeBool(&p, v) == STATUS_OK; }
		static bool get(AParcel const &p, bool &v) { return AParcel_readBool(&p, &v) == STATUS_OK; }
	};

	template <> struct Codec<int8_t>
	{
		static bool put(AParcel &p, int8_t v)        { return AParcel_writeByte(&p, v) == STATUS_OK; }
		static bool get(AParcel const &p, int8_t &v) { return AParcel_readByte(&p, &v) == STATUS_OK; }
	};

	template <> struct Codec<uint8_t>
	{
		static bool put(AParcel &p, uint8_t v) { return AParcel_writeByte(&p, int8_t(v)) == STATUS_OK; }

		static bool get(AParcel const &p, uint8_t &v)
		{
			int8_t b = 0;
			if (AParcel_readByte(&p, &b) != STATUS_OK) return false;
			v = uint8_t(b);
			return true;
		}
	};

	template <> struct Codec<char16_t>
	{
		static bool put(AParcel &p, char16_t v)        { return AParcel_writeChar(&p, v) == STATUS_OK; }
		static bool get(AParcel const &p, char16_t &v) { return AParcel_readChar(&p, &v) == STATUS_OK; }
	};

	/* enum: the backing type's slot */
	template <typename E, typename B>
	struct Enum_codec
	{
		static bool put(AParcel &p, E v) { return Codec<B>::put(p, B(v)); }

		static bool get(AParcel const &p, E &v)
		{
			B b { };
			if (!Codec<B>::get(p, b)) return false;
			v = E(b);
			return true;
		}
	};

	template <unsigned CAP>
	struct Codec<Str_n<CAP>>
	{
		static bool put(AParcel &p, Str_n<CAP> const &s)
		{
			/* 'len' is clamped: the struct may have been filled by hand */
			uint32_t const len = s.len < CAP ? s.len : CAP - 1;
			return AParcel_writeString(&p, s.null ? nullptr : s.buf,
			                           s.null ? -1 : int32_t(len)) == STATUS_OK;
		}

		static bool get(AParcel const &p, Str_n<CAP> &s)
		{
			int32_t len = 0;
			if (AParcel_readInt32(&p, &len) != STATUS_OK) return false;
			s = Str_n<CAP>();
			if (len < 0) { s.null = true; return true; }

			uint32_t const n = uint32_t(len);
			if (n >= 0x7ffffff0u || pad4(n + 1) > remaining(p)) return false;

			char const *src = (char const *)Android_binder::parcel_data(&p) + pos(p);
			s.len       = n < CAP ? n : CAP - 1;
			s.truncated = n >= CAP;
			copy(s.buf, src, s.len);
			s.buf[s.len] = 0;
			return seek(p, pos(p) + int32_t(pad4(n + 1)));
		}
	};

	/* 'const char *' request argument */
	inline bool put_cstring(AParcel &p, char const *s)
	{
		int32_t len = 0;
		if (s) while (s[len]) len++;
		return AParcel_writeString(&p, s, s ? len : -1) == STATUS_OK;
	}

	/* element-wise array: int32 count, elements */
	template <typename T, unsigned N>
	struct Codec<Vec<T, N>>
	{
		static bool put(AParcel &p, Vec<T, N> const &v)
		{
			if (v.null) return AParcel_writeInt32(&p, -1) == STATUS_OK;
			/* 'count' is clamped: the struct may have been filled by hand */
			uint32_t const count = v.count < N ? v.count : N;
			if (AParcel_writeInt32(&p, int32_t(count)) != STATUS_OK) return false;
			for (unsigned i = 0; i < count; i++)
				if (!Codec<T>::put(p, v.items[i])) return false;
			return true;
		}

		static bool get(AParcel const &p, Vec<T, N> &v)
		{
			int32_t count = 0;
			if (AParcel_readInt32(&p, &count) != STATUS_OK) return false;
			v.count = 0; v.null = false; v.truncated = false;
			if (count < 0) { v.null = true; return true; }

			/* every element takes at least 4 bytes */
			if (uint32_t(count) > remaining(p) / 4) return false;

			for (int32_t i = 0; i < count; i++) {
				if (v.count < N) {
					if (!Codec<T>::get(p, v.items[v.count])) return false;
					v.count++;
				} else {
					T excess { };
					if (!Codec<T>::get(p, excess)) return false;
					v.truncated = true;
				}
			}
			return true;
		}
	};

	/* packed byte array (byte[] and arrays of byte-backed enums) */
	template <typename T, unsigned N>
	struct Byte_vec_codec
	{
		static_assert(sizeof(T) == 1, "packed arrays need 1-byte elements");

		static bool put(AParcel &p, Vec<T, N> const &v)
		{
			if (v.null) return AParcel_writeByteArray(&p, nullptr, -1) == STATUS_OK;
			return AParcel_writeByteArray(&p, (int8_t const *)v.items,
			                              int32_t(v.count < N ? v.count : N)) == STATUS_OK;
		}

		static bool get(AParcel const &p, Vec<T, N> &v)
		{
			int32_t count = 0;
			if (AParcel_readInt32(&p, &count) != STATUS_OK) return false;
			v.count = 0; v.null = false; v.truncated = false;
			if (count < 0) { v.null = true; return true; }

			uint32_t const n = uint32_t(count);
			if (n >= 0x7ffffff0u || pad4(n) > remaining(p)) return false;

			uint8_t const *src = Android_binder::parcel_data(&p) + pos(p);
			v.count     = n < N ? n : N;
			v.truncated = n > N;
			for (uint32_t i = 0; i < v.count; i++) v.items[i] = T(src[i]);
			return seek(p, pos(p) + int32_t(pad4(n)));
		}
	};

	template <unsigned N> struct Codec<Vec<uint8_t, N>> : Byte_vec_codec<uint8_t, N> { };
	template <unsigned N> struct Codec<Vec<int8_t,  N>> : Byte_vec_codec<int8_t,  N> { };

	template <typename T>
	struct Codec<Opt<T>>
	{
		static bool put(AParcel &p, Opt<T> const &o)
		{
			if (!o.present) return AParcel_writeInt32(&p, 0) == STATUS_OK;
			return AParcel_writeInt32(&p, 1) == STATUS_OK && o.value.write(p);
		}

		static bool get(AParcel const &p, Opt<T> &o)
		{
			int32_t marker = 0;
			if (AParcel_readInt32(&p, &marker) != STATUS_OK) return false;
			o.present = marker != 0;
			return !o.present || o.value.read(p);
		}
	};

	/*
	 * Parcelable body: int32 size placeholder, backfilled when the fields
	 * are written (the size counts the size field itself)
	 */
	struct Parcelable_writer
	{
		AParcel &p;
		int32_t  start;
		bool     ok;

		Parcelable_writer(AParcel &p)
		: p(p), start(pos(p)), ok(AParcel_writeInt32(&p, 0) == STATUS_OK) { }

		bool finish()
		{
			int32_t const end = pos(p);
			return ok && seek(p, start) && AParcel_writeInt32(&p, end - start) == STATUS_OK
			          && seek(p, end);
		}
	};

	/*
	 * Parcelable body on read: fields are read while inside the declared
	 * size (an older sender has fewer fields, they keep their defaults),
	 * 'finish' seeks to start + size (skips fields of a newer sender) and
	 * fails if the fields read ran past the size, so no part of a parcel
	 * is decoded twice
	 */
	struct Parcelable_reader
	{
		AParcel const &p;
		int32_t        start;
		int32_t        size = 0;
		bool           ok;

		Parcelable_reader(AParcel const &p)
		:
			p(p), start(pos(p)),
			ok(AParcel_readInt32(&p, &size) == STATUS_OK && size >= 4
			   && start <= 0x7fffffff - size)
		{ }

		bool more() const { return pos(p) - start < size; }

		bool finish() { return pos(p) - start <= size && seek(p, start + size); }
	};

	/**
	 * Oneway transaction: a fresh parcel with the connection's codec,
	 * filled by 'encode', sent with 'code'
	 *
	 * CONN is 'Android_binder::Client_conn' (or a test double with the same
	 * 'codec', 'transact' and 'Transact_result').
	 */
	template <typename CONN, typename FN>
	inline bool transact_oneway(CONN &conn, uint32_t code, FN const &encode)
	{
		AParcel *p = Android_binder::parcel_create();
		if (!p) return false;
		Android_binder::set_binder_codec(p, &conn.codec());
		bool const ok = encode(*p)
		             && conn.transact(code, *p, true) == CONN::Transact_result::OK;
		AParcel_delete(p);
		return ok;
	}

	/**
	 * Register a local callback object and return its binder token
	 *
	 * \return nullptr if the connection's callback table is full
	 */
	template <typename CONN>
	inline AIBinder *callback_binder(CONN &conn, Android_binder::Callback &cb)
	{
		return conn.register_callback(cb) > 0 ? CONN::binder(cb) : nullptr;
	}

	/**
	 * Meta transaction 'getInterfaceVersion' (two-way, any interface)
	 */
	template <typename CONN>
	inline bool interface_version(CONN &conn, int32_t &version)
	{
		AParcel *in  = Android_binder::parcel_create();
		AParcel *out = Android_binder::parcel_create();
		bool ok = in && out;
		if (ok) {
			Android_binder::set_binder_codec(in, &conn.codec());
			binder_status_t st = STATUS_OK;
			ok = conn.transact(GET_INTERFACE_VERSION, *in, false, out, &st)
			     == CONN::Transact_result::OK && st == STATUS_OK;
		}
		if (ok) {
			AStatus *status = nullptr;
			ok = AParcel_readStatusHeader(out, &status) == STATUS_OK && status
			     && AStatus_isOk(status);
			if (status) AStatus_delete(status);
		}
		if (ok) ok = AParcel_readInt32(out, &version) == STATUS_OK;
		if (in)  AParcel_delete(in);
		if (out) AParcel_delete(out);
		return ok;
	}
}

#endif /* _INCLUDE__RADIO_AIDL__TYPES_H_ */
