/*
 * \brief  Parcel part of the libbinder_ndk API (AParcel_*, AStatus_*)
 * \author Ivan Loskutov
 * \date   2026-09-25
 *
 * Signatures follow frameworks/native/libs/binder/ndk/include_ndk. The
 * types are opaque to Android code, so the parcel format is ours: both ends
 * of every transaction use this library -- the Android runtime (vendor
 * code) and native Genode clients.
 */

/*
 * SPDX-License-Identifier: MIT
 */

#ifndef _INCLUDE__ANDROID_BINDER__PARCEL_H_
#define _INCLUDE__ANDROID_BINDER__PARCEL_H_

#include <stddef.h>
#include <stdint.h>

typedef int32_t  binder_status_t;
typedef int32_t  binder_exception_t;
typedef uint32_t transaction_code_t;
typedef uint32_t binder_flags_t;

enum : binder_status_t {
	STATUS_OK = 0, STATUS_UNKNOWN_ERROR = (-2147483647 - 1), STATUS_NO_MEMORY = -12,
	STATUS_INVALID_OPERATION = -38, STATUS_BAD_VALUE = -22, STATUS_BAD_TYPE = STATUS_UNKNOWN_ERROR + 1,
	STATUS_NAME_NOT_FOUND = -2, STATUS_PERMISSION_DENIED = -1, STATUS_NO_INIT = -19,
	STATUS_DEAD_OBJECT = -32, STATUS_FAILED_TRANSACTION = STATUS_UNKNOWN_ERROR + 2,
	STATUS_NOT_ENOUGH_DATA = -61, STATUS_UNKNOWN_TRANSACTION = -74,
	STATUS_UNEXPECTED_NULL = STATUS_UNKNOWN_ERROR + 8 };

enum : binder_exception_t {
	EX_NONE = 0, EX_SECURITY = -1, EX_BAD_PARCELABLE = -2, EX_ILLEGAL_ARGUMENT = -3,
	EX_NULL_POINTER = -4, EX_ILLEGAL_STATE = -5, EX_UNSUPPORTED_OPERATION = -7,
	EX_SERVICE_SPECIFIC = -8, EX_TRANSACTION_FAILED = -129 };

enum : binder_flags_t { FLAG_ONEWAY = 0x01 };

struct AParcel;
struct AStatus;
struct AIBinder;

extern "C" {

	/* AStatus */
	AStatus    *AStatus_newOk();
	AStatus    *AStatus_fromExceptionCode(binder_exception_t);
	AStatus    *AStatus_fromExceptionCodeWithMessage(binder_exception_t, char const *);
	AStatus    *AStatus_fromServiceSpecificError(int32_t);
	AStatus    *AStatus_fromServiceSpecificErrorWithMessage(int32_t, char const *);
	AStatus    *AStatus_fromStatus(binder_status_t);
	bool        AStatus_isOk(AStatus const *);
	binder_exception_t AStatus_getExceptionCode(AStatus const *);
	int32_t     AStatus_getServiceSpecificError(AStatus const *);
	binder_status_t AStatus_getStatus(AStatus const *);
	char const *AStatus_getMessage(AStatus const *);
	char const *AStatus_getDescription(AStatus const *);
	void        AStatus_deleteDescription(char const *);
	void        AStatus_delete(AStatus *);

	/* AParcel */
	typedef bool (*AParcel_stringAllocator)(void *, int32_t, char **);
	typedef bool (*AParcel_int32ArrayAllocator)(void *, int32_t, int32_t **);
	typedef bool (*AParcel_byteArrayAllocator)(void *, int32_t, int8_t **);
	typedef bool (*AParcel_stringArrayAllocator)(void *, int32_t);
	typedef bool (*AParcel_stringArrayElementAllocator)(void *, size_t, int32_t, char **);
	typedef char const *(*AParcel_stringArrayElementGetter)(void const *, size_t, int32_t *);
	typedef bool (*AParcel_parcelableArrayAllocator)(void *, int32_t);
	typedef binder_status_t (*AParcel_writeParcelableElement)(AParcel *, void const *, size_t);
	typedef binder_status_t (*AParcel_readParcelableElement)(AParcel const *, void *, size_t);

	void            AParcel_delete(AParcel *);
	int32_t         AParcel_getDataPosition(AParcel const *);
	binder_status_t AParcel_setDataPosition(AParcel const *, int32_t);

	binder_status_t AParcel_writeInt32(AParcel *, int32_t);
	binder_status_t AParcel_writeInt64(AParcel *, int64_t);
	binder_status_t AParcel_writeBool(AParcel *, bool);
	binder_status_t AParcel_writeByte(AParcel *, int8_t);
	binder_status_t AParcel_writeChar(AParcel *, char16_t);
	binder_status_t AParcel_readInt32(AParcel const *, int32_t *);
	binder_status_t AParcel_readInt64(AParcel const *, int64_t *);
	binder_status_t AParcel_readBool(AParcel const *, bool *);
	binder_status_t AParcel_readByte(AParcel const *, int8_t *);
	binder_status_t AParcel_readChar(AParcel const *, char16_t *);

	binder_status_t AParcel_writeString(AParcel *, char const *, int32_t);
	binder_status_t AParcel_readString(AParcel const *, void *, AParcel_stringAllocator);
	binder_status_t AParcel_writeInt32Array(AParcel *, int32_t const *, int32_t);
	binder_status_t AParcel_readInt32Array(AParcel const *, void *, AParcel_int32ArrayAllocator);
	binder_status_t AParcel_writeByteArray(AParcel *, int8_t const *, int32_t);
	binder_status_t AParcel_readByteArray(AParcel const *, void *, AParcel_byteArrayAllocator);
	binder_status_t AParcel_writeStringArray(AParcel *, void const *, int32_t, AParcel_stringArrayElementGetter);
	binder_status_t AParcel_readStringArray(AParcel const *, void *, AParcel_stringArrayAllocator,
	                                        AParcel_stringArrayElementAllocator);
	binder_status_t AParcel_writeParcelableArray(AParcel *, void const *, int32_t, AParcel_writeParcelableElement);
	binder_status_t AParcel_readParcelableArray(AParcel const *, void *, AParcel_parcelableArrayAllocator,
	                                            AParcel_readParcelableElement);
	binder_status_t AParcel_writeStatusHeader(AParcel *, AStatus const *);
	binder_status_t AParcel_readStatusHeader(AParcel const *, AStatus **);
	binder_status_t AParcel_writeStrongBinder(AParcel *, AIBinder *);
	binder_status_t AParcel_readStrongBinder(AParcel const *, AIBinder **);
}

namespace Android_binder {

	AParcel *parcel_create();

	/**
	 * Parcel holding a copy of 'size' bytes, read position 0
	 */
	AParcel *parcel_from(void const *data, size_t size);

	uint8_t const *parcel_data(AParcel const *);
	size_t         parcel_size(AParcel const *);

	/**
	 * Replace the content by a copy of 'size' bytes, read position 0
	 *
	 * The binder codec stays installed.
	 *
	 * \return false if out of memory (the parcel is then empty)
	 */
	bool parcel_set(AParcel *, void const *data, size_t size);

	/**
	 * Binder objects in parcels are encoded by the transport (android_rt's
	 * sym_binder.cc, Client_core)
	 */
	struct Binder_codec
	{
		virtual binder_status_t write(AParcel *, AIBinder *) = 0;
		virtual binder_status_t read(AParcel const *, AIBinder **) = 0;
		virtual ~Binder_codec() { }
	};

	void set_binder_codec(AParcel *, Binder_codec *);
	Binder_codec *binder_codec(AParcel const *);
}

#endif /* _INCLUDE__ANDROID_BINDER__PARCEL_H_ */
