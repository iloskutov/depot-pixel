/*
 * \brief  Client connection to one Android_binder service instance
 * \author Ivan Loskutov
 * \date   2026-09-27
 *
 * Native counterpart of what vendor code gets from
 * 'AServiceManager_waitForService': a session to one exported instance
 * (e.g. "android.hardware.radio.network.IRadioNetwork/slot1"), whose root
 * object is handle 0. Requests are parcels (android_binder/parcel.h)
 * serialised into the session's transaction area; oneway transactions from
 * the server to the client's callback objects arrive in the callback ring and
 * are dispatched by 'drain'. Used by android_rt (sym_binder.cc) and by native
 * components talking to vendor services.
 */

/*
 * SPDX-License-Identifier: MIT
 */

#ifndef _INCLUDE__ANDROID_BINDER__CLIENT_H_
#define _INCLUDE__ANDROID_BINDER__CLIENT_H_

#include <android_binder/client_core.h>
#include <android_binder_session/connection.h>

#include <base/attached_dataspace.h>
#include <base/env.h>
#include <base/mutex.h>
#include <util/noncopyable.h>
#include <util/reconstructible.h>
#include <util/string.h>

namespace Android_binder { class Client_conn; }


/**
 * One Android_binder session to one exported instance (root = handle 0)
 */
class Android_binder::Client_conn : Genode::Noncopyable
{
	public:

		/* a local object that receives oneway transactions from the server */
		using Callback = Android_binder::Callback;

		enum class Open_result     { OK, DENIED, FAILED };
		enum class Transact_result { OK, FAILED };

		using Instance = Genode::String<160>;

	private:

		using Session        = Android_binder_session::Session;
		using Try_connection = Android_binder_session::Try_connection;

		enum { TXN_SIZE = Session::TXN_SIZE, RING_SIZE = Session::RING_SIZE };

		struct Session_transport : Transport
		{
			Client_conn &conn;

			Session_transport(Client_conn &conn) : conn(conn) { }

			Result transact(uint32_t code, bool oneway, uint32_t len) override;
		};

		Genode::Env    &_env;
		Instance const  _instance;

		Genode::Constructible<Try_connection>              _conn { };
		Genode::Constructible<Genode::Attached_dataspace>  _ds   { };
		Genode::Constructible<Ring>                        _ring { };

		bool _connected = false;

		Client_core       _core { };
		Session_transport _transport { *this };

		Genode::Mutex _txn_mutex { };   /* one transaction at a time */
		Genode::Mutex _cb_mutex  { };   /* serialises register_callback */

		Genode::Signal_context_capability _sigh { };

		unsigned _skipped_logged = 0;

		void _disconnect(char const *reason);
		void _install_sigh();

	public:

		/**
		 * Constructor, does not connect yet
		 *
		 * \param instance  instance name = last element of the session label
		 */
		Client_conn(Genode::Env &, char const *instance);

		/**
		 * Request the session once (the server denies an instance its program
		 * has not exported yet: the caller retries on DENIED)
		 *
		 * After a failure ('connected()' false), 'open' closes the old
		 * session and requests a new one. Registered callbacks keep their ids
		 * (the caller re-sends them to the new session). Must not run
		 * concurrently with 'transact' or 'drain'.
		 */
		Open_result open();

		bool connected() const { return _connected; }

		Instance const &instance() const { return _instance; }

		/**
		 * Serialise 'in' into the txn area and transact on handle 0
		 *
		 * \param reply   two-way only (may be nullptr): replaced by the reply
		 * \param status  optional: the server's binder status on OK,
		 *                STATUS_FAILED_TRANSACTION / STATUS_DEAD_OBJECT /
		 *                STATUS_NO_MEMORY on FAILED
		 *
		 * FAILED if not connected, the request exceeds the transaction area
		 * (connection kept), no memory for the reply (connection kept), or
		 * the transport failed ('connected()' becomes false).
		 */
		Transact_result transact(uint32_t code, AParcel const &in, bool oneway,
		                         AParcel *reply = nullptr,
		                         binder_status_t *status = nullptr);

		/**
		 * Register a local object, its id is what the codec writes as {1, id}
		 *
		 * \return 1-based id, -1 if the table is full (Client_core::MAX_CB)
		 */
		int register_callback(Callback &);

		/**
		 * Token of a registered callback for 'AParcel_writeStrongBinder'
		 */
		static AIBinder *binder(Callback &cb) { return Client_core::binder(cb); }

		/**
		 * Codec to install on outgoing parcels so writeStrongBinder encodes
		 * callbacks
		 */
		Binder_codec &codec() { return _core.codec(); }

		/**
		 * Pop ring entries and dispatch them to the registered callbacks
		 *
		 * Single consumer: call from one thread at a time. One call consumes
		 * at most Client_core::MAX_DRAIN entries; if it stops there, it
		 * submits the 'callback_sigh' signal itself, so the handler drains
		 * the rest.
		 *
		 * \return number of entries consumed (0 if not connected)
		 */
		unsigned drain();

		/**
		 * Signal to trigger 'drain' (the server submits it on every push)
		 *
		 * May be called before 'open'; installed on every (re)connect.
		 */
		void callback_sigh(Genode::Signal_context_capability);
};

#endif /* _INCLUDE__ANDROID_BINDER__CLIENT_H_ */
