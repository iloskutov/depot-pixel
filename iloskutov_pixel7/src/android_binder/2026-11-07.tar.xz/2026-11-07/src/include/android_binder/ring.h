/*
 * \brief  Callback ring: oneway transactions from a server to its client
 * \author Ivan Loskutov
 * \date   2026-09-25
 *
 * Lives in the session's shared dataspace. One producer (the server's
 * binder threads, serialised by the caller) and one consumer (the client's
 * binder thread). Positions grow modulo twice the capacity, so 'head - tail'
 * is the used size for any capacity; an entry never straddles the end: a
 * WRAP marker sends the reader back to offset 0. A full ring rejects the
 * new entry -- the writer cannot move the reader's position safely.
 *
 * The peer writes the other half of the header and the records, so the
 * consumer validates every record before using it and resynchronises on a
 * corrupt one; the producer only ever writes inside the buffer.
 */

/*
 * SPDX-License-Identifier: MIT
 */

#ifndef _ANDROID_BINDER__RING_H_
#define _ANDROID_BINDER__RING_H_

#include <stddef.h>
#include <stdint.h>
#include <string.h>

namespace Android_binder { class Ring; }


class Android_binder::Ring
{
	public:

		struct Entry
		{
			uint32_t object, code, len;
			uint8_t const *data;
			uint32_t next;               /* reader position after this entry */
		};

	private:

		struct Header
		{
			uint32_t head;     /* written by the producer */
			uint32_t tail;     /* written by the consumer */
			uint32_t dropped;  /* written by the producer */
			uint32_t corrupt;  /* written by the consumer */
		};

		struct Record { uint32_t size, object, code, len; };   /* size 0 = WRAP */

		enum { ALIGN = 8 };

		Header  &_hdr;
		uint8_t *_buf;
		uint32_t _cap;

		static uint32_t _aligned(uint32_t n) { return (n + ALIGN - 1) & ~uint32_t(ALIGN - 1); }

		uint32_t _load(uint32_t const &v) const { return __atomic_load_n(&v, __ATOMIC_ACQUIRE); }
		void     _store(uint32_t &v, uint32_t x) { __atomic_store_n(&v, x, __ATOMIC_RELEASE); }

		/* positions live in [0, 2*_cap) */
		uint32_t _advance(uint32_t pos, uint32_t n) const { return (pos + n) % (2*_cap); }
		uint32_t _used(uint32_t head, uint32_t tail) const { return (head + 2*_cap - tail) % (2*_cap); }

		/* the peer's half of the header is untrusted: a position out of range
		 * is read as the other side's, i.e. an empty ring */
		uint32_t _peer_pos(uint32_t v, uint32_t mine) const { return v < 2*_cap ? v : mine; }

	public:

		Ring(void *mem, size_t size)
		:
			_hdr(*(Header *)mem), _buf((uint8_t *)mem + sizeof(Header)),
			_cap(uint32_t(size - sizeof(Header)) & ~uint32_t(ALIGN - 1))
		{ }

		/**
		 * Server side, once per session
		 */
		void init() { memset(&_hdr, 0, sizeof(_hdr)); }

		/**
		 * Entries the producer could not append (consumer too slow)
		 */
		uint32_t dropped() const { return _load(_hdr.dropped); }

		/**
		 * Records the consumer found malformed (ring resynchronised each time)
		 */
		uint32_t corrupt() const { return _load(_hdr.corrupt); }

		/**
		 * Append an entry
		 *
		 * \return false if it does not fit (counted in 'dropped')
		 */
		bool push(uint32_t object, uint32_t code, void const *data, uint32_t len)
		{
			uint32_t const need = _aligned(uint32_t(sizeof(Record)) + len);
			uint32_t head = _load(_hdr.head);
			uint32_t const tail = _peer_pos(_load(_hdr.tail), head);
			uint32_t const used = _used(head, tail);

			uint32_t const off  = head % _cap;
			uint32_t const room_to_end = _cap - off;
			uint32_t const extra = (room_to_end < need) ? room_to_end : 0;   /* WRAP */

			if (len > _cap || need > _cap || used + extra + need > _cap) {
				_store(_hdr.dropped, _load(_hdr.dropped) + 1);
				return false;
			}
			if (extra) {
				if (room_to_end >= sizeof(uint32_t)) *(uint32_t *)(_buf + off) = 0;
				head = _advance(head, extra);
			}
			Record *r = (Record *)(_buf + head % _cap);
			r->size = need; r->object = object; r->code = code; r->len = len;
			if (len) memcpy(r + 1, data, len);
			_store(_hdr.head, _advance(head, need));
			return true;
		}

		/**
		 * Look at the oldest entry (valid until 'release')
		 *
		 * A record that does not fit the ring or the used part is the peer's
		 * fault: the consumer skips everything up to 'head' and counts it.
		 */
		bool pop(Entry &e)
		{
			uint32_t tail = _load(_hdr.tail);
			uint32_t const head = _peer_pos(_load(_hdr.head), tail);
			if (tail == head) return false;

			auto resync = [&] {
				_store(_hdr.corrupt, _load(_hdr.corrupt) + 1);
				_store(_hdr.tail, head);
				return false;
			};

			uint32_t used = _used(head, tail);
			uint32_t off  = tail % _cap;
			/* a record's size is read once: the peer may change it any time */
			auto size_at = [&] (uint32_t at) { return _load(*(uint32_t const *)(_buf + at)); };

			uint32_t size = (_cap - off < sizeof(Record)) ? 0 : size_at(off);
			if (size == 0) {
				uint32_t const skip = _cap - off;            /* follow the WRAP */
				if (skip > used) return resync();
				tail = _advance(tail, skip); used -= skip; off = 0;
				if (tail == head) { _store(_hdr.tail, tail); return false; }
				size = size_at(0);
			}
			Record const *r = (Record const *)(_buf + off);
			uint32_t const len = _load(r->len);
			if (size < sizeof(Record) || size > used || size > _cap - off
			 || len > size - sizeof(Record) || size != _aligned(uint32_t(sizeof(Record)) + len))
				return resync();
			e = { r->object, r->code, len, (uint8_t const *)(r + 1), _advance(tail, size) };
			return true;
		}

		void release(Entry const &e) { _store(_hdr.tail, e.next); }
};

#endif /* _ANDROID_BINDER__RING_H_ */
