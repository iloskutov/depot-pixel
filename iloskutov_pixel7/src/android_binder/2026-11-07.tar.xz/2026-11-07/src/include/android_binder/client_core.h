/*
 * \brief  Transport-independent core of an Android_binder client connection
 * \author Ivan Loskutov
 * \date   2026-09-27
 *
 * Keeps the table of client-local callback objects, encodes them in
 * outgoing parcels ({int32 1, int32 id}, ids 1-based per connection),
 * marshals a transaction through the transaction area of a 'Transport' and
 * dispatches the entries of a callback ring. Uses no session (of Genode
 * only the log); the session part is 'Client_conn' (client.h).
 */

/*
 * SPDX-License-Identifier: MIT
 */

#ifndef _INCLUDE__ANDROID_BINDER__CLIENT_CORE_H_
#define _INCLUDE__ANDROID_BINDER__CLIENT_CORE_H_

#include <android_binder/parcel.h>
#include <android_binder/ring.h>
#include <util/interface.h>

namespace Android_binder {

	struct Callback;
	struct Transport;
	class  Client_core;
}


/**
 * Client-local object that receives oneway transactions from the server
 */
struct Android_binder::Callback : Genode::Interface
{
	/**
	 * \param in  the transaction's parcel, read position 0 (valid for the
	 *            duration of the call only)
	 */
	virtual void on_transact(uint32_t code, AParcel const &in) = 0;
};


/**
 * Transaction path of a connection (the session's 'transact' RPC)
 */
struct Android_binder::Transport : Genode::Interface
{
	struct Result
	{
		bool            ok;          /* false: the transport failed */
		binder_status_t status;      /* status returned by the server */
		uint32_t        reply_len;   /* two-way: reply bytes in the txn area */
	};

	/**
	 * Run the request of 'len' bytes placed at the start of the transaction
	 * area on the root object (handle 0); a two-way reply is written back to
	 * the start of the area
	 */
	virtual Result transact(uint32_t code, bool oneway, uint32_t len) = 0;
};


class Android_binder::Client_core
{
	public:

		enum { MAX_CB = 64 };

		/* ring entries one 'drain' call dispatches at most */
		enum { MAX_DRAIN = 256 };

		enum class Transact_result { OK, TOO_LARGE, FAILED, NO_MEMORY };

	private:

		Client_core(Client_core const &) = delete;
		Client_core &operator = (Client_core const &) = delete;

		/* entries [0, _cb_n) are immutable once published (_cb_n: release) */
		Callback *_cb[MAX_CB] { };
		unsigned  _cb_n    = 0;
		unsigned  _skipped = 0;

		/* ring counters already reported by 'drain' */
		uint32_t  _dropped_seen = 0;
		uint32_t  _corrupt_seen = 0;

		struct Codec : Binder_codec
		{
			Client_core &core;

			Codec(Client_core &core) : core(core) { }

			binder_status_t write(AParcel *, AIBinder *) override;
			binder_status_t read(AParcel const *, AIBinder **) override;
		} _codec { *this };

		unsigned _count() const { return __atomic_load_n(&_cb_n, __ATOMIC_ACQUIRE); }

	public:

		Client_core() { }

		/**
		 * Register a callback object (idempotent)
		 *
		 * Not thread-safe against itself: concurrent registrations must be
		 * serialised by the caller. Lookups ('drain', the codec) may run
		 * concurrently.
		 *
		 * \return 1-based id, -1 if the table is full
		 */
		int register_callback(Callback &);

		/**
		 * Registered callback of 'id', or nullptr
		 */
		Callback *callback(unsigned id) const;

		/**
		 * Binder token of a callback, to pass to 'AParcel_writeStrongBinder'
		 * of a parcel that carries 'codec()'
		 *
		 * The token is never dereferenced as 'AIBinder'; the codec maps it back
		 * to the registered callback.
		 */
		static AIBinder *binder(Callback &cb) { return reinterpret_cast<AIBinder *>(&cb); }

		/**
		 * Codec for outgoing parcels
		 *
		 * write: nullptr -> {0, 0}, token of a registered callback -> {1, id},
		 *        anything else -> STATUS_BAD_VALUE (nothing written)
		 * read:  server->client binder objects are unsupported: consumed and
		 *        returned as nullptr
		 */
		Binder_codec &codec() { return _codec; }

		/**
		 * Serialise 'in' into 'txn' and run it through 'transport'
		 *
		 * \param reply   two-way only (may be nullptr): receives the reply
		 * \param status  receives the server's status (OK), STATUS_FAILED_
		 *                TRANSACTION (TOO_LARGE), STATUS_DEAD_OBJECT (FAILED)
		 *                or STATUS_NO_MEMORY
		 */
		Transact_result transact(Transport &transport, uint8_t *txn, size_t txn_size,
		                         uint32_t code, AParcel const &in, bool oneway,
		                         AParcel *reply, binder_status_t &status);

		/**
		 * Pop ring entries and dispatch them to the registered callbacks
		 *
		 * Single consumer: call from one thread at a time. Entries for an
		 * unknown object id (or that cannot be copied into a parcel for lack
		 * of memory) are skipped and counted in 'skipped()'. At most
		 * MAX_DRAIN entries are consumed per call, so a server that keeps
		 * filling the ring cannot hold the caller: a result of MAX_DRAIN
		 * means that more entries may be pending.
		 *
		 * \return number of entries consumed
		 */
		unsigned drain(Ring &);

		/**
		 * Number of ring entries skipped so far
		 */
		unsigned skipped() const { return __atomic_load_n(&_skipped, __ATOMIC_RELAXED); }
};

#endif /* _INCLUDE__ANDROID_BINDER__CLIENT_CORE_H_ */
